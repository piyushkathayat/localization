import { createBrowserHistory } from 'history';
import { APP_PREFIX } from 'constants/common';

// Redux utility functions
import { compose, createStore, combineReducers, applyMiddleware } from 'redux';
import { routerMiddleware, connectRouter } from 'connected-react-router';
import { Socket } from '@ubs.partner/shared-ui';
import createSagaMiddleware from 'redux-saga';

import {
  handleValidationProgress,
  handleLoadAndQaJobsProgress
} from 'utils/socketHandlers';
import * as reducers from './reducers';
import sagas from './sagas/index';

export const history = createBrowserHistory();
const reducer = combineReducers({ ...reducers });
const sagaMiddleware = createSagaMiddleware();

const store = createStore(
  connectRouter(history)(reducer),
  compose(
    applyMiddleware(routerMiddleware(history), sagaMiddleware),
    window.__REDUX_DEVTOOLS_EXTENSION__ ? window.__REDUX_DEVTOOLS_EXTENSION__() : f => f
  )
);

sagaMiddleware.run(sagas);

const socket = new Socket();
socket.addTopic(`/topic/${APP_PREFIX}/validation`, message => handleValidationProgress(message, store.dispatch));
socket.addTopic(`/topic/${APP_PREFIX}/loadAndQa`, message => handleLoadAndQaJobsProgress(message, store.dispatch));

export default store;
