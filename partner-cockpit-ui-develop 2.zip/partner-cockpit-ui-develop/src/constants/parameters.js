export const RESPONSE_STATUSES = {
  SUCCESS: 'SUCCESS'
};

export const PARAMETERS_STATUSES = {
  CHECKED_IN: 'CHECKED_IN',
  CHECKED_OUT: 'CHECKED_OUT'
};

export const PARAMETERS_TYPES = {
  SAA: 'saa',
  REFERENCE_PORTFOLIOS: 'reference',
  INSTRUMENT_UNIVERSE: 'universe',
  LOOKUP_TABLES: 'lk',
  MAPPING_TABLES: 'mapping',
  BROKERAGE: 'brokerage',
  STAR_WS: 'star_ws'
};

export const PARAMETERS = {
  [PARAMETERS_TYPES.SAA]: {
    title: {
      id: 'parameters.saa',
      defaultMessage: 'SAA'
    },
    sortOrder: 50
  },
  [PARAMETERS_TYPES.REFERENCE_PORTFOLIOS]: {
    title: {
      id: 'parameters.reference_portfolios',
      defaultMessage: 'Reference Portfolios'
    },
    sortOrder: 40
  },
  [PARAMETERS_TYPES.INSTRUMENT_UNIVERSE]: {
    title: {
      id: 'parameters.instrument_universe',
      defaultMessage: 'Instrument Universe'
    },
    sortOrder: 10
  },
  [PARAMETERS_TYPES.LOOKUP_TABLES]: {
    title: {
      id: 'parameters.lookup_tables',
      defaultMessage: 'Lookup Tables'
    },
    sortOrder: 20
  },
  [PARAMETERS_TYPES.MAPPING_TABLES]: {
    title: {
      id: 'parameters.mapping_tables',
      defaultMessage: 'Mapping Tables'
    },
    sortOrder: 30
  },
  [PARAMETERS_TYPES.BROKERAGE]: {
    title: {
      id: 'parameters.brokerage',
      defaultMessage: 'Brokerage'
    },
    sortOrder: 60
  },
  [PARAMETERS_TYPES.STAR_WS]: {
    title: {
      id: 'parameters.star_ws',
      defaultMessage: 'STAR'
    },
    sortOrder: 70
  }
};

export const PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE = 60;
