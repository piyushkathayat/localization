export const SERVER_TYPES = {
  CENTRAL: 'CENTRAL',
  STAGING: 'STAGING',
  SHADOW: 'SHADOW',
  LIVE: 'LIVE'
};

export const SERVER = {
  [SERVER_TYPES.CENTRAL]: {
    name: 'Central'
  },
  [SERVER_TYPES.STAGING]: {
    name: 'Staging'
  },
  [SERVER_TYPES.SHADOW]: {
    name: 'Shadow'
  },
  [SERVER_TYPES.LIVE]: {
    name: 'Live'
  }
};

export const DB_TYPES = {
  CENTRAL: 'CENTRAL',
  PARTNER: 'PARTNER'
};

export const FEATURES = {
  BROKERAGE: 'brokerage'
};
