const LOCALE = {
  SWITCH: 'LOCALE.SWITCH'
};

export default LOCALE;
