export const CONTEXT_TYPES = {
  SOLVE_ALL: 'SOLVE-ALL',
  SOLVE_RECENT: 'SOLVE-RECENT',
  SOLVE_SELECTED: 'SOLVE-SELECTED',
  SOLVE_SINGLE: 'SOLVE-SINGLE'
};

export const CONTEXT = {
  [CONTEXT_TYPES.SOLVE_ALL]: {
    title: {
      id: 'logger.context.solve_all',
      defaultMessage: 'Solve All (batch)'
    },
    isIssueIdsRequired: false
  },
  [CONTEXT_TYPES.SOLVE_RECENT]: {
    title: {
      id: 'logger.context.solve_recent',
      defaultMessage: 'Solve Recent (batch)'
    },
    isIssueIdsRequired: false
  },
  [CONTEXT_TYPES.SOLVE_SELECTED]: {
    title: {
      id: 'logger.context.solve_selected',
      defaultMessage: 'Solve Selected (online)'
    },
    isIssueIdsRequired: true
  },
  [CONTEXT_TYPES.SOLVE_SINGLE]: {
    title: {
      id: 'logger.context.solve_single',
      defaultMessage: 'Solve Single (batch)'
    },
    isIssueIdsRequired: true
  }
};
