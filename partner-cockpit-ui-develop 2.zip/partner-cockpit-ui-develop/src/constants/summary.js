export const SUMMARY_TYPES = {
  DELTA_ISSUE_COUNT_PORTFOLIO_LVL: 'DELTA_ISSUE_COUNT_PORTFOLIO_LVL',
  TOTAL_ISSUE_COUNT_PORTFOLIO_LVL: 'TOTAL_ISSUE_COUNT_PORTFOLIO_LVL',
  NEW_BREACHES: 'DELTA_ISSUE_COUNT',
  ALL_BREACHES: 'TOTAL_ISSUE_COUNT',
  PORTFOLIOS: 'CORTEX_CLIENT_BOOK',
  GROSS_ASSETS: 'TOTAL_ASSET_VALUE_GROSS',
  ST_FILE_INSTRUMENTS: 'ST_COUNT_INSTRUMENT',
  ST_FILE_INSTRUMENTS_ISIN_MISSING: 'ST_MISSING_ISIN',
  ST_FILE_POSITIONS: 'ST_POSITION_COUNT',
  ST_FILE_INSTRUMENTS_NAME_MISSING: 'CORTEX_INSTRUMENT_NAMES',
  CORTEX_INSTRUMENTS: 'CORTEX_INSTRUMENT',
  CORTEX_INSTRUMENT_ENRICHED: 'CORTEX_INSTRUMENT_ENRICHED',
  CORTEX_INSTRUMENT_NOT_ENRICHED: 'CORTEX_INSTRUMENT_ENRICH_FAILED',
  CORTEX_INSTRUMENTS_UNBUNDLED: 'CORTEX_UNBUNDLED_INSTRUMENTS',
  CORTEX_PORTFOLIOS_RISK_NOT_COVERED: 'CORTEX_PORTFOLIOS_RISK_NOT_COVERED'
};

export const SUMMARY_INFO_GROUPS = {
  QUALITY_CHECK: 'QualityCheck',
  PORTFOLIO: 'Portfolio',
  ASSET: 'Asset',
  INSTRUMENT: 'Instrument',
  POSITION: 'Position'
};

export const SUMMARY_INFO = {
  [SUMMARY_TYPES.DELTA_ISSUE_COUNT_PORTFOLIO_LVL]: {
    title: {
      id: 'summary.new_breaching_portfolios',
      defaultMessage: 'New breaching portfolios'
    },
    sortOrder: 5
  },
  [SUMMARY_TYPES.TOTAL_ISSUE_COUNT_PORTFOLIO_LVL]: {
    title: {
      id: 'summary.all_breaching_portfolios',
      defaultMessage: 'All breaching portfolios'
    },
    sortOrder: 6
  },
  [SUMMARY_TYPES.NEW_BREACHES]: {
    title: {
      id: 'summary.new_breaches',
      defaultMessage: 'New breaches'
    },
    sortOrder: 10
  },
  [SUMMARY_TYPES.ALL_BREACHES]: {
    title: {
      id: 'summary.all_breaches',
      defaultMessage: 'All breaches'
    },
    sortOrder: 20
  },
  [SUMMARY_TYPES.PORTFOLIOS]: {
    title: {
      id: 'summary.portfolios',
      defaultMessage: 'Portfolios'
    },
    sortOrder: 30
  },
  [SUMMARY_TYPES.GROSS_ASSETS]: {
    title: {
      id: 'summary.gross_assets',
      defaultMessage: 'Gross assets'
    },
    sortOrder: 40
  },
  [SUMMARY_TYPES.ST_FILE_INSTRUMENTS]: {
    title: {
      id: 'summary.st_file_instruments',
      defaultMessage: 'ST file - Instruments'
    },
    sortOrder: 50
  },
  [SUMMARY_TYPES.ST_FILE_INSTRUMENTS_ISIN_MISSING]: {
    title: {
      id: 'summary.st_file_instruments_isin_missing',
      defaultMessage: 'ST file - Instruments - ISIN missing'
    },
    sortOrder: 60
  },
  [SUMMARY_TYPES.ST_FILE_POSITIONS]: {
    title: {
      id: 'summary.st_file_positions',
      defaultMessage: 'ST file - Positions'
    },
    sortOrder: 70
  },
  [SUMMARY_TYPES.ST_FILE_INSTRUMENTS_NAME_MISSING]: {
    title: {
      id: 'summary.st_file_instruments_name_missing',
      defaultMessage: 'ST file - Instruments - name missing'
    },
    sortOrder: 999
  },
  [SUMMARY_TYPES.CORTEX_INSTRUMENTS]: {
    title: {
      id: 'summary.cortex_instruments',
      defaultMessage: 'Cortex - Instruments'
    },
    sortOrder: 80
  },
  [SUMMARY_TYPES.CORTEX_INSTRUMENT_ENRICHED]: {
    title: {
      id: 'summary.cortex_instruments_enriched',
      defaultMessage: 'Cortex - Instruments - enriched'
    },
    sortOrder: 90
  },
  [SUMMARY_TYPES.CORTEX_INSTRUMENT_NOT_ENRICHED]: {
    title: {
      id: 'summary.cortex_instruments_not_enriched',
      defaultMessage: 'Cortex - Instruments - not enriched'
    },
    sortOrder: 100
  },
  [SUMMARY_TYPES.CORTEX_INSTRUMENTS_UNBUNDLED]: {
    title: {
      id: 'summary.cortex_instruments_unbundled',
      defaultMessage: 'Cortex - Instruments - unbundled'
    },
    sortOrder: 110
  },
  [SUMMARY_TYPES.CORTEX_PORTFOLIOS_RISK_NOT_COVERED]: {
    title: {
      id: 'summary.cortex_portfolios_risk_not_covered',
      defaultMessage: 'Portfolios without risk'
    },
    sortOrder: 120
  }
};
