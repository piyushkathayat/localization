export const INFINITY = 'Infinity';

export const APP_PREFIX = 'cockpit';

export const SORT_DIRECTIONS = {
  ASC: 'ASC',
  DESC: 'DESC'
};

export const MODAL_TYPES = {
  CONFIRMATION: 'CONFIRMATION',
  VALIDATION_DECISION: 'VALIDATION_DECISION',
  VALIDATION_RELEASE: 'VALIDATION_RELEASE',
  DEMOTE_DATABASE: 'DEMOTE_DATABASE',
  PROMOTE_DATABASE: 'PROMOTE_DATABASE',
  EDIT_COMMENT: 'EDIT_COMMENT'
};

export const SOCKET_STATUS = {
  IN_PROGRESS: 'IN_PROGRESS',
  FINISHED: 'FINISHED',
  FAILED: 'FAILED'
};

export const FORMATS = {
  CURRENCY: 'CURRENCY',
  NUMBER: 'NUMBER',
  PERCENTAGE: 'PERCENTAGE'
};

export const LOCALES = [
  { text: 'Deutsch', value: 'de' },
  { text: 'English', value: 'en' },
  { text: 'Italiano', value: 'it' }
];
