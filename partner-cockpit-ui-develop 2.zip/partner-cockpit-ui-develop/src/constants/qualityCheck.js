export const QC_TYPE_IDS = {
  SAA_CHECK: 1,
  BULK_RISK: 2,
  OUTSIDE_UNIVERSE: 4,
  STOCK_RATING: 8,
  FUND_RATING: 16,
  DOWNGRADE: 32,
  MATURITY_DATE: 64,
  ITALIAN_GOV_RISK: 128,
  ISSUER_RISK: 256,
  DIVERSIFICATION: 512,
  LIMITS: 1024,
  PORTFOLIO_RISK: 2048,
  PRODUCT_RISK_ISR: 4096,
  SP_RATING_SELL: 8192,
  FUND_RATING_SELL: 16384,
  STOCK_RATING_SELL: 32768,
  BOND_RATING_SELL: 65536,
  GOAL: 131072,
  FUND_BULK_RISK: 262144,
  BOND_RATING: 524288,
  RISK_BEARING: 1048576,
  TAA_CHECK: 8388608
};

export const QUALITY_CHECKS_LEVELS = {
  INSTRUMENT: 1,
  PORTFOLIO: 2,
  ISSUER: 3,
  ASSET_CLASS: 4
};

export const ALTERNATIVE_LEVEL_LABEL = {
  [QUALITY_CHECKS_LEVELS.INSTRUMENT]: {
    id: 'qualityCheck.breaching_positions',
    defaultMessage: 'Breaching positions'
  },
  [QUALITY_CHECKS_LEVELS.ISSUER]: {
    id: 'qualityCheck.breaching_issuers',
    defaultMessage: 'Breaching issuers'
  },
  [QUALITY_CHECKS_LEVELS.ASSET_CLASS]: {
    id: 'qualityCheck.breaching_asset_classes',
    defaultMessage: 'Breaching asset classes'
  },
  UNKNOWN: {
    id: 'qualityCheck.breaching_unknown',
    defaultMessage: 'Breaching alternative'
  }
};

export const UNKNOWN_QUALITY_CHECK = {
  title: {
    id: 'qualityCheck.unknown_check',
    defaultMessage: 'Unknown Check'
  },
  hasAlternativeLevel: false,
  hasFailIssues: true
};

export const QUALITY_CHECKS = {
  [QC_TYPE_IDS.SAA_CHECK]: {
    title: {
      id: 'qualityCheck.saa_check',
      defaultMessage: 'Strategic Asset Allocation'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.ASSET_CLASS_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: true,
    validationBreachingLabel: {
      id: 'validation.details.breaching_asset_classes',
      defaultMessage: 'Number of Breaching Asset Classes'
    }
  },
  [QC_TYPE_IDS.BULK_RISK]: {
    title: {
      id: 'qualityCheck.bulk_risk',
      defaultMessage: 'Bulk Risk'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false,
    validationBreachingLabel: {
      id: 'validation.details.breaching_positions',
      defaultMessage: 'Number of Breaching Positions'
    }
  },
  [QC_TYPE_IDS.OUTSIDE_UNIVERSE]: {
    title: {
      id: 'qualityCheck.outside_universe',
      defaultMessage: 'Outside Universe'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.STOCK_RATING]: {
    title: {
      id: 'qualityCheck.stock_rating',
      defaultMessage: 'Stock Rating'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.FUND_RATING]: {
    title: {
      id: 'qualityCheck.fund_rating',
      defaultMessage: 'Fund Rating'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.DOWNGRADE]: {
    title: {
      id: 'qualityCheck.downgrade',
      defaultMessage: 'Downgrade'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.MATURITY_DATE]: {
    title: {
      id: 'qualityCheck.maturity_date',
      defaultMessage: 'Maturity Date'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.ITALIAN_GOV_RISK]: {
    title: {
      id: 'qualityCheck.gov_risk',
      defaultMessage: 'Gov. Issuer Risk'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false,
    validationBreachingLabel: {
      id: 'validation.details.breaching_issuers',
      defaultMessage: 'Number of Breaching Issuers'
    }
  },
  [QC_TYPE_IDS.ISSUER_RISK]: {
    title: {
      id: 'qualityCheck.issuer_risk',
      defaultMessage: 'Issuer Risk'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.ISSUERS_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false,
    validationBreachingLabel: {
      id: 'validation.details.breaching_issuers',
      defaultMessage: 'Number of Breaching Issuers'
    }
  },
  [QC_TYPE_IDS.DIVERSIFICATION]: {
    title: {
      id: 'qualityCheck.diversification',
      defaultMessage: 'Diversification'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false,
    validationBreachingLabel: {
      id: 'validation.details.breaching_levels',
      defaultMessage: 'Number of Breaching Levels'
    }
  },
  [QC_TYPE_IDS.LIMITS]: {
    title: {
      id: 'qualityCheck.limits',
      defaultMessage: 'Limits'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.PORTFOLIO_RISK]: {
    title: {
      id: 'qualityCheck.portfolio_risk',
      defaultMessage: 'Portfolio Risk'
    },
    hasAlternativeLevel: false,
    hasFailIssues: true,
    validationBreachingLabel: {
      id: 'validation.details.breaching_bands',
      defaultMessage: 'Number of Breaching Bands'
    }
  },
  [QC_TYPE_IDS.PRODUCT_RISK_ISR]: {
    title: {
      id: 'qualityCheck.portfolio_risk_isr',
      defaultMessage: 'Portfolio Risk ISR'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.SP_RATING_SELL]: {
    title: {
      id: 'qualityCheck.sp_rating_sell',
      defaultMessage: 'SP Rating WS'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.FUND_RATING_SELL]: {
    title: {
      id: 'qualityCheck.fund_rating_sell',
      defaultMessage: 'Fund Rating WS'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.STOCK_RATING_SELL]: {
    title: {
      id: 'qualityCheck.stock_rating_sell',
      defaultMessage: 'Stock Rating WS'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.BOND_RATING_SELL]: {
    title: {
      id: 'qualityCheck.bond_rating_sell',
      defaultMessage: 'Bond Rating WS'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.GOAL]: {
    title: {
      id: 'qualityCheck.goal',
      defaultMessage: 'Goal'
    },
    hasAlternativeLevel: false,
    hasFailIssues: true
  },
  [QC_TYPE_IDS.FUND_BULK_RISK]: {
    title: {
      id: 'qualityCheck.fund_bulk_risk',
      defaultMessage: 'Fund Bulk Risk'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false,
    validationBreachingLabel: {
      id: 'validation.details.breaching_positions',
      defaultMessage: 'Number of Breaching Positions'
    }
  },
  [QC_TYPE_IDS.BOND_RATING]: {
    title: {
      id: 'qualityCheck.bond_rating',
      defaultMessage: 'Bond Rating'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.POSITION_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: false
  },
  [QC_TYPE_IDS.RISK_BEARING]: {
    title: {
      id: 'qualityCheck.risk_bearing',
      defaultMessage: 'Risk Profile Check'
    },
    hasAlternativeLevel: false,
    hasFailIssues: false,
    validationBreachingLabel: {
      id: 'validation.details.breaching_bands',
      defaultMessage: 'Number of Breaching Bands'
    }
  },
  [QC_TYPE_IDS.TAA_CHECK]: {
    title: {
      id: 'qualityCheck.taa_check',
      defaultMessage: 'TAA Check'
    },
    alternativeLevelLabel: ALTERNATIVE_LEVEL_LABEL.ASSET_CLASS_LEVEL,
    hasAlternativeLevel: true,
    hasFailIssues: true,
    validationBreachingLabel: {
      id: 'validation.details.breaching_asset_classes',
      defaultMessage: 'Number of Breaching Asset Classes'
    }
  }
};
