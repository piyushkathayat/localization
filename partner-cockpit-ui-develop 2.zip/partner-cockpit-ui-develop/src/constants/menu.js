import { SERVER_TYPES } from 'constants/serverInfo';

export const MENU_ITEMS = {
  SUMMARY: 'summary',
  LOAD: 'load',
  QUALITY_CHECK: 'quality-check',
  VALIDATION: 'validation',
  PROMOTION: 'promotion',
  PARAMETERS: 'parameters',
  CORE_ENGINE: 'core-engine',
  LOGGER: 'logger'
};

export const VALIDATION_ITEMS = {
  QUALITY_CHECKS: 'checks',
  BROKERAGE: 'brokerage'
};

export const MAIN_MENU = [
  {
    id: MENU_ITEMS.SUMMARY,
    translation: {
      id: 'menu.summary',
      defaultMessage: 'Summary'
    }
  },
  {
    id: MENU_ITEMS.LOAD,
    translation: {
      id: 'menu.load',
      defaultMessage: 'Load and QA Result'
    }
  },
  {
    id: MENU_ITEMS.QUALITY_CHECK,
    translation: {
      id: 'menu.quality_check_results',
      defaultMessage: 'Quality Check Results'
    }
  },
  {
    id: MENU_ITEMS.VALIDATION,
    translation: {
      id: 'menu.validation',
      defaultMessage: 'Validation'
    }
  },
  {
    id: MENU_ITEMS.PROMOTION,
    translation: {
      id: 'menu.promotion',
      defaultMessage: 'Promotion'
    }
  },
  {
    id: MENU_ITEMS.PARAMETERS,
    translation: {
      id: 'menu.parameters',
      defaultMessage: 'Parameters'
    }
  },
  {
    id: MENU_ITEMS.CORE_ENGINE,
    translation: {
      id: 'menu.core_engine',
      defaultMessage: 'Core Engine'
    }
  },
  {
    id: MENU_ITEMS.LOGGER,
    translation: {
      id: 'menu.logger',
      defaultMessage: 'Logger'
    }
  }
];

export const VALIDATION_MENU = [
  {
    id: VALIDATION_ITEMS.QUALITY_CHECKS,
    translation: {
      id: 'validation.menu.quality_checks',
      defaultMessage: 'Portfolio Quality Checks'
    }
  },
  {
    id: VALIDATION_ITEMS.BROKERAGE,
    translation: {
      id: 'validation.menu.brokerage',
      defaultMessage: 'Brokerage'
    }
  }
];

export const MENU_CONFIGURATION = {
  [SERVER_TYPES.CENTRAL]: {
    disabledMenuItems: [
      MENU_ITEMS.SUMMARY,
      MENU_ITEMS.QUALITY_CHECK,
      MENU_ITEMS.VALIDATION,
      MENU_ITEMS.PROMOTION,
      MENU_ITEMS.PARAMETERS,
      MENU_ITEMS.CORE_ENGINE,
      MENU_ITEMS.LOGGER
    ],
    defaultPath: MENU_ITEMS.LOAD
  },
  [SERVER_TYPES.STAGING]: {
    disabledMenuItems: [
      MENU_ITEMS.VALIDATION,
      MENU_ITEMS.CORE_ENGINE
    ]
  },
  [SERVER_TYPES.SHADOW]: {
    disabledMenuItems: [
      MENU_ITEMS.CORE_ENGINE
    ]
  },
  [SERVER_TYPES.LIVE]: {
    disabledMenuItems: [
      MENU_ITEMS.CORE_ENGINE
    ]
  }
};
