export const VALIDATION_COMPONENTS = {
  QUALITY_CHECKS_OVERVIEW: 'QUALITY_CHECKS_OVERVIEW',
  QUALITY_CHECKS_DETAILS: 'QUALITY_CHECKS_DETAILS',
  BROKERAGE_OVERVIEW: 'BROKERAGE_OVERVIEW',
  BROKERAGE_DETAILS: 'BROKERAGE_DETAILS'
};

export const APPROVAL_STATUSES_IDS = {
  INVALIDATE: 12,
  POSTPONE: 13,
  ACCEPT: 20,
  REJECT: 30
};

export const APPROVAL_STATUSES = {
  [APPROVAL_STATUSES_IDS.INVALIDATE]: {
    title: {
      id: 'validation.invalidate',
      defaultMessage: 'Invalidate'
    },
    sortOrder: 20
  },
  [APPROVAL_STATUSES_IDS.POSTPONE]: {
    title: {
      id: 'validation.postpone',
      defaultMessage: 'Postpone'
    },
    sortOrder: 30
  },
  [APPROVAL_STATUSES_IDS.ACCEPT]: {
    title: {
      id: 'validation.accept',
      defaultMessage: 'Accept'
    },
    sortOrder: 10
  },
  [APPROVAL_STATUSES_IDS.REJECT]: {
    title: {
      id: 'validation.reject',
      defaultMessage: 'Reject'
    },
    sortOrder: 40
  }
};

export const SEARCHABLE_FIELDS = ['displayKey', 'displayDescription'];

export const SORTABLE_KEYS = ['displayKey', 'displayDescription', 'issueSince', 'affectedPortfolios'];

export const BROKERAGE_SEARCHABLE_FIELDS = ['buyInstrumentName', 'sellInstrumentName'];

export const BROKERAGE_SORTABLE_KEYS = ['buyInstrumentName', 'sellInstrumentName', 'affectedPortfolios'];

export const DECISION_LEVELS_IDS = {
  INSTRUMENT: 1,
  PORTFOLIO: 2,
  ISSUER: 3
};

export const DECISION_GROUPS_IDS = {
  FIRST: 1,
  SECOND: 2
};

export const DECISION_STATUSES = {
  GENERATED: 100,
  ONGOING: 110,
  CLOSED: 120,
  RECALCULATED: 170,
  FINALIZED: 200,
  ERROR: 255
};
