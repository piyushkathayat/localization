import {
  bool,
  shape,
  number,
  string,
  array,
  arrayOf,
  oneOfType,
  node,
  func
} from 'prop-types';

// common types

export const EmptyObjectType = shape({
});

export const IntlType = shape({
  formatMessage: func.isRequired
});

export const DropdownOptionsType = shape({
  key: oneOfType([string, number]).isRequired,
  text: oneOfType([string, node]).isRequired,
  value: oneOfType([string, number]).isRequired
});

export const LineGraphType = shape({
  date: string.isRequired,
  value: number.isRequired
});

export const SortingType = shape({
  sortBy: string,
  sortDirection: string.isRequired
});

export const AgGridTableColumnDefType = shape({
  headerName: string.isRequired,
  field: string.isRequired,
  tooltipField: string,
  headerTooltip: string,
  onCellClicked: func
});

// Server Info types

export const LayersVersionsType = shape({
  database: string.isRequired,
  cockpitService: string.isRequired,
  gatewayService: string.isRequired,
  ui: string.isRequired
});

// Summary page types

export const SummaryInfoType = shape({
  recNo: number.isRequired,
  format: string.isRequired,
  group: string.isRequired,
  marquee: number.isRequired,
  pctChange: oneOfType([number, string]).isRequired,
  type: string.isRequired,
  data: arrayOf(LineGraphType).isRequired
});

// Load And QA page types

export const IssueHistoryType = shape({
  activityDate: string.isRequired,
  sumIssues: number.isRequired
});

export const ActionType = shape({
  actionId: number.isRequired,
  activityKey: string.isRequired,
  statusCode: string.isRequired,
  percentage: number,
  actionDescription: string.isRequired,
  startTime: string,
  endTime: string,
  elapsedSec: number.isRequired,
  issues: number.isRequired,
  duration: number,
  averageDuration: number,
  averageDeviation: number,
  message: string,
  drillDownType: string,
  drillDownKey: string,
  issueHistory: arrayOf(IssueHistoryType).isRequired
});

export const ActivityType = shape({
  id: string.isRequired,
  activityId: oneOfType([number, string]).isRequired,
  activityKey: string.isRequired,
  activityOwner: string.isRequired,
  statusCode: string.isRequired,
  percentage: number.isRequired,
  activityName: string.isRequired,
  activityInstance: number.isRequired,
  startTime: string,
  endTime: string,
  elapsedSec: number.isRequired,
  duration: number,
  averageDuration: number.isRequired,
  averageDeviation: number.isRequired,
  message: string,
  issues: number.isRequired,
  feedAgeDate: string,
  outdatedFeedDate: string,
  isOutdatedCheckViolated: bool,
  isFeedAgeCheckViolated: bool,
  hasFeedAgeCheck: bool,
  hasOutdatedCheck: bool,
  scheduledFrequency: string,
  issueHistory: arrayOf(IssueHistoryType).isRequired
});

export const JobType = shape({
  key: string.isRequired,
  value: string.isRequired
});

export const ColumnDefsType = shape({
  header: node.isRequired,
  type: string.isRequired,
  field: string.isRequired,
  width: number.isRequired,
  textAlign: string,
  className: string
});

export const DrilldownBaseFields = {
  drilldownDetail: oneOfType([string, number]),
  drilldownKey: oneOfType([string, number]),
  drilldownType: string.isRequired,
  issueHistory: arrayOf(IssueHistoryType),
  hasDetail: number.isRequired
};

export const DrilldownFileType = shape({
  ...DrilldownBaseFields,
  duration: number.isRequired,
  fileName: string.isRequired,
  filePath: string.isRequired,
  fileSize: number.isRequired,
  invalidRecordCount: number.isRequired,
  processedSize: number.isRequired,
  recordCount: number.isRequired
});

export const DrilldownValidationType = shape({
  ...DrilldownBaseFields,
  databaseName: string.isRequired,
  invalidRows: number.isRequired,
  schemaName: string.isRequired,
  tableName: string.isRequired
});

export const DrilldownQAType = shape({
  ...DrilldownBaseFields,
  brsCode: string.isRequired,
  description: string.isRequired,
  numberOfIssues: number.isRequired
});

export const DrilldownType = oneOfType([
  DrilldownValidationType,
  DrilldownFileType,
  DrilldownQAType
]);

// Quality Checks page types

export const QualityCheckDataType = shape({
  date: string.isRequired,
  portfoliosNewIssues: number.isRequired,
  portfoliosFailIssues: number.isRequired,
  portfoliosTotalIssues: number.isRequired,
  maxPortfoliosTotalIssues: number.isRequired,
  alternativeLevelTotalIssues: number.isRequired,
  maxAlternativeLevelTotalIssues: number.isRequired
});

export const QualityCheckType = shape({
  data: arrayOf(QualityCheckDataType).isRequired,
  type: number.isRequired,
  description: string.isRequired,
  isFailureEnabled: bool.isRequired,
  qualityCheckLevel: number.isRequired
});

// Validation page types

export const ApprovalType = shape({
  approvalStatusId: number.isRequired,
  distinctIssues: number.isRequired,
  decisionRemaining: number.isRequired
});

export const DecisionQualityCheckType = shape({
  qualityCheckType: number.isRequired,
  totalIssues: number.isRequired,
  newIssues: number.isRequired,
  oldIssues: number.isRequired,
  sortOrder: number.isRequired,
  approvals: arrayOf(ApprovalType).isRequired,
  description: string.isRequired
});

export const DecisionCommonType = shape({
  decisionId: number.isRequired,
  date: string.isRequired,
  statusId: number.isRequired,
  isLatestLoad: bool.isRequired,
  isFreezed: bool
});

export const DecisionOverviewType = shape({
  decisionId: number.isRequired,
  isReleaseAllowed: bool.isRequired,
  qualityChecks: arrayOf(DecisionQualityCheckType).isRequired
});

export const DecisionItemPortfolioType = shape({
  assetId: number.isRequired,
  portfolioCode: string.isRequired,
  portfolioCcy: string.isRequired,
  investmentStrategyDesc: string.isRequired
});

export const DecisionItemType = shape({
  decisionKey: number.isRequired,
  approvalStatus: number.isRequired,
  affectedPortfolios: number.isRequired,
  displayDescription: string,
  displayKey: string.isRequired,
  commentLast: string,
  confirmedBy: string,
  portfoliosList: arrayOf(DecisionItemPortfolioType)
});

export const DecisionItemColumnDefType = shape({
  label: shape({
    id: string.isRequired,
    defaultMessage: string.isRequired
  }).isRequired,
  dataKey: string.isRequired,
  width: number.isRequired, // in percentage [0, 100]
  maxWidth: number.isRequired, // in percentage [0, 100]
  className: string
});

export const TriggerThemeType = shape({
  triggerThemeId: number.isRequired,
  triggerTheme: string.isRequired,
  triggerCount: number.isRequired,
  triggerLocked: number.isRequired
});

export const TriggerType = shape({
  triggerThemeId: number.isRequired,
  triggerId: number.isRequired,
  affectedPortfolios: number.isRequired,
  buyInstrumentId: number.isRequired,
  buyIsin: string.isRequired,
  buyInstrumentName: string.isRequired,
  sellInstrumentId: number.isRequired,
  sellIsin: string.isRequired,
  sellInstrumentName: string.isRequired,
  isLocked: bool.isRequired
});

// Promotion page types

export const PromotionDatabaseType = shape({
  id: number.isRequired,
  name: string.isRequired,
  internalName: string,
  internalKey: string,
  isMarkedForPromotion: bool,
  isPreselected: bool.isRequired,
  isAutoPromoted: bool.isRequired,
  source: string.isRequired,
  creationDate: string,
  isPromotedToLive: bool,
  isOldDatabase: bool,
  isUsedInLoadOnStaging: bool,
  comment: string,
  confirmedBy: string,
  commentAuthor: string,
  commentDate: string,
  info: string,
  isDirty: bool
});

export const DependencyType = shape({
  databaseId: number.isRequired,
  dependents: arrayOf(number).isRequired
});

// Parameters page types

export const TableType = shape({
  id: number.isRequired,
  tableData: array.isRequired,
  tableDisplayName: string.isRequired,
  tableName: string.isRequired
});

export const CheckoutStatusType = shape({
  feedName: string.isRequired,
  isUpdating: bool,
  checkedOutAt: string,
  checkedOutBy: string,
  checkedInAt: string,
  checkedInBy: string,
  lastCheckedOutAt: string,
  lastCheckedOutBy: string,
  lastCheckedInAt: string,
  lastCheckedInBy: string
});

export const ParameterTileType = shape({
  feedName: string.isRequired,
  status: string.isRequired,
  lastUpdatedAt: string,
  lastUpdatedBy: string
});

export const InstrumentUniverseType = shape({
  location: string,
  orgUnit: string,
  isin: string.isRequired,
  instrumentName: string.isRequired,
  tradingCurrency: string.isRequired,
  ranking: number,
  provider: string,
  lastUpdate: string,
  comment: string,
  buy: bool.isRequired
});
