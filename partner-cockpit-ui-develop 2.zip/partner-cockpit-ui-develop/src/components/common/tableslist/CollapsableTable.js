import React, { PureComponent } from 'react';
import * as R from 'ramda';
import { AgGridTable } from 'components/common';
import { TableType } from 'components/Types';
import './CollapsableTable.css';

export default class CollapsableTable extends PureComponent {
  state = {
    isOpen: false
  };

  rowsCount = R.length(this.props.table.tableData);

  handleTableBarClick = () => {
    if (this.rowsCount) {
      this.setState({ isOpen: !this.state.isOpen });
    }
  };

  renderTableBar = () => {
    const { table } = this.props;
    const iconTableBar = this.rowsCount ? 'icon-database' : 'icon-cancel';
    const iconCollapse = this.state.isOpen ? 'icon-fast-up' : 'icon-fast-down';
    return (
      <div
        className={`tableBar ${this.rowsCount ? 'collapseable' : ''}`}
        onClick={this.handleTableBarClick}
      >
        <div className="left">
          <i className={`icon-ubs ${iconTableBar} iconTableBar`} />
          <div className="tableName">
            {table.tableDisplayName}
          </div>
        </div>
        <div className="right">
          {!!this.rowsCount && <i className={`icon-ubs ${iconCollapse} iconCollapse`} />}
        </div>
      </div>
    );
  };

  renderTable = () => {
    const { table: { tableData } } = this.props;
    return (
      <AgGridTable
        tableData={tableData}
        className="collapsableTable"
      />
    );
  }

  render() {
    return (
      <div className="collapsableTableContainer">
        {this.renderTableBar()}
        {this.state.isOpen && this.renderTable()}
      </div>
    );
  }
}

CollapsableTable.propTypes = {
  table: TableType.isRequired
};

CollapsableTable.defaultProps = {
  table: {
    tableData: []
  }
};
