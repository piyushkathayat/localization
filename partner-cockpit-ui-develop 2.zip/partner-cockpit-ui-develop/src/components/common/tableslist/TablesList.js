import React from 'react';
import PropTypes from 'prop-types';
import { TableType } from 'components/Types';
import { NoResults } from 'components/common';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';
import CollapsableTable from './CollapsableTable';
import './TablesList.css';

export default function TablesList(props) {
  const { tablesList } = props;

  const renderTablesList = () => tablesList.map(
    table => <CollapsableTable key={table.id} table={table} />
  );

  return (
    <div className="tablesListContainer">
      {isNonEmptyArray(tablesList)
        ? renderTablesList()
        : <NoResults />
      }
    </div>
  );
}

TablesList.propTypes = {
  tablesList: PropTypes.arrayOf(TableType).isRequired
};

TablesList.defaultProps = {
  tablesList: []
};
