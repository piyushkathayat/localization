import React from 'react';
import PropTypes from 'prop-types';
import { Input } from 'semantic-ui-react';
import { voidFn } from 'utils/common';
import { injectIntl, defineMessages } from 'react-intl';
import { IntlType } from 'components/Types';
import './SearchInput.css';

const messages = defineMessages({
  placeholder: {
    id: 'common.search',
    defaultMessage: 'Search'
  }
});

export function SearchInput(props) {
  const { className, value, onChange, onClear, intl: { formatMessage } } = props;

  const icon = value.length
    ? {
      name: 'close',
      link: true,
      onClick: onClear
    }
    : 'search';

  const handleSearchInputChange = (event, { value: search }) => onChange(search);

  return (
    <div className={`searchInput ${className}`}>
      <Input
        icon={icon}
        placeholder={formatMessage(messages.placeholder)}
        onChange={handleSearchInputChange}
        value={value}
      />
    </div>
  );
}

SearchInput.propTypes = {
  className: PropTypes.string,
  value: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  onClear: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

SearchInput.defaultProps = {
  className: '',
  value: '',
  onChange: voidFn,
  onClear: voidFn
};

export default injectIntl(SearchInput);
