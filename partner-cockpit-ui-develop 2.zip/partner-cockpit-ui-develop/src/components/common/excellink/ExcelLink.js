import React from 'react';
import PropTypes from 'prop-types';
import { Loader } from 'semantic-ui-react';
import { voidFn } from 'utils/common';
import './ExcelLink.css';

export default function ExcelLink(props) {
  const { isLoading, onFileFetch } = props;

  return isLoading
    ? <Loader active inline="centered" size="tiny" />
    : (
      <div className="excelLink" onClick={onFileFetch}>
        <i className="icon-ubs icon-excel iconDetails" />
      </div>
    );
}

ExcelLink.propTypes = {
  isLoading: PropTypes.bool,
  onFileFetch: PropTypes.func.isRequired
};

ExcelLink.defaultProps = {
  isLoading: false,
  onFileFetch: voidFn
};
