import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { voidFn } from 'utils/common';
import { Confirm, Button } from 'semantic-ui-react';
import './ConfirmModal.css';

export default function ConfirmModal(props) {
  const {
    className,
    open,
    size,
    header,
    content,
    cancelButton,
    confirmButton,
    onCancel,
    onConfirm
  } = props;
  return (
    <Confirm
      className={`confirmModal ${className}`}
      open={open}
      size={size}
      header={(
        <div className="header">
          {header}
        </div>
      )}
      content={(
        <div className="content">
          {content}
        </div>
      )}
      cancelButton={cancelButton}
      confirmButton={confirmButton}
      onCancel={onCancel}
      onConfirm={onConfirm}
    />
  );
}

ConfirmModal.propTypes = {
  className: PropTypes.string,
  open: PropTypes.bool,
  size: PropTypes.string,
  header: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  content: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  onCancel: PropTypes.func.isRequired,
  onConfirm: PropTypes.func.isRequired
};

ConfirmModal.defaultProps = {
  className: '',
  open: true,
  size: 'tiny',
  header: <FormattedMessage defaultMessage="Confirmation" id="common.confirmation.header" />,
  content: <FormattedMessage defaultMessage="Are you sure?" id="common.confirmation.content" />,
  cancelButton: (
    <Button className="ubs-secondary-button">
      <FormattedMessage defaultMessage="Cancel" id="common.cancel" />
    </Button>
  ),
  confirmButton: (
    <Button className="ubs-primary-button">
      <FormattedMessage defaultMessage="OK" id="common.ok" />
    </Button>
  ),
  onCancel: voidFn,
  onConfirm: voidFn
};
