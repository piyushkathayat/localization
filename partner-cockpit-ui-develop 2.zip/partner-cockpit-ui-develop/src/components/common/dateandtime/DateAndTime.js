import React from 'react';
import { string, bool, number, oneOfType } from 'prop-types';
import { FormattedDate, FormattedRelative } from 'react-intl';

// default : July 11, 2018
// add hours and minute : numeric => July 10, 2018, 4:32 AM
export default function DateAndTime(props) {
  const { relative, value } = props;
  return relative
    ? (
      <FormattedRelative value={value} />
    )
    : (
      <FormattedDate
        value={props.value}
        day={props.day}
        month={props.month}
        year={props.year}
        hour={props.hour}
        minute={props.minute}
      />
    );
}

DateAndTime.propTypes = {
  relative: bool,
  value: oneOfType([string, number]).isRequired,
  day: string,
  month: string,
  year: string,
  hour: string,
  minute: string
};

DateAndTime.defaultProps = {
  relative: false,
  day: 'numeric',
  month: 'long',
  year: 'numeric',
  hour: undefined,
  minute: undefined
};
