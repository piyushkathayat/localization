import React from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { AgGridReact } from 'ag-grid-react';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';
import { NoResults } from 'components/common';
import { AgGridTableColumnDefType } from 'components/Types';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import './AgGridTable.css';

export const HEADER_HEIGHT = 32;
export const SCROLL_HEIGHT = 10;
export const BORDER_HEIGHT = 1;
export const ROW_HEIGHT = 28;

export default function AgGridTable(props) {
  const {
    className,
    columnDefs,
    tableData,
    maxHeight,
    enableFilter,
    hasFixedHeight,
    isSelectable
  } = props;

  if (!isNonEmptyArray(tableData)) {
    return <NoResults />;
  }

  const MAX_ROWS_WITHOUT_SCROLL =
    (maxHeight - HEADER_HEIGHT - SCROLL_HEIGHT - BORDER_HEIGHT) / ROW_HEIGHT;

  const getDefaultColumnDefs = () => Object.keys(tableData[0]).map(key => ({
    headerName: key,
    field: key,
    tooltipField: key,
    headerTooltip: key
  }));

  const defaultColDef = { minWidth: 90 };
  const hasVerticalScroll = tableData.length > MAX_ROWS_WITHOUT_SCROLL;

  const onGridReady = params => {
    params.api.sizeColumnsToFit();
  };

  const gridStyle = hasVerticalScroll || hasFixedHeight
    ? { height: `${maxHeight}px` }
    : {};

  return (
    <div
      className={`${className} agGridTable ag-theme-balham ${isSelectable ? 'selectable' : ''}`}
      style={gridStyle}
    >
      <AgGridReact
        columnDefs={R.isEmpty(columnDefs)
          ? getDefaultColumnDefs()
          : columnDefs
        }
        defaultColDef={defaultColDef}
        rowData={tableData}
        onGridReady={onGridReady}
        enableColResize
        enableSorting
        enableFilter={enableFilter}
        domLayout={hasVerticalScroll ? 'normal' : 'autoHeight'}
      />
    </div>
  );
}

AgGridTable.propTypes = {
  columnDefs: PropTypes.arrayOf(AgGridTableColumnDefType),
  tableData: PropTypes.array.isRequired,
  maxHeight: PropTypes.number.isRequired,
  enableFilter: PropTypes.bool.isRequired,
  className: PropTypes.string,
  hasFixedHeight: PropTypes.bool.isRequired,
  isSelectable: PropTypes.bool
};

AgGridTable.defaultProps = {
  columnDefs: [],
  tableData: [],
  maxHeight: 520,
  enableFilter: true,
  className: '',
  hasFixedHeight: false,
  isSelectable: true
};
