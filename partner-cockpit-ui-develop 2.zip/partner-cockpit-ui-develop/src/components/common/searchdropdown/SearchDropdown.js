import React from 'react';
import PropTypes from 'prop-types';
import { Dropdown } from 'semantic-ui-react';
import { injectIntl } from 'react-intl';
import { voidFn } from 'utils/common';
import { DropdownOptionsType, IntlType } from 'components/Types';
import './SearchDropdown.css';

const messages = {
  all: {
    id: 'common.all',
    defaultMessage: 'All'
  }
};

export function SearchDropdown(props) {
  const { className, options, onChange, intl: { formatMessage } } = props;

  const handleOptionChange = (event, { value }) => onChange(value);

  return (
    <div className={`filterDropdown ${className}`}>
      <Dropdown
        placeholder={formatMessage(messages.all)}
        fluid
        multiple
        search
        selection
        options={options}
        onChange={handleOptionChange}
      />
    </div>
  );
}

SearchDropdown.propTypes = {
  className: PropTypes.string,
  options: PropTypes.arrayOf(DropdownOptionsType).isRequired,
  onChange: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

SearchDropdown.defaultProps = {
  className: '',
  onChange: voidFn
};

export default injectIntl(SearchDropdown);
