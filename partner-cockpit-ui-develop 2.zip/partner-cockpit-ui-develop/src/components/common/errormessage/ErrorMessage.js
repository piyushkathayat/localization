import React from 'react';
import PropTypes from 'prop-types';
import { voidFn } from 'utils/common';
import { Message } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import './ErrorMessage.css';

export default function ErrorMessage(props) {
  const { header, message, onDismiss } = props;

  const defaultMessage = (
    <FormattedMessage
      defaultMessage="Something went wrong"
      id="common.error.message"
    />
  );

  return (
    <Message negative className="errorMessage" onDismiss={onDismiss}>
      <Message.Header>{header}</Message.Header>
      <p>{message || defaultMessage}</p>
    </Message>
  );
}

ErrorMessage.propTypes = {
  header: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  message: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  onDismiss: PropTypes.func.isRequired
};

ErrorMessage.defaultProps = {
  header: (
    <FormattedMessage
      defaultMessage="We are currently unable to process your request"
      id="common.error.header"
    />
  ),
  onDismiss: voidFn
};
