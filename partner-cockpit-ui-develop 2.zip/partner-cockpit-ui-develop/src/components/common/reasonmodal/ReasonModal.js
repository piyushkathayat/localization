import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Form, Input, TextArea, Message } from 'semantic-ui-react';
import { FormattedMessage, injectIntl, defineMessages } from 'react-intl';
import { voidFn } from 'utils/common';
import { MODAL_TYPES } from 'constants/common';
import { PromotionDatabaseType, IntlType } from 'components/Types';
import './ReasonModal.css';

const common = {
  no_cid: {
    id: 'common.reason_modal.no_cid',
    defaultMessage: 'No CID information to be included in the comment!'
  },
  save: {
    id: 'common.save',
    defaultMessage: 'Save'
  },
  error: {
    id: 'common.reason_modal.error',
    defaultMessage: 'Please fill in all fields.'
  },
  confirmedBy: {
    id: 'common.reason_modal.confirmedBy',
    defaultMessage: 'Confirmed by:'
  },
  confirmedByPlaceholder: {
    id: 'common.reason_modal.confirmedBy.instructions',
    defaultMessage: 'Add supervisor'
  },
  explanationTextPlaceholder: {
    id: 'common.reason_modal.description',
    defaultMessage: 'Add comment'
  }
};

const reasonTypes = {
  [MODAL_TYPES.VALIDATION_DECISION]: {
    messages: defineMessages({
      ...common,
      header: {
        id: 'validation.details.modal.header',
        defaultMessage: 'Validation'
      },
      explanation: {
        id: 'validation.details.modal.insert_explanation',
        defaultMessage: 'Please insert an explanation for not accepting decision'
      },
      explanationTextPlaceholder: {
        id: 'validation.details.modal.explanationText_placeholder',
        defaultMessage: '...add comment (For example: \'Stock rating for Twitter is incorrect\')'
      }
    })
  },
  [MODAL_TYPES.VALIDATION_RELEASE]: {
    messages: defineMessages({
      ...common,
      header: {
        id: 'validation.overview.modal.header',
        defaultMessage: 'Validation'
      }
    })
  },
  [MODAL_TYPES.DEMOTE_DATABASE]: {
    messages: defineMessages({
      ...common,
      header: {
        id: 'promotion.demote_modal.title',
        defaultMessage: 'Demote database'
      },
      explanation: {
        id: 'promotion.demote_modal.description',
        defaultMessage: 'Please insert an explanation for not promoting {item}'
      },
      explanation_second_line: {
        id: 'promotion.demote_modal.demote_dependants_warning',
        defaultMessage: 'Following databases depends on {item}: {items}. Since you have deselected {item}, you should also deselect following databases: {items}.'
      }
    }),
    dynamicMessages: true
  },
  [MODAL_TYPES.PROMOTE_DATABASE]: {
    messages: defineMessages({
      ...common,
      header: {
        id: 'promotion.promote_modal.title',
        defaultMessage: 'Promote database'
      },
      explanation: {
        id: 'promotion.promote_modal.description',
        defaultMessage: 'You intend to promote {item} that was not promoted in the past.'
      },
      explanation_second_line: {
        id: 'promotion.promote_modal.instructions',
        defaultMessage: 'Please insert an explanation for promoting {item} today.'
      }
    })
  },
  [MODAL_TYPES.EDIT_COMMENT]: {
    messages: defineMessages({
      ...common,
      header: {
        id: 'promotion.edit_comment_modal.title',
        defaultMessage: 'Edit comment'
      }
    })
  }
};

export class ReasonModal extends PureComponent {
  state = {
    confirmedBy: this.props.confirmedBy || '',
    explanationText: this.props.explanationText || '',
    error: false
  };

  showSection = type =>
    reasonTypes[type].dynamicMessages
    && this.props.firstTextVariable
    && this.props.secondTextVariable;

  handleConfirmedByChange = (e, { value }) => this.setState({ confirmedBy: value });

  handleExplanationTextChange = (e, { value }) => this.setState({ explanationText: value });

  handleSubmit = () => {
    const { confirmedBy, explanationText } = this.state;
    if (confirmedBy && explanationText) {
      this.setState({ error: false });
      this.props.onSubmit({
        confirmedBy,
        explanationText
      });
    } else {
      this.setState({ error: true });
    }
  };

  handleClose = () => {
    const { onClose } = this.props;
    this.setState({ error: false });
    onClose();
  };

  render() {
    const {
      isOpen,
      intl: { formatMessage },
      type,
      firstTextVariable,
      secondTextVariable
    } = this.props;
    const { confirmedBy, explanationText, error } = this.state;

    return (
      <Modal
        className="reasonModal"
        dimmer="blurring"
        size="tiny"
        open={isOpen}
        closeIcon
        onClose={this.handleClose}
      >
        <Modal.Header>
          <FormattedMessage {...reasonTypes[type].messages.header} />
        </Modal.Header>
        <Modal.Content>
          <div className="subHeader">
            {reasonTypes[type].messages.explanation && (
              <div className="insertExplanation">
                <FormattedMessage
                  {...reasonTypes[type].messages.explanation}
                  values={{ item: <strong>{firstTextVariable}</strong> }}
                />
              </div>
            )}
            {reasonTypes[type].messages.explanation_second_line && this.showSection(type) && (
              <div className="insertExplanationSecondLine">
                <FormattedMessage
                  {...reasonTypes[type].messages.explanation_second_line}
                  values={{
                    item: <strong>{firstTextVariable}</strong>,
                    items: <span>{secondTextVariable}</span>
                  }}
                />
              </div>
            )}
            {reasonTypes[type].messages.no_cid && (
              <div className="noCID">
                <FormattedMessage {...reasonTypes[type].messages.no_cid} />
              </div>
            )}
          </div>
          <div className="explanationForm">
            {error && (
              <Message negative>
                <FormattedMessage {...reasonTypes[type].messages.error} />
              </Message>
            )}
            <Form>
              <div className="confirmedBy">
                <div>
                  <FormattedMessage {...reasonTypes[type].messages.confirmedBy} />
                </div>
                <Input
                  placeholder={formatMessage(reasonTypes[type].messages.confirmedByPlaceholder)}
                  ref={this.confirmedBy}
                  defaultValue={confirmedBy}
                  onChange={this.handleConfirmedByChange}
                />
              </div>
              <TextArea
                className="explanationTextArea"
                autoHeight
                rows={3}
                ref={this.explanationText}
                placeholder={formatMessage(reasonTypes[type].messages.explanationTextPlaceholder)}
                defaultValue={explanationText}
                onChange={this.handleExplanationTextChange}
              />
            </Form>
          </div>
        </Modal.Content>
        <Modal.Actions>
          <Button
            className="ubs-primary-button"
            onClick={this.handleSubmit}
            disabled={!confirmedBy || !explanationText}
          >
            <FormattedMessage {...reasonTypes[type].messages.save} />
          </Button>
        </Modal.Actions>
      </Modal>
    );
  }
}

ReasonModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  type: PropTypes.string.isRequired,
  firstTextVariable: PropTypes.string,
  secondTextVariable: PropTypes.string,
  confirmedBy: PropTypes.string,
  explanationText: PropTypes.string,
  dependentDatabases: PropTypes.arrayOf(PromotionDatabaseType),
  onClose: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

ReasonModal.defaultProps = {
  isOpen: false,
  confirmedBy: '',
  explanationText: '',
  firstTextVariable: '',
  secondTextVariable: '',
  onClose: voidFn,
  onSubmit: voidFn
};

export default injectIntl(ReasonModal);
