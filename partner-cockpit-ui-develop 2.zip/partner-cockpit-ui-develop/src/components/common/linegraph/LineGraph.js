import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';
import { DateAndTime } from 'components/common';
import { formatValue } from 'utils/common';
import { FORMATS } from 'constants/common';
import {
  ResponsiveContainer,
  LineChart,
  XAxis,
  Line,
  Tooltip
} from 'recharts';
import moment from 'moment';
import { LineGraphType } from 'components/Types';
import './LineGraph.css';

// Coefficient of margin bars in the graph. 0.2 equals to 20%
const BAR_CATEGORY_GAP = 0.2;
// Coefficient of cursor's width. 1.5 equals to 150% of bar's width
const CURSOR_WIDTH_COEF = 1.5;
const MAX_BAR_WIDTH = 20;

export function CustomizedCursor(props) {
  const { barsCount, width, height, points = [] } = props;
  const { x, y } = points[0];
  const barWidth = Math.min(
    (width / barsCount) * (1 - 2 * BAR_CATEGORY_GAP),
    MAX_BAR_WIDTH
  );
  return (
    <rect
      className="barHover"
      x={x - barWidth * (CURSOR_WIDTH_COEF / 2)}
      y={y}
      width={barWidth * CURSOR_WIDTH_COEF}
      height={height - 1}
    />
  );
}

export default function LineGraph(props) {
  const {
    chartData,
    styles: { width, height, padding },
    format,
    currency,
    hasOnlyStartAndEndDates
  } = props;

  const barsCount = chartData.length;
  const interval = hasOnlyStartAndEndDates
    ? Math.max(barsCount - 2, 0)
    : 'preserveStartEnd';

  const xAxisFormat = data => moment(data).format('MM-DD');

  const renderToolTip = data => {
    const { payload = [] } = data;
    if (!payload.length) {
      return null;
    }
    const { payload: issue = {} } = payload[0];
    const {
      date,
      value
    } = issue;

    return (
      <div className="customTooltip">
        <div className="tooltipRow">
          <div className="tooltipLabel">
            <FormattedMessage defaultMessage="Total" id="common.line_graph_total" />:
          </div>
          <div className="tooltipValue">
            {formatValue(value, format, currency)}
          </div>
        </div>
        <div className="tooltipRow">
          <DateAndTime value={date} />
        </div>
      </div>
    );
  };

  const renderNoData = () => {
    return (
      <div className="noGraphData">
        <FormattedMessage defaultMessage="There is no data to display" id="common.no_results" />
      </div>
    );
  };

  const renderChart = () => (
    <ResponsiveContainer className="lineGraph" width="100%" height={height}>
      <LineChart
        width={width}
        height={height / 2}
        data={chartData}
        margin={{ top: padding.top, bottom: padding.bottom }}
      >
        <XAxis
          dataKey="date"
          tickFormatter={xAxisFormat}
          height={10}
          padding={{ left: padding.left, right: padding.right }}
          interval={interval}
        />
        <Tooltip
          cursor={<CustomizedCursor barsCount={barsCount} />}
          position={{ y: -45 }}
          content={renderToolTip}
        />
        <Line isAnimationActive={false} type="monotone" dataKey="value" stroke="#007099" />
      </LineChart>
    </ResponsiveContainer>
  );

  return (
    <div className="lineGraphContainer">
      {isNonEmptyArray(chartData)
        ? renderChart()
        : renderNoData()
      }
    </div>
  );
}

LineGraph.propTypes = {
  chartData: PropTypes.arrayOf(LineGraphType).isRequired,
  styles: PropTypes.shape({
    width: PropTypes.number.isRequired,
    height: PropTypes.number.isRequired,
    padding: PropTypes.shape({
      top: PropTypes.number,
      right: PropTypes.number,
      bottom: PropTypes.number,
      left: PropTypes.number
    })
  }),
  format: PropTypes.string,
  currency: PropTypes.string,
  hasOnlyStartAndEndDates: PropTypes.bool
};

// we use defaultProps for LineGraph on LoadAndQA page
// LineGraph on Summary page has it's own styles
LineGraph.defaultProps = {
  chartData: [],
  styles: {
    width: 230,
    height: 60,
    padding: {
      top: 10,
      right: 15,
      bottom: 10,
      left: 15
    }
  },
  format: FORMATS.NUMBER,
  currency: 'USD',
  hasOnlyStartAndEndDates: true
};
