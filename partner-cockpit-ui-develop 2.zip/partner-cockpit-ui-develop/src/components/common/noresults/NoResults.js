import React from 'react';
import { Grid } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import './NoResults.css';

export default function NoResults() {
  return (
    <div className="noResults">
      <Grid textAlign="center" verticalAlign="middle" columns="equal" container>
        <Grid.Row centered>
          <Grid.Column width={4} textAlign="center">
            <FormattedMessage
              defaultMessage="There is no data to display"
              id="common.no_results"
            />
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </div>
  );
}
