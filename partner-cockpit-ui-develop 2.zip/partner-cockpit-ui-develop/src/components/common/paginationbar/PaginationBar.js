import React from 'react';
import PropTypes from 'prop-types';
import { Icon, Pagination } from 'semantic-ui-react';
import { voidFn } from 'utils/common';

export default function PaginationBar(props) {
  const { currentPage, totalPages, onPageChange } = props;

  if (!totalPages) {
    return null;
  }

  const handlePageChange = (e, { activePage: nextPage }) => onPageChange(nextPage);

  return (
    <Pagination
      className="paginationBar"
      activePage={currentPage}
      ellipsisItem={{ content: <Icon name="ellipsis horizontal" />, icon: true }}
      firstItem={{ content: <Icon name="angle double left" />, icon: true }}
      lastItem={{ content: <Icon name="angle double right" />, icon: true }}
      prevItem={{ content: <Icon name="angle left" />, icon: true }}
      nextItem={{ content: <Icon name="angle right" />, icon: true }}
      totalPages={totalPages}
      onPageChange={handlePageChange}
    />
  );
}

PaginationBar.propTypes = {
  currentPage: PropTypes.number.isRequired,
  totalPages: PropTypes.number.isRequired,
  onPageChange: PropTypes.func.isRequired
};

PaginationBar.defaultProps = {
  currentPage: 1,
  onPageChange: voidFn
};
