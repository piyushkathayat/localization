import React from 'react';
import { shallow } from 'enzyme';
import { SERVER_TYPES } from 'constants/serverInfo';
import { ErrorMessage } from 'components/common';
import HeaderTitle from 'components/header/HeaderTitle';
import HeaderMenu from 'components/header/HeaderMenu';
import Header from 'components/header/Header';

const getInitialProps = () => ({
  serverType: SERVER_TYPES.STAGING,
  layersVersions: {
    database: '2.0.1',
    cockpitService: '2.0.2',
    gatewayService: '2.0.3',
    ui: '2.0.4'
  },
  isLoading: false,
  error: null,
  onErrorDismiss: jest.fn()
});

describe('Header component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Header {...props} />);

    // then
    expect(enzymeWrapper.exists('.headerContainer')).toBe(true);
  });

  it('should render HeaderTitle', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Header {...props} />);

    // then
    expect(enzymeWrapper.find(HeaderTitle)).toHaveLength(1);
  });

  it('should render HeaderMenu with props', () => {
    // given
    const props = getInitialProps();
    const expectedMenuProps = {
      serverType: SERVER_TYPES.STAGING,
      layersVersions: props.layersVersions,
      isLoading: false
    };

    // when
    const enzymeWrapper = shallow(<Header {...props} />);

    // then
    expect(enzymeWrapper.find(HeaderMenu)).toHaveLength(1);
    const menuProps = enzymeWrapper.find(HeaderMenu).props();
    expect(menuProps.serverType).toEqual(expectedMenuProps.serverType);
    expect(menuProps.layersVersions).toEqual(expectedMenuProps.layersVersions);
    expect(menuProps.isLoading).toEqual(expectedMenuProps.isLoading);
  });

  it('should render ErrorMessage with props', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';
    const expectedErrorProps = {
      message: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<Header {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);
    const errorProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorProps.message).toEqual(expectedErrorProps.message);
    errorProps.onDismiss();
    expect(props.onErrorDismiss).toHaveBeenCalled();
  });
});
