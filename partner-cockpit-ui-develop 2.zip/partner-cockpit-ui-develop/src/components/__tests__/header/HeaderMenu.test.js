import React from 'react';
import { shallow } from 'enzyme';
import { SERVER_TYPES } from 'constants/serverInfo';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import { Link } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';
import { Menu, Popup, Loader } from 'semantic-ui-react';
import { HeaderMenu } from 'components/header/HeaderMenu';

const getInitialProps = () => ({
  serverType: SERVER_TYPES.STAGING,
  layersVersions: {
    database: '2.0.1',
    cockpitService: '2.0.2',
    gatewayService: '2.0.3',
    ui: '2.0.4'
  },
  isLoading: false,
  location: {
    pathname: `/${APP_PREFIX}/${MENU_ITEMS.SUMMARY}`
  }
});

// TODO: add layersVersions

describe('HeaderMenu component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    expect(enzymeWrapper.exists('.headerMenuContainer')).toBe(true);
  });

  it('should render Menu', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    expect(enzymeWrapper.find(Menu)).toHaveLength(1);
    expect(enzymeWrapper.find(Menu).hasClass('headerMenu')).toBe(true);
  });

  it('should render main menu - all items on LIVE server', () => {
    // given
    const props = getInitialProps();
    props.serverType = SERVER_TYPES.LIVE;

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    const mainMenuItems = enzymeWrapper.find(Menu.Item)
      .filterWhere(n => n.prop('position') !== 'right');
    expect(mainMenuItems).toHaveLength(7);
    const activeMenuItems = mainMenuItems.filterWhere(n => n.prop('active'));
    expect(activeMenuItems).toHaveLength(1);
  });

  it('should render main menu - no validation item on STAGING server', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    const mainMenuItems = enzymeWrapper.find(Menu.Item)
      .filterWhere(n => n.prop('position') !== 'right');
    expect(mainMenuItems).toHaveLength(6);
    const validationMenuItem = mainMenuItems.filterWhere(n => n.prop('to').includes(MENU_ITEMS.VALIDATION));
    expect(validationMenuItem).toHaveLength(0);
  });

  it('should render main menu - one item on CENTRAL server', () => {
    // given
    const props = getInitialProps();
    props.serverType = SERVER_TYPES.CENTRAL;

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    const mainMenuItems = enzymeWrapper.find(Menu.Item)
      .filterWhere(n => n.prop('position') !== 'right');
    expect(mainMenuItems).toHaveLength(1);
  });

  it('should render Menu Items with props', () => {
    // given
    const props = getInitialProps();
    const expectedItemProps = {
      active: true,
      as: Link,
      to: `/${APP_PREFIX}/${MENU_ITEMS.SUMMARY}`
    };

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    const itemProps = enzymeWrapper.find(Menu.Item).at(0).props();
    expect(itemProps.active).toEqual(expectedItemProps.active);
    expect(itemProps.as).toEqual(expectedItemProps.as);
    expect(itemProps.to).toEqual(expectedItemProps.to);
  });

  it('should get active Menu Item properly', () => {
    // given
    const props = getInitialProps();
    props.location.pathname = `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`;

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    const itemProps = enzymeWrapper.find(Menu.Item).at(0).props();
    expect(itemProps.active).toBe(false);
  });

  it('should render Loader instead of serverType if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    expect(enzymeWrapper.exists('.serverTypeLoader')).toBe(true);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.find(Popup)).toHaveLength(0);
  });

  it('should render serverType Popup trigger - STAGING server', () => {
    // given
    const props = getInitialProps();
    const expectedTrigger = (
      <span className="serverType">
        Staging
      </span>
    );

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    expect(enzymeWrapper.find(Popup).prop('trigger')).toEqual(expectedTrigger);
  });

  it('should render serverType Popup trigger - unknown server', () => {
    // given
    const props = getInitialProps();
    props.serverType = undefined;
    const expectedTrigger = (
      <span className="serverType">
        <FormattedMessage defaultMessage="Unknown server" id="menu.unknown_server" />
      </span>
    );

    // when
    const enzymeWrapper = shallow(<HeaderMenu {...props} />);

    // then
    expect(enzymeWrapper.find(Popup).prop('trigger')).toEqual(expectedTrigger);
  });
});
