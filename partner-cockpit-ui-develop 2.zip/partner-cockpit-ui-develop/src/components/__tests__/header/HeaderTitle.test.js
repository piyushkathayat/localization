import React from 'react';
import { shallow } from 'enzyme';
import LocaleDropdown from 'components/header/LocaleDropdown';
import HeaderTitle from 'components/header/HeaderTitle';

const getInitialProps = () => ({
  productName: undefined
});

describe('HeaderTitle component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderTitle {...props} />);

    // then
    expect(enzymeWrapper.exists('.headerTitleContainer')).toBe(true);
  });

  it('should render logo', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderTitle {...props} />);

    // then
    expect(enzymeWrapper.exists('.bankLogo')).toBe(true);
  });

  it('should render productName - default value', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderTitle {...props} />);

    // then
    expect(enzymeWrapper.exists('.productName')).toBe(true);
    expect(enzymeWrapper.find('.productName').text()).toContain('Partner Cockpit');
  });

  it('should render productName - set value', () => {
    // given
    const props = getInitialProps();
    props.productName = 'Some wholesaler';

    // when
    const enzymeWrapper = shallow(<HeaderTitle {...props} />);

    // then
    expect(enzymeWrapper.find('.productName').text()).toContain('Some wholesaler');
  });

  it('should not render localization dropdown', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<HeaderTitle {...props} />);

    // then
    expect(enzymeWrapper.exists('.localDropdown')).toBe(false);
    expect(enzymeWrapper.find(LocaleDropdown)).toHaveLength(0);
  });
});
