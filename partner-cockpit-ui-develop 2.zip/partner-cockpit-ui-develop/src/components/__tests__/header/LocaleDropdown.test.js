import React from 'react';
import { shallow } from 'enzyme';
import { Dropdown } from 'semantic-ui-react';
import { LOCALES } from 'constants/common';
import LocaleDropdown from 'components/header/LocaleDropdown';

describe('LocaleDropdown component', () => {
  it('should render Dropdown', () => {
    // given

    // when
    const enzymeWrapper = shallow(<LocaleDropdown />);

    // then
    expect(enzymeWrapper.find(Dropdown)).toHaveLength(1);
  });

  it('should render Dropdown with props', () => {
    // given
    const expectedDropdownProps = {
      value: 'en',
      selection: true,
      options: LOCALES
    };

    // when
    const enzymeWrapper = shallow(<LocaleDropdown />);

    // then
    const dropdownProps = enzymeWrapper.find(Dropdown).props();
    expect(dropdownProps.value).toEqual(expectedDropdownProps.value);
    expect(dropdownProps.selection).toEqual(expectedDropdownProps.selection);
    expect(dropdownProps.options).toEqual(expectedDropdownProps.options);
  });
});
