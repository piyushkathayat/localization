import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { FormatNumber } from '@ubs.partner/shared-ui';
import { LineGraph } from 'components/common';
import { INFINITY } from 'constants/common';
import SummaryTile from 'components/summary/SummaryTile';

const getInitialProps = () => ({
  currency: 'EUR',
  summaryInfo: {
    data: [
      {
        date: '2018-12-14T00:00:00',
        value: 10000
      },
      {
        date: '2018-12-15T00:00:00',
        value: 10000
      },
      {
        date: '2018-12-16T00:00:00',
        value: 15000
      }
    ],
    format: 'NUMBER',
    group: 'Instrument',
    marquee: 15000,
    pctChange: 0.5,
    recNo: 1,
    type: 'CORTEX_INSTRUMENT'
  }
});

describe('SummaryTile component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.summaryTile')).toBe(true);
    expect(enzymeWrapper.exists('.description')).toBe(true);
    expect(enzymeWrapper.exists('.total')).toBe(true);
    expect(enzymeWrapper.exists('.trend')).toBe(true);
    expect(enzymeWrapper.exists('.tileGraph')).toBe(true);
  });

  it('should render proper tile name with existing type', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find(FormattedMessage)).toHaveLength(1);
    const formattedMessageProps = enzymeWrapper.find(FormattedMessage).props();
    expect(formattedMessageProps.id).toEqual('summary.cortex_instruments');
  });

  it('should render type as a tile name with unknown type', () => {
    // given
    const props = getInitialProps();
    props.summaryInfo.type = 'unknown_type';

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find(FormattedMessage)).toHaveLength(0);
    expect(enzymeWrapper.find('.description').text()).toEqual('unknown_type');
  });

  it('should render proper trend', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find('.trendLabel').hasClass('warning')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-disclosureup')).toBe(true);
    expect(enzymeWrapper.find('.trend').find(FormatNumber)).toHaveLength(1);
  });

  it('should render proper trend with pctChange === 0', () => {
    // given
    const props = getInitialProps();
    props.summaryInfo.pctChange = 0;

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find('.trendLabel').hasClass('warning')).toBe(false);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(false);
  });

  it('should render proper trend with small pctChange', () => {
    // given
    const props = getInitialProps();
    props.summaryInfo.pctChange = -0.05;

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find('.trendLabel').hasClass('warning')).toBe(false);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-disclosuredown')).toBe(true);
  });

  it('should render proper trend if pctChange === INFINITY', () => {
    // given
    const props = getInitialProps();
    props.summaryInfo.pctChange = INFINITY;

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find('.trendLabel').hasClass('warning')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-disclosureup')).toBe(true);
    expect(enzymeWrapper.find('trend').find(FormatNumber)).toHaveLength(0);
    expect(enzymeWrapper.exists('.infinitySign')).toBe(true);
    expect(enzymeWrapper.find('.infinitySign').text()).toEqual('∞');
  });

  it('should render LineGraph with props', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTile {...props} />);

    // then
    expect(enzymeWrapper.find(LineGraph)).toHaveLength(1);
    const lineGraphProps = enzymeWrapper.find(LineGraph).props();
    expect(lineGraphProps.chartData).toEqual(props.summaryInfo.data);
    expect(lineGraphProps.format).toEqual(props.summaryInfo.format);
    expect(lineGraphProps.currency).toEqual(props.currency);
  });
});
