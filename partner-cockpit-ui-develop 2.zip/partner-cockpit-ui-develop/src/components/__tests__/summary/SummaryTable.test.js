import React from 'react';
import { shallow } from 'enzyme';
import { Grid } from 'semantic-ui-react';
import SummaryTable from 'components/summary/SummaryTable';
import SummaryTile from 'components/summary/SummaryTile';

const getInitialProps = () => ({
  currency: 'EUR',
  summaryInfo: [
    {
      data: [],
      format: 'CURRENCY',
      group: 'Asset',
      marquee: 7035663855,
      pctChange: 0,
      recNo: 0,
      type: 'TOTAL_ASSET_VALUE_GROSS'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 1,
      type: 'CORTEX_INSTRUMENT'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 2,
      type: 'ST_COUNT_INSTRUMENT'
    }
  ]
});

describe('SummaryTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTable {...props} />);

    // then
    expect(enzymeWrapper.find(Grid)).toHaveLength(1);
    expect(enzymeWrapper.find(Grid).hasClass('summaryTable')).toBe(true);
  });

  it('should render proper amount of SummaryTiles', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTable {...props} />);

    // then
    expect(enzymeWrapper.find(SummaryTile)).toHaveLength(3);
  });

  it('should pass proper props to SummaryTile', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SummaryTable {...props} />);

    // then
    const summaryTileProps = enzymeWrapper.find(SummaryTile).first().props();
    expect(summaryTileProps.summaryInfo).toEqual(props.summaryInfo[0]);
    expect(summaryTileProps.currency).toEqual(props.currency);
  });
});
