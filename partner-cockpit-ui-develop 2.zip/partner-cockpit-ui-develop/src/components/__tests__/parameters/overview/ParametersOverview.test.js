import React from 'react';
import { shallow } from 'enzyme';
import { Grid, Loader } from 'semantic-ui-react';
import { ErrorMessage, NoResults } from 'components/common';
import { ParametersOverview } from 'components/parameters/overview/ParametersOverview';
import ParameterTile from 'components/parameters/overview/ParameterTile';

const getInitialProps = () => ({
  parametersList: [
    {
      checkedInAt: '2018-07-20T13:45:46.857',
      checkedInBy: '43471071',
      checkedOutAt: '2018-12-17T13:26:18.73',
      checkedOutBy: '43535763',
      feedName: 'mapping',
      isUpdating: true
    },
    {
      checkedInAt: '2018-08-30T15:41:04.133',
      checkedInBy: '43395564',
      checkedOutAt: '2018-12-19T15:19:20.287',
      checkedOutBy: '00355799',
      feedName: 'saa'
    }
  ],
  isLoading: false,
  error: null,
  onParameterTileClick: jest.fn(),
  clearError: jest.fn()
});

describe('ParametersOverview component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.parametersOverviewContainer')).toBe(true);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.parametersTable')).toBe(false);
  });

  it('should render NoResults if there are no parameters', () => {
    // given
    const props = getInitialProps();
    props.parametersList = [];

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.exists('.parametersTable')).toBe(false);
  });

  it('should render a content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(0);
    expect(enzymeWrapper.find(Grid)).toHaveLength(1);
    expect(enzymeWrapper.find(Grid).hasClass('parametersTable')).toBe(true);
  });

  it('should render proper amount of tiles', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    expect(enzymeWrapper.find(ParameterTile)).toHaveLength(2);
  });

  it('should pass props to tiles', () => {
    // given
    const props = getInitialProps();
    const expectedTileProps = {
      feedName: 'mapping',
      isUpdating: true,
      onTileClick: props.onParameterTileClick
    };

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    const tileProps = enzymeWrapper.find(ParameterTile).first().props();
    expect(tileProps.feedName).toEqual(expectedTileProps.feedName);
    expect(tileProps.isUpdating).toEqual(expectedTileProps.isUpdating);
    tileProps.onTileClick();
    expect(props.onParameterTileClick.mock.calls.length).toBe(1);
  });

  it('should render ErrorMessage if error !== null', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';

    // when
    const enzymeWrapper = shallow(<ParametersOverview {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    errorMessageProps.onDismiss();
    expect(props.clearError.mock.calls.length).toBe(1);
  });
});
