import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import ParameterTile from 'components/parameters/overview/ParameterTile';
import ParameterStatus from 'components/parameters/common/ParameterStatus';

// TODO: update

const getInitialProps = () => ({
  feedName: 'mapping',
  isUpdating: false,
  onTileClick: jest.fn()
});

describe('ParametersOverview component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.parameterTileContainer')).toBe(true);
  });

  it('should render translated parameter name if found', () => {
    // given
    const props = getInitialProps();
    const expectedFormattedMessageProps = {
      id: 'parameters.mapping_tables',
      defaultMessage: 'Mapping Tables'
    };

    // when
    const enzymeWrapper = shallow(<ParameterTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.parameterName')).toBe(true);
    expect(enzymeWrapper.find(FormattedMessage)).toHaveLength(1);
    const formattedMessageProps = enzymeWrapper.find(FormattedMessage).props();
    expect(formattedMessageProps.id).toEqual(expectedFormattedMessageProps.id);
    expect(formattedMessageProps.defaultMessage)
      .toEqual(expectedFormattedMessageProps.defaultMessage);
  });

  it('should render raw feedName if translation is not found', () => {
    // given
    const props = getInitialProps();
    props.feedName = 'some new feedName';

    // when
    const enzymeWrapper = shallow(<ParameterTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.parameterName')).toBe(true);
    expect(enzymeWrapper.find(FormattedMessage)).toHaveLength(0);
    expect(enzymeWrapper.find('.parameterName').text()).toEqual('some new feedName');
  });

  it('should render ParameterStatus with props', () => {
    // given
    const props = getInitialProps();
    const expectedParameterStatusProps = {
      feedName: 'mapping'
    };

    // when
    const enzymeWrapper = shallow(<ParameterTile {...props} />);

    // then
    expect(enzymeWrapper.find(ParameterStatus)).toHaveLength(1);
    const parameterStatusProps = enzymeWrapper.find(ParameterStatus).props();
    expect(parameterStatusProps.feedName).toEqual(expectedParameterStatusProps.feedName);
  });

  it('should handle tile click', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterTile {...props} />);

    // then
    enzymeWrapper.find('.parameterTileContainer').simulate('click');
    expect(props.onTileClick.mock.calls.length).toBe(1);
    expect(props.onTileClick.mock.calls[0][0]).toBe('mapping');
  });
});
