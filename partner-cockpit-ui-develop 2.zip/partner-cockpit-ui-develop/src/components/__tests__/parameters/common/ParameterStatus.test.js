import React from 'react';
import { shallow } from 'enzyme';
import { Button } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { DateAndTime } from 'components/common';
import { PARAMETERS_STATUSES, PARAMETERS_TYPES } from 'constants/parameters';
import { ParameterStatus } from 'components/parameters/common/ParameterStatus';

// TODO: update

const getInitialProps = () => ({
  feedName: 'mapping',
  parameter: {
    feedName: 'mapping',
    status: PARAMETERS_STATUSES.CHECKED_OUT,
    isUpdating: false,
    lastUpdatedAt: '2018-12-17T13:26:18.73',
    lastUpdatedBy: '43535763'
  },
  serverType: 'STAGING',
  loggedInUser: '43535763',
  isParametersDetails: false,
  feedCheckIn: jest.fn(),
  feedCheckOut: jest.fn(),
  feedCancel: jest.fn()
});

describe('ParameterStatus component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.parameterStatus')).toBe(true);
  });

  it('should render status: Checked Out', () => {
    // given
    const props = getInitialProps();
    const expectedFormattedMessageProps = {
      id: 'parameters.overview.checked_out',
      defaultMessage: 'Checked Out'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.status')).toBe(true);
    expect(enzymeWrapper.find('.status').find(FormattedMessage)).toHaveLength(1);
    const formattedMessageProps = enzymeWrapper.find('.status').find(FormattedMessage).props();
    expect(formattedMessageProps.id).toEqual(expectedFormattedMessageProps.id);
    expect(formattedMessageProps.defaultMessage)
      .toEqual(expectedFormattedMessageProps.defaultMessage);
  });

  it('should render status: Checked In', () => {
    // given
    const props = getInitialProps();
    props.parameter.status = PARAMETERS_STATUSES.CHECKED_IN;
    const expectedFormattedMessageProps = {
      id: 'parameters.overview.checked_in',
      defaultMessage: 'Checked In'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.status')).toBe(true);
    expect(enzymeWrapper.find('.status').find(FormattedMessage)).toHaveLength(1);
    const formattedMessageProps = enzymeWrapper.find('.status').find(FormattedMessage).props();
    expect(formattedMessageProps.id).toEqual(expectedFormattedMessageProps.id);
    expect(formattedMessageProps.defaultMessage)
      .toEqual(expectedFormattedMessageProps.defaultMessage);
  });

  it('should render updatedAt', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.updatedAt')).toBe(true);
  });

  it('should render updatedAt: no icon if isParametersDetails === false', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedAt').exists('.statusInfoIcon')).toBe(false);
  });

  it('should render updatedAt: with icon if isParametersDetails === true', () => {
    // given
    const props = getInitialProps();
    props.isParametersDetails = true;

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedAt').exists('.statusInfoIcon')).toBe(true);
  });

  it('should render updatedAt: no DateAndTime if !lastUpdatedAt', () => {
    // given
    const props = getInitialProps();
    props.parameter.lastUpdatedAt = '';

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedAt').find(DateAndTime)).toHaveLength(0);
    expect(enzymeWrapper.find('.updatedAt').text()).toEqual('-');
  });

  it('should render updatedAt: with DateAndTime', () => {
    // given
    const props = getInitialProps();
    const expectedDateAndTimeProps = {
      value: '2018-12-17T13:26:18.73'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedAt').find(DateAndTime)).toHaveLength(1);
    const dateAndTimeProps = enzymeWrapper.find('.updatedAt').find(DateAndTime).props();
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should not render updatedBy if !lastUpdatedBy && !isParametersDetails', () => {
    // given
    const props = getInitialProps();
    props.parameter.lastUpdatedBy = '';

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.updatedBy')).toBe(false);
  });

  it('should render updatedBy', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.updatedBy')).toBe(true);
  });

  it('should render updatedBy: "By" if !isParametersDetails', () => {
    // given
    const props = getInitialProps();
    const expectedByProps = {
      id: 'parameters.overview.by',
      defaultMessage: 'By'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    const byProps = enzymeWrapper.find('.updatedBy').find(FormattedMessage).first().props();
    expect(byProps.id).toBe(expectedByProps.id);
    expect(byProps.defaultMessage).toBe(expectedByProps.defaultMessage);
  });

  it('should render updatedBy: icon if isParametersDetails', () => {
    // given
    const props = getInitialProps();
    props.isParametersDetails = true;

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedBy').exists('.statusInfoIcon')).toBe(true);
  });

  it('should render updatedBy: "You" if lastUpdatedBy === loggedInUser', () => {
    // given
    const props = getInitialProps();
    const expectedYouProps = {
      id: 'parameters.overview.you',
      defaultMessage: 'You'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    const youProps = enzymeWrapper.find('.updatedBy').find(FormattedMessage).at(1).props();
    expect(youProps.id).toBe(expectedYouProps.id);
    expect(youProps.defaultMessage).toBe(expectedYouProps.defaultMessage);
  });

  it('should render updatedBy: lastUpdatedBy if !!lastUpdatedBy && lastUpdatedBy !== loggedInUser', () => {
    // given
    const props = getInitialProps();
    props.loggedInUser = '00000000';

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedBy').text()).toContain('43535763');
  });

  it('should render updatedBy: "-" if !lastUpdatedBy', () => {
    // given
    const props = getInitialProps();
    props.isParametersDetails = true;
    props.parameter.lastUpdatedBy = '';

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find('.updatedBy').text()).toContain('-');
  });

  it('should render buttons', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.parameterButtons')).toBe(true);
  });

  it('should render buttons: CheckOut button', () => {
    // given
    const props = getInitialProps();
    props.parameter.status = PARAMETERS_STATUSES.CHECKED_IN;
    const expectedLabelProps = {
      id: 'parameters.overview.check_out',
      defaultMessage: 'Check Out'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(1);
    const checkOutButtonWrapper = enzymeWrapper.find(Button);
    expect(checkOutButtonWrapper.hasClass('statusButton')).toBe(true);
    expect(checkOutButtonWrapper.hasClass('ubs-primary-button')).toBe(true);
    expect(checkOutButtonWrapper.find(FormattedMessage)).toHaveLength(1);
    const labelProps = checkOutButtonWrapper.find(FormattedMessage).props();
    expect(labelProps.id).toEqual(expectedLabelProps.id);
    expect(labelProps.defaultMessage).toEqual(expectedLabelProps.defaultMessage);
  });

  it('should handle button click: CheckOut button', () => {
    // given
    const props = getInitialProps();
    props.parameter.status = PARAMETERS_STATUSES.CHECKED_IN;
    const event = {
      stopPropagation: jest.fn()
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    enzymeWrapper.find(Button).simulate('click', event);
    expect(event.stopPropagation.mock.calls.length).toBe(1);
    expect(props.feedCheckOut.mock.calls.length).toBe(1);
    expect(props.feedCheckOut.mock.calls[0][0]).toEqual('mapping');
  });

  it('should render buttons: Cancel button', () => {
    // given
    const props = getInitialProps();
    const expectedLabelProps = {
      id: 'parameters.overview.cancel',
      defaultMessage: 'Cancel'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(2);
    const cancelButtonWrapper = enzymeWrapper.find(Button).at(0);
    expect(cancelButtonWrapper.hasClass('statusButton')).toBe(true);
    expect(cancelButtonWrapper.hasClass('ubs-secondary-button')).toBe(true);
    expect(cancelButtonWrapper.find(FormattedMessage)).toHaveLength(1);
    const labelProps = cancelButtonWrapper.find(FormattedMessage).props();
    expect(labelProps.id).toEqual(expectedLabelProps.id);
    expect(labelProps.defaultMessage).toEqual(expectedLabelProps.defaultMessage);
  });

  it('should handle button click: Cancel button', () => {
    // given
    const props = getInitialProps();
    const event = {
      stopPropagation: jest.fn()
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    enzymeWrapper.find(Button).at(0).simulate('click', event);
    expect(event.stopPropagation.mock.calls.length).toBe(1);
    expect(props.feedCancel.mock.calls.length).toBe(1);
    expect(props.feedCancel.mock.calls[0][0]).toEqual('mapping');
  });

  it('should render buttons: CheckIn button', () => {
    // given
    const props = getInitialProps();
    const expectedLabelProps = {
      id: 'parameters.overview.check_in',
      defaultMessage: 'Check In'
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(2);
    const checkInButtonWrapper = enzymeWrapper.find(Button).at(1);
    expect(checkInButtonWrapper.hasClass('statusButton')).toBe(true);
    expect(checkInButtonWrapper.hasClass('ubs-tertiary-button')).toBe(true);
    expect(checkInButtonWrapper.find(FormattedMessage)).toHaveLength(1);
    const labelProps = checkInButtonWrapper.find(FormattedMessage).props();
    expect(labelProps.id).toEqual(expectedLabelProps.id);
    expect(labelProps.defaultMessage).toEqual(expectedLabelProps.defaultMessage);
    expect(checkInButtonWrapper.exists('input')).toBe(true);
    expect(checkInButtonWrapper.find('input').hasClass('hidden')).toBe(true);
    expect(checkInButtonWrapper.find('input').props().type).toEqual('file');
  });

  it('should handle button click: Check In button', () => {
    // given
    const props = getInitialProps();
    const event = {
      stopPropagation: jest.fn()
    };

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);
    const instance = enzymeWrapper.instance();
    instance.fileInput = {
      click: jest.fn()
    };

    // then
    enzymeWrapper.find(Button).at(1).simulate('click', event);
    expect(event.stopPropagation.mock.calls.length).toBe(1);
    expect(instance.fileInput.click.mock.calls.length).toBe(1);
  });

  it('should enable buttons in serverType === STAGING: Check Out', () => {
    // given
    const props = getInitialProps();
    props.parameter.status = PARAMETERS_STATUSES.CHECKED_IN;

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button).props().disabled).toBe(false);
  });

  it('should enable buttons in serverType === STAGING: Check In and Cancel', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button).at(0).props().disabled).toBe(false);
    expect(enzymeWrapper.find(Button).at(1).props().disabled).toBe(false);
  });

  it('should disable buttons for Reference Feed', () => {
    // given
    const props = getInitialProps();
    props.feedName = PARAMETERS_TYPES.REFERENCE_PORTFOLIOS;
    props.parameter.status = PARAMETERS_STATUSES.CHECKED_IN;

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button).props().disabled).toBe(true);
  });

  it('should disable buttons in serverType !== STAGING: Check Out', () => {
    // given
    const props = getInitialProps();
    props.serverType = 'LIVE';
    props.parameter.status = PARAMETERS_STATUSES.CHECKED_IN;

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button).props().disabled).toBe(true);
  });

  it('should disable buttons in serverType !== STAGING: Check In and Cancel', () => {
    // given
    const props = getInitialProps();
    props.serverType = 'LIVE';

    // when
    const enzymeWrapper = shallow(<ParameterStatus {...props} />);

    // then
    expect(enzymeWrapper.find(Button).at(0).props().disabled).toBe(true);
    expect(enzymeWrapper.find(Button).at(1).props().disabled).toBe(true);
  });
});
