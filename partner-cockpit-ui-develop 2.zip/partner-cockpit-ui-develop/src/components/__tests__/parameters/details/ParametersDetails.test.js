import React from 'react';
import { shallow } from 'enzyme';
import { Loader } from 'semantic-ui-react';
import { ErrorMessage, TablesList } from 'components/common';
import { ParametersDetails } from 'components/parameters/details/ParametersDetails';
import ParametersDetailsStatus from 'components/parameters/details/ParametersDetailsStatus';

const getInitialProps = () => ({
  feedName: 'saa',
  tablesList: [
    {
      id: 0,
      tableData: [],
      tableDisplayName: 'SAA',
      tableName: 'ST_SAA'
    },
    {
      id: 1,
      tableData: [],
      tableDisplayName: 'SAA Risk Return',
      tableName: 'ST_SAARiskReturn'
    },
    {
      id: 2,
      tableData: [],
      tableDisplayName: 'ST_SAAWeights',
      tableName: 'ST_SAAWeights'
    }
  ],
  isLoading: false,
  error: null,
  clearParametersDetails: jest.fn(),
  clearError: jest.fn()
});

describe('ParametersDetails component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);

    // then
    expect(enzymeWrapper.exists('.parametersDetailsContainer')).toBe(true);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.parametersDetailsContent')).toBe(false);
  });

  it('should render content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.exists('.parametersDetailsContent')).toBe(true);
  });

  it('should render TablesList with props', () => {
    // given
    const props = getInitialProps();
    const expectedTablesListProps = {
      tablesList: [
        {
          id: 0,
          tableData: [],
          tableDisplayName: 'SAA',
          tableName: 'ST_SAA'
        },
        {
          id: 1,
          tableData: [],
          tableDisplayName: 'SAA Risk Return',
          tableName: 'ST_SAARiskReturn'
        },
        {
          id: 2,
          tableData: [],
          tableDisplayName: 'ST_SAAWeights',
          tableName: 'ST_SAAWeights'
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);

    // then
    expect(enzymeWrapper.find(TablesList)).toHaveLength(1);
    const tablesListProps = enzymeWrapper.find(TablesList).props();
    expect(tablesListProps.tablesList).toEqual(expectedTablesListProps.tablesList);
  });

  it('should render ParametersDetailsStatus with props', () => {
    // given
    const props = getInitialProps();
    const expectedStatusProps = {
      feedName: 'saa'
    };

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);

    // then
    expect(enzymeWrapper.find(ParametersDetailsStatus)).toHaveLength(1);
    const statusProps = enzymeWrapper.find(ParametersDetailsStatus).props();
    expect(statusProps.feedName).toEqual(expectedStatusProps.feedName);
  });

  it('should render ErrorMessage if error !== null', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    errorMessageProps.onDismiss();
    expect(props.clearError.mock.calls.length).toBe(1);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersDetails {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearParametersDetails).toHaveBeenCalled();
  });
});
