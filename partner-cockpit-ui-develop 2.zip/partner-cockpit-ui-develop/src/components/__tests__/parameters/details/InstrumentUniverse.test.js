import React from 'react';
import { shallow } from 'enzyme';
import { Loader, Dimmer } from 'semantic-ui-react';
import { PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE } from 'constants/parameters';
import { ErrorMessage, PaginationBar, AgGridTable } from 'components/common';
import { InstrumentUniverse } from 'components/parameters/details/InstrumentUniverse';
import ParametersDetailsStatus from 'components/parameters/details/ParametersDetailsStatus';

const getInitialProps = () => ({
  feedName: 'universe',
  instrumentsList: [
    {
      isin: 'isin0',
      instrumentName: 'instrument0',
      tradingCurrency: 'EUR',
      buy: false
    },
    {
      isin: 'isin1',
      instrumentName: 'instrument1',
      tradingCurrency: 'USD',
      buy: true
    }
  ],
  totalCount: 1200,
  currentPage: 1,
  isLoading: false,
  isUpdating: false,
  error: null,
  changePage: jest.fn(),
  clearParametersUniverse: jest.fn(),
  clearError: jest.fn()
});

describe('InstrumentUniverse component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.exists('.parametersUniverseContainer')).toBe(true);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.parametersUniverseContent')).toBe(false);
  });

  it('should render content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.exists('.parametersUniverseContent')).toBe(true);
  });

  it('should render instruments table with props', () => {
    // given
    const props = getInitialProps();
    const expectedGridProps = {
      tableData: [
        {
          isin: 'isin0',
          instrumentName: 'instrument0',
          tradingCurrency: 'EUR',
          buy: false
        },
        {
          isin: 'isin1',
          instrumentName: 'instrument1',
          tradingCurrency: 'USD',
          buy: true
        }
      ],
      enableFilter: false,
      hasFixedHeight: true
    };

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.find(AgGridTable)).toHaveLength(1);
    expect(enzymeWrapper.find(AgGridTable).hasClass('parametersUniverseGrid')).toBe(true);
    const gridProps = enzymeWrapper.find(AgGridTable).props();
    expect(gridProps.tableData).toEqual(expectedGridProps.tableData);
    expect(gridProps.enableFilter).toEqual(expectedGridProps.enableFilter);
    expect(gridProps.hasFixedHeight).toEqual(expectedGridProps.hasFixedHeight);
  });

  it('should render pagination with props', () => {
    // given
    const props = getInitialProps();
    const expectedPaginationProps = {
      currentPage: 1,
      totalPages: Math.ceil(1200 / PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE),
      onPageChange: props.changePage
    };

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.exists('.parametersUniversePagination')).toBe(true);
    expect(enzymeWrapper.find(PaginationBar)).toHaveLength(1);
    const paginationProps = enzymeWrapper.find(PaginationBar).props();
    expect(paginationProps.currentPage).toEqual(expectedPaginationProps.currentPage);
    expect(paginationProps.totalPages).toEqual(expectedPaginationProps.totalPages);
    paginationProps.onPageChange();
    expect(props.changePage.mock.calls.length).toBe(1);
  });

  it('should render checkout status with props', () => {
    // given
    const props = getInitialProps();
    const expectedStatusProps = {
      feedName: 'universe'
    };

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.find(ParametersDetailsStatus)).toHaveLength(1);
    const statusProps = enzymeWrapper.find(ParametersDetailsStatus).props();
    expect(statusProps.feedName).toEqual(expectedStatusProps.feedName);
  });

  it('should render ErrorMessage if error !== null', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    errorMessageProps.onDismiss();
    expect(props.clearError.mock.calls.length).toBe(1);
  });

  it('should render Updater (with content) if isUpdating === true', () => {
    // given
    const props = getInitialProps();
    props.isUpdating = true;

    // when
    const enzymeWrapper = shallow(<InstrumentUniverse {...props} />);

    // then
    expect(enzymeWrapper.find(Dimmer)).toHaveLength(1);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.parametersUniverseContent')).toBe(true);
  });
});
