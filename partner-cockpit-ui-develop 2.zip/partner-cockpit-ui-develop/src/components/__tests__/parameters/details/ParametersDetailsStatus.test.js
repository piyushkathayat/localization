import React from 'react';
import { shallow } from 'enzyme';
import ParametersDetailsStatus from 'components/parameters/details/ParametersDetailsStatus';
import ParameterStatus from 'components/parameters/common/ParameterStatus';

const getInitialProps = () => ({
  feedName: 'saa'
});

describe('ParametersDetailsStatus component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ParametersDetailsStatus {...props} />);

    // then
    expect(enzymeWrapper.exists('.parametersDetailsStatus')).toBe(true);
  });

  it('should render ParameterStatus with props', () => {
    // given
    const props = getInitialProps();
    const expectedStatusProps = {
      feedName: 'saa'
    };

    // when
    const enzymeWrapper = shallow(<ParametersDetailsStatus {...props} />);

    // then
    expect(enzymeWrapper.find(ParameterStatus)).toHaveLength(1);
    const statusProps = enzymeWrapper.find(ParameterStatus).props();
    expect(statusProps.feedName).toEqual(expectedStatusProps.feedName);
  });
});
