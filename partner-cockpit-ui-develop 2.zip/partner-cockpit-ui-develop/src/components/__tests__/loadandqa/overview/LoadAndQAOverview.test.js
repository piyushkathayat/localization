import React from 'react';
import { shallow } from 'enzyme';
import { Breadcrumb, Loader, Dimmer } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { DB_TYPES, SERVER_TYPES } from 'constants/serverInfo';
import { ErrorMessage, NoResults } from 'components/common';
import { LoadAndQAOverview } from 'components/loadandqa/overview/LoadAndQAOverview';
import ServerTable from 'components/loadandqa/overview/ServerTable';
import Status from 'components/loadandqa/common/Status';

const getInitialProps = () => ({
  centralDBData: [
    {
      id: '2-central',
      activityId: 2,
      activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
      activityName: 'LK Tables',
      activityOwner: 'central',
      activityInstance: 2,
      elapsedSec: 10,
      averageDuration: 15,
      averageDeviation: 6,
      issues: 0,
      issueHistory: [],
      actions: [],
      statusCode: ACTIVITY_STATUSES.FINISHED,
      percentage: 100
    },
    {
      id: '18-central',
      activityId: 18,
      activityKey: 'a3fc6f08-ca59-44ea-bf73-66ac427aeb63',
      activityName: 'Panacea',
      activityOwner: 'central',
      activityInstance: 2,
      elapsedSec: 10,
      averageDuration: 15,
      averageDeviation: 6,
      issues: 1,
      issueHistory: [],
      actions: [],
      statusCode: ACTIVITY_STATUSES.ERROR,
      percentage: 0
    }
  ],
  partnerDBData: [
    {
      id: '3-WS004',
      activityId: 3,
      activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
      activityName: 'Lipper',
      activityOwner: 'WS004',
      activityInstance: 2,
      elapsedSec: 10,
      averageDuration: 15,
      averageDeviation: 6,
      issues: 1,
      issueHistory: [],
      actions: [],
      statusCode: ACTIVITY_STATUSES.FINISHED,
      percentage: 100
    },
    {
      id: '7-WS004',
      activityId: 7,
      activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
      activityName: 'Snowman',
      activityOwner: 'WS004',
      activityInstance: 2,
      elapsedSec: 10,
      averageDuration: 15,
      averageDeviation: 6,
      issues: 1,
      issueHistory: [],
      actions: [],
      statusCode: ACTIVITY_STATUSES.ERROR,
      percentage: 0
    }
  ],
  partnerJobs: [
    {
      key: '23c4885f-fa30-4fcc-b2e1-2161e5742813',
      value: 'Copy Test Files'
    },
    {
      key: 'bd20617d-1ec9-449c-a3b8-79863e360deb',
      value: 'LK Tables'
    }
  ],
  centralJobs: [
    {
      key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
      value: 'Get Central Instruments'
    },
    {
      key: '0085e781-e1ca-454f-965a-5201d163cd62',
      value: 'MiniCentral Extract'
    }
  ],
  serverType: SERVER_TYPES.STAGING,
  isJobStarting: false,
  isLoading: false,
  error: null,
  clearError: jest.fn()
});

describe('LoadAndQAOverview component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.loadAndQAOverviewContainer')).toBe(true);
  });

  it('should render breadcrumbs with props', () => {
    // given
    const props = getInitialProps();
    const expectedBreadcrumbsSections = [
      {
        key: 'Overview',
        content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
        active: true
      }
    ];

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Breadcrumb)).toHaveLength(1);
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.className).toEqual('breadcrumbsContainer');
    expect(breadcrumbsProps.icon).toEqual('right angle');
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsSections);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.loadAndQATables')).toBe(false);
  });

  it('should render NoResults if there is no activities', () => {
    // given
    const props = getInitialProps();
    props.centralDBData = [];
    props.partnerDBData = [];

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.exists('.loadAndQATables')).toBe(false);
  });

  it('should render a content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(0);
    expect(enzymeWrapper.exists('.loadAndQATables')).toBe(true);
  });

  it('should render a central ServerTable with a props', () => {
    // given
    const props = getInitialProps();
    props.partnerDBData = [];
    const expectedServerTableProps = {
      title: <FormattedMessage defaultMessage="Central DB" id="load_and_qa.central_db" />,
      activities: props.centralDBData,
      dbType: DB_TYPES.CENTRAL,
      jobs: props.centralJobs,
      isJobStarting: props.isJobStarting
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(ServerTable)).toHaveLength(1);
    const serverTableProps = enzymeWrapper.find(ServerTable).props();
    expect(serverTableProps.title).toEqual(expectedServerTableProps.title);
    expect(serverTableProps.activities).toEqual(expectedServerTableProps.activities);
    expect(serverTableProps.dbType).toEqual(expectedServerTableProps.dbType);
    expect(serverTableProps.jobs).toEqual(expectedServerTableProps.jobs);
  });

  it('should render a partner ServerTable with a props', () => {
    // given
    const props = getInitialProps();
    props.centralDBData = [];
    const expectedServerTableProps = {
      title: <FormattedMessage defaultMessage="Data Staging" id="load_and_qa.data_staging" />,
      activities: props.partnerDBData,
      dbType: DB_TYPES.PARTNER,
      jobs: props.partnerJobs,
      isJobStarting: props.isJobStarting
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(ServerTable)).toHaveLength(1);
    const serverTableProps = enzymeWrapper.find(ServerTable).props();
    expect(serverTableProps.title).toEqual(expectedServerTableProps.title);
    expect(serverTableProps.activities).toEqual(expectedServerTableProps.activities);
    expect(serverTableProps.dbType).toEqual(expectedServerTableProps.dbType);
    expect(serverTableProps.jobs).toEqual(expectedServerTableProps.jobs);
  });

  it('should render a partner ServerTable with a proper title - SERVER_TYPES.CENTRAL', () => {
    // given
    const props = getInitialProps();
    props.centralDBData = [];
    props.serverType = SERVER_TYPES.CENTRAL;
    const expectedServerTableProps = {
      title: <FormattedMessage defaultMessage="Data Central" id="load_and_qa.data_central" />
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    const serverTableProps = enzymeWrapper.find(ServerTable).props();
    expect(serverTableProps.title).toEqual(expectedServerTableProps.title);
  });

  it('should render a partner ServerTable with a proper title - SERVER_TYPES.SHADOW', () => {
    // given
    const props = getInitialProps();
    props.centralDBData = [];
    props.serverType = SERVER_TYPES.SHADOW;
    const expectedServerTableProps = {
      title: <FormattedMessage defaultMessage="Data Shadow" id="load_and_qa.data_shadow" />
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    const serverTableProps = enzymeWrapper.find(ServerTable).props();
    expect(serverTableProps.title).toEqual(expectedServerTableProps.title);
  });

  it('should render a partner ServerTable with a proper title - SERVER_TYPES.LIVE', () => {
    // given
    const props = getInitialProps();
    props.centralDBData = [];
    props.serverType = SERVER_TYPES.LIVE;
    const expectedServerTableProps = {
      title: <FormattedMessage defaultMessage="Data Live" id="load_and_qa.data_live" />
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    const serverTableProps = enzymeWrapper.find(ServerTable).props();
    expect(serverTableProps.title).toEqual(expectedServerTableProps.title);
  });

  it('should render both tables', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(ServerTable)).toHaveLength(2);
  });

  it('should render legend', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.legend')).toBe(true);
    expect(enzymeWrapper.find(Status)).toHaveLength(5);
    const statusWrapper = enzymeWrapper.find(Status);
    expect(statusWrapper.at(0).props().status).toEqual(ACTIVITY_STATUSES.ERROR);
    expect(statusWrapper.at(1).props().status).toEqual(ACTIVITY_STATUSES.FINISHED);
    expect(statusWrapper.at(2).props().status).toEqual(ACTIVITY_STATUSES.WARNING);
    expect(statusWrapper.at(3).props().status).toEqual(ACTIVITY_STATUSES.DELTA);
    expect(statusWrapper.at(4).props().status).toEqual(ACTIVITY_STATUSES.STOPPED);
    expect(enzymeWrapper.find('.legendStatusLabel')).toHaveLength(5);
  });

  it('should render ErrorMessage if error !== null', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    expect(errorMessageProps.onDismiss).toBe(props.clearError);
  });

  it('should render Loader with Dimmer if isJobStarting === true', () => {
    // given
    const props = getInitialProps();
    props.isJobStarting = true;

    // when
    const enzymeWrapper = shallow(<LoadAndQAOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.dimmerContainer')).toBe(true);
    expect(enzymeWrapper.find(Dimmer)).toHaveLength(1);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });
});
