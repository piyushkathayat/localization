import React from 'react';
import { shallow } from 'enzyme';
import { Table, Popup, Dropdown, Button } from 'semantic-ui-react';
import { FormattedMessage, FormattedNumber } from 'react-intl';
import { Link } from 'react-router-dom';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { DB_TYPES, SERVER_TYPES } from 'constants/serverInfo';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import { DateAndTime, LineGraph, ConfirmModal } from 'components/common';
import { ServerTable } from 'components/loadandqa/overview/ServerTable';
import Status from 'components/loadandqa/common/Status';

const getInitialProps = () => ({
  title: <FormattedMessage defaultMessage="Central DB" id="load_and_qa.central_db" />,
  activities: [
    {
      id: '2-central',
      activityId: 2,
      activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
      activityName: 'LK Tables',
      activityOwner: 'central',
      activityInstance: 2,
      elapsedSec: 10,
      averageDuration: 15,
      averageDeviation: 6,
      issues: 0,
      issueHistory: [
        {
          activityDate: '2019-01-10T00:00:00',
          sumIssues: 0
        },
        {
          activityDate: '2019-01-11T00:00:00',
          sumIssues: 0
        }
      ],
      actions: [],
      statusCode: ACTIVITY_STATUSES.FINISHED,
      percentage: 100,
      message: '',
      startTime: '2019-01-11T07:31:05.08',
      endTime: '2019-01-11T07:31:15.08',
      hasFeedAgeCheck: true,
      hasOutdatedCheck: false,
      isFeedAgeCheckViolated: false,
      isOutdatedCheckViolated: null,
      feedAgeDate: '2019-01-13T00:00:00',
      outdatedFeedDate: null
    },
    {
      id: '18-central',
      activityId: 18,
      activityKey: 'a3fc6f08-ca59-44ea-bf73-66ac427aeb63',
      activityName: 'Panacea',
      activityOwner: 'central',
      activityInstance: 2,
      elapsedSec: 10,
      averageDuration: 15,
      averageDeviation: 6,
      issues: 1,
      issueHistory: [],
      actions: [],
      statusCode: ACTIVITY_STATUSES.ERROR,
      percentage: 0,
      message: '',
      startTime: '2019-01-11T07:31:05.08',
      endTime: '2019-01-11T07:31:15.08',
      hasFeedAgeCheck: true,
      hasOutdatedCheck: false,
      isFeedAgeCheckViolated: false,
      isOutdatedCheckViolated: null,
      feedAgeDate: '2019-01-13T00:00:00',
      outdatedFeedDate: null
    }
  ],
  dbType: DB_TYPES.CENTRAL,
  jobs: [
    {
      key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
      value: 'Get Central Instruments'
    },
    {
      key: '0085e781-e1ca-454f-965a-5201d163cd62',
      value: 'MiniCentral Extract'
    }
  ],
  serverType: SERVER_TYPES.CENTRAL,
  startJob: jest.fn(),
  stopJob: jest.fn()
});

describe('ServerTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.serverTableContainer')).toBe(true);
  });

  it('should render title', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.title')).toBe(true);
    expect(enzymeWrapper.find('.title').find(FormattedMessage)).toHaveLength(1);
  });

  it('should render table', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table)).toHaveLength(1);
    expect(enzymeWrapper.find(Table).hasClass('serverTable')).toBe(true);
    expect(enzymeWrapper.find(Table).hasClass('cockpitTable')).toBe(true);
  });

  it('should render table header', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Header).hasClass('tableHeader')).toBe(true);
    expect(enzymeWrapper.find(Table.Header).hasClass('serverTableHeader')).toBe(true);
  });

  it('should render table header with 5 columns for central server', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.HeaderCell)).toHaveLength(5);
  });

  it('should render table header with 6 columns for any other server', () => {
    // given
    const props = getInitialProps();
    props.serverType = SERVER_TYPES.STAGING;

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.HeaderCell)).toHaveLength(6);
  });

  it('should render table body', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Body)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Body).hasClass('tableBody')).toBe(true);
    expect(enzymeWrapper.find(Table.Body).hasClass('serverTableBody')).toBe(true);
  });

  it('should render all the activities', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.find('.activityRow')).toHaveLength(2);
  });

  it('should render 5 columns for central server', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const activityRowWrapper = enzymeWrapper.find('.activityRow').first();
    expect(activityRowWrapper.find(Table.Cell)).toHaveLength(5);
  });

  it('should render 6 columns for any other server', () => {
    // given
    const props = getInitialProps();
    props.serverType = SERVER_TYPES.SHADOW;

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const activityRowWrapper = enzymeWrapper.find('.activityRow').first();
    expect(activityRowWrapper.find(Table.Cell)).toHaveLength(6);
  });

  it('should render proper activityRow cells: Status warning icon for feed age check violation', () => {
    // given
    const props = getInitialProps();
    props.activities[0].isFeedAgeCheckViolated = true;

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const statusWrapper = enzymeWrapper.find('.activityRow').first().find(Status);
    expect(statusWrapper).toHaveLength(1);
    expect(statusWrapper.props().status).toEqual(ACTIVITY_STATUSES.WARNING);
    expect(statusWrapper.props().percentage).toEqual(100);
    expect(statusWrapper.props().errorMessage).toEqual('');
    expect(statusWrapper.props().showErrorPopup).toEqual(true);
  });

  it('should render proper activityRow cells: Status warning icon for outdated violation', () => {
    // given
    const props = getInitialProps();
    props.activities[0].isOutdatedCheckViolated = true;

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const statusWrapper = enzymeWrapper.find('.activityRow').first().find(Status);
    expect(statusWrapper).toHaveLength(1);
    expect(statusWrapper.props().status).toEqual(ACTIVITY_STATUSES.WARNING);
    expect(statusWrapper.props().percentage).toEqual(100);
    expect(statusWrapper.props().errorMessage).toEqual('');
    expect(statusWrapper.props().showErrorPopup).toEqual(true);
  });

  it('should render proper activityRow cells: Status error even when outdated', () => {
    // given
    const props = getInitialProps();
    props.activities[0].isOutdatedSuccessful = true;
    props.activities[0].statusCode = ACTIVITY_STATUSES.ERROR;

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const statusWrapper = enzymeWrapper.find('.activityRow').first().find(Status);
    expect(statusWrapper).toHaveLength(1);
    expect(statusWrapper.props().status).toEqual(ACTIVITY_STATUSES.ERROR);
    expect(statusWrapper.props().percentage).toEqual(100);
    expect(statusWrapper.props().errorMessage).toEqual('');
    expect(statusWrapper.props().showErrorPopup).toEqual(true);
  });

  it('should render proper activityRow cells: Status icon', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const statusWrapper = enzymeWrapper.find('.activityRow').first().find(Status);
    expect(statusWrapper).toHaveLength(1);
    expect(statusWrapper.props().status).toEqual(ACTIVITY_STATUSES.FINISHED);
    expect(statusWrapper.props().percentage).toEqual(100);
    expect(statusWrapper.props().errorMessage).toEqual('');
    expect(statusWrapper.props().showErrorPopup).toEqual(true);
  });

  it('should render proper activityRow cells: Popup activity name', () => {
    // given
    const props = getInitialProps();
    const expectedPopupProps = {
      trigger: (
        <Link
          className="nameTitle"
          to={`/${APP_PREFIX}/${MENU_ITEMS.LOAD}/2-central`}
        >
          LK Tables
        </Link>
      ),
      position: 'bottom center'
    };

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const popupWrapper = enzymeWrapper.find('.activityRow').first().find(Popup);
    expect(popupWrapper).toHaveLength(1);
    expect(popupWrapper.hasClass('activityPopup')).toBe(true);
    expect(popupWrapper.props().trigger).toEqual(expectedPopupProps.trigger);
    expect(popupWrapper.props().position).toEqual(expectedPopupProps.position);
  });

  it('should render proper activityRow cells: Last Run', () => {
    // given
    const DATE_TO_USE = Date.now();
    global.Date.now = jest.fn(() => DATE_TO_USE);
    const props = getInitialProps();
    const expectedDateAndTimeProps = {
      relative: true,
      value: DATE_TO_USE - props.activities[0].elapsedSec * 1000
    };

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const dateAndTimeWrapper = enzymeWrapper.find('.activityRow').first().find(DateAndTime);
    expect(dateAndTimeWrapper).toHaveLength(1);
    const dateAndTimeProps = dateAndTimeWrapper.props();
    expect(dateAndTimeProps.relative).toEqual(expectedDateAndTimeProps.relative);
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should render proper activityRow cells: no Last Run (if not presented)', () => {
    // given
    const props = getInitialProps();
    props.activities[0].endTime = null;

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const dateAndTimeWrapper = enzymeWrapper.find('.activityRow').first().find(DateAndTime);
    expect(dateAndTimeWrapper).toHaveLength(0);
  });

  it('should render proper activityRow cells: issues', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const issuesWrapper = enzymeWrapper.find('.activityRow').first().find(FormattedNumber);
    expect(issuesWrapper).toHaveLength(1);
    expect(issuesWrapper.props().value).toEqual(0);
  });

  it('should render proper activityRow cells: LineGraph', () => {
    // given
    const props = getInitialProps();
    const expectedChartData = [
      {
        date: '2019-01-10T00:00:00',
        value: 0
      },
      {
        date: '2019-01-11T00:00:00',
        value: 0
      }
    ];

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const activityRowWrapper = enzymeWrapper.find('.activityRow').first();
    expect(activityRowWrapper.exists('.issueHistoryGraph')).toBe(true);
    expect(activityRowWrapper.find(LineGraph)).toHaveLength(1);
    expect(activityRowWrapper.find(LineGraph).props().chartData).toEqual(expectedChartData);
  });

  it('should render table footer', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.footer')).toBe(true);
    const footerWrapper = enzymeWrapper.find('.footer');
    expect(footerWrapper.find(Dropdown)).toHaveLength(1);
    expect(footerWrapper.find(Button)).toHaveLength(2);
  });

  it('should render proper footer: Dropdown', () => {
    // given
    const props = getInitialProps();
    const expectedDropdownProps = {
      options: [
        {
          text: 'Get Central Instruments',
          value: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
        },
        {
          text: 'MiniCentral Extract',
          value: '0085e781-e1ca-454f-965a-5201d163cd62'
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const dropdownWrapper = enzymeWrapper.find('.footer').find(Dropdown);
    expect(dropdownWrapper.hasClass('jobsDropdown')).toBe(true);
    expect(dropdownWrapper.props().options).toEqual(expectedDropdownProps.options);
    dropdownWrapper.simulate('change', {}, {
      value: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
    });
    expect(enzymeWrapper.find('.footer').find(Button).at(0).props().disabled).toBe(false);
    expect(enzymeWrapper.find('.footer').find(Button).at(1).props().disabled).toBe(false);
  });

  it('should render proper footer: Start Button', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const buttonWrapper = enzymeWrapper.find('.footer').find(Button).at(0);
    expect(buttonWrapper.hasClass('ubs-primary-button')).toBe(true);
    buttonWrapper.simulate('click');
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(1);
  });

  it('should render proper footer: Stop Button', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    const buttonWrapper = enzymeWrapper.find('.footer').find(Button).at(1);
    expect(buttonWrapper.hasClass('ubs-secondary-button')).toBe(true);
    buttonWrapper.simulate('click');
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(1);
  });

  it('should handle ConfirmPopup actions: cancel', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    enzymeWrapper.find('.footer').find(Button).at(0).simulate('click');
    const modalWrapper = enzymeWrapper.find(ConfirmModal);
    modalWrapper.props().onCancel();
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  });

  it('should handle ConfirmPopup actions: confirm start job', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    enzymeWrapper.find('.footer').find(Dropdown).simulate('change', {}, {
      value: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
    });
    enzymeWrapper.find('.footer').find(Button).at(0).simulate('click');
    const modalWrapper = enzymeWrapper.find(ConfirmModal);
    modalWrapper.props().onConfirm();
    expect(props.startJob.mock.calls.length).toBe(1);
    expect(props.startJob.mock.calls[0][0]).toBe('f78dc9be-e4a1-42f3-8cf8-6202b646f216');
    expect(props.startJob.mock.calls[0][1]).toBe(props.dbType);
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  });

  it('should handle ConfirmPopup actions: confirm stop job', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ServerTable {...props} />);

    // then
    enzymeWrapper.find('.footer').find(Dropdown).simulate('change', {}, {
      value: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
    });
    enzymeWrapper.find('.footer').find(Button).at(1).simulate('click');
    const modalWrapper = enzymeWrapper.find(ConfirmModal);
    modalWrapper.props().onConfirm();
    expect(props.stopJob.mock.calls.length).toBe(1);
    expect(props.stopJob.mock.calls[0][0]).toBe('f78dc9be-e4a1-42f3-8cf8-6202b646f216');
    expect(props.stopJob.mock.calls[0][1]).toBe(props.dbType);
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  });
});
