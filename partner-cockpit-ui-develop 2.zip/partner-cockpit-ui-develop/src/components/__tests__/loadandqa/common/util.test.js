import { formatGraphData } from 'components/loadandqa/common/util';

describe('LoadAndQA util functions', () => {
  it('should formatGraphData', () => {
    // given
    const daysList = [
      {
        activityDate: '2019-01-21T00:00:00',
        sumIssues: 0
      },
      {
        activityDate: '2019-01-22T00:00:00',
        sumIssues: 0
      }
    ];
    const expectedGraphData = [
      {
        date: '2019-01-21T00:00:00',
        value: 0
      },
      {
        date: '2019-01-22T00:00:00',
        value: 0
      }
    ];

    // when
    const graphData = formatGraphData(daysList);

    // then
    expect(graphData).toEqual(expectedGraphData);
  });
});
