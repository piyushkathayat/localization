import React from 'react';
import { shallow } from 'enzyme';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import CircularProgressbar from 'react-circular-progressbar';
import { Popup } from 'semantic-ui-react';
import Status from 'components/loadandqa/common/Status';

const getInitialProps = () => ({
  status: ACTIVITY_STATUSES.FINISHED,
  percentage: 100,
  errorMessage: '',
  showErrorPopup: true
});

describe('Status component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.exists('.statusIconContainer')).toBe(true);
  });

  it('should render status properly: FINISHED', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find('.statusIconContainer').hasClass('success')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-ok')).toBe(true);
  });

  it('should render status properly: ERROR - icon', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.ERROR;
    props.showErrorPopup = false;

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find('.statusIconContainer').hasClass('error')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-flash')).toBe(true);
  });

  it('should render status properly: ERROR - popup', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.ERROR;
    props.errorMessage = 'some error';
    const expectedPopupTrigger = (
      <div className="statusIconContainer error">
        <i className="icon-ubs icon-flash" />
      </div>
    );

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find(Popup)).toHaveLength(1);
    expect(enzymeWrapper.find(Popup).prop('content')).toContain('some error');
    expect(enzymeWrapper.find(Popup).prop('trigger')).toEqual(expectedPopupTrigger);
  });

  it('should render status properly: RUNNING', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.RUNNING;
    props.percentage = 60;
    const expectedBarProps = {
      percentage: 60,
      strokeWidth: 5,
      background: true,
      backgroundPadding: 0
    };

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find(CircularProgressbar)).toHaveLength(1);
    const barProps = enzymeWrapper.find(CircularProgressbar).props();
    expect(barProps.percentage).toEqual(expectedBarProps.percentage);
    expect(barProps.strokeWidth).toEqual(expectedBarProps.strokeWidth);
    expect(barProps.background).toEqual(expectedBarProps.background);
    expect(barProps.backgroundPadding).toEqual(expectedBarProps.backgroundPadding);
  });

  it('should render status properly: DELTA', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.DELTA;

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find('.statusIconContainer').hasClass('delta')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-flag')).toBe(true);
  });

  it('should render status properly: INIT', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.INIT;

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find('.statusIconContainer').hasClass('init')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(false);
  });

  it('should render status properly: STOPPED', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.STOPPED;

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find('.statusIconContainer').hasClass('stopped')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-stop')).toBe(true);
  });

  it('should render status properly: WARNING', () => {
    // given
    const props = getInitialProps();
    props.status = ACTIVITY_STATUSES.WARNING;

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.find('.statusIconContainer').hasClass('warning')).toBe(true);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.icon-ubs').hasClass('icon-ok')).toBe(true);
  });

  it('should render null with unknown status', () => {
    // given
    const props = getInitialProps();
    props.status = 'some unknown status';

    // when
    const enzymeWrapper = shallow(<Status {...props} />);

    // then
    expect(enzymeWrapper.exists('.statusIconContainer')).toBe(false);
    expect(enzymeWrapper.exists('.icon-ubs')).toBe(false);
  });
});
