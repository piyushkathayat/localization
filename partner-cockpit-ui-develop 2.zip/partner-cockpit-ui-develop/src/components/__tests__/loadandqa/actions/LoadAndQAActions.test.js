import React from 'react';
import { shallow } from 'enzyme';
import { Link } from 'react-router-dom';
import { Loader, Table } from 'semantic-ui-react';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { ErrorMessage, NoResults, LineGraph, DateAndTime } from 'components/common';
import { LoadAndQAActions } from 'components/loadandqa/actions/LoadAndQAActions';
import Status from 'components/loadandqa/common/Status';

const getInitialProps = () => ({
  actions: [
    {
      actionDescription: 'Check that files are available and correct ("OK files")',
      actionId: 126,
      activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
      averageDeviation: 0,
      averageDuration: 0,
      drillDownKey: '',
      drillDownType: '',
      duration: 1,
      endTime: '2019-01-11T07:30:25.047',
      elapsedSec: 10,
      issueHistory: [
        {
          activityDate: '2019-01-09T00:00:00',
          sumIssues: 0
        },
        {
          activityDate: '2019-01-10T00:00:00',
          sumIssues: 0
        }
      ],
      issues: 0,
      message: '',
      percentage: 100,
      startTime: '2019-01-11T07:30:24.99',
      statusCode: 'FINISHED'
    },
    {
      actionDescription: 'Create temporary tables',
      actionId: 118,
      activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
      averageDeviation: 0,
      averageDuration: 0,
      drillDownKey: '1323',
      drillDownType: 'FILE',
      duration: 0,
      endTime: '',
      elapsedSec: 10,
      issueHistory: [],
      issues: 0,
      message: '',
      percentage: 100,
      startTime: '2019-01-11T07:30:25.397',
      statusCode: 'FINISHED'
    }
  ],
  isLoading: false,
  error: null,
  clearError: jest.fn(),
  match: {
    url: '/cockpit/load/2-central'
  }
});

describe('LoadAndQAActions component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.exists('.loadAndQAActionsContainer')).toBe(true);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.actionsContent')).toBe(false);
  });

  it('should render NoResults if there is no actions', () => {
    // given
    const props = getInitialProps();
    props.actions = [];

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.exists('.actionsContent')).toBe(false);
  });

  it('should render a content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(0);
    expect(enzymeWrapper.exists('.actionsContent')).toBe(true);
  });

  it('should render a Details Table', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(Table)).toHaveLength(1);
    expect(enzymeWrapper.find(Table).hasClass('cockpitTable')).toBe(true);
    expect(enzymeWrapper.find(Table).hasClass('actionsTable')).toBe(true);
  });

  it('should render a Details Table header with 5 columns', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Header).hasClass('tableHeader')).toBe(true);
    expect(enzymeWrapper.find(Table.HeaderCell)).toHaveLength(5);
  });

  it('should render a Details Table body with 2 rows by 5 columns', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Body)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Body).hasClass('tableBody')).toBe(true);
    const tableBodyWrapper = enzymeWrapper.find(Table.Body);
    expect(tableBodyWrapper.find(Table.Row)).toHaveLength(2);
    expect(tableBodyWrapper.find(Table.Cell)).toHaveLength(10);
  });

  it('should render Status', () => {
    // given
    const props = getInitialProps();
    const expectedStatusProps = {
      status: 'FINISHED',
      percentage: 100,
      errorMessage: '',
      showErrorPopup: true
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).first();
    expect(firstRowWrapper.find(Status)).toHaveLength(1);
    const statusProps = firstRowWrapper.find(Status).props();
    expect(statusProps.status).toEqual(expectedStatusProps.status);
    expect(statusProps.percentage).toEqual(expectedStatusProps.percentage);
    expect(statusProps.errorMessage).toEqual(expectedStatusProps.errorMessage);
    expect(statusProps.showErrorPopup).toEqual(expectedStatusProps.showErrorPopup);
  });

  it('should render actionDescription with no drilldown', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).first();
    expect(firstRowWrapper.find(Table.Cell).at(1).render().text())
      .toEqual('Check that files are available and correct ("OK files")');
  });

  it('should render actionDescription with drilldown', () => {
    // given
    const props = getInitialProps();
    const expectedLinkProps = {
      to: '/cockpit/load/2-central/FILE/1323'
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const secondRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).at(1);
    expect(secondRowWrapper.find(Link)).toHaveLength(1);
    const linkProps = secondRowWrapper.find(Link).props();
    expect(linkProps.to).toEqual(expectedLinkProps.to);
  });

  it('should render Last Run if presented', () => {
    // given
    const DATE_TO_USE = Date.now();
    global.Date.now = jest.fn(() => DATE_TO_USE);
    const props = getInitialProps();
    const expectedDateAndTimeProps = {
      relative: true,
      value: DATE_TO_USE - props.actions[0].elapsedSec * 1000
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).first();
    expect(firstRowWrapper.find(DateAndTime)).toHaveLength(1);
    const dateAndTimeProps = firstRowWrapper.find(DateAndTime).props();
    expect(dateAndTimeProps.relative).toEqual(expectedDateAndTimeProps.relative);
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should render no endTime if not presented', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const secondRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).at(1);
    expect(secondRowWrapper.find(DateAndTime)).toHaveLength(0);
  });

  it('should render issues', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).first();
    expect(firstRowWrapper.find('.issuesColumn')).toHaveLength(1);
    expect(firstRowWrapper.find('.issuesColumn').render().text()).toEqual('0');
  });

  it('should render LineGraph', () => {
    // given
    const props = getInitialProps();
    const expectedLineGraphProps = {
      chartData: [
        {
          date: '2019-01-09T00:00:00',
          value: 0
        },
        {
          date: '2019-01-10T00:00:00',
          value: 0
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).first();
    expect(firstRowWrapper.find(LineGraph)).toHaveLength(1);
    const lineGraphProps = firstRowWrapper.find(LineGraph).props();
    expect(lineGraphProps.chartData).toEqual(expectedLineGraphProps.chartData);
  });

  it('should render legend', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.exists('.legend')).toBe(true);
    expect(enzymeWrapper.find('.legendStatus')).toHaveLength(4);
    const legendWrapper = enzymeWrapper.find('.legend');
    expect(legendWrapper.find(Status)).toHaveLength(4);
    expect(legendWrapper.find(Status).at(0).props().status).toEqual(ACTIVITY_STATUSES.ERROR);
    expect(legendWrapper.find(Status).at(1).props().status).toEqual(ACTIVITY_STATUSES.FINISHED);
    expect(legendWrapper.find(Status).at(2).props().status).toEqual(ACTIVITY_STATUSES.INIT);
    expect(legendWrapper.find(Status).at(3).props().status).toEqual(ACTIVITY_STATUSES.STOPPED);
  });

  it('should render ErrorMessage if error !== null', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';

    // when
    const enzymeWrapper = shallow(<LoadAndQAActions {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    errorMessageProps.onDismiss();
    expect(props.clearError.mock.calls.length).toBe(1);
  });
});
