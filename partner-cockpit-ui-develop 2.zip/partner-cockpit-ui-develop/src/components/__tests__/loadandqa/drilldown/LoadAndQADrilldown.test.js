import React from 'react';
import { shallow } from 'enzyme';
import { DRILLDOWN_TYPES } from 'constants/loadAndQA';
import { Loader } from 'semantic-ui-react';
import { ErrorMessage, NoResults } from 'components/common';
import { LoadAndQADrilldown } from 'components/loadandqa/drilldown/LoadAndQADrilldown';
import LoadAndQADrilldownTable from 'components/loadandqa/drilldown/LoadAndQADrilldownTable';

// TODO: update

const getInitialProps = () => ({
  drilldowns: [
    {
      brsCode: 'UBS-PAN-3.1',
      description: 'Not all country, currency, and sector breakdowns add up to 100%',
      drilldownDetail: 87,
      drilldownKey: 'PANACEA',
      drilldownType: 'QA',
      hasDetail: 1,
      issueHistory: [],
      numberOfIssues: 2
    },
    {
      brsCode: 'UBS-PAN-XX.X1',
      description: 'Sum(contributed_weight) = 0.0 in table datacycle.panacea_weight_allocation',
      drilldownDetail: 88,
      drilldownKey: 'PANACEA',
      drilldownType: 'QA',
      hasDetail: 0,
      issueHistory: [],
      numberOfIssues: 0
    }
  ],
  drilldownType: DRILLDOWN_TYPES.QA,
  isLoading: false,
  error: null,
  clearError: jest.fn(),
  clearLoadAndQADrilldown: jest.fn()
});

describe('LoadAndQADrilldown component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.exists('.drilldownContainer')).toBe(true);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.drilldownContent')).toBe(false);
  });

  it('should render NoResults instead of a content if drilldowns is empty', () => {
    // given
    const props = getInitialProps();
    props.drilldowns = [];

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.exists('.drilldownContent')).toBe(false);
  });

  it('should render content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.exists('.drilldownContent')).toBe(true);
  });

  it('should render proper table depends on drilldownType: TableQA', () => {
    // given
    const props = getInitialProps();
    const expectedTableProps = {
      drilldowns: [
        {
          brsCode: 'UBS-PAN-3.1',
          description: 'Not all country, currency, and sector breakdowns add up to 100%',
          drilldownDetail: 87,
          drilldownKey: 'PANACEA',
          drilldownType: 'QA',
          hasDetail: 1,
          issueHistory: [],
          numberOfIssues: 2
        },
        {
          brsCode: 'UBS-PAN-XX.X1',
          description: 'Sum(contributed_weight) = 0.0 in table datacycle.panacea_weight_allocation',
          drilldownDetail: 88,
          drilldownKey: 'PANACEA',
          drilldownType: 'QA',
          hasDetail: 0,
          issueHistory: [],
          numberOfIssues: 0
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQADrilldownTable)).toHaveLength(1);
    const tableProps = enzymeWrapper.find(LoadAndQADrilldownTable).props();
    expect(tableProps.drilldowns).toEqual(expectedTableProps.drilldowns);
  });

  it('should render proper table depends on drilldownType: TableValidation', () => {
    // given
    const props = getInitialProps();
    props.drilldownType = DRILLDOWN_TYPES.VALIDATION;
    props.drilldowns = [
      {
        databaseName: 'CommonFeed',
        drilldownDetail: 'CommonFeed.panacea_benchmark',
        drilldownKey: 1559,
        drilldownType: 'VALIDATION',
        hasDetail: 0,
        invalidRows: 0,
        issueHistory: [],
        schemaName: 'datacycle',
        tableName: 'panacea_benchmark'
      },
      {
        databaseName: 'CommonFeed',
        drilldownDetail: 'CommonFeed.panacea_weight_allocation',
        drilldownKey: 1559,
        drilldownType: 'VALIDATION',
        hasDetail: 1,
        invalidRows: 6,
        issueHistory: [],
        schemaName: 'datacycle',
        tableName: 'panacea_weight_allocation'
      }
    ];

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQADrilldownTable)).toHaveLength(1);
    const tableProps = enzymeWrapper.find(LoadAndQADrilldownTable).props();
    expect(tableProps.drilldowns).toEqual(props.drilldowns);
  });

  it('should render proper table depends on drilldownType: TableFile', () => {
    // given
    const props = getInitialProps();
    props.drilldownType = DRILLDOWN_TYPES.FILE;
    props.drilldowns = [
      {
        drilldownDetail: 0,
        drilldownKey: 1702,
        drilldownType: 'FILE',
        duration: 0,
        fileName: 'panacea_benchmark.csv',
        filePath: 'filePath',
        fileSize: 153903,
        hasDetail: 0,
        invalidRecordCount: 0,
        issueHistory: [],
        processedSize: 153903,
        recordCount: 1634
      },
      {
        drilldownDetail: 1,
        drilldownKey: 1702,
        drilldownType: 'FILE',
        duration: 10,
        fileName: 'panacea_weight_allocation.csv',
        filePath: 'filePath',
        fileSize: 2530209,
        hasDetail: 0,
        invalidRecordCount: 0,
        issueHistory: [],
        processedSize: 2530209,
        recordCount: 42336
      }
    ];

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQADrilldownTable)).toHaveLength(1);
    const tableProps = enzymeWrapper.find(LoadAndQADrilldownTable).props();
    expect(tableProps.drilldowns).toEqual(props.drilldowns);
  });

  it('should render ErrorMessage if error !== null', () => {
    // given
    const props = getInitialProps();
    props.error = 'some error';

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    errorMessageProps.onDismiss();
    expect(props.clearError.mock.calls.length).toBe(1);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQADrilldown {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearLoadAndQADrilldown).toHaveBeenCalled();
  });
});
