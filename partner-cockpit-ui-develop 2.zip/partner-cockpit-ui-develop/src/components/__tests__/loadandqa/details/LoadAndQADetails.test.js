import React from 'react';
import { shallow } from 'enzyme';
import { Link } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';
import { Loader, Breadcrumb } from 'semantic-ui-react';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { LoadAndQADetails } from 'components/loadandqa/details/LoadAndQADetails';
import LoadAndQAActions from 'components/loadandqa/actions/LoadAndQAActions';
import LoadAndQADrilldown from 'components/loadandqa/drilldown/LoadAndQADrilldown';

const getInitialProps = () => ({
  activity: {
    id: '2-central',
    activityId: 2,
    activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
    activityName: 'LK Tables',
    activityOwner: 'central',
    activityInstance: 2,
    elapsedSec: 10,
    averageDuration: 15,
    averageDeviation: 6,
    issues: 0,
    issueHistory: [],
    actions: [],
    statusCode: ACTIVITY_STATUSES.FINISHED,
    percentage: 100
  },
  action: {
    actionDescription: 'Create temporary tables',
    actionId: 118,
    activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
    averageDeviation: 0,
    averageDuration: 0,
    drillDownKey: '1323',
    drillDownType: 'FILE',
    duration: 0,
    endTime: '',
    elapsedSec: 10,
    issueHistory: [],
    issues: 0,
    message: '',
    percentage: 100,
    startTime: '2019-01-11T07:30:25.397',
    statusCode: ACTIVITY_STATUSES.FINISHED
  },
  clearLoadAndQAActions: jest.fn(),
  match: {
    params: {
      id: '2-central',
      drilldownType: 'FILE',
      drilldownKey: '1323'
    }
  }
});

describe('LoadAndQADetails component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    expect(enzymeWrapper.exists('.loadAndQADetailsContainer')).toBe(true);
  });

  it('should render Breadcrumbs - LOAD_AND_QA_DETAILS_LEVELS.ACTIONS - Loader', () => {
    // given
    const props = getInitialProps();
    props.activity = undefined;
    props.match.params.drilldownType = undefined;
    props.match.params.drilldownKey = undefined;

    const expectedBreadcrumbsProps = {
      icon: 'right angle',
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`
        },
        {
          key: 'Activity',
          content: (
            <div className="breadcrumbsLoaderContainer">
              <Loader active inline="centered" size="tiny" />
            </div>
          ),
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    expect(enzymeWrapper.find(Breadcrumb)).toHaveLength(1);
    expect(enzymeWrapper.find(Breadcrumb).hasClass('breadcrumbsContainer')).toBe(true);
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.icon).toEqual(expectedBreadcrumbsProps.icon);
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render Breadcrumbs - LOAD_AND_QA_DETAILS_LEVELS.ACTIONS - activityName', () => {
    // given
    const props = getInitialProps();
    props.match.params.drilldownType = undefined;
    props.match.params.drilldownKey = undefined;

    const expectedBreadcrumbsProps = {
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`
        },
        {
          key: 'Activity',
          content: 'LK Tables',
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render Breadcrumbs - LOAD_AND_QA_DETAILS_LEVELS.DRILLDOWN - Loader', () => {
    // given
    const props = getInitialProps();
    props.action = undefined;

    const expectedBreadcrumbsProps = {
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`
        },
        {
          key: 'Activity',
          content: 'LK Tables',
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/${props.match.params.id}`
        },
        {
          key: 'Drilldown',
          content: (
            <div className="breadcrumbsLoaderContainer">
              <Loader active inline="centered" size="tiny" />
            </div>
          ),
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render Breadcrumbs - LOAD_AND_QA_DETAILS_LEVELS.DRILLDOWN - actionDescription', () => {
    // given
    const props = getInitialProps();

    const expectedBreadcrumbsProps = {
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`
        },
        {
          key: 'Activity',
          content: 'LK Tables',
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/${props.match.params.id}`
        },
        {
          key: 'Drilldown',
          content: 'Create temporary tables',
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render LoadAndQAActions if no drilldown in URL', () => {
    // given
    const props = getInitialProps();
    props.match.params.drilldownType = undefined;
    props.match.params.drilldownKey = undefined;

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQAActions)).toHaveLength(1);
  });

  it('should render LoadAndQADrilldown if drilldownType specified in URL', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQADrilldown)).toHaveLength(1);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQADetails {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearLoadAndQAActions).toHaveBeenCalled();
  });
});
