import React from 'react';
import { shallow } from 'enzyme';
import { NoResults } from 'components/common';
import QualityCheckResult from 'components/qualitychecks/QualityCheckResult';
import QualityCheckSummary from 'components/qualitychecks/QualityCheckSummary';
import QualityCheckLineGraph from 'components/qualitychecks/QualityCheckLineGraph';

// TODO: update

const getInitialProps = () => ({
  qualityCheckList: [
    {
      data: [
        {
          alternativeLevelFailIssues: 0,
          alternativeLevelNewIssues: 0,
          alternativeLevelTotalIssues: 1628,
          date: '2018-11-05T00:00:00',
          maxAlternativeLevelTotalIssues: 6750,
          maxPortfoliosTotalIssues: 6750,
          portfoliosFailIssues: 0,
          portfoliosNewIssues: 0,
          portfoliosTotalIssues: 1628
        },
        {
          alternativeLevelFailIssues: 0,
          alternativeLevelNewIssues: 0,
          alternativeLevelTotalIssues: 1628,
          date: '2018-11-08T00:00:00',
          maxAlternativeLevelTotalIssues: 6750,
          maxPortfoliosTotalIssues: 6750,
          portfoliosFailIssues: 0,
          portfoliosNewIssues: 0,
          portfoliosTotalIssues: 1628
        }
      ],
      type: 1048576,
      description: '',
      qualityCheckLevel: 1,
      isFailureEnabled: true
    },
    {
      data: [
        {
          alternativeLevelFailIssues: 0,
          alternativeLevelNewIssues: 0,
          alternativeLevelTotalIssues: 0,
          date: '2018-11-05T00:00:00',
          maxAlternativeLevelTotalIssues: 40212,
          maxPortfoliosTotalIssues: 5974,
          portfoliosFailIssues: 0,
          portfoliosNewIssues: 0,
          portfoliosTotalIssues: 0
        },
        {
          alternativeLevelFailIssues: 0,
          alternativeLevelNewIssues: 0,
          alternativeLevelTotalIssues: 0,
          date: '2018-11-08T00:00:00',
          maxAlternativeLevelTotalIssues: 40212,
          maxPortfoliosTotalIssues: 5974,
          portfoliosFailIssues: 0,
          portfoliosNewIssues: 0,
          portfoliosTotalIssues: 0
        }
      ],
      type: 16384,
      description: '',
      qualityCheckLevel: 1,
      isFailureEnabled: true
    }
  ]
});

describe('QualityCheckResult component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckResult {...props} />);

    // then
    expect(enzymeWrapper.exists('.qualityCheckResultContainer')).toBe(true);
  });

  it('should render NoResults if no qualityChecks', () => {
    // given
    const props = getInitialProps();
    props.qualityCheckList = [];

    // when
    const enzymeWrapper = shallow(<QualityCheckResult {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.exists('.qcRow')).toBe(false);
  });

  it('should render qualityChecks list', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckResult {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(0);
    expect(enzymeWrapper.find('.qcRow')).toHaveLength(2);
    const qcRowWrapper = enzymeWrapper.find('.qcRow').first();
    expect(qcRowWrapper.exists('.title')).toBe(true);
    expect(qcRowWrapper.find(QualityCheckLineGraph)).toHaveLength(1);
    expect(qcRowWrapper.find(QualityCheckSummary)).toHaveLength(1);
  });

  // it('should render qualityCheck title', () => {
  //   // given
  //   const props = getInitialProps();
  //   const expectedFormattedMessageProps = {
  //     id: 'qualityCheck.risk_bearing',
  //     defaultMessage: 'Risk Profile Check'
  //   };

  //   // when
  //   const enzymeWrapper = shallow(<QualityCheckResult {...props} />);

  //   // then
  //   const qcRowWrapper = enzymeWrapper.find('.qcRow').first();
  //   expect(qcRowWrapper.find('.title').find(FormattedMessage)).toHaveLength(1);
  //   const formattedMessageProps = qcRowWrapper.find('.title').find(FormattedMessage).props();
  //   expect(formattedMessageProps.id).toEqual(expectedFormattedMessageProps.id);
  //   expect(formattedMessageProps.defaultMessage)
  //     .toEqual(expectedFormattedMessageProps.defaultMessage);
  // });

  it('should render qualityCheck graph', () => {
    // given
    const props = getInitialProps();
    const expectedGraphProps = {
      qualityCheck: props.qualityCheckList[0]
    };

    // when
    const enzymeWrapper = shallow(<QualityCheckResult {...props} />);

    // then
    const graphProps = enzymeWrapper.find(QualityCheckLineGraph).first().props();
    expect(graphProps.qualityCheck).toEqual(expectedGraphProps.qualityCheck);
  });

  it('should render qualityCheck summary', () => {
    // given
    const props = getInitialProps();
    const expectedSummaryProps = {
      data: {
        alternativeLevelFailIssues: 0,
        alternativeLevelNewIssues: 0,
        alternativeLevelTotalIssues: 1628,
        date: '2018-11-08T00:00:00',
        maxAlternativeLevelTotalIssues: 6750,
        maxPortfoliosTotalIssues: 6750,
        portfoliosFailIssues: 0,
        portfoliosNewIssues: 0,
        portfoliosTotalIssues: 1628
      }
    };

    // when
    const enzymeWrapper = shallow(<QualityCheckResult {...props} />);

    // then
    const summaryProps = enzymeWrapper.find(QualityCheckSummary).first().props();
    expect(summaryProps.data).toEqual(expectedSummaryProps.data);
  });
});
