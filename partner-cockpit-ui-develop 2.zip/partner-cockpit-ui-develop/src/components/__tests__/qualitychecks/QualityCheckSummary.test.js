import React from 'react';
import { shallow } from 'enzyme';
import QualityCheckSummary from 'components/qualitychecks/QualityCheckSummary';

// TODO: update

const getInitialProps = () => ({
  data: {
    alternativeLevelFailIssues: 0,
    alternativeLevelNewIssues: 0,
    alternativeLevelTotalIssues: 1628,
    date: '2018-11-08T00:00:00',
    maxAlternativeLevelTotalIssues: 6750,
    maxPortfoliosTotalIssues: 6750,
    portfoliosFailIssues: 0,
    portfoliosNewIssues: 0,
    portfoliosTotalIssues: 1628
  },
  qualityCheckLevel: 2,
  isFailureEnabled: false
});

describe('QualityCheckSummary component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckSummary {...props} />);

    // then
    expect(enzymeWrapper.exists('.summaryMenu')).toBe(true);
  });

  it('should render newIssues and breachingPortfolios if no alternativeLevel and no fails', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckSummary {...props} />);

    // then
    expect(enzymeWrapper.find('.summaryRow')).toHaveLength(2);
    expect(enzymeWrapper.exists('.newIssuesRow')).toBe(true);
    expect(enzymeWrapper.exists('.breachingPortfolios')).toBe(true);
  });

  it('should render breachingAlternative if presented', () => {
    // given
    const props = getInitialProps();
    props.qualityCheckLevel = 1;

    // when
    const enzymeWrapper = shallow(<QualityCheckSummary {...props} />);

    // then
    expect(enzymeWrapper.find('.summaryRow')).toHaveLength(3);
    expect(enzymeWrapper.exists('.breachingAlternative')).toBe(true);
  });

  it('should render fails if presented', () => {
    // given
    const props = getInitialProps();
    props.isFailureEnabled = true;

    // when
    const enzymeWrapper = shallow(<QualityCheckSummary {...props} />);

    // then
    expect(enzymeWrapper.find('.summaryRow')).toHaveLength(3);
    expect(enzymeWrapper.exists('.failIssuesRow')).toBe(true);
  });

  it('should render all 4 rows if presented', () => {
    // given
    const props = getInitialProps();
    props.qualityCheckLevel = 1;
    props.isFailureEnabled = true;

    // when
    const enzymeWrapper = shallow(<QualityCheckSummary {...props} />);

    // then
    expect(enzymeWrapper.find('.summaryRow')).toHaveLength(4);
  });
});
