import React from 'react';
import { shallow } from 'enzyme';
import { QualityCheckLineGraph } from 'components/qualitychecks/QualityCheckLineGraph';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  Line,
  Tooltip,
  CartesianGrid
} from 'recharts';

// TODO: update

const getInitialProps = () => ({
  qualityCheck: {
    data: [
      {
        alternativeLevelFailIssues: 0,
        alternativeLevelNewIssues: 0,
        alternativeLevelTotalIssues: 1628,
        date: '2018-11-05T00:00:00',
        maxAlternativeLevelTotalIssues: 6750,
        maxPortfoliosTotalIssues: 6750,
        portfoliosFailIssues: 0,
        portfoliosNewIssues: 0,
        portfoliosTotalIssues: 1628
      },
      {
        alternativeLevelFailIssues: 0,
        alternativeLevelNewIssues: 0,
        alternativeLevelTotalIssues: 1628,
        date: '2018-11-08T00:00:00',
        maxAlternativeLevelTotalIssues: 6750,
        maxPortfoliosTotalIssues: 6750,
        portfoliosFailIssues: 0,
        portfoliosNewIssues: 0,
        portfoliosTotalIssues: 1628
      }
    ],
    isFailureEnabled: false,
    qualityCheckLevel: 1
  },
  intl: {
    formatMessage: jest.fn(),
    formatNumber: jest.fn()
  }
});

describe('QualityCheckLineGraph component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckLineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(ResponsiveContainer)).toHaveLength(1);
    expect(enzymeWrapper.exists('.qualityCheckGraph')).toBe(true);
  });

  it('should render base structure of graph', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckLineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(ComposedChart)).toHaveLength(1);
    expect(enzymeWrapper.find(XAxis)).toHaveLength(1);
    expect(enzymeWrapper.find(YAxis)).toHaveLength(2);
    expect(enzymeWrapper.find(CartesianGrid)).toHaveLength(1);
    expect(enzymeWrapper.find(Bar)).toHaveLength(1);
    expect(enzymeWrapper.find(Tooltip)).toHaveLength(1);
  });

  it('should render only one Line if no fails', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckLineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(Line)).toHaveLength(1);
  });

  it('should render two Lines if there are fails', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.isFailureEnabled = true;

    // when
    const enzymeWrapper = shallow(<QualityCheckLineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(Line)).toHaveLength(2);
  });
});
