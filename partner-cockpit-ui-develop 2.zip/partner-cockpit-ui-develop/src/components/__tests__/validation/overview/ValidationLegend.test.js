import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import ValidationLegend from 'components/validation/qualitychecks/overview/ValidationLegend';

describe('ValidationLegend component', () => {
  it('should render self and subcomponents', () => {
    // given

    // when
    const enzymeWrapper = shallow(<ValidationLegend />);

    // then
    expect(enzymeWrapper.exists('.validationLegendContainer')).toBe(true);
  });

  it('should render 4 blocks with 5 messages', () => {
    // given

    // when
    const enzymeWrapper = shallow(<ValidationLegend />);

    // then
    expect(enzymeWrapper.find('.legendBlock')).toHaveLength(4);
    expect(enzymeWrapper.find(FormattedMessage)).toHaveLength(5);
  });

  it('should render blocks for all the types', () => {
    // given

    // when
    const enzymeWrapper = shallow(<ValidationLegend />);

    // then
    expect(enzymeWrapper.exists('.accept')).toBe(true);
    expect(enzymeWrapper.exists('.invalidate')).toBe(true);
    expect(enzymeWrapper.exists('.reject')).toBe(true);
    expect(enzymeWrapper.exists('.noDecision')).toBe(true);

    expect(enzymeWrapper.find('.invalidate').hasClass('postpone')).toBe(true);
  });
});
