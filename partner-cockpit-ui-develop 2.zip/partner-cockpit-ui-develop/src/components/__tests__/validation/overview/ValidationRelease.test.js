import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { Button } from 'semantic-ui-react';
import { DateAndTime } from 'components/common';
import { DECISION_STATUSES } from 'constants/validation';
import ValidationRelease from 'components/validation/qualitychecks/overview/ValidationRelease';

const getInitialProps = () => ({
  decisionCommon: {
    decisionId: 25,
    date: '2018-12-06T00:00:00',
    statusId: DECISION_STATUSES.ONGOING,
    isLatestLoad: true
  },
  isReleaseAllowed: true,
  lastSuccessfulValidationDate: '2018-11-28T00:00:00',
  onRelease: jest.fn()
});

describe('ValidationRelease component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.exists('.releaseContainer')).toBe(true);
  });

  it('should render last successful validation date title', () => {
    // given
    const props = getInitialProps();
    const expectedTitleProps = {
      id: 'validation.overview.last_successful_validation',
      defaultMessage: 'Last Successful Validation'
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.exists('.lastValidation')).toBe(true);
    const titleProps = enzymeWrapper.find('.lastValidation').find(FormattedMessage).props();
    expect(titleProps.id).toEqual(expectedTitleProps.id);
    expect(titleProps.defaultMessage).toEqual(expectedTitleProps.defaultMessage);
  });

  it('should render last successful validation date if presented', () => {
    // given
    const props = getInitialProps();
    const expectedDateAndTimeProps = {
      value: '2018-11-28T00:00:00'
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.find('.lastValidation').exists('.date')).toBe(true);
    expect(enzymeWrapper.find(DateAndTime)).toHaveLength(1);
    const dateAndTimeProps = enzymeWrapper.find(DateAndTime).props();
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should not render last successful validation date if not presented', () => {
    // given
    const props = getInitialProps();
    props.lastSuccessfulValidationDate = '';

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.exists('.lastValidation')).toBe(false);
  });

  it('should render validate option: Button', () => {
    // given
    const props = getInitialProps();
    const expectedButtonProps = {
      loading: false,
      disabled: false
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.exists('.validateOption')).toBe(true);
    expect(enzymeWrapper.find(Button)).toHaveLength(1);
    expect(enzymeWrapper.find(Button).hasClass('decisionButton')).toBe(true);
    expect(enzymeWrapper.find(Button).hasClass('ubs-primary-button')).toBe(true);
    const buttonProps = enzymeWrapper.find(Button).props();
    expect(buttonProps.loading).toEqual(expectedButtonProps.loading);
    expect(buttonProps.disabled).toEqual(expectedButtonProps.disabled);
  });

  it('should render validate option: disabled Button by isReleaseAllowed', () => {
    // given
    const props = getInitialProps();
    props.isReleaseAllowed = false;
    const expectedButtonProps = {
      loading: false,
      disabled: true
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(1);
    const buttonProps = enzymeWrapper.find(Button).props();
    expect(buttonProps.loading).toEqual(expectedButtonProps.loading);
    expect(buttonProps.disabled).toEqual(expectedButtonProps.disabled);
  });

  it('should render validate option: disabled Button by isFreezed', () => {
    // given
    const props = getInitialProps();
    props.decisionCommon.isFreezed = true;
    const expectedButtonProps = {
      loading: false,
      disabled: true
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(1);
    const buttonProps = enzymeWrapper.find(Button).props();
    expect(buttonProps.loading).toEqual(expectedButtonProps.loading);
    expect(buttonProps.disabled).toEqual(expectedButtonProps.disabled);
  });

  it('should render validate option: disabled Button with Loader by status', () => {
    // given
    const props = getInitialProps();
    props.decisionCommon.statusId = DECISION_STATUSES.CLOSED;
    const expectedButtonProps = {
      loading: true,
      disabled: true
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(1);
    const buttonProps = enzymeWrapper.find(Button).props();
    expect(buttonProps.loading).toEqual(expectedButtonProps.loading);
    expect(buttonProps.disabled).toEqual(expectedButtonProps.disabled);
  });

  // TODO: add DECISION_STATUSES.RECALCULATED

  it('should render validate option: label', () => {
    // given
    const props = getInitialProps();
    props.decisionCommon.statusId = DECISION_STATUSES.FINALIZED;
    props.isReleaseAllowed = false;
    const expectedLabelProps = {
      id: 'validation.overview.validated',
      defaultMessage: 'Validated'
    };

    // when
    const enzymeWrapper = shallow(<ValidationRelease {...props} />);

    // then
    expect(enzymeWrapper.exists('.validatedLabel')).toBe(true);
    expect(enzymeWrapper.find('.validatedLabel').find(FormattedMessage)).toHaveLength(1);
    const labelProps = enzymeWrapper.find('.validatedLabel').find(FormattedMessage).props();
    expect(labelProps.id).toEqual(expectedLabelProps.id);
    expect(labelProps.defaultMessage).toEqual(expectedLabelProps.defaultMessage);
  });

  // TODO: adjust
  // it('should handle validate button click', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<ValidationRelease {...props} />);

  //   // then
  //   enzymeWrapper.find(Button).simulate('click');
  //   expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(1);
  // });

  // TODO: adjust
  // it('should handle ConfirmModal click: cancel', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<ValidationRelease {...props} />);

  //   // then
  //   enzymeWrapper.find(Button).simulate('click');
  //   enzymeWrapper.find(ConfirmModal).props().onCancel();
  //   expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  //   expect(props.onRelease).not.toHaveBeenCalled();
  // });

  // TODO: adjust
  // it('should handle ConfirmModal click: confirm', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<ValidationRelease {...props} />);

  //   // then
  //   enzymeWrapper.find(Button).simulate('click');
  //   enzymeWrapper.find(ConfirmModal).props().onConfirm();
  //   expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  //   expect(props.onRelease).toHaveBeenCalled();
  //   expect(props.onRelease.mock.calls[0][0]).toEqual(25);
  // });
});
