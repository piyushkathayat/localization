import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { Popup } from 'semantic-ui-react';
import QualityCheckTile from 'components/validation/qualitychecks/overview/QualityCheckTile';

const getInitialProps = () => ({
  qualityCheck: {
    qualityCheckType: 1,
    sortOrder: 10,
    description: 'Strategic Asset Allocation',
    totalIssues: 120,
    newIssues: 100,
    oldIssues: 20,
    approvals: [
      {
        distinctIssues: 120,
        approvalStatusId: 20,
        decisionRemaining: 0
      }
    ]
  },
  onClick: jest.fn()
});

describe('QualityCheckTile component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.qualityCheckTileContainer')).toBe(true);
  });

  it('should render description', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.description')).toBe(true);
    const title = enzymeWrapper.find('.description');
    expect(title.text()).toEqual(props.qualityCheck.description);
  });

  it('should render noDecision count', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.noDecisionCount')).toBe(true);
    expect(enzymeWrapper.find('.noDecisionCount').text()).toEqual('0');
  });

  it('should render new issues count', () => {
    // given
    const props = getInitialProps();
    const expectedNewTitleProps = {
      id: 'validation.overview.new',
      defaultMessage: 'New'
    };

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.newAndOld')).toBe(true);
    expect(enzymeWrapper.exists('.new')).toBe(true);
    const newTitleProps = enzymeWrapper.find('.new').find(FormattedMessage).props();
    expect(newTitleProps.id).toEqual(expectedNewTitleProps.id);
    expect(newTitleProps.defaultMessage).toEqual(expectedNewTitleProps.defaultMessage);
    expect(enzymeWrapper.find('.new').text()).toContain('100');
  });

  it('should render old issues count', () => {
    // given
    const props = getInitialProps();
    const expectedOldTitleProps = {
      id: 'validation.overview.old',
      defaultMessage: 'Old'
    };

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.newAndOld')).toBe(true);
    expect(enzymeWrapper.exists('.old')).toBe(true);
    const oldTitleProps = enzymeWrapper.find('.old').find(FormattedMessage).props();
    expect(oldTitleProps.id).toEqual(expectedOldTitleProps.id);
    expect(oldTitleProps.defaultMessage).toEqual(expectedOldTitleProps.defaultMessage);
    expect(enzymeWrapper.find('.old').text()).toContain('20');
  });

  it('should render tile bar: empty bar', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.totalIssues = 0;

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.tileBar')).toBe(true);
    expect(enzymeWrapper.find(Popup)).toHaveLength(0);
    expect(enzymeWrapper.exists('svg')).toBe(true);
    expect(enzymeWrapper.find('svg').find('rect')).toHaveLength(1);
    expect(enzymeWrapper.find('svg').find('rect').hasClass('noIssues')).toBe(true);
  });

  it('should render tile bar: bar with Popup', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    expect(enzymeWrapper.exists('.tileBar')).toBe(true);
    expect(enzymeWrapper.find(Popup)).toHaveLength(1);
    expect(enzymeWrapper.find(Popup).hasClass('tileBarTooltip')).toBe(true);
    expect(enzymeWrapper.find(Popup).render().find('rect')).toHaveLength(5);
  });

  it('should calculate bars width properly: 100% accept', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    const releaseBar = enzymeWrapper.find(Popup).render().find('rect').filter('.accept');
    expect(releaseBar.attr('x')).toEqual('0%');
    expect(releaseBar.attr('width')).toEqual('100%');
  });

  it('should calculate bars width properly: 50% accept, 50% noDecision', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.approvals = [
      {
        distinctIssues: 60,
        approvalStatusId: 20,
        decisionRemaining: 0
      },
      {
        distinctIssues: 60,
        approvalStatusId: 2,
        decisionRemaining: 60
      }
    ];

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    const releaseBar = enzymeWrapper.find(Popup).render().find('rect').filter('.accept');
    expect(releaseBar.attr('x')).toEqual('0%');
    expect(releaseBar.attr('width')).toEqual('50%');

    const noDecisionBar = enzymeWrapper.find(Popup).render().find('rect').filter('.noDecision');
    expect(noDecisionBar.attr('x')).toEqual('50%');
    expect(noDecisionBar.attr('width')).toEqual('50%');
  });

  it('should calculate bars width properly: 25% accept, 25% postpone, 50% noDecision', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.approvals = [
      {
        distinctIssues: 30,
        approvalStatusId: 20,
        decisionRemaining: 0
      },
      {
        distinctIssues: 30,
        approvalStatusId: 13,
        decisionRemaining: 0
      },
      {
        distinctIssues: 60,
        approvalStatusId: 2,
        decisionRemaining: 60
      }
    ];

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    const releaseBar = enzymeWrapper.find(Popup).render().find('rect').filter('.accept');
    expect(releaseBar.attr('x')).toEqual('0%');
    expect(releaseBar.attr('width')).toEqual('25%');

    const reviewTomorrowBar = enzymeWrapper.find(Popup).render().find('rect').filter('.postpone');
    expect(reviewTomorrowBar.attr('x')).toEqual('25%');
    expect(reviewTomorrowBar.attr('width')).toEqual('25%');

    const noDecisionBar = enzymeWrapper.find(Popup).render().find('rect').filter('.noDecision');
    expect(noDecisionBar.attr('x')).toEqual('50%');
    expect(noDecisionBar.attr('width')).toEqual('50%');
  });

  it('should calculate bars width properly: 25% accept, 25% invalidate, 50% noDecision', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.approvals = [
      {
        distinctIssues: 30,
        approvalStatusId: 20,
        decisionRemaining: 0
      },
      {
        distinctIssues: 30,
        approvalStatusId: 12,
        decisionRemaining: 0
      },
      {
        distinctIssues: 60,
        approvalStatusId: 2,
        decisionRemaining: 60
      }
    ];

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    const releaseBar = enzymeWrapper.find(Popup).render().find('rect').filter('.accept');
    expect(releaseBar.attr('x')).toEqual('0%');
    expect(releaseBar.attr('width')).toEqual('25%');

    const reviewTomorrowBar = enzymeWrapper.find(Popup).render().find('rect').filter('.invalidate');
    expect(reviewTomorrowBar.attr('x')).toEqual('25%');
    expect(reviewTomorrowBar.attr('width')).toEqual('25%');

    const noDecisionBar = enzymeWrapper.find(Popup).render().find('rect').filter('.noDecision');
    expect(noDecisionBar.attr('x')).toEqual('50%');
    expect(noDecisionBar.attr('width')).toEqual('50%');
  });

  it('should calculate bars width properly: 25% accept, 25% postpone, 25% reject, 25% noDecision', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.approvals = [
      {
        distinctIssues: 30,
        approvalStatusId: 20,
        decisionRemaining: 0
      },
      {
        distinctIssues: 30,
        approvalStatusId: 13,
        decisionRemaining: 0
      },
      {
        distinctIssues: 30,
        approvalStatusId: 30,
        decisionRemaining: 0
      },
      {
        distinctIssues: 30,
        approvalStatusId: 2,
        decisionRemaining: 30
      }
    ];

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);

    // then
    const releaseBar = enzymeWrapper.find(Popup).render().find('rect').filter('.accept');
    expect(releaseBar.attr('x')).toEqual('0%');
    expect(releaseBar.attr('width')).toEqual('25%');

    const reviewTomorrowBar = enzymeWrapper.find(Popup).render().find('rect').filter('.postpone');
    expect(reviewTomorrowBar.attr('x')).toEqual('25%');
    expect(reviewTomorrowBar.attr('width')).toEqual('25%');

    const rejectBar = enzymeWrapper.find(Popup).render().find('rect').filter('.reject');
    expect(rejectBar.attr('x')).toEqual('50%');
    expect(rejectBar.attr('width')).toEqual('25%');

    const noDecisionBar = enzymeWrapper.find(Popup).render().find('rect').filter('.noDecision');
    expect(noDecisionBar.attr('x')).toEqual('75%');
    expect(noDecisionBar.attr('width')).toEqual('25%');
  });

  it('should render proper Popup content - postpone', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.approvals = [
      {
        distinctIssues: 31,
        approvalStatusId: 20,
        decisionRemaining: 0
      },
      {
        distinctIssues: 0,
        approvalStatusId: 12,
        decisionRemaining: 0
      },
      {
        distinctIssues: 29,
        approvalStatusId: 13,
        decisionRemaining: 0
      },
      {
        distinctIssues: 32,
        approvalStatusId: 30,
        decisionRemaining: 0
      },
      {
        distinctIssues: 28,
        approvalStatusId: 2,
        decisionRemaining: 30
      }
    ];

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);
    const popupWrapper = shallow(enzymeWrapper.find(Popup).first().prop('content'));

    // then
    expect(popupWrapper.find('.tooltipRow')).toHaveLength(5);
    expect(popupWrapper.find('.tooltipRow').find('.accept').text()).toContain('31');
    expect(popupWrapper.find('.tooltipRow').find('.invalidate').text()).toContain('0');
    expect(popupWrapper.find('.tooltipRow').find('.postpone').text()).toContain('29');
    expect(popupWrapper.find('.tooltipRow').find('.reject').text()).toContain('32');
    expect(popupWrapper.find('.tooltipRow').find('.noDecision').text()).toContain('28');
  });

  it('should render proper Popup content - invalidate', () => {
    // given
    const props = getInitialProps();
    props.qualityCheck.approvals = [
      {
        distinctIssues: 31,
        approvalStatusId: 20,
        decisionRemaining: 0
      },
      {
        distinctIssues: 29,
        approvalStatusId: 12,
        decisionRemaining: 0
      },
      {
        distinctIssues: 0,
        approvalStatusId: 13,
        decisionRemaining: 0
      },
      {
        distinctIssues: 0,
        approvalStatusId: 30,
        decisionRemaining: 0
      },
      {
        distinctIssues: 60,
        approvalStatusId: 2,
        decisionRemaining: 60
      }
    ];

    // when
    const enzymeWrapper = shallow(<QualityCheckTile {...props} />);
    const popupWrapper = shallow(enzymeWrapper.find(Popup).first().prop('content'));

    // then
    expect(popupWrapper.find('.tooltipRow')).toHaveLength(5);
    expect(popupWrapper.find('.tooltipRow').find('.accept').text()).toContain('31');
    expect(popupWrapper.find('.tooltipRow').find('.invalidate').text()).toContain('29');
    expect(popupWrapper.find('.tooltipRow').find('.postpone').text()).toContain('0');
    expect(popupWrapper.find('.tooltipRow').find('.reject').text()).toContain('0');
    expect(popupWrapper.find('.tooltipRow').find('.noDecision').text()).toContain('60');
  });
});
