import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { Loader, Breadcrumb, Grid } from 'semantic-ui-react';
import { NoResults } from 'components/common';
import { ValidationOverview } from 'components/validation/qualitychecks/overview/ValidationOverview';
import QualityCheckTile from 'components/validation/qualitychecks/overview/QualityCheckTile';
import ValidationLegend from 'components/validation/qualitychecks/overview/ValidationLegend';
import ValidationRelease from 'components/validation/qualitychecks/overview/ValidationRelease';

const getInitialProps = () => ({
  decisionCommon: {
    decisionId: 25,
    date: '2018-12-06T00:00:00',
    statusId: 110,
    isLatestLoad: true
  },
  decisionOverview: {
    decisionId: 25,
    isReleaseAllowed: true,
    qualityChecks: [
      {
        qualityCheckType: 1,
        sortOrder: 10,
        description: 'Strategic Asset Allocation',
        totalIssues: 139,
        newIssues: 126,
        oldIssues: 13,
        approvals: [
          {
            distinctIssues: 139,
            approvalStatusId: 20,
            decisionRemaining: 0
          }
        ]
      },
      {
        qualityCheckType: 1048576,
        sortOrder: 11,
        description: 'Risk Profile',
        totalIssues: 0,
        newIssues: 0,
        oldIssues: 0,
        approvals: [
          {
            distinctIssues: 0,
            approvalStatusId: 20,
            decisionRemaining: 0
          }
        ]
      }
    ]
  },
  lastSuccessfulValidationDate: '2018-11-28T00:00:00',
  isLoading: false,
  onQualityCheckTileClick: jest.fn(),
  clearValidationOverview: jest.fn(),
  recalculateDecision: jest.fn(),
  validateDecision: jest.fn()
});

describe('ValidationOverview component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.validationOverviewContainer')).toBe(true);
  });

  it('should render breadcrumbs', () => {
    // given
    const props = getInitialProps();
    const expectedBreadcrumbsProps = {
      icon: 'right angle',
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Breadcrumb)).toHaveLength(1);
    expect(enzymeWrapper.find(Breadcrumb).hasClass('breadcrumbsContainer')).toBe(true);
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.icon).toEqual(expectedBreadcrumbsProps.icon);
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.qualityChecksTableContainer')).toBe(false);
  });

  it('should render content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.exists('.qualityChecksTableContainer')).toBe(true);
  });

  it('should render NoResults if there are no quality checks', () => {
    // given
    const props = getInitialProps();
    props.decisionOverview.qualityChecks = [];

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.qualityChecksTableContainer')).toBe(false);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
  });

  it('should render quality checks table', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.find(Grid)).toHaveLength(1);
    expect(enzymeWrapper.find(Grid).hasClass('qualityChecksTable')).toBe(true);
  });

  it('should render proper amount of tiles', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.find(QualityCheckTile)).toHaveLength(2);
  });

  it('should pass proper props to QualityCheckTile', () => {
    // given
    const props = getInitialProps();
    const expectedTileProps = {
      qualityCheck: {
        qualityCheckType: 1,
        sortOrder: 10,
        description: 'Strategic Asset Allocation',
        totalIssues: 139,
        newIssues: 126,
        oldIssues: 13,
        approvals: [
          {
            distinctIssues: 139,
            approvalStatusId: 20,
            decisionRemaining: 0
          }
        ]
      },
      onClick: props.onQualityCheckTileClick
    };

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    const tileProps = enzymeWrapper.find(QualityCheckTile).first().props();
    expect(tileProps.qualityCheck).toEqual(expectedTileProps.qualityCheck);
    tileProps.onClick();
    expect(props.onQualityCheckTileClick).toHaveBeenCalled();
  });

  it('should render table footer', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    expect(enzymeWrapper.exists('.validationOverviewFooter')).toBe(true);
    expect(enzymeWrapper.find(ValidationLegend)).toHaveLength(1);
    expect(enzymeWrapper.find(ValidationRelease)).toHaveLength(1);
  });

  it('should pass proper props to ValidationRelease', () => {
    // given
    const props = getInitialProps();
    const expectedReleaseProps = {
      decisionCommon: {
        decisionId: 25,
        date: '2018-12-06T00:00:00',
        statusId: 110,
        isLatestLoad: true
      },
      isReleaseAllowed: true,
      lastSuccessfulValidationDate: '2018-11-28T00:00:00',
      onRecalculate: props.recalculateDecision,
      onValidate: props.validateDecision
    };

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);

    // then
    const releaseProps = enzymeWrapper.find(ValidationRelease).props();
    expect(releaseProps.decisionCommon).toEqual(expectedReleaseProps.decisionCommon);
    expect(releaseProps.isReleaseAllowed).toEqual(expectedReleaseProps.isReleaseAllowed);
    expect(releaseProps.lastSuccessfulValidationDate)
      .toEqual(expectedReleaseProps.lastSuccessfulValidationDate);
    releaseProps.onRecalculate();
    expect(props.recalculateDecision).toHaveBeenCalled();
    releaseProps.onValidate();
    expect(props.validateDecision).toHaveBeenCalled();
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationOverview {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearValidationOverview).toHaveBeenCalled();
  });
});
