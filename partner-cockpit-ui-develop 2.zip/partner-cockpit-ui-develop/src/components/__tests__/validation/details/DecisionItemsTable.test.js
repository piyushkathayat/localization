import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { ReasonModal } from 'components/common';
import { WindowScroller } from 'react-virtualized';
import { SORT_DIRECTIONS, MODAL_TYPES } from 'constants/common';
import { APPROVAL_STATUSES_IDS } from 'constants/validation';
import { DecisionItemsTable } from 'components/validation/qualitychecks/details/DecisionItemsTable';

// TODO: update

const getInitialProps = () => ({
  columnDefs: [
    {
      label: {
        id: 'validation.details.isin',
        defaultMessage: 'ISIN'
      },
      dataKey: 'displayKey',
      width: 10,
      maxWidth: 10
    },
    {
      label: {
        id: 'validation.details.instrument_name',
        defaultMessage: 'Instrument Name'
      },
      dataKey: 'displayDescription',
      width: 31,
      maxWidth: 31
    },
    {
      label: {
        id: 'validation.details.issue_since',
        defaultMessage: 'Issue Since'
      },
      dataKey: 'issueSince',
      width: 13,
      maxWidth: 13
    },
    {
      label: {
        id: 'validation.details.breaching_positions',
        defaultMessage: 'Number of Breaching Positions'
      },
      dataKey: 'affectedPortfolios',
      width: 14,
      maxWidth: 14,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    }
  ],
  decisionItemsList: [
    {
      decisionKey: 1,
      approvalStatus: 20,
      affectedPortfolios: 0,
      displayKey: 'LU0452418154',
      displayDescription: 'ALT KEMPEN NDP F',
      commentLast: null,
      confirmedBy: null,
      portfoliosList: [
        {
          assetId: 1049321,
          portfolioCode: 'code',
          portfolioCcy: 'EUR',
          investmentStrategyDesc: 'Elevated'
        }
      ]
    },
    {
      decisionKey: 2,
      approvalStatus: 12,
      affectedPortfolios: 0,
      displayKey: 'FR0000121964',
      displayDescription: 'A KLEPIERRE',
      commentLast: 'Some comment',
      confirmedBy: '43535763'
    }
  ],
  decisionItemsIds: [1, 2],
  decisionLevel: 1,
  decisionGroup: 1,
  qualityCheckType: 2,
  actions: [
    {
      key: 20,
      text: <FormattedMessage id="validation.accept" defaultMessage="Accept" />,
      value: 20
    },
    {
      key: 12,
      text: <FormattedMessage id="validation.invalidate" defaultMessage="Invalidate" />,
      value: 12
    }
  ],
  isDisabled: false,
  sorting: {
    sortBy: '',
    sortDirection: SORT_DIRECTIONS.ASC
  },
  onUpdate: jest.fn(),
  onSort: jest.fn(),
  intl: {
    formatMessage: jest.fn()
  }
});

describe('DecisionItemsTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.decisionItemsTableContainer')).toBe(true);
  });

  it('should render details table', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);

    // then
    expect(enzymeWrapper.find(WindowScroller)).toHaveLength(1);
  });

  it('should handle header click: no sorting for not sortable columns', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleHeaderClick({ dataKey: 'comment' });
    expect(props.onSort).not.toHaveBeenCalled();
  });

  it('should handle header click: trigger sorting for sortable columns', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleHeaderClick({ dataKey: 'displayKey' });
    expect(props.onSort).toHaveBeenCalled();
  });

  it('should handle header checkbox click: check all items', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleAllCheckboxChange();
    expect(instance.state.selectedDecisionItemsIds).toHaveLength(2);
  });

  it('should handle header checkbox click: uncheck all items', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleAllCheckboxChange();
    instance.handleAllCheckboxChange();
    expect(instance.state.selectedDecisionItemsIds).toHaveLength(0);
  });

  it('should handle header checkbox click: uncheck some checked items', () => {
    // given
    const props = getInitialProps();
    const event = {
      stopPropagation: jest.fn()
    };

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleSingleCheckboxChange(1)(event);
    instance.handleAllCheckboxChange();
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(instance.state.selectedDecisionItemsIds).toHaveLength(0);
  });

  it('should handle single checkbox click', () => {
    // given
    const props = getInitialProps();
    const event = {
      stopPropagation: jest.fn()
    };

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleSingleCheckboxChange(1)(event);
    expect(event.stopPropagation).toHaveBeenCalled();
    expect(instance.state.selectedDecisionItemsIds).toEqual([1]);
  });

  it('should handle single dropdown change: explanation modal', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleSingleDropdownChange(1)({}, {
      value: APPROVAL_STATUSES_IDS.POSTPONE
    });
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(1);
  });

  it('should handle single dropdown change: explanation modal - props', () => {
    // given
    const props = getInitialProps();
    const expectedModalProps = {
      isOpen: true,
      type: MODAL_TYPES.VALIDATION_DECISION
    };

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleSingleDropdownChange(1)({}, {
      value: APPROVAL_STATUSES_IDS.POSTPONE
    });
    const modalProps = enzymeWrapper.find(ReasonModal).props();
    expect(modalProps.isOpen).toEqual(expectedModalProps.isOpen);
    expect(modalProps.type).toEqual(expectedModalProps.type);
    modalProps.onClose();
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.onUpdate).not.toHaveBeenCalled();
    modalProps.onSubmit({
      confirmedBy: 'user1',
      explanationText: 'explanation'
    });
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.onUpdate).toHaveBeenCalled();
    expect(props.onUpdate.mock.calls[0][0].decisionItemsIds).toEqual([1]);
    expect(props.onUpdate.mock.calls[0][0].approvalStatusId)
      .toEqual(APPROVAL_STATUSES_IDS.POSTPONE);
    expect(props.onUpdate.mock.calls[0][0].comment).toEqual('explanation');
    expect(props.onUpdate.mock.calls[0][0].confirmedBy).toEqual('user1');
  });

  it('should handle single dropdown change: change status', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleSingleDropdownChange(1)({}, {
      value: APPROVAL_STATUSES_IDS.ACCEPT
    });
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.onUpdate).toHaveBeenCalled();
  });

  it('should handle single dropdown change: change status - props', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleSingleDropdownChange(1)({}, {
      value: APPROVAL_STATUSES_IDS.ACCEPT
    });
    expect(props.onUpdate.mock.calls[0][0].decisionItemsIds).toEqual([1]);
    expect(props.onUpdate.mock.calls[0][0].approvalStatusId)
      .toEqual(APPROVAL_STATUSES_IDS.ACCEPT);
    expect(props.onUpdate.mock.calls[0][0].comment).toEqual(undefined);
    expect(props.onUpdate.mock.calls[0][0].confirmedBy).toEqual(undefined);
  });

  it('should handle header dropdown change: explanation modal', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleAllCheckboxChange();
    instance.handleAllDropdownChange({}, {
      value: APPROVAL_STATUSES_IDS.POSTPONE
    });
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(1);
  });

  it('should handle header dropdown change: explanation modal - props', () => {
    // given
    const props = getInitialProps();
    const expectedModalProps = {
      isOpen: true,
      type: MODAL_TYPES.VALIDATION_DECISION
    };

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleAllCheckboxChange();
    instance.handleAllDropdownChange({}, {
      value: APPROVAL_STATUSES_IDS.POSTPONE
    });
    const modalProps = enzymeWrapper.find(ReasonModal).props();
    expect(modalProps.isOpen).toEqual(expectedModalProps.isOpen);
    expect(modalProps.type).toEqual(expectedModalProps.type);
    modalProps.onClose();
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.onUpdate).not.toHaveBeenCalled();
    modalProps.onSubmit({
      confirmedBy: 'user1',
      explanationText: 'explanation'
    });
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.onUpdate).toHaveBeenCalled();
    expect(props.onUpdate.mock.calls[0][0].decisionItemsIds).toEqual([1, 2]);
    expect(props.onUpdate.mock.calls[0][0].approvalStatusId)
      .toEqual(APPROVAL_STATUSES_IDS.POSTPONE);
    expect(props.onUpdate.mock.calls[0][0].comment).toEqual('explanation');
    expect(props.onUpdate.mock.calls[0][0].confirmedBy).toEqual('user1');
  });

  it('should handle single dropdown change: change status - props', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DecisionItemsTable {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    instance.handleAllCheckboxChange();
    instance.handleAllDropdownChange({}, {
      value: APPROVAL_STATUSES_IDS.ACCEPT
    });
    expect(props.onUpdate.mock.calls[0][0].decisionItemsIds).toEqual([1, 2]);
    expect(props.onUpdate.mock.calls[0][0].approvalStatusId)
      .toEqual(APPROVAL_STATUSES_IDS.ACCEPT);
    expect(props.onUpdate.mock.calls[0][0].comment).toEqual(undefined);
    expect(props.onUpdate.mock.calls[0][0].confirmedBy).toEqual(undefined);
  });
});
