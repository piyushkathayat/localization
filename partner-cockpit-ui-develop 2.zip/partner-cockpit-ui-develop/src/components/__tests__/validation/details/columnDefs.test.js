import {
  getColumnDefs,
  getDescriptionalColumnDefs,
  issueSinceColumnDef,
  getNumberColumnDef
} from 'components/validation/qualitychecks/details/columnDefs';
import { DECISION_LEVELS_IDS, DECISION_GROUPS_IDS } from 'constants/validation';
import { QC_TYPE_IDS } from 'constants/qualityCheck';
import { voidFn } from 'utils/common';

describe('columnDefs util functions', () => {
  it('should getColumnDefs', () => {
    // given
    const input = {
      decisionGroup: 1,
      decisionLevel: 1,
      qualityCheckType: 2
    };
    const expectedOutput = [
      ...getDescriptionalColumnDefs(input.decisionLevel),
      issueSinceColumnDef,
      getNumberColumnDef({
        decisionGroup: input.decisionGroup,
        qualityCheckType: input.qualityCheckType
      })
    ];

    // when
    const output = getColumnDefs(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getDescriptionalColumnDefs - DECISION_LEVELS_IDS.INSTRUMENT', () => {
    // given
    const input = DECISION_LEVELS_IDS.INSTRUMENT;
    const expectedOutput = [
      {
        label: {
          id: 'validation.details.isin',
          defaultMessage: 'ISIN'
        },
        dataKey: 'displayKey',
        width: 10,
        maxWidth: 10
      },
      {
        label: {
          id: 'validation.details.instrument_name',
          defaultMessage: 'Instrument Name'
        },
        dataKey: 'displayDescription',
        width: 31,
        maxWidth: 31,
        isLink: false,
        onClick: voidFn
      }
    ];

    // when
    const output = getDescriptionalColumnDefs(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getDescriptionalColumnDefs - DECISION_LEVELS_IDS.PORTFOLIO', () => {
    // given
    const input = DECISION_LEVELS_IDS.PORTFOLIO;
    const expectedOutput = [
      {
        label: {
          id: 'validation.details.assetId',
          defaultMessage: 'Asset ID'
        },
        dataKey: 'displayKey',
        width: 10,
        maxWidth: 10
      },
      {
        label: {
          id: 'validation.details.portfolio',
          defaultMessage: 'Portfolio'
        },
        dataKey: 'displayDescription',
        width: 31,
        maxWidth: 31,
        isLink: true,
        onClick: expect.any(Function)
      }
    ];

    // when
    const output = getDescriptionalColumnDefs(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getDescriptionalColumnDefs - DECISION_LEVELS_IDS.ISSUER', () => {
    // given
    const input = DECISION_LEVELS_IDS.ISSUER;
    const expectedOutput = [
      {
        label: {
          id: 'validation.details.issuerId',
          defaultMessage: 'Issuer ID'
        },
        dataKey: 'displayKey',
        width: 10,
        maxWidth: 10
      },
      {
        label: {
          id: 'validation.details.issuer_name',
          defaultMessage: 'Issuer Name'
        },
        dataKey: 'displayDescription',
        width: 31,
        maxWidth: 31,
        isLink: false,
        onClick: voidFn
      }
    ];

    // when
    const output = getDescriptionalColumnDefs(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getDescriptionalColumnDefs - unknownLevel', () => {
    // given
    const input = 'unknown';
    const expectedOutput = [
      {
        label: {
          id: 'validation.details.unknown_display_key',
          defaultMessage: 'Display Key'
        },
        dataKey: 'displayKey',
        width: 10,
        maxWidth: 10
      },
      {
        label: {
          id: 'validation.details.unknown_display_description',
          defaultMessage: 'Display Description'
        },
        dataKey: 'displayDescription',
        width: 31,
        maxWidth: 31,
        isLink: false,
        onClick: voidFn
      }
    ];

    // when
    const output = getDescriptionalColumnDefs(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getNumberColumnDef - DECISION_GROUPS_IDS.FIRST, qcType === QC_TYPE_IDS.BULK_RISK', () => {
    // given
    const input = {
      decisionGroup: DECISION_GROUPS_IDS.FIRST,
      qualityCheckType: QC_TYPE_IDS.BULK_RISK
    };
    const expectedOutput = {
      label: {
        id: 'validation.details.breaching_positions',
        defaultMessage: 'Number of Breaching Positions'
      },
      dataKey: 'affectedPortfolios',
      width: 14,
      maxWidth: 14,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    };

    // when
    const output = getNumberColumnDef(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getNumberColumnDef - DECISION_GROUPS_IDS.FIRST, qcType === unknownType', () => {
    // given
    const input = {
      decisionGroup: DECISION_GROUPS_IDS.FIRST,
      qualityCheckType: 'unknown'
    };
    const expectedOutput = {
      label: {
        id: 'validation.details.breaching_unknown',
        defaultMessage: 'Number of Breaches'
      },
      dataKey: 'affectedPortfolios',
      width: 14,
      maxWidth: 14,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    };

    // when
    const output = getNumberColumnDef(input);

    // then
    expect(output).toEqual(expectedOutput);
  });

  it('should getNumberColumnDef - DECISION_GROUPS_IDS.SECOND', () => {
    // given
    const input = {
      decisionGroup: DECISION_GROUPS_IDS.SECOND,
      qualityCheckType: QC_TYPE_IDS.OUTSIDE_UNIVERSE
    };
    const expectedOutput = {
      label: {
        id: 'validation.details.affected_portfolios',
        defaultMessage: 'Affected Portfolios'
      },
      dataKey: 'affectedPortfolios',
      width: 14,
      maxWidth: 14,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    };

    // when
    const output = getNumberColumnDef(input);

    // then
    expect(output).toEqual(expectedOutput);
  });
});
