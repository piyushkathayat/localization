import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { NoResults, ErrorMessage } from 'components/common';
import { Loader, Dimmer, Breadcrumb } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import { SORT_DIRECTIONS, APP_PREFIX } from 'constants/common';
import { MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { SERVER_TYPES } from 'constants/serverInfo';
import { ValidationDetails } from 'components/validation/qualitychecks/details/ValidationDetails';
import DecisionItemsTable from 'components/validation/qualitychecks/details/DecisionItemsTable';
// import { getColumnDefs } from 'components/validation/qualitychecks/details/columnDefs';

// TODO: update

const getInitialProps = () => ({
  qualityCheckType: 2,
  approvalStatuses: [13, 20, 30],
  decisionCommon: {
    decisionId: 25,
    date: '2018-12-06T00:00:00',
    statusId: 110,
    isLatestLoad: false
  },
  decisionItemsList: [
    {
      decisionKey: 1,
      approvalStatus: 20,
      affectedPortfolios: 0,
      displayKey: 'LU0452418154',
      displayDescription: 'ALT KEMPEN NDP F',
      commentLast: null,
      confirmedBy: null
    },
    {
      decisionKey: 2,
      approvalStatus: 12,
      affectedPortfolios: 0,
      displayKey: 'FR0000121964',
      displayDescription: 'A KLEPIERRE',
      commentLast: 'Some comment',
      confirmedBy: '43535763'
    }
  ],
  decisionItemsIds: [1, 2],
  decisionLevel: 1,
  decisionGroup: 1,
  qualityCheckName: 'Bulk Risk',
  sorting: {
    sortBy: '',
    sortDirection: SORT_DIRECTIONS.ASC
  },
  serverType: SERVER_TYPES.SHADOW,
  isLoading: false,
  isUpdating: false,
  error: null,
  clearValidationDetails: jest.fn(),
  sortValidationDetails: jest.fn(),
  updateValidationDetails: jest.fn(),
  clearError: jest.fn(),
  fetchAffectedPortfolios: jest.fn()
});

describe('ValidationDetails component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.exists('.validationDetailsContainer')).toBe(true);
  });

  it('should render Breadcrumbs - Loader', () => {
    // given
    const props = getInitialProps();
    props.qualityCheckName = null;
    const expectedBreadcrumbsProps = {
      icon: 'right angle',
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`
        },
        {
          key: 'Details',
          content: (
            <div className="breadcrumbsLoaderContainer">
              <Loader active inline="centered" size="tiny" />
            </div>
          ),
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.find(Breadcrumb)).toHaveLength(1);
    expect(enzymeWrapper.find(Breadcrumb).hasClass('breadcrumbsContainer')).toBe(true);
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.icon).toEqual(expectedBreadcrumbsProps.icon);
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render Breadcrumbs - qualityCheckName', () => {
    // given
    const props = getInitialProps();
    const expectedBreadcrumbsProps = {
      icon: 'right angle',
      sections: [
        {
          key: 'Overview',
          content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
          active: false,
          as: Link,
          to: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`
        },
        {
          key: 'Details',
          content: 'Bulk Risk',
          active: true
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.icon).toEqual(expectedBreadcrumbsProps.icon);
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsProps.sections);
  });

  it('should render Loader instead of a content if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    expect(enzymeWrapper.exists('.decisionItemsListContainer')).toBe(false);
  });

  it('should render NoResults if decisionItemsList is empty', () => {
    // given
    const props = getInitialProps();
    props.decisionItemsList = [];

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.exists('.decisionItemsListContainer')).toBe(false);
  });

  it('should render content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.find(Loader)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(0);
    expect(enzymeWrapper.exists('.decisionItemsListContainer')).toBe(true);
  });

  it('should render DecisionItemsTable', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.find(DecisionItemsTable)).toHaveLength(1);
  });

  // it('should pass proper props to DecisionItemsTable', () => {
  //   // given
  //   const props = getInitialProps();
  //   const expectedTableProps = {
  //     columnDefs: getColumnDefs({
  //       decisionLevel: props.decisionLevel,
  //       decisionGroup: props.decisionGroup,
  //       qualityCheckType: props.qualityCheckType
  //     }),
  //     decisionItemsList: props.decisionItemsList,
  //     decisionItemsIds: props.decisionItemsIds,
  //     qualityCheckType: props.qualityCheckType,
  //     sorting: props.sorting,
  //     onSort: props.sortValidationDetails
  //   };

  //   // when
  //   const enzymeWrapper = shallow(<ValidationDetails {...props} />);

  //   // then
  //   const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
  //   expect(tableProps.columnDefs).toEqual(expectedTableProps.columnDefs);
  //   expect(tableProps.decisionItemsList).toEqual(expectedTableProps.decisionItemsList);
  //   expect(tableProps.decisionItemsIds).toEqual(expectedTableProps.decisionItemsIds);
  //   expect(tableProps.qualityCheckType).toEqual(expectedTableProps.qualityCheckType);
  //   expect(tableProps.sorting).toEqual(expectedTableProps.sorting);
  //   expect(tableProps.onSort).toEqual(expectedTableProps.onSort);
  //   tableProps.onPortfoliosFetch(7139);
  //   expect(props.fetchAffectedPortfolios).toHaveBeenCalled();
  //   expect(props.fetchAffectedPortfolios.mock.calls[0][0]).toEqual({
  //     decisionId: 25,
  //     decisionItemId: 7139
  //   });
  // });

  it('should pass proper props to DecisionItemsTable - actions - postpone', () => {
    // given
    const props = getInitialProps();
    const expectedActions = [
      {
        key: 20,
        text: <FormattedMessage id="validation.accept" defaultMessage="Accept" />,
        value: 20
      },
      {
        key: 13,
        text: <FormattedMessage id="validation.postpone" defaultMessage="Postpone" />,
        value: 13
      },
      {
        key: 30,
        text: <FormattedMessage id="validation.reject" defaultMessage="Reject" />,
        value: 30
      }
    ];

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    expect(tableProps.actions).toEqual(expectedActions);
  });

  it('should pass proper props to DecisionItemsTable - actions - invalidate', () => {
    // given
    const props = getInitialProps();
    props.approvalStatuses = [12, 20];
    const expectedActions = [
      {
        key: 20,
        text: <FormattedMessage id="validation.accept" defaultMessage="Accept" />,
        value: 20
      },
      {
        key: 12,
        text: <FormattedMessage id="validation.invalidate" defaultMessage="Invalidate" />,
        value: 12
      }
    ];

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    expect(tableProps.actions).toEqual(expectedActions);
  });

  it('should pass proper props to DecisionItemsTable - isDisabled - disabled - !isLatestLoad', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    expect(tableProps.isDisabled).toEqual(true);
  });

  it('should pass proper props to DecisionItemsTable - isDisabled - disabled - statusId', () => {
    // given
    const props = getInitialProps();
    props.decisionCommon.isLatestLoad = true;
    props.decisionCommon.statusId = 170;

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    expect(tableProps.isDisabled).toEqual(true);
  });

  it('should pass proper props to DecisionItemsTable - isDisabled - disabled - serverType !== SHADOW', () => {
    // given
    const props = getInitialProps();
    props.decisionCommon.isLatestLoad = true;
    props.decisionCommon.statusId = 110;
    props.serverType = SERVER_TYPES.LIVE;

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    expect(tableProps.isDisabled).toEqual(true);
  });

  it('should pass proper props to DecisionItemsTable - isDisabled - enabled', () => {
    // given
    const props = getInitialProps();
    props.decisionCommon.isLatestLoad = true;
    props.decisionCommon.statusId = 110;

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    expect(tableProps.isDisabled).toEqual(false);
  });

  it('should pass proper props to DecisionItemsTable - onUpdate', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    const tableProps = enzymeWrapper.find(DecisionItemsTable).props();
    tableProps.onUpdate({
      decisionItemsIds: [1, 2],
      approvalStatusId: 13,
      comment: 'postpone',
      confirmedBy: '43535763'
    });
    expect(props.updateValidationDetails).toHaveBeenCalled();
    expect(props.updateValidationDetails.mock.calls[0][0]).toEqual({
      decisionItemsIds: [1, 2],
      approvalStatusId: 13,
      comment: 'postpone',
      confirmedBy: '43535763',
      decisionId: 25,
      qualityCheckType: 2
    });
  });

  it('should render Updater if isUpdating === true', () => {
    // given
    const props = getInitialProps();
    props.isUpdating = true;

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.exists('.updaterContainer')).toBe(true);
    expect(enzymeWrapper.find(Dimmer)).toHaveLength(1);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    errorMessageProps.onDismiss();
    expect(props.clearError).toHaveBeenCalled();
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ValidationDetails {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearValidationDetails).toHaveBeenCalled();
  });
});
