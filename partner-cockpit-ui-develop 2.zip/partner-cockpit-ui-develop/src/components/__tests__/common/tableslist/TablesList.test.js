import React from 'react';
import { shallow } from 'enzyme';
import { TablesList, NoResults, CollapsableTable } from 'components/common';

const getInitialProps = () => ({
  tablesList: [
    {
      id: 0,
      tableData: [
        {
          language: 'EN',
          priority: 2
        },
        {
          language: 'NL',
          priority: 1
        }
      ],
      tableDisplayName: 'allowed_document_language',
      tableName: 'allowed_document_language'
    },
    {
      id: 1,
      tableData: [],
      tableDisplayName: 'application',
      tableName: 'application'
    }
  ]
});

describe('TablesList component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<TablesList {...props} />);

    // then
    expect(enzymeWrapper.exists('.tablesListContainer')).toBe(true);
  });

  it('should render NoResults if no data', () => {
    // given
    const props = getInitialProps();
    props.tablesList = [];

    // when
    const enzymeWrapper = shallow(<TablesList {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
    expect(enzymeWrapper.find(CollapsableTable)).toHaveLength(0);
  });

  it('should render CollapsableTables', () => {
    // given
    const props = getInitialProps();
    const expectedTableProps = {
      table: props.tablesList[0]
    };

    // when
    const enzymeWrapper = shallow(<TablesList {...props} />);

    // then
    expect(enzymeWrapper.find(CollapsableTable)).toHaveLength(2);
    const tableProps = enzymeWrapper.find(CollapsableTable).at(0).props();
    expect(tableProps.table).toEqual(expectedTableProps.table);
  });
});
