import React from 'react';
import { shallow } from 'enzyme';
import { AgGridTable, CollapsableTable } from 'components/common';

const getInitialProps = () => ({
  table: {
    id: 0,
    tableData: [
      {
        language: 'EN',
        priority: 2
      },
      {
        language: 'NL',
        priority: 1
      }
    ],
    tableDisplayName: 'allowed_document_language',
    tableName: 'allowed_document_language'
  }
});

describe('CollapsableTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<CollapsableTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.collapsableTableContainer')).toBe(true);
  });

  it('should render tableBar - with data - collapsed', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<CollapsableTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.tableBar')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').hasClass('collapseable')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').exists('.iconTableBar')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.iconTableBar').hasClass('icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.iconTableBar').hasClass('icon-database')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').exists('.tableName')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.tableName').text()).toEqual('allowed_document_language');
    expect(enzymeWrapper.find('.tableBar').exists('.iconCollapse')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.iconCollapse').hasClass('icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.iconCollapse').hasClass('icon-fast-down')).toBe(true);
  });

  it('should handle tableBar click', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<CollapsableTable {...props} />);

    // then
    enzymeWrapper.find('.tableBar').simulate('click');
    expect(enzymeWrapper.find(AgGridTable)).toHaveLength(1);
    expect(enzymeWrapper.find('.tableBar').find('.iconCollapse').hasClass('icon-fast-up')).toBe(true);
  });

  it('should render tableBar - with no data', () => {
    // given
    const props = getInitialProps();
    props.table.tableData = [];

    // when
    const enzymeWrapper = shallow(<CollapsableTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.tableBar')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').hasClass('collapseable')).toBe(false);
    expect(enzymeWrapper.find('.tableBar').exists('.iconTableBar')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.iconTableBar').hasClass('icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').find('.iconTableBar').hasClass('icon-cancel')).toBe(true);
    expect(enzymeWrapper.find('.tableBar').exists('.iconCollapse')).toBe(false);
  });

  it('should render AgGridTable with props', () => {
    // given
    const props = getInitialProps();
    const expectedTableProps = {
      tableData: props.table.tableData
    };

    // when
    const enzymeWrapper = shallow(<CollapsableTable {...props} />);

    // then
    enzymeWrapper.find('.tableBar').simulate('click');
    expect(enzymeWrapper.find(AgGridTable)).toHaveLength(1);
    expect(enzymeWrapper.find(AgGridTable).hasClass('collapsableTable')).toBe(true);
    const tableProps = enzymeWrapper.find(AgGridTable).props();
    expect(tableProps.tableData).toEqual(expectedTableProps.tableData);
  });
});
