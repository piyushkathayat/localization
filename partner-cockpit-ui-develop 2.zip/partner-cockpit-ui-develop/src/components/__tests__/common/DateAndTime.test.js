import React from 'react';
import { shallow } from 'enzyme';
import { FormattedDate, FormattedRelative } from 'react-intl';
import { DateAndTime } from 'components/common';

const getInitialProps = () => ({
  value: '2019-02-13T00:00:00',
  relative: false,
  day: '2-digit',
  month: '2-digit',
  year: '2-digit',
  hour: '2-digit',
  minute: '2-digit'
});

describe('DateAndTime component', () => {
  it('should render FormattedDate if relative === false', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DateAndTime {...props} />);

    // then
    expect(enzymeWrapper.find(FormattedDate)).toHaveLength(1);
    expect(enzymeWrapper.find(FormattedRelative)).toHaveLength(0);
  });

  it('should render FormattedRelative if relative === true', () => {
    // given
    const props = getInitialProps();
    props.relative = true;

    // when
    const enzymeWrapper = shallow(<DateAndTime {...props} />);

    // then
    expect(enzymeWrapper.find(FormattedDate)).toHaveLength(0);
    expect(enzymeWrapper.find(FormattedRelative)).toHaveLength(1);
    expect(enzymeWrapper.find(FormattedRelative).prop('value')).toEqual('2019-02-13T00:00:00');
  });

  it('should pass props - default', () => {
    // given
    const props = {
      value: '2019-02-13T00:00:00'
    };
    const expectedDateProps = {
      value: '2019-02-13T00:00:00',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: undefined,
      minute: undefined
    };

    // when
    const enzymeWrapper = shallow(<DateAndTime {...props} />);

    // then
    const dateProps = enzymeWrapper.find(FormattedDate).props();
    expect(dateProps.value).toEqual(expectedDateProps.value);
    expect(dateProps.day).toEqual(expectedDateProps.day);
    expect(dateProps.month).toEqual(expectedDateProps.month);
    expect(dateProps.year).toEqual(expectedDateProps.year);
    expect(dateProps.hour).toEqual(expectedDateProps.hour);
    expect(dateProps.minute).toEqual(expectedDateProps.minute);
  });

  it('should pass props - set up manually', () => {
    // given
    const props = getInitialProps();
    const expectedDateProps = {
      value: '2019-02-13T00:00:00',
      day: '2-digit',
      month: '2-digit',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    };

    // when
    const enzymeWrapper = shallow(<DateAndTime {...props} />);

    // then
    const dateProps = enzymeWrapper.find(FormattedDate).props();
    expect(dateProps.value).toEqual(expectedDateProps.value);
    expect(dateProps.day).toEqual(expectedDateProps.day);
    expect(dateProps.month).toEqual(expectedDateProps.month);
    expect(dateProps.year).toEqual(expectedDateProps.year);
    expect(dateProps.hour).toEqual(expectedDateProps.hour);
    expect(dateProps.minute).toEqual(expectedDateProps.minute);
  });
});
