import React from 'react';
import { shallow } from 'enzyme';
import { Grid } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { NoResults } from 'components/common';

describe('NoResults component', () => {
  it('should render self and subcomponents', () => {
    // given

    // when
    const enzymeWrapper = shallow(<NoResults />);

    // then
    expect(enzymeWrapper.exists('.noResults')).toBe(true);
  });

  it('should render Grid', () => {
    // given

    // when
    const enzymeWrapper = shallow(<NoResults />);

    // then
    expect(enzymeWrapper.find(Grid)).toHaveLength(1);
    expect(enzymeWrapper.find(Grid).prop('textAlign')).toEqual('center');
    expect(enzymeWrapper.find(Grid).prop('verticalAlign')).toEqual('middle');
    expect(enzymeWrapper.find(Grid).prop('columns')).toEqual('equal');
    expect(enzymeWrapper.find(Grid).prop('container')).toEqual(true);
  });

  it('should render Grid.Row', () => {
    // given

    // when
    const enzymeWrapper = shallow(<NoResults />);

    // then
    expect(enzymeWrapper.find(Grid.Row)).toHaveLength(1);
    expect(enzymeWrapper.find(Grid.Row).prop('centered')).toEqual(true);
  });

  it('should render Grid.Column', () => {
    // given

    // when
    const enzymeWrapper = shallow(<NoResults />);

    // then
    expect(enzymeWrapper.find(Grid.Column)).toHaveLength(1);
    expect(enzymeWrapper.find(Grid.Column).prop('width')).toEqual(4);
    expect(enzymeWrapper.find(Grid.Column).prop('textAlign')).toEqual('center');
  });

  it('should render FormattedMessage', () => {
    // given

    // when
    const enzymeWrapper = shallow(<NoResults />);

    // then
    expect(enzymeWrapper.find(FormattedMessage)).toHaveLength(1);
    expect(enzymeWrapper.find(FormattedMessage).prop('id')).toEqual('common.no_results');
    expect(enzymeWrapper.find(FormattedMessage).prop('defaultMessage'))
      .toEqual('There is no data to display');
  });
});
