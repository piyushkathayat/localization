import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { Confirm, Button } from 'semantic-ui-react';
import { ConfirmModal } from 'components/common';

const getInitialProps = () => ({
  className: 'myOwnClassName',
  open: false,
  size: 'small',
  header: 'myOwnHeader',
  content: 'myOwnContent',
  cancelButton: (
    <Button className="ubs-secondary-button">
      myOwnCancelButton
    </Button>
  ),
  confirmButton: (
    <Button className="ubs-primary-button">
      myOwnConfirmButton
    </Button>
  ),
  onCancel: jest.fn(),
  onConfirm: jest.fn()
});

describe('ConfirmModal component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ConfirmModal {...props} />);

    // then
    expect(enzymeWrapper.find(Confirm)).toHaveLength(1);
    expect(enzymeWrapper.find(Confirm).hasClass('confirmModal')).toBe(true);
  });

  it('should pass props - default', () => {
    // given
    const props = {
      onCancel: jest.fn(),
      onConfirm: jest.fn()
    };
    const expectedConfirmProps = {
      open: true,
      size: 'tiny',
      header: (
        <div className="header">
          <FormattedMessage defaultMessage="Confirmation" id="common.confirmation.header" />
        </div>
      ),
      content: (
        <div className="content">
          <FormattedMessage defaultMessage="Are you sure?" id="common.confirmation.content" />
        </div>
      ),
      cancelButton: (
        <Button className="ubs-secondary-button">
          <FormattedMessage defaultMessage="Cancel" id="common.cancel" />
        </Button>
      ),
      confirmButton: (
        <Button className="ubs-primary-button">
          <FormattedMessage defaultMessage="OK" id="common.ok" />
        </Button>
      )
    };

    // when
    const enzymeWrapper = shallow(<ConfirmModal {...props} />);

    // then
    const confirmProps = enzymeWrapper.find(Confirm).props();
    expect(confirmProps.open).toEqual(expectedConfirmProps.open);
    expect(confirmProps.size).toEqual(expectedConfirmProps.size);
    expect(confirmProps.header).toEqual(expectedConfirmProps.header);
    expect(confirmProps.content).toEqual(expectedConfirmProps.content);
    expect(confirmProps.cancelButton).toEqual(expectedConfirmProps.cancelButton);
    expect(confirmProps.confirmButton).toEqual(expectedConfirmProps.confirmButton);
    confirmProps.onCancel();
    expect(props.onCancel).toHaveBeenCalled();
    confirmProps.onConfirm();
    expect(props.onConfirm).toHaveBeenCalled();
  });

  it('should pass props - set up manually', () => {
    // given
    const props = getInitialProps();
    const expectedConfirmProps = {
      open: false,
      size: 'small',
      header: (
        <div className="header">
          myOwnHeader
        </div>
      ),
      content: (
        <div className="content">
          myOwnContent
        </div>
      ),
      cancelButton: (
        <Button className="ubs-secondary-button">
          myOwnCancelButton
        </Button>
      ),
      confirmButton: (
        <Button className="ubs-primary-button">
          myOwnConfirmButton
        </Button>
      )
    };

    // when
    const enzymeWrapper = shallow(<ConfirmModal {...props} />);

    // then
    expect(enzymeWrapper.find(Confirm).hasClass('myOwnClassName')).toBe(true);
    const confirmProps = enzymeWrapper.find(Confirm).props();
    expect(confirmProps.open).toEqual(expectedConfirmProps.open);
    expect(confirmProps.size).toEqual(expectedConfirmProps.size);
    expect(confirmProps.header).toEqual(expectedConfirmProps.header);
    expect(confirmProps.content).toEqual(expectedConfirmProps.content);
    expect(confirmProps.cancelButton).toEqual(expectedConfirmProps.cancelButton);
    expect(confirmProps.confirmButton).toEqual(expectedConfirmProps.confirmButton);
    confirmProps.onCancel();
    expect(props.onCancel).toHaveBeenCalled();
    confirmProps.onConfirm();
    expect(props.onConfirm).toHaveBeenCalled();
  });
});
