import React from 'react';
import { shallow } from 'enzyme';
import { Dropdown } from 'semantic-ui-react';
import { SearchDropdown } from 'components/common/searchdropdown/SearchDropdown';

const getInitialProps = () => ({
  className: 'myOwnClassName',
  options: [
    {
      key: '1',
      text: 'first',
      value: '1'
    },
    {
      key: '2',
      text: 'second',
      value: '2'
    },
    {
      key: '3',
      text: 'third',
      value: '3'
    }
  ],
  onChange: jest.fn(),
  intl: {
    formatMessage: jest.fn()
  }
});

describe('SearchDropdown component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SearchDropdown {...props} />);

    // then
    expect(enzymeWrapper.exists('.filterDropdown')).toBe(true);
    expect(enzymeWrapper.find('.filterDropdown').hasClass('myOwnClassName')).toBe(true);
  });

  it('should render Dropdown with props', () => {
    // given
    const props = getInitialProps();
    const expectedDropdownProps = {
      fluid: true,
      multiple: true,
      search: true,
      selection: true,
      options: props.options
    };

    // when
    const enzymeWrapper = shallow(<SearchDropdown {...props} />);

    // then
    expect(enzymeWrapper.find(Dropdown)).toHaveLength(1);
    const dropdownProps = enzymeWrapper.find(Dropdown).props();
    expect(dropdownProps.fluid).toEqual(expectedDropdownProps.fluid);
    expect(dropdownProps.multiple).toEqual(expectedDropdownProps.multiple);
    expect(dropdownProps.search).toEqual(expectedDropdownProps.search);
    expect(dropdownProps.selection).toEqual(expectedDropdownProps.selection);
    expect(dropdownProps.options).toEqual(expectedDropdownProps.options);
    dropdownProps.onChange({}, { value: '2' });
    expect(props.onChange).toHaveBeenCalled();
    expect(props.onChange.mock.calls[0][0]).toEqual('2');
  });
});
