import React from 'react';
import { shallow } from 'enzyme';
import { Icon, Pagination } from 'semantic-ui-react';
import { PaginationBar } from 'components/common';

const getInitialProps = () => ({
  currentPage: 1,
  totalPages: 5,
  onPageChange: jest.fn()
});

describe('PaginationBar component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PaginationBar {...props} />);

    // then
    expect(enzymeWrapper.find(Pagination)).toHaveLength(1);
    expect(enzymeWrapper.find(Pagination).hasClass('paginationBar')).toBe(true);
  });

  it('should render null if !totalPages', () => {
    // given
    const props = getInitialProps();
    props.totalPages = 0;

    // when
    const enzymeWrapper = shallow(<PaginationBar {...props} />);

    // then
    expect(enzymeWrapper.getElement()).toBe(null);
  });

  it('should render PaginationBar with props', () => {
    // given
    const props = getInitialProps();
    const expectedBarProps = {
      activePage: 1,
      ellipsisItem: {
        content: <Icon name="ellipsis horizontal" />,
        icon: true
      },
      firstItem: {
        content: <Icon name="angle double left" />,
        icon: true
      },
      lastItem: {
        content: <Icon name="angle double right" />,
        icon: true
      },
      prevItem: {
        content: <Icon name="angle left" />,
        icon: true
      },
      nextItem: {
        content: <Icon name="angle right" />,
        icon: true
      },
      totalPages: 5
    };

    // when
    const enzymeWrapper = shallow(<PaginationBar {...props} />);

    // then
    const barProps = enzymeWrapper.find(Pagination).props();
    expect(barProps.activePage).toEqual(expectedBarProps.activePage);
    expect(barProps.ellipsisItem).toEqual(expectedBarProps.ellipsisItem);
    expect(barProps.firstItem).toEqual(expectedBarProps.firstItem);
    expect(barProps.lastItem).toEqual(expectedBarProps.lastItem);
    expect(barProps.prevItem).toEqual(expectedBarProps.prevItem);
    expect(barProps.nextItem).toEqual(expectedBarProps.nextItem);
    expect(barProps.totalPages).toEqual(expectedBarProps.totalPages);
    barProps.onPageChange({}, { activePage: 2 });
    expect(props.onPageChange).toHaveBeenCalled();
    expect(props.onPageChange.mock.calls[0][0]).toEqual(2);
  });
});
