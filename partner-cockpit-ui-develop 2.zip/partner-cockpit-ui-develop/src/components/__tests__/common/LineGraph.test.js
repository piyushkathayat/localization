import React from 'react';
import { shallow } from 'enzyme';
import { FORMATS } from 'constants/common';
import { FormattedMessage } from 'react-intl';
import {
  ResponsiveContainer,
  LineChart,
  XAxis,
  Line,
  Tooltip
} from 'recharts';
import { LineGraph } from 'components/common';
import { CustomizedCursor } from 'components/common/linegraph/LineGraph';

const getInitialProps = () => ({
  chartData: [
    {
      date: '2019-02-13T00:00:00',
      value: 7570
    },
    {
      date: '2019-02-12T00:00:00',
      value: 7570
    },
    {
      date: '2019-02-11T00:00:00',
      value: 7546
    },
    {
      date: '2019-01-16T00:00:00',
      value: 7546
    },
    {
      date: '2019-01-15T00:00:00',
      value: 7546
    }
  ],
  styles: {
    width: 230,
    height: 60,
    padding: {
      top: 10,
      right: 15,
      bottom: 10,
      left: 15
    }
  },
  format: FORMATS.NUMBER,
  currency: 'USD',
  hasOnlyStartAndEndDates: true
});

describe('LineGraph component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.exists('.lineGraphContainer')).toBe(true);
  });

  it('should render noData instead of graph if data is empty', () => {
    // given
    const props = getInitialProps();
    props.chartData = [];
    const expectedMessageProps = {
      id: 'common.no_results',
      defaultMessage: 'There is no data to display'
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.exists('.lineGraphContainer')).toBe(true);
    expect(enzymeWrapper.exists('.noGraphData')).toBe(true);
    expect(enzymeWrapper.find('.noGraphData').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.noGraphData').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render ResponsiveContainer', () => {
    // given
    const props = getInitialProps();
    const expectedContainerProps = {
      width: '100%',
      height: 60
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(ResponsiveContainer)).toHaveLength(1);
    expect(enzymeWrapper.find(ResponsiveContainer).hasClass('lineGraph')).toBe(true);
    const containerProps = enzymeWrapper.find(ResponsiveContainer).props();
    expect(containerProps.width).toEqual(expectedContainerProps.width);
    expect(containerProps.height).toEqual(expectedContainerProps.height);
  });

  it('should render LineChart', () => {
    // given
    const props = getInitialProps();
    const expectedChartProps = {
      width: 230,
      height: 30,
      data: props.chartData,
      margin: {
        top: 10,
        bottom: 10
      }
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(LineChart)).toHaveLength(1);
    const chartProps = enzymeWrapper.find(LineChart).props();
    expect(chartProps.width).toEqual(expectedChartProps.width);
    expect(chartProps.height).toEqual(expectedChartProps.height);
    expect(chartProps.data).toEqual(expectedChartProps.data);
    expect(chartProps.margin).toEqual(expectedChartProps.margin);
  });

  it('should render XAxis with proper props', () => {
    // given
    const props = getInitialProps();
    const expectedAxisProps = {
      dataKey: 'date',
      height: 10,
      padding: {
        left: 15,
        right: 15
      },
      interval: 3
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(XAxis)).toHaveLength(1);
    const axisProps = enzymeWrapper.find(XAxis).props();
    expect(axisProps.dataKey).toEqual(expectedAxisProps.dataKey);
    expect(axisProps.height).toEqual(expectedAxisProps.height);
    expect(axisProps.padding).toEqual(expectedAxisProps.padding);
    expect(axisProps.interval).toEqual(expectedAxisProps.interval);
  });

  it('should pass XAxis interval correctly', () => {
    // given
    const props = getInitialProps();
    props.hasOnlyStartAndEndDates = false;
    const expectedAxisProps = {
      interval: 'preserveStartEnd'
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    const axisProps = enzymeWrapper.find(XAxis).props();
    expect(axisProps.interval).toEqual(expectedAxisProps.interval);
  });

  it('should calculate XAxis interval correctly - chartData.length === 2', () => {
    // given
    const props = getInitialProps();
    props.chartData = [
      {
        date: '2019-02-13T00:00:00',
        value: 7570
      },
      {
        date: '2019-02-12T00:00:00',
        value: 7570
      }
    ];
    const expectedAxisProps = {
      interval: 0
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    const axisProps = enzymeWrapper.find(XAxis).props();
    expect(axisProps.interval).toEqual(expectedAxisProps.interval);
  });

  it('should calculate XAxis interval correctly - chartData.length < 2', () => {
    // given
    const props = getInitialProps();
    props.chartData = [
      {
        date: '2019-02-13T00:00:00',
        value: 7570
      }
    ];
    const expectedAxisProps = {
      interval: 0
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    const axisProps = enzymeWrapper.find(XAxis).props();
    expect(axisProps.interval).toEqual(expectedAxisProps.interval);
  });

  it('should render Tooltip', () => {
    // given
    const props = getInitialProps();
    const expectedTooltipProps = {
      cursor: <CustomizedCursor barsCount={5} />,
      position: { y: -45 }
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(Tooltip)).toHaveLength(1);
    const tooltipProps = enzymeWrapper.find(Tooltip).props();
    expect(tooltipProps.cursor).toEqual(expectedTooltipProps.cursor);
    expect(tooltipProps.position).toEqual(expectedTooltipProps.position);
  });

  it('should render Line', () => {
    // given
    const props = getInitialProps();
    const expectedLineProps = {
      isAnimationActive: false,
      type: 'monotone',
      dataKey: 'value',
      stroke: '#007099'
    };

    // when
    const enzymeWrapper = shallow(<LineGraph {...props} />);

    // then
    expect(enzymeWrapper.find(Line)).toHaveLength(1);
    const lineProps = enzymeWrapper.find(Line).props();
    expect(lineProps.isAnimationActive).toEqual(expectedLineProps.isAnimationActive);
    expect(lineProps.type).toEqual(expectedLineProps.type);
    expect(lineProps.dataKey).toEqual(expectedLineProps.dataKey);
    expect(lineProps.stroke).toEqual(expectedLineProps.stroke);
  });

  it('should render CustomizedCursor - MAX_BAR_WIDTH reached', () => {
    // given
    const props = {
      barsCount: 5,
      width: 230,
      height: 30,
      points: [
        {
          x: 0,
          y: 0
        }
      ]
    };
    const expectedRectProps = {
      x: -15,
      y: 0,
      width: 30,
      height: 29
    };

    // when
    const enzymeWrapper = shallow(<CustomizedCursor {...props} />);

    // then
    expect(enzymeWrapper.find('rect')).toHaveLength(1);
    const rectProps = enzymeWrapper.find('rect').props();
    expect(rectProps.x).toEqual(expectedRectProps.x);
    expect(rectProps.y).toEqual(expectedRectProps.y);
    expect(rectProps.width).toEqual(expectedRectProps.width);
    expect(rectProps.height).toEqual(expectedRectProps.height);
  });

  it('should render CustomizedCursor - MAX_BAR_WIDTH not reached', () => {
    // given
    const props = {
      barsCount: 10,
      width: 230,
      height: 30,
      points: [
        {
          x: 0,
          y: 0
        }
      ]
    };
    const expectedRectProps = {
      x: -10.35,
      width: 20.7
    };

    // when
    const enzymeWrapper = shallow(<CustomizedCursor {...props} />);

    // then
    expect(enzymeWrapper.find('rect')).toHaveLength(1);
    const rectProps = enzymeWrapper.find('rect').props();
    expect(rectProps.x).toEqual(expectedRectProps.x);
    expect(rectProps.width).toEqual(expectedRectProps.width);
  });
});
