import React from 'react';
import { shallow } from 'enzyme';
import { MODAL_TYPES } from 'constants/common';
import { Modal, Button, Form, Input, TextArea, Message } from 'semantic-ui-react';
import { ReasonModal } from 'components/common/reasonmodal/ReasonModal';
import { FormattedMessage } from 'react-intl';

const getInitialProps = () => ({
  isOpen: true,
  type: MODAL_TYPES.VALIDATION_DECISION,
  firstTextVariable: undefined,
  secondTextVariable: undefined,
  confirmedBy: undefined,
  explanationText: undefined,
  dependentDatabases: undefined,
  onClose: jest.fn(),
  onSubmit: jest.fn(),
  intl: {
    formatMessage: jest.fn()
  }
});

describe('ReasonModal component', () => {
  it('should render Modal with props', () => {
    // given
    const props = getInitialProps();
    const expectedModalProps = {
      dimmer: 'blurring',
      size: 'tiny',
      open: true,
      closeIcon: true
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal)).toHaveLength(1);
    expect(enzymeWrapper.find(Modal).hasClass('reasonModal')).toBe(true);
    const modalProps = enzymeWrapper.find(Modal).props();
    expect(modalProps.dimmer).toEqual(expectedModalProps.dimmer);
    expect(modalProps.size).toEqual(expectedModalProps.size);
    expect(modalProps.open).toEqual(expectedModalProps.open);
    expect(modalProps.closeIcon).toEqual(expectedModalProps.closeIcon);
    modalProps.onClose();
    expect(props.onClose).toHaveBeenCalled();
  });

  it('should render Modal.Header - MODAL_TYPES.VALIDATION_DECISION', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'validation.details.modal.header',
      defaultMessage: 'Validation'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Modal.Header).find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find(Modal.Header).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render Modal.Header - MODAL_TYPES.DEMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.DEMOTE_DATABASE;
    const expectedMessageProps = {
      id: 'promotion.demote_modal.title',
      defaultMessage: 'Demote database'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Modal.Header).find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find(Modal.Header).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render Modal.Header - MODAL_TYPES.PROMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.PROMOTE_DATABASE;
    const expectedMessageProps = {
      id: 'promotion.promote_modal.title',
      defaultMessage: 'Promote database'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Modal.Header).find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find(Modal.Header).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render Modal.Header - MODAL_TYPES.EDIT_COMMENT', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.EDIT_COMMENT;
    const expectedMessageProps = {
      id: 'promotion.edit_comment_modal.title',
      defaultMessage: 'Edit comment'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Modal.Header).find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find(Modal.Header).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render Modal.Content', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal.Content)).toHaveLength(1);
    expect(enzymeWrapper.find(Modal.Content).find('.subHeader')).toHaveLength(1);
  });

  it('should render explanation - MODAL_TYPES.VALIDATION_DECISION', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'validation.details.modal.insert_explanation',
      defaultMessage: 'Please insert an explanation for not accepting decision'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanation')).toHaveLength(1);
    expect(enzymeWrapper.find('.insertExplanation').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.insertExplanation').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render explanation - MODAL_TYPES.DEMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.DEMOTE_DATABASE;
    props.firstTextVariable = 'databaseName';
    const expectedMessageProps = {
      id: 'promotion.demote_modal.description',
      defaultMessage: 'Please insert an explanation for not promoting {item}',
      values: {
        item: <strong>databaseName</strong>
      }
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanation')).toHaveLength(1);
    expect(enzymeWrapper.find('.insertExplanation').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.insertExplanation').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(messageProps.values).toEqual(expectedMessageProps.values);
  });

  it('should render explanation - MODAL_TYPES.PROMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.PROMOTE_DATABASE;
    props.firstTextVariable = 'databaseName';
    const expectedMessageProps = {
      id: 'promotion.promote_modal.description',
      defaultMessage: 'You intend to promote {item} that was not promoted in the past.',
      values: {
        item: <strong>databaseName</strong>
      }
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanation')).toHaveLength(1);
    expect(enzymeWrapper.find('.insertExplanation').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.insertExplanation').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(messageProps.values).toEqual(expectedMessageProps.values);
  });

  it('should not render explanation - MODAL_TYPES.EDIT_COMMENT', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.EDIT_COMMENT;

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanation')).toHaveLength(0);
  });

  it('should not render explanationSecondLine - MODAL_TYPES.VALIDATION_DECISION', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanationSecondLine')).toHaveLength(0);
  });

  it('should render explanationSecondLine - MODAL_TYPES.DEMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.DEMOTE_DATABASE;
    props.firstTextVariable = 'databaseName';
    props.secondTextVariable = 'databaseName, databaseName';
    const expectedMessageProps = {
      id: 'promotion.demote_modal.demote_dependants_warning',
      defaultMessage: 'Following databases depends on {item}: {items}. Since you have deselected {item}, you should also deselect following databases: {items}.',
      values: {
        item: <strong>databaseName</strong>,
        items: <span>databaseName, databaseName</span>
      }
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanationSecondLine')).toHaveLength(1);
    expect(enzymeWrapper.find('.insertExplanationSecondLine').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.insertExplanationSecondLine').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(messageProps.values).toEqual(expectedMessageProps.values);
  });

  it('should not render explanationSecondLine - MODAL_TYPES.PROMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.PROMOTE_DATABASE;

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanationSecondLine')).toHaveLength(0);
  });

  it('should not render explanationSecondLine - MODAL_TYPES.EDIT_COMMENT', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.EDIT_COMMENT;

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.insertExplanationSecondLine')).toHaveLength(0);
  });

  it('should render noCID - MODAL_TYPES.VALIDATION_DECISION', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'common.reason_modal.no_cid',
      defaultMessage: 'No CID information to be included in the comment!'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.noCID')).toHaveLength(1);
    expect(enzymeWrapper.find('.noCID').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.noCID').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render noCID - MODAL_TYPES.DEMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.DEMOTE_DATABASE;
    const expectedMessageProps = {
      id: 'common.reason_modal.no_cid',
      defaultMessage: 'No CID information to be included in the comment!'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.noCID')).toHaveLength(1);
    expect(enzymeWrapper.find('.noCID').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.noCID').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render noCID - MODAL_TYPES.PROMOTE_DATABASE', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.PROMOTE_DATABASE;
    const expectedMessageProps = {
      id: 'common.reason_modal.no_cid',
      defaultMessage: 'No CID information to be included in the comment!'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.noCID')).toHaveLength(1);
    expect(enzymeWrapper.find('.noCID').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.noCID').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render noCID - MODAL_TYPES.EDIT_COMMENT', () => {
    // given
    const props = getInitialProps();
    props.type = MODAL_TYPES.EDIT_COMMENT;
    const expectedMessageProps = {
      id: 'common.reason_modal.no_cid',
      defaultMessage: 'No CID information to be included in the comment!'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.noCID')).toHaveLength(1);
    expect(enzymeWrapper.find('.noCID').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.noCID').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render explanationForm', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.explanationForm')).toHaveLength(1);
    expect(enzymeWrapper.find('.explanationForm').find(Form)).toHaveLength(1);
  });

  it('should render confirmedBy', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'common.reason_modal.confirmedBy',
      defaultMessage: 'Confirmed by:'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.confirmedBy')).toHaveLength(1);
    expect(enzymeWrapper.find('.confirmedBy').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.confirmedBy').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render confirmedBy Input', () => {
    // given
    const props = getInitialProps();
    props.confirmedBy = '43535763';
    const expectedInputProps = {
      defaultValue: '43535763'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find('.confirmedBy')).toHaveLength(1);
    expect(enzymeWrapper.find('.confirmedBy').find(Input)).toHaveLength(1);
    const inputProps = enzymeWrapper.find('.confirmedBy').find(Input).props();
    expect(inputProps.defaultValue).toEqual(expectedInputProps.defaultValue);
  });

  it('should render TextArea', () => {
    // given
    const props = getInitialProps();
    props.explanationText = 'someText';
    const expectedTextAreaProps = {
      placeholder: props.intl.formatMessage,
      autoHeight: true,
      rows: 3,
      defaultValue: 'someText'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(TextArea)).toHaveLength(1);
    expect(enzymeWrapper.find(TextArea).hasClass('explanationTextArea')).toBe(true);
    const textAreaProps = enzymeWrapper.find(TextArea).props();
    expect(textAreaProps.autoHeight).toEqual(expectedTextAreaProps.autoHeight);
    expect(textAreaProps.rows).toEqual(expectedTextAreaProps.rows);
    expect(textAreaProps.defaultValue).toEqual(expectedTextAreaProps.defaultValue);
  });

  it('should handle Input and TextArea changes', () => {
    // given
    const props = getInitialProps();
    props.confirmedBy = '43535763';
    props.explanationText = 'someText';

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);
    const instance = enzymeWrapper.instance();

    // then
    enzymeWrapper.find('.confirmedBy').find(Input).simulate('change', {}, { value: '43535764' });
    enzymeWrapper.find(TextArea).simulate('change', {}, { value: 'someOtherText' });
    expect(instance.state.confirmedBy).toEqual('43535764');
    expect(instance.state.explanationText).toEqual('someOtherText');
  });

  it('should render Modal.Actions', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Modal.Actions)).toHaveLength(1);
  });

  it('should render Button with props', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'common.save',
      defaultMessage: 'Save'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Button)).toHaveLength(1);
    expect(enzymeWrapper.find(Button).hasClass('ubs-primary-button')).toBe(true);
    expect(enzymeWrapper.find(Button).find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find(Button).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should disable Button if some fields are not filled in - both fields', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Button).prop('disabled')).toBe(true);
  });

  it('should disable Button if some fields are not filled in - confirmedBy', () => {
    // given
    const props = getInitialProps();
    props.explanationText = 'someText';

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Button).prop('disabled')).toBe(true);
  });

  it('should disable Button if some fields are not filled in - explanationText', () => {
    // given
    const props = getInitialProps();
    props.confirmedBy = '43535763';

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Button).prop('disabled')).toBe(true);
  });

  it('should enable Button if both fields are filled in', () => {
    // given
    const props = getInitialProps();
    props.confirmedBy = '43535763';
    props.explanationText = 'someText';

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    expect(enzymeWrapper.find(Button).prop('disabled')).toBe(false);
  });

  it('should handle Button click - error', () => {
    // given
    const props = getInitialProps();
    props.confirmedBy = '43535763';
    const expectedMessageProps = {
      id: 'common.reason_modal.error',
      defaultMessage: 'Please fill in all fields.'
    };

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    enzymeWrapper.find(Button).simulate('click');
    expect(enzymeWrapper.find(Message)).toHaveLength(1);
    expect(enzymeWrapper.find(Message).prop('negative')).toEqual(true);
    expect(enzymeWrapper.find(Message).find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find(Message).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should handle Button click - success', () => {
    // given
    const props = getInitialProps();
    props.confirmedBy = '43535763';
    props.explanationText = 'someText';

    // when
    const enzymeWrapper = shallow(<ReasonModal {...props} />);

    // then
    enzymeWrapper.find(Button).simulate('click');
    expect(enzymeWrapper.find(Message)).toHaveLength(0);
    expect(props.onSubmit).toHaveBeenCalled();
    expect(props.onSubmit.mock.calls[0][0]).toEqual({
      confirmedBy: '43535763',
      explanationText: 'someText'
    });
  });
});
