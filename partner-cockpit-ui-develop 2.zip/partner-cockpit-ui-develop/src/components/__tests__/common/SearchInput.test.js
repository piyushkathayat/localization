import React from 'react';
import { shallow } from 'enzyme';
import { Input } from 'semantic-ui-react';
import { SearchInput } from 'components/common/searchinput/SearchInput';

const getInitialProps = () => ({
  className: 'myOwnClassName',
  value: 'searchTerm',
  onChange: jest.fn(),
  onClear: jest.fn(),
  intl: {
    formatMessage: jest.fn()
  }
});

describe('SearchInput component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<SearchInput {...props} />);

    // then
    expect(enzymeWrapper.exists('.searchInput')).toBe(true);
    expect(enzymeWrapper.find('.searchInput').hasClass('myOwnClassName')).toBe(true);
  });

  it('should render Input - with close icon', () => {
    // given
    const props = getInitialProps();
    const expectedInputProps = {
      icon: {
        name: 'close',
        link: true,
        onClick: props.onClear
      },
      value: 'searchTerm'
    };

    // when
    const enzymeWrapper = shallow(<SearchInput {...props} />);

    // then
    expect(enzymeWrapper.find(Input)).toHaveLength(1);
    const inputProps = enzymeWrapper.find(Input).props();
    expect(inputProps.icon).toEqual(expectedInputProps.icon);
    expect(inputProps.value).toEqual(expectedInputProps.value);
    inputProps.icon.onClick();
    expect(props.onClear).toHaveBeenCalled();
    inputProps.onChange({}, { value: 'searchTerm!' });
    expect(props.onChange).toHaveBeenCalled();
    expect(props.onChange.mock.calls[0][0]).toEqual('searchTerm!');
  });

  it('should render Input - with search icon', () => {
    // given
    const props = getInitialProps();
    props.value = '';
    const expectedInputProps = {
      icon: 'search'
    };

    // when
    const enzymeWrapper = shallow(<SearchInput {...props} />);

    // then
    const inputProps = enzymeWrapper.find(Input).props();
    expect(inputProps.icon).toEqual(expectedInputProps.icon);
  });
});
