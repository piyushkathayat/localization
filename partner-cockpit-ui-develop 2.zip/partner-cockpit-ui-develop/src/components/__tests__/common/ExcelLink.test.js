import React from 'react';
import { shallow } from 'enzyme';
import { Loader } from 'semantic-ui-react';
import { ExcelLink } from 'components/common';

const getInitialProps = () => ({
  isLoading: false,
  onFileFetch: jest.fn()
});

describe('ExcelLink component', () => {
  it('should render excelLink', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ExcelLink {...props} />);

    // then
    expect(enzymeWrapper.find('div')).toHaveLength(1);
    expect(enzymeWrapper.find('div').hasClass('excelLink')).toBe(true);
    enzymeWrapper.find('div').simulate('click');
    expect(props.onFileFetch).toHaveBeenCalled();
    expect(enzymeWrapper.find('div').find('i')).toHaveLength(1);
    expect(enzymeWrapper.find('div').find('i').hasClass('icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('div').find('i').hasClass('icon-excel')).toBe(true);
    expect(enzymeWrapper.find('div').find('i').hasClass('iconDetails')).toBe(true);
  });

  it('should render Loader if isLoading === true', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;
    const expectedLoaderProps = {
      active: true,
      inline: 'centered',
      size: 'tiny'
    };

    // when
    const enzymeWrapper = shallow(<ExcelLink {...props} />);

    // then
    expect(enzymeWrapper.find('div')).toHaveLength(0);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
    const loaderProps = enzymeWrapper.find(Loader).props();
    expect(loaderProps.active).toEqual(expectedLoaderProps.active);
    expect(loaderProps.inline).toEqual(expectedLoaderProps.inline);
    expect(loaderProps.size).toEqual(expectedLoaderProps.size);
  });
});
