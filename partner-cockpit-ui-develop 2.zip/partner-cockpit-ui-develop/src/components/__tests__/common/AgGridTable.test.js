import React from 'react';
import { shallow } from 'enzyme';
import { AgGridReact } from 'ag-grid-react';
import { AgGridTable, NoResults } from 'components/common';

const getInitialProps = () => ({
  tableData: [
    {
      language: 'EN',
      priority: 2
    },
    {
      language: 'NL',
      priority: 1
    }
  ],
  maxHeight: 520,
  enableFilter: true,
  className: '',
  hasFixedHeight: false,
  isSelectable: true
});

describe('AgGridTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.agGridTable')).toBe(true);
    expect(enzymeWrapper.find('.agGridTable').hasClass('ag-theme-balham')).toBe(true);
    expect(enzymeWrapper.find(AgGridReact)).toHaveLength(1);
  });

  it('should render NoResults instead of a table if no data', () => {
    // given
    const props = getInitialProps();
    props.tableData = [];

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.agGridTable')).toBe(false);
    expect(enzymeWrapper.find(AgGridReact)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
  });

  it('should set className', () => {
    // given
    const props = getInitialProps();
    props.className = 'myOwnClassName';

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find('.agGridTable').hasClass('myOwnClassName')).toBe(true);
  });

  it('should set className - isSelectable === true', () => {
    // given
    const props = getInitialProps();
    props.isSelectable = true;

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find('.agGridTable').hasClass('selectable')).toBe(true);
  });

  it('should set className - isSelectable === false', () => {
    // given
    const props = getInitialProps();
    props.isSelectable = false;

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find('.agGridTable').hasClass('selectable')).toBe(false);
  });

  it('should set styles to .agGridTable - no styles', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find('.agGridTable').prop('style')).toEqual({});
  });

  it('should set styles to .agGridTable - height: hasVerticalScroll', () => {
    // given
    const props = getInitialProps();
    props.tableData.length = 9999;

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find('.agGridTable').prop('style')).toEqual({ height: '520px' });
  });

  it('should set styles to .agGridTable - height: hasFixedHeight', () => {
    // given
    const props = getInitialProps();
    props.hasFixedHeight = true;

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find('.agGridTable').prop('style')).toEqual({ height: '520px' });
  });

  it('should render AgGridReact with props - default', () => {
    // given
    const props = getInitialProps();
    const expectedTableProps = {
      columnDefs: [
        {
          headerName: 'language',
          field: 'language',
          tooltipField: 'language',
          headerTooltip: 'language'
        },
        {
          headerName: 'priority',
          field: 'priority',
          tooltipField: 'priority',
          headerTooltip: 'priority'
        }
      ],
      defaultColDef: {
        minWidth: 90
      },
      rowData: props.tableData,
      enableColResize: true,
      enableSorting: true,
      enableFilter: true,
      domLayout: 'autoHeight'
    };

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    const tableProps = enzymeWrapper.find(AgGridReact).props();
    expect(tableProps.columnDefs).toEqual(expectedTableProps.columnDefs);
    expect(tableProps.defaultColDef).toEqual(expectedTableProps.defaultColDef);
    expect(tableProps.rowData).toEqual(expectedTableProps.rowData);
    expect(tableProps.enableColResize).toEqual(expectedTableProps.enableColResize);
    expect(tableProps.enableSorting).toEqual(expectedTableProps.enableSorting);
    expect(tableProps.enableFilter).toEqual(expectedTableProps.enableFilter);
    expect(tableProps.domLayout).toEqual(expectedTableProps.domLayout);
  });

  it('should calculate hasVerticalScroll properly - false', () => {
    // given
    const props = getInitialProps();
    props.tableData.length = 17;

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find(AgGridReact).prop('domLayout')).toEqual('autoHeight');
  });

  it('should calculate hasVerticalScroll properly - true', () => {
    // given
    const props = getInitialProps();
    props.tableData.length = 18;

    // when
    const enzymeWrapper = shallow(<AgGridTable {...props} />);

    // then
    expect(enzymeWrapper.find(AgGridReact).prop('domLayout')).toEqual('normal');
  });
});
