import React from 'react';
import { shallow } from 'enzyme';
import { Message } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { ErrorMessage } from 'components/common';

const getInitialProps = () => ({
  header: 'myOwnHeader',
  message: 'myOwnMessage',
  onDismiss: jest.fn()
});

describe('ErrorMessage component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ErrorMessage {...props} />);

    // then
    expect(enzymeWrapper.find(Message)).toHaveLength(1);
    expect(enzymeWrapper.find(Message).hasClass('errorMessage')).toBe(true);
    expect(enzymeWrapper.find(Message).prop('negative')).toBe(true);
    enzymeWrapper.find(Message).props().onDismiss();
    expect(props.onDismiss).toHaveBeenCalled();
  });

  it('should render default header', () => {
    // given
    const props = {
      onDismiss: jest.fn()
    };
    const expectedHeaderProps = {
      id: 'common.error.header',
      defaultMessage: 'We are currently unable to process your request'
    };

    // when
    const enzymeWrapper = shallow(<ErrorMessage {...props} />);

    // then
    expect(enzymeWrapper.find(Message.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Message.Header).find(FormattedMessage)).toHaveLength(1);
    const headerProps = enzymeWrapper.find(Message.Header).find(FormattedMessage).props();
    expect(headerProps.id).toEqual(expectedHeaderProps.id);
    expect(headerProps.defaultMessage).toEqual(expectedHeaderProps.defaultMessage);
  });

  it('should render custom header', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ErrorMessage {...props} />);

    // then
    expect(enzymeWrapper.find(Message.Header).render().text()).toEqual('myOwnHeader');
  });

  it('should render default message', () => {
    // given
    const props = {
      onDismiss: jest.fn()
    };
    const expectedMessageProps = {
      id: 'common.error.message',
      defaultMessage: 'Something went wrong'
    };

    // when
    const enzymeWrapper = shallow(<ErrorMessage {...props} />);

    // then
    expect(enzymeWrapper.find('p')).toHaveLength(1);
    expect(enzymeWrapper.find('p').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('p').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render custom message', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<ErrorMessage {...props} />);

    // then
    expect(enzymeWrapper.find('p').render().text()).toEqual('myOwnMessage');
  });
});
