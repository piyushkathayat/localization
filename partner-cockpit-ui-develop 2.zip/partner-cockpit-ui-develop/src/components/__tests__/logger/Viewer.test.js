import React from 'react';
import { shallow } from 'enzyme';
import ReactJson from 'react-json-view';
import { NoResults } from 'components/common';
import Viewer from 'components/logger/Viewer';

const getInitialProps = () => ({
  json: [
    {
      data: {
        '@mt': 'Remediation starting for portfolio {AssetId} where profile is {ClientProfile}, SAA is {SAA_Id} {SAA_Name}',
        AssetId: 1041845,
        ClientProfile: null,
        SAA_Id: 502,
        SAA_Name: 'Prof Desk'
      }
    },
    {
      data: {
        '@mt': 'Remediation finished in {elapsedTotalSeconds}',
        elapsedTotalSeconds: 0.026562799999999998
      }
    }
  ]
});

describe('Viewer component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Viewer {...props} />);

    // then
    expect(enzymeWrapper.exists('.loggerViewerContainer')).toBe(true);
  });

  it('should render NoResults if json is empty', () => {
    // given
    const props = getInitialProps();
    props.json = [];

    // when
    const enzymeWrapper = shallow(<Viewer {...props} />);

    // then
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
  });

  it('should render ReactJson with props', () => {
    // given
    const props = getInitialProps();
    const expectedJsonProps = {
      src: [
        {
          data: {
            '@mt': 'Remediation starting for portfolio {AssetId} where profile is {ClientProfile}, SAA is {SAA_Id} {SAA_Name}',
            AssetId: 1041845,
            ClientProfile: null,
            SAA_Id: 502,
            SAA_Name: 'Prof Desk'
          }
        },
        {
          data: {
            '@mt': 'Remediation finished in {elapsedTotalSeconds}',
            elapsedTotalSeconds: 0.026562799999999998
          }
        }
      ],
      name: null,
      collapsed: 6,
      iconStyle: 'triangle',
      enableClipboard: false,
      displayObjectSize: false,
      displayDataTypes: false
    };

    // when
    const enzymeWrapper = shallow(<Viewer {...props} />);

    // then
    expect(enzymeWrapper.find(ReactJson)).toHaveLength(1);
    const jsonProps = enzymeWrapper.find(ReactJson).props();
    expect(jsonProps.src).toEqual(expectedJsonProps.src);
    expect(jsonProps.name).toEqual(expectedJsonProps.name);
    expect(jsonProps.collapsed).toEqual(expectedJsonProps.collapsed);
    expect(jsonProps.iconStyle).toEqual(expectedJsonProps.iconStyle);
    expect(jsonProps.enableClipboard).toEqual(expectedJsonProps.enableClipboard);
    expect(jsonProps.displayObjectSize).toEqual(expectedJsonProps.displayObjectSize);
    expect(jsonProps.displayDataTypes).toEqual(expectedJsonProps.displayDataTypes);
  });
});
