import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { Input, Dropdown, Button } from 'semantic-ui-react';
import { CONTEXT_TYPES } from 'constants/logger';
import { Toolbar } from 'components/logger/Toolbar';

// TODO: update

const getInitialProps = () => ({
  issueIdsOptions: [
    {
      key: 0,
      text: 'Strategic Asset Allocation - -101',
      value: -101
    },
    {
      key: 1,
      text: 'Strategic Asset Allocation - -102',
      value: -102
    },
    {
      key: 2,
      text: 'Bulk Risk - 54',
      value: 54
    }
  ],
  isLoading: false,
  onJsonRequest: jest.fn(),
  onExtractRequest: jest.fn(),
  onIssueIdsRequest: jest.fn(),
  onIssueIdsClear: jest.fn(),
  intl: {
    formatMessage: jest.fn()
  }
});

describe('Toolbar component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.exists('.loggerToolbarContainer')).toBe(true);
  });

  it('should render Asset ID Input', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.exists('.assetIdInput')).toBe(true);
    expect(enzymeWrapper.find('.assetIdInput').hasClass('toolbarInput')).toBe(true);
    expect(enzymeWrapper.find('.assetIdInput').find(FormattedMessage)).toHaveLength(1);
    expect(enzymeWrapper.find('.assetIdInput').find(Input)).toHaveLength(1);
  });

  it('should handle Asset ID Input change', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const instance = enzymeWrapper.instance();

    // then
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    expect(instance.state.assetId).toEqual('10410011');
    expect(enzymeWrapper.find('.assetIdInput').find(Input).prop('value')).toEqual('10410011');
  });

  it('should handle Asset ID Input change - clear both dropdowns', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });
    issueIdsDropdownWrapper.props().onChange({}, { value: [-101] });
    assetIdInputWrapper.props().onChange({}, { value: '' });

    // then
    expect(enzymeWrapper.find('.contextDropdown').find(Dropdown).prop('value')).toEqual('');
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('value')).toEqual(undefined);
  });

  it('should handle Asset ID Input change - with issueIdsOptions', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });

    // then
    expect(props.onIssueIdsClear).toHaveBeenCalled();
  });

  it('should handle Asset ID Input change - without issueIdsOptions', () => {
    // given
    const props = getInitialProps();
    props.issueIdsOptions = [];

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });

    // then
    expect(props.onIssueIdsClear).not.toHaveBeenCalled();
  });

  it('should render Context Dropdown', () => {
    // given
    const props = getInitialProps();
    const expectedDropdownProps = {
      clearable: true,
      selection: true,
      selectOnBlur: false,
      options: [
        {
          key: 'SOLVE-ALL',
          text: <FormattedMessage id="logger.context.solve_all" defaultMessage="Solve All (batch)" />,
          value: 'SOLVE-ALL'
        },
        {
          key: 'SOLVE-RECENT',
          text: <FormattedMessage id="logger.context.solve_recent" defaultMessage="Solve Recent (batch)" />,
          value: 'SOLVE-RECENT'
        },
        {
          key: 'SOLVE-SELECTED',
          text: <FormattedMessage id="logger.context.solve_selected" defaultMessage="Solve Selected (online)" />,
          value: 'SOLVE-SELECTED'
        },
        {
          key: 'SOLVE-SINGLE',
          text: <FormattedMessage id="logger.context.solve_single" defaultMessage="Solve Single (batch)" />,
          value: 'SOLVE-SINGLE'
        }
      ]
    };

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.exists('.contextDropdown')).toBe(true);
    expect(enzymeWrapper.find('.contextDropdown').hasClass('toolbarInput')).toBe(true);
    expect(enzymeWrapper.find('.contextDropdown').find(FormattedMessage)).toHaveLength(1);
    expect(enzymeWrapper.find('.contextDropdown').find(Dropdown)).toHaveLength(1);
    const dropdownProps = enzymeWrapper.find('.contextDropdown').find(Dropdown).props();
    expect(dropdownProps.clearable).toEqual(expectedDropdownProps.clearable);
    expect(dropdownProps.selection).toEqual(expectedDropdownProps.selection);
    expect(dropdownProps.selectOnBlur).toEqual(expectedDropdownProps.selectOnBlur);
    expect(dropdownProps.options).toEqual(expectedDropdownProps.options);
  });

  it('should disable Context Dropdown if no assetId', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.find('.contextDropdown').find(Dropdown).prop('disabled')).toBe(true);
  });

  it('should enable Context Dropdown if there is assetId', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    expect(enzymeWrapper.find('.contextDropdown').find(Dropdown).prop('disabled')).toBe(false);
  });

  it('should handle Context Dropdown change', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_ALL });

    // then
    expect(enzymeWrapper.find('.contextDropdown').find(Dropdown).prop('value')).toEqual(CONTEXT_TYPES.SOLVE_ALL);
  });

  it('should handle Context Dropdown change - clear issueIds dropdown', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });
    issueIdsDropdownWrapper.props().onChange({}, { value: [-101] });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_ALL });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('value')).toEqual(undefined);
  });

  it('should handle Context Dropdown change - with isIssueIdsRequired', () => {
    // given
    const props = getInitialProps();
    props.issueIdsOptions = [];

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });

    // then
    expect(props.onIssueIdsRequest).toHaveBeenCalled();
    expect(props.onIssueIdsRequest.mock.calls[0][0]).toEqual('10410011');
  });

  it('should handle Context Dropdown change - without isIssueIdsRequired (because of the context)', () => {
    // given
    const props = getInitialProps();
    props.issueIdsOptions = [];

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_ALL });

    // then
    expect(props.onIssueIdsRequest).not.toHaveBeenCalled();
  });

  it('should handle Context Dropdown change - without isIssueIdsRequired (because issueIdsOptions are already loaded)', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });

    // then
    expect(props.onIssueIdsRequest).not.toHaveBeenCalled();
  });

  it('should render IssueIds Dropdown', () => {
    // given
    const props = getInitialProps();
    const expectedDropdownProps = {
      clearable: true,
      selection: true,
      selectOnBlur: false,
      options: [
        {
          key: 0,
          text: 'Strategic Asset Allocation - -101',
          value: -101
        },
        {
          key: 1,
          text: 'Strategic Asset Allocation - -102',
          value: -102
        },
        {
          key: 2,
          text: 'Bulk Risk - 54',
          value: 54
        }
      ],
      loading: false,
      multiple: false,
      disabled: true
    };

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.exists('.issueIdsDropdown')).toBe(true);
    expect(enzymeWrapper.find('.issueIdsDropdown').hasClass('toolbarInput')).toBe(true);
    expect(enzymeWrapper.find('.issueIdsDropdown').find(FormattedMessage)).toHaveLength(1);
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown)).toHaveLength(1);
    const dropdownProps = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).props();
    expect(dropdownProps.clearable).toEqual(expectedDropdownProps.clearable);
    expect(dropdownProps.selection).toEqual(expectedDropdownProps.selection);
    expect(dropdownProps.selectOnBlur).toEqual(expectedDropdownProps.selectOnBlur);
    expect(dropdownProps.options).toEqual(expectedDropdownProps.options);
    expect(dropdownProps.loading).toEqual(expectedDropdownProps.loading);
    expect(dropdownProps.multiple).toEqual(expectedDropdownProps.multiple);
    expect(dropdownProps.disabled).toEqual(expectedDropdownProps.disabled);
  });

  it('should set IssueIds Dropdown props: loading', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('loading')).toBe(true);
  });

  it('should set IssueIds Dropdown props: multiple', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('multiple')).toBe(true);
  });

  it('should set IssueIds Dropdown props: disabled - no assetId', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('disabled')).toBe(true);
  });

  it('should set IssueIds Dropdown props: disabled - no context', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('disabled')).toBe(true);
  });

  it('should set IssueIds Dropdown props: disabled - issueIds is not required', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_ALL });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('disabled')).toBe(true);
  });

  it('should set IssueIds Dropdown props: enabled', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('disabled')).toBe(false);
  });

  it('should handle IssueIds Dropdown change - multiple choice', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const instance = enzymeWrapper.instance();
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });
    issueIdsDropdownWrapper.props().onChange({}, { value: [-101, -102] });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('value')).toEqual([-101, -102]);
    expect(instance.state.issueIds).toEqual([-101, -102]);
  });

  it('should handle IssueIds Dropdown change - single choice', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const instance = enzymeWrapper.instance();
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });
    issueIdsDropdownWrapper.props().onChange({}, { value: '-101' });

    // then
    expect(enzymeWrapper.find('.issueIdsDropdown').find(Dropdown).prop('value')).toEqual('-101');
    expect(instance.state.issueIds).toEqual(['-101']);

    issueIdsDropdownWrapper.props().onChange({}, { value: '' });
    expect(instance.state.issueIds).toEqual([]);
  });

  it('should render Load Button', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);

    // then
    expect(enzymeWrapper.exists('.toolbarButton')).toBe(true);
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button)).toHaveLength(1);
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).hasClass('ubs-primary-button')).toBe(true);
  });

  it('should set Load Button props: disabled - isLoading', () => {
    // given
    const props = getInitialProps();
    props.isLoading = true;

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });
    issueIdsDropdownWrapper.props().onChange({}, { value: '-101' });

    // then
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(true);
  });

  it('should set Load Button props: disabled - no assetId', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });
    issueIdsDropdownWrapper.props().onChange({}, { value: '-101' });

    // then
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(true);
  });

  it('should set Load Button props: disabled - no context', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: '' });
    issueIdsDropdownWrapper.props().onChange({}, { value: '-101' });

    // then
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(true);
  });

  it('should set Load Button props: disabled - no issueIds if required', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });
    issueIdsDropdownWrapper.props().onChange({}, { value: '' });

    // then
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(true);

    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });
    issueIdsDropdownWrapper.props().onChange({}, { value: [] });
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(true);
  });

  it('should set Load Button props: enabled', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });
    issueIdsDropdownWrapper.props().onChange({}, { value: '-101' });

    // then
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(false);

    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });
    issueIdsDropdownWrapper.props().onChange({}, { value: [-101] });
    expect(enzymeWrapper.find('.toolbarButton').at(0).find(Button).prop('disabled')).toBe(false);
  });

  it('should handle Load Button click - solve all', () => {
    // given
    const props = getInitialProps();
    const expectedParameters = {
      assetId: '10410011',
      context: CONTEXT_TYPES.SOLVE_ALL,
      issueIds: []
    };

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const buttonWrapper = enzymeWrapper.find('.toolbarButton').at(0).find(Button);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_ALL });
    buttonWrapper.props().onClick();

    // then
    expect(props.onJsonRequest).toHaveBeenCalled();
    expect(props.onJsonRequest.mock.calls[0][0]).toEqual(expectedParameters);
  });

  it('should handle Load Button click - solve recent', () => {
    // given
    const props = getInitialProps();
    const expectedParameters = {
      assetId: '10410011',
      context: CONTEXT_TYPES.SOLVE_RECENT,
      issueIds: []
    };

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const buttonWrapper = enzymeWrapper.find('.toolbarButton').at(0).find(Button);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_RECENT });
    buttonWrapper.props().onClick();

    // then
    expect(props.onJsonRequest).toHaveBeenCalled();
    expect(props.onJsonRequest.mock.calls[0][0]).toEqual(expectedParameters);
  });

  it('should handle Load Button click - solve single', () => {
    // given
    const props = getInitialProps();
    const expectedParameters = {
      assetId: '10410011',
      context: CONTEXT_TYPES.SOLVE_SINGLE,
      issueIds: ['-101']
    };

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    const buttonWrapper = enzymeWrapper.find('.toolbarButton').at(0).find(Button);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SINGLE });
    issueIdsDropdownWrapper.props().onChange({}, { value: '-101' });
    buttonWrapper.props().onClick();

    // then
    expect(props.onJsonRequest).toHaveBeenCalled();
    expect(props.onJsonRequest.mock.calls[0][0]).toEqual(expectedParameters);
  });

  it('should handle Load Button click - solve selected', () => {
    // given
    const props = getInitialProps();
    const expectedParameters = {
      assetId: '10410011',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: [-101, -102]
    };

    // when
    const enzymeWrapper = shallow(<Toolbar {...props} />);
    const assetIdInputWrapper = enzymeWrapper.find('.assetIdInput').find(Input);
    const contextDropdownWrapper = enzymeWrapper.find('.contextDropdown').find(Dropdown);
    const issueIdsDropdownWrapper = enzymeWrapper.find('.issueIdsDropdown').find(Dropdown);
    const buttonWrapper = enzymeWrapper.find('.toolbarButton').at(0).find(Button);
    assetIdInputWrapper.props().onChange({}, { value: '10410011' });
    contextDropdownWrapper.props().onChange({}, { value: CONTEXT_TYPES.SOLVE_SELECTED });
    issueIdsDropdownWrapper.props().onChange({}, { value: [-101, -102] });
    buttonWrapper.props().onClick();

    // then
    expect(props.onJsonRequest).toHaveBeenCalled();
    expect(props.onJsonRequest.mock.calls[0][0]).toEqual(expectedParameters);
  });
});
