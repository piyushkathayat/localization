import React from 'react';
import { shallow } from 'enzyme';
import { FormattedMessage } from 'react-intl';
import { DateAndTime } from 'components/common';
import DatabaseCommentPopup from 'components/promotion/DatabaseCommentPopup';

const getInitialProps = () => ({
  database: {
    comment: 'This database is marked for autopromotion on the Live DB.',
    commentAuthor: '43535763',
    commentDate: '2019-01-23T08:43:49.773',
    confirmedBy: '00355799',
    creationDate: '2019-01-16T08:43:49.773',
    id: 3,
    internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
    internalName: 'Unbundling',
    isDirty: false,
    isMarkedForPromotion: false,
    isPreselected: false,
    isOldDatabase: false,
    isPromotedToLive: true,
    isUsedInLoadOnStaging: true,
    name: 'UNBUNDLING',
    source: 'NZUR18125DSQ'
  }
});

describe('DatabaseCommentPopup component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.commentPopupContainer')).toBe(true);
  });

  it('should render commentDate if presented', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'promotion.date',
      defaultMessage: 'Date:'
    };
    const expectedDateAndTimeProps = {
      value: '2019-01-23T08:43:49.773'
    };

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.commentDate')).toBe(true);
    expect(enzymeWrapper.find('.commentDate').hasClass('commentRow')).toBe(true);
    expect(enzymeWrapper.find('.commentDate').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.commentDate').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(enzymeWrapper.find('.commentDate').find(DateAndTime)).toHaveLength(1);
    const dateAndTimeProps = enzymeWrapper.find('.commentDate').find(DateAndTime).props();
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should not render commentDate if not presented', () => {
    // given
    const props = getInitialProps();
    props.database.commentDate = '';

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.commentDate')).toBe(false);
  });

  it('should render confirmedBy if presented', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'promotion.confirmedBy',
      defaultMessage: 'Confirmed by:'
    };
    const expectedValueText = '00355799';

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.confirmedBy')).toBe(true);
    expect(enzymeWrapper.find('.confirmedBy').hasClass('commentRow')).toBe(true);
    expect(enzymeWrapper.find('.confirmedBy').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.confirmedBy').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(enzymeWrapper.find('.confirmedBy').find('.value')).toHaveLength(1);
    const valueText = enzymeWrapper.find('.confirmedBy').find('.value').render().text();
    expect(valueText).toEqual(expectedValueText);
  });

  it('should not render confirmedBy if not presented', () => {
    // given
    const props = getInitialProps();
    props.database.confirmedBy = '';

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.confirmedBy')).toBe(false);
  });

  it('should render commentAuthor if presented', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'promotion.cockpit_member',
      defaultMessage: 'Cockpit member:'
    };
    const expectedValueText = '43535763';

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.commentAuthor')).toBe(true);
    expect(enzymeWrapper.find('.commentAuthor').hasClass('commentRow')).toBe(true);
    expect(enzymeWrapper.find('.commentAuthor').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.commentAuthor').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(enzymeWrapper.find('.commentAuthor').find('.value')).toHaveLength(1);
    const valueText = enzymeWrapper.find('.commentAuthor').find('.value').render().text();
    expect(valueText).toEqual(expectedValueText);
  });

  it('should not render commentAuthor if not presented', () => {
    // given
    const props = getInitialProps();
    props.database.commentAuthor = '';

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.commentAuthor')).toBe(false);
  });

  it('should render comment - Reason', () => {
    // given
    const props = getInitialProps();
    props.database.isPromotedToLive = true;
    const expectedMessageProps = {
      id: 'promotion.reason',
      defaultMessage: 'Reason:'
    };
    const expectedValueText = 'This database is marked for autopromotion on the Live DB.';

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    expect(enzymeWrapper.exists('.comment')).toBe(true);
    expect(enzymeWrapper.find('.comment').hasClass('commentRow')).toBe(true);
    expect(enzymeWrapper.find('.comment').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.comment').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    expect(enzymeWrapper.find('.comment').find('.value')).toHaveLength(1);
    const valueText = enzymeWrapper.find('.comment').find('.value').render().text();
    expect(valueText).toEqual(expectedValueText);
  });

  it('should render comment - Reason to promote', () => {
    // given
    const props = getInitialProps();
    props.database.isPromotedToLive = false;
    props.database.isPreselected = true;
    const expectedMessageProps = {
      id: 'promotion.reason_to_promote',
      defaultMessage: 'Reason to promote:'
    };

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    const messageProps = enzymeWrapper.find('.comment').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render comment - Reason not to promote', () => {
    // given
    const props = getInitialProps();
    props.database.isPromotedToLive = false;
    props.database.isPreselected = false;
    const expectedMessageProps = {
      id: 'promotion.reason_not_to_promote',
      defaultMessage: 'Reason not to promote:'
    };

    // when
    const enzymeWrapper = shallow(<DatabaseCommentPopup {...props} />);

    // then
    const messageProps = enzymeWrapper.find('.comment').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });
});
