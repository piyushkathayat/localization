import React from 'react';
import { shallow } from 'enzyme';
import { Table } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { DateAndTime } from 'components/common';
import PromotedTable from 'components/promotion/PromotedTable';

const getInitialProps = () => ({
  databases: {
    3: {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T08:43:49.773',
      id: 3,
      internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
      internalName: 'Unbundling',
      isDirty: false,
      isMarkedForPromotion: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      isPreselected: false,
      name: 'UNBUNDLING',
      source: 'NZUR18125DSQ'
    },
    4: {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T05:00:20.783',
      id: 4,
      internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
      internalName: 'BBS',
      isDirty: false,
      isMarkedForPromotion: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      isPreselected: false,
      name: 'BBS',
      source: 'NZUR18125DSQ'
    },
    15: {
      comment: '',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '',
      creationDate: '2019-01-16T08:53:35.09',
      id: 15,
      internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
      internalName: 'LK',
      isDirty: false,
      isMarkedForPromotion: false,
      isOldDatabase: false,
      isPromotedToLive: false,
      isUsedInLoadOnStaging: true,
      isPreselected: true,
      name: 'Lookup Tables',
      source: 'NZUR18130DSQ'
    }
  }
});

describe('PromotedTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotedTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.promotedTableContainer')).toBe(true);
  });

  it('should render Table', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotedTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table)).toHaveLength(1);
    expect(enzymeWrapper.find(Table).hasClass('databases')).toBe(true);
  });

  it('should render Table.Header', () => {
    // given
    const props = getInitialProps();
    const expectedMessagesProps = [
      {
        id: 'promotion.name',
        defaultMessage: 'Name'
      },
      {
        id: 'promotion.source',
        defaultMessage: 'Source'
      },
      {
        id: 'promotion.creation_date',
        defaultMessage: 'Creation date'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotedTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Header).find(Table.HeaderCell)).toHaveLength(3);
    expect(enzymeWrapper.find(Table.Header).find(FormattedMessage)).toHaveLength(3);
    let messageProps = enzymeWrapper.find(Table.Header).find(FormattedMessage).at(0).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[0].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[0].defaultMessage);
    messageProps = enzymeWrapper.find(Table.Header).find(FormattedMessage).at(1).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[1].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[1].defaultMessage);
    messageProps = enzymeWrapper.find(Table.Header).find(FormattedMessage).at(2).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[2].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[2].defaultMessage);
  });

  it('should render Table.Body', () => {
    // given
    const props = getInitialProps();
    const expectedCellsText = [
      'UNBUNDLING',
      'NZUR18125DSQ'
    ];
    const expectedDateAndTimeProps = {
      value: '2019-01-16T08:43:49.773'
    };

    // when
    const enzymeWrapper = shallow(<PromotedTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Body)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Body).find(Table.Row)).toHaveLength(3);
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).at(0);
    expect(firstRowWrapper.find(Table.Cell)).toHaveLength(3);
    let cellText = firstRowWrapper.find(Table.Cell).at(0).render().text();
    expect(cellText).toEqual(expectedCellsText[0]);
    cellText = firstRowWrapper.find(Table.Cell).at(1).render().text();
    expect(cellText).toEqual(expectedCellsText[1]);
    expect(firstRowWrapper.find(Table.Cell).at(2).find(DateAndTime)).toHaveLength(1);
    const dateAndTimeProps = firstRowWrapper.find(Table.Cell).at(2).find(DateAndTime).props();
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should not render creationDate if not presented', () => {
    // given
    const props = getInitialProps();
    props.databases['3'].creationDate = null;

    // when
    const enzymeWrapper = shallow(<PromotedTable {...props} />);

    // then
    const firstRowWrapper = enzymeWrapper.find(Table.Body).find(Table.Row).at(0);
    expect(firstRowWrapper.find(Table.Cell).at(2).find(DateAndTime)).toHaveLength(0);
  });
});
