import React from 'react';
import { shallow } from 'enzyme';
import { Table, Button } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { MODAL_TYPES } from 'constants/common';
import { DateAndTime, ReasonModal, ConfirmModal } from 'components/common';
import PromotionTableRow from 'components/promotion/PromotionTableRow';
import { PromotionTable } from 'components/promotion/PromotionTable';

// TODO: update

const getInitialProps = () => ({
  databases: {
    3: {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T08:43:49.773',
      id: 3,
      internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
      internalName: 'Unbundling',
      isDirty: false,
      isMarkedForPromotion: false,
      isPreselected: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      name: 'UNBUNDLING',
      source: 'NZUR18125DSQ'
    },
    4: {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T05:00:20.783',
      id: 4,
      internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
      internalName: 'BBS',
      isDirty: false,
      isMarkedForPromotion: false,
      isPreselected: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      name: 'BBS',
      source: 'NZUR18125DSQ'
    },
    15: {
      comment: '',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '',
      creationDate: '2019-01-16T08:53:35.09',
      id: 15,
      internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
      internalName: 'LK',
      isDirty: false,
      isMarkedForPromotion: false,
      isPreselected: true,
      isOldDatabase: false,
      isPromotedToLive: false,
      isUsedInLoadOnStaging: true,
      name: 'Lookup Tables',
      source: 'NZUR18130DSQ'
    }
  },
  dependencies: [
    {
      databaseId: 3,
      dependents: [4, 15]
    },
    {
      databaseId: 4,
      dependents: []
    },
    {
      databaseId: 15,
      dependents: []
    }
  ],
  lastPromotion: '2018-10-23T16:33:21.08',
  isPromotionRunning: false,
  canPromote: true,
  updateDatabases: jest.fn(),
  promoteToLiveDB: jest.fn()
});

describe('PromotionTable component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    expect(enzymeWrapper.exists('.promotionTableContainer')).toBe(true);
  });

  it('should render Table', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table)).toHaveLength(1);
    expect(enzymeWrapper.find(Table).hasClass('databases')).toBe(true);
  });

  it('should render Table.Header', () => {
    // given
    const props = getInitialProps();
    const expectedMessagesProps = [
      {},
      {
        id: 'promotion.name',
        defaultMessage: 'Name'
      },
      {
        id: 'promotion.source',
        defaultMessage: 'Source'
      },
      {
        id: 'promotion.creation_date',
        defaultMessage: 'Creation date'
      },
      {
        id: 'promotion.marked',
        defaultMessage: 'Marked'
      },
      {
        id: 'promotion.live_db',
        defaultMessage: 'Live DB'
      },
      {
        id: 'promotion.comment',
        defaultMessage: 'Comment'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Header)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Header).find(Table.HeaderCell)).toHaveLength(7);
    const headerCellWrapper = enzymeWrapper.find(Table.Header).find(Table.HeaderCell);
    let messageProps = headerCellWrapper.at(1).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[1].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[1].defaultMessage);
    messageProps = headerCellWrapper.at(2).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[2].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[2].defaultMessage);
    messageProps = headerCellWrapper.at(3).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[3].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[3].defaultMessage);
    messageProps = headerCellWrapper.at(4).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[4].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[4].defaultMessage);
    messageProps = headerCellWrapper.at(5).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[5].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[5].defaultMessage);
    messageProps = headerCellWrapper.at(6).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessagesProps[6].id);
    expect(messageProps.defaultMessage).toEqual(expectedMessagesProps[6].defaultMessage);
  });

  it('should render Table.Body', () => {
    // given
    const props = getInitialProps();
    const expectedRowProps = {
      database: {
        comment: 'This database is marked for autopromotion on the Live DB.',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '00355799',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isDirty: false,
        isMarkedForPromotion: false,
        isPreselected: false,
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      },
      isPromotionRunning: false
    };

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Body)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Body).find(PromotionTableRow)).toHaveLength(3);
    const rowProps = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0).props();
    expect(rowProps.database).toEqual(expectedRowProps.database);
    expect(rowProps.isPromotionRunning).toEqual(expectedRowProps.isPromotionRunning);
  });

  it('should handle PromotionTableRow - ReasonModal - onClose', () => {
    // given
    const props = getInitialProps();
    props.databases['3'].isDirty = false;
    props.databases['3'].isPreselected = true;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promotionRowWrapper = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0);
    promotionRowWrapper.props().onCheckboxChange(false);
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(1);
    enzymeWrapper.find(ReasonModal).props().onClose();
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
  });

  it('should handle PromotionTableRow - onCheckboxChange: !isDirty - !checked', () => {
    // given
    const props = getInitialProps();
    props.databases['3'].isDirty = false;
    props.databases['3'].isPreselected = true;
    props.databases['4'].isPreselected = true;
    props.databases['15'].isPreselected = true;

    const expectedModalProps = {
      type: MODAL_TYPES.DEMOTE_DATABASE,
      isOpen: true,
      firstTextVariable: 'UNBUNDLING',
      secondTextVariable: 'BBS, Lookup Tables'
    };

    const expectedUpdateDatabasesParameter = [
      {
        isDirty: true,
        isMarkedForPromotion: false,
        isPreselected: false,
        oldComment: 'This database is marked for autopromotion on the Live DB.',
        oldConfirmedBy: '00355799',
        oldInfo: undefined,
        comment: 'some comment',
        confirmedBy: '123123123',
        info: '',
        commentAuthor: '',
        commentDate: '',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      },
      {
        isDirty: true,
        isMarkedForPromotion: false,
        isPreselected: false,
        oldComment: 'This database is marked for autopromotion on the Live DB.',
        oldConfirmedBy: '00355799',
        oldInfo: undefined,
        comment: 'some comment',
        confirmedBy: '123123123',
        info: '',
        commentAuthor: '',
        commentDate: '',
        creationDate: '2019-01-16T05:00:20.783',
        id: 4,
        internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
        internalName: 'BBS',
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'BBS',
        source: 'NZUR18125DSQ'
      },
      {
        isDirty: true,
        isMarkedForPromotion: false,
        isPreselected: false,
        oldComment: '',
        oldConfirmedBy: '',
        oldInfo: undefined,
        comment: 'some comment',
        confirmedBy: '123123123',
        info: '',
        commentAuthor: '',
        commentDate: '',
        creationDate: '2019-01-16T08:53:35.09',
        id: 15,
        internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
        internalName: 'LK',
        isOldDatabase: false,
        isPromotedToLive: false,
        isUsedInLoadOnStaging: true,
        name: 'Lookup Tables',
        source: 'NZUR18130DSQ'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promotionRowWrapper = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0);
    promotionRowWrapper.props().onCheckboxChange(false);
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(1);
    const modalProps = enzymeWrapper.find(ReasonModal).props();
    expect(modalProps.type).toEqual(expectedModalProps.type);
    expect(modalProps.isOpen).toEqual(expectedModalProps.isOpen);
    expect(modalProps.firstTextVariable).toEqual(expectedModalProps.firstTextVariable);
    expect(modalProps.secondTextVariable).toEqual(expectedModalProps.secondTextVariable);
    modalProps.onSubmit({ explanationText: 'some comment', confirmedBy: '123123123' });
    expect(props.updateDatabases).toHaveBeenCalled();
    expect(props.updateDatabases.mock.calls[0][0]).toEqual(expectedUpdateDatabasesParameter);
  });

  it('should handle PromotionTableRow - onCheckboxChange: !isDirty - checked', () => {
    // given
    const props = getInitialProps();
    props.databases['3'].isDirty = false;
    props.databases['3'].isPreselected = false;

    const expectedModalProps = {
      type: MODAL_TYPES.PROMOTE_DATABASE,
      isOpen: true,
      firstTextVariable: 'UNBUNDLING'
    };

    const expectedUpdateDatabasesParameter = [
      {
        isDirty: true,
        isMarkedForPromotion: false,
        isPreselected: true,
        oldComment: 'This database is marked for autopromotion on the Live DB.',
        oldConfirmedBy: '00355799',
        oldInfo: undefined,
        comment: 'some comment',
        confirmedBy: '123123123',
        info: '',
        commentAuthor: '',
        commentDate: '',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promotionRowWrapper = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0);
    promotionRowWrapper.props().onCheckboxChange(true);
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(1);
    const modalProps = enzymeWrapper.find(ReasonModal).props();
    expect(modalProps.type).toEqual(expectedModalProps.type);
    expect(modalProps.isOpen).toEqual(expectedModalProps.isOpen);
    expect(modalProps.firstTextVariable).toEqual(expectedModalProps.firstTextVariable);
    modalProps.onSubmit({ explanationText: 'some comment', confirmedBy: '123123123' });
    expect(props.updateDatabases).toHaveBeenCalled();
    expect(props.updateDatabases.mock.calls[0][0]).toEqual(expectedUpdateDatabasesParameter);
  });

  it('should handle PromotionTableRow - onCheckboxChange: isDirty - !checked', () => {
    // given
    const props = getInitialProps();
    props.databases['3'] = {
      ...props.databases['3'],
      isDirty: true,
      isMarkedForPromotion: false,
      isPreselected: true,
      oldComment: 'This database is marked for autopromotion on the Live DB.',
      oldConfirmedBy: '00355799',
      comment: 'some comment',
      confirmedBy: '123123123'
    };
    props.databases['4'] = {
      ...props.databases['4'],
      isDirty: true,
      isMarkedForPromotion: false,
      isPreselected: true,
      oldComment: 'This database is marked for autopromotion on the Live DB.',
      oldConfirmedBy: '00355799',
      comment: 'some comment',
      confirmedBy: '123123123'
    };
    props.databases['15'] = {
      ...props.databases['15'],
      isDirty: true,
      isMarkedForPromotion: false,
      isPreselected: true,
      oldComment: 'This database is marked for autopromotion on the Live DB.',
      oldConfirmedBy: '00355799',
      comment: 'some comment',
      confirmedBy: '123123123'
    };

    // reverting changes should not affect dependencies
    const expectedUpdateDatabasesParameter = [
      {
        isDirty: false,
        isMarkedForPromotion: false,
        isPreselected: false,
        oldComment: undefined,
        oldConfirmedBy: undefined,
        oldInfo: undefined,
        comment: 'This database is marked for autopromotion on the Live DB.',
        confirmedBy: '00355799',
        info: undefined,
        commentAuthor: '',
        commentDate: '',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promotionRowWrapper = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0);
    promotionRowWrapper.props().onCheckboxChange(false);
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.updateDatabases).toHaveBeenCalled();
    expect(props.updateDatabases.mock.calls[0][0]).toEqual(expectedUpdateDatabasesParameter);
  });

  it('should handle PromotionTableRow - onCheckboxChange: isDirty - checked', () => {
    // given
    const props = getInitialProps();
    props.databases['3'] = {
      ...props.databases['3'],
      isDirty: true,
      isMarkedForPromotion: false,
      isPreselected: false,
      oldComment: 'This database is marked for autopromotion on the Live DB.',
      oldConfirmedBy: '00355799',
      comment: 'some comment',
      confirmedBy: '123123123'
    };

    const expectedUpdateDatabasesParameter = [
      {
        isDirty: false,
        isMarkedForPromotion: false,
        isPreselected: true,
        oldComment: undefined,
        oldConfirmedBy: undefined,
        oldInfo: undefined,
        comment: 'This database is marked for autopromotion on the Live DB.',
        confirmedBy: '00355799',
        commentAuthor: '',
        info: undefined,
        commentDate: '',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promotionRowWrapper = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0);
    promotionRowWrapper.props().onCheckboxChange(false);
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(0);
    expect(props.updateDatabases).toHaveBeenCalled();
    expect(props.updateDatabases.mock.calls[0][0]).toEqual(expectedUpdateDatabasesParameter);
  });

  it('should handle PromotionTableRow - onEditComment', () => {
    // given
    const props = getInitialProps();
    props.databases['3'] = {
      ...props.databases['3'],
      isDirty: true,
      isMarkedForPromotion: false,
      isPreselected: false,
      oldComment: 'This database is marked for autopromotion on the Live DB.',
      oldConfirmedBy: '00355799',
      comment: 'some comment',
      confirmedBy: '123123123'
    };

    const expectedModalProps = {
      type: MODAL_TYPES.EDIT_COMMENT,
      isOpen: true,
      confirmedBy: '123123123',
      explanationText: 'some comment'
    };

    const expectedUpdateDatabasesParameter = [
      {
        isDirty: true,
        isMarkedForPromotion: false,
        isPreselected: false,
        oldComment: 'This database is marked for autopromotion on the Live DB.',
        oldConfirmedBy: '00355799',
        comment: 'updated comment',
        confirmedBy: '43535763',
        commentAuthor: '',
        commentDate: '',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      }
    ];

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promotionRowWrapper = enzymeWrapper.find(Table.Body).find(PromotionTableRow).at(0);
    promotionRowWrapper.props().onEditComment();
    expect(enzymeWrapper.find(ReasonModal)).toHaveLength(1);
    const modalProps = enzymeWrapper.find(ReasonModal).props();
    expect(modalProps.type).toEqual(expectedModalProps.type);
    expect(modalProps.isOpen).toEqual(expectedModalProps.isOpen);
    expect(modalProps.confirmedBy).toEqual(expectedModalProps.confirmedBy);
    expect(modalProps.explanationText).toEqual(expectedModalProps.explanationText);
    modalProps.onSubmit({ explanationText: 'updated comment', confirmedBy: '43535763' });
    expect(props.updateDatabases).toHaveBeenCalled();
    expect(props.updateDatabases.mock.calls[0][0]).toEqual(expectedUpdateDatabasesParameter);
  });

  it('should render Table.Footer', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Footer)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Footer).find(Table.HeaderCell)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Footer).find(Table.HeaderCell).exists('.footerCell')).toBe(true);
  });

  it('should render Table.Footer - lastPromotedDate', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'promotion.last_promotion',
      defaultMessage: 'Last promotion: '
    };
    const expectedDateAndTimeProps = {
      value: '2018-10-23T16:33:21.08',
      hour: 'numeric',
      minute: 'numeric'
    };

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const footerCellWrapper = enzymeWrapper.find('.footerCell');
    expect(footerCellWrapper.exists('.lastPromotedDate')).toBe(true);
    expect(footerCellWrapper.find('.lastPromotedDate').find(FormattedMessage)).toHaveLength(1);
    expect(footerCellWrapper.find('.lastPromotedDate').find(DateAndTime)).toHaveLength(1);
    const messageProps = footerCellWrapper.find('.lastPromotedDate').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
    const dateAndTimeProps = footerCellWrapper.find('.lastPromotedDate').find(DateAndTime).props();
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
    expect(dateAndTimeProps.hour).toEqual(expectedDateAndTimeProps.hour);
    expect(dateAndTimeProps.minute).toEqual(expectedDateAndTimeProps.minute);
  });

  it('should render Table.Footer - no lastPromotedDate if not presented', () => {
    // given
    const props = getInitialProps();
    props.lastPromotion = '';

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const footerCellWrapper = enzymeWrapper.find('.footerCell');
    expect(footerCellWrapper.exists('.lastPromotedDate')).toBe(false);
  });

  it('should render Table.Footer - promoteButton', () => {
    // given
    const props = getInitialProps();
    const expectedButtonProps = {
      floated: 'right',
      size: 'small',
      loading: false
    };
    const expectedMessageProps = {
      id: 'promotion.promote',
      defaultMessage: 'Promote'
    };

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const footerCellWrapper = enzymeWrapper.find('.footerCell');
    expect(footerCellWrapper.find(Button)).toHaveLength(1);
    expect(footerCellWrapper.find(Button).hasClass('ubs-primary-button')).toBe(true);
    const buttonProps = footerCellWrapper.find(Button).props();
    expect(buttonProps.floated).toEqual(expectedButtonProps.floated);
    expect(buttonProps.size).toEqual(expectedButtonProps.size);
    expect(buttonProps.loading).toEqual(expectedButtonProps.loading);
    expect(footerCellWrapper.find(Button).find(FormattedMessage)).toHaveLength(1);
    const messageProps = footerCellWrapper.find(Button).find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render Table.Footer - promoteButton - not loading', () => {
    // given
    const props = getInitialProps();
    props.isPromotionRunning = false;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('loading')).toBe(false);
  });

  it('should render Table.Footer - promoteButton - loading', () => {
    // given
    const props = getInitialProps();
    props.isPromotionRunning = true;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('loading')).toBe(true);
  });

  it('should render Table.Footer - promoteButton - disabled - isPromotionRunning', () => {
    // given
    const props = getInitialProps();
    props.isPromotionRunning = true;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('disabled')).toBe(true);
  });

  it('should render Table.Footer - promoteButton - disabled - this.isMainDataLoadRunning', () => {
    // given
    const props = getInitialProps();
    props.databases['3'].internalKey = null;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('disabled')).toBe(true);
  });

  it('should render Table.Footer - promoteButton - disabled - !canPromote', () => {
    // given
    const props = getInitialProps();
    props.canPromote = false;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('disabled')).toBe(true);
  });

  it('should render Table.Footer - promoteButton - disabled - !this.isAnyDatabaseSelectedForPromotion', () => {
    // given
    const props = getInitialProps();
    props.databases['3'].isPreselected = false;
    props.databases['4'].isPreselected = false;
    props.databases['15'].isPreselected = false;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('disabled')).toBe(true);
  });

  it('should render Table.Footer - promoteButton - enabled', () => {
    // given
    const props = getInitialProps();
    props.isPromotionRunning = false;
    props.databases['3'].isPreselected = false;
    props.databases['4'].isPreselected = false;
    props.databases['15'].isPreselected = true;

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    expect(promoteButtonWrapper.prop('disabled')).toBe(false);
  });

  it('should render Table.Footer - promoteButton - onClick', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    promoteButtonWrapper.simulate('click');
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(1);
  });

  it('should render ConfirmModal - onCancel', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    promoteButtonWrapper.simulate('click');
    const confirmModalWrapper = enzymeWrapper.find(ConfirmModal);
    confirmModalWrapper.props().onCancel();
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  });

  it('should render ConfirmModal - onConfirm', () => {
    // given
    const props = getInitialProps();
    const expectedPromoteParameter = Object.values(props.databases);

    // when
    const enzymeWrapper = shallow(<PromotionTable {...props} />);

    // then
    const promoteButtonWrapper = enzymeWrapper.find('.footerCell').find(Button);
    promoteButtonWrapper.simulate('click');
    const confirmModalWrapper = enzymeWrapper.find(ConfirmModal);
    confirmModalWrapper.props().onConfirm();
    expect(props.promoteToLiveDB).toHaveBeenCalled();
    expect(props.promoteToLiveDB.mock.calls[0][0]).toEqual(expectedPromoteParameter);
    expect(enzymeWrapper.find(ConfirmModal)).toHaveLength(0);
  });
});
