import React from 'react';
import { shallow } from 'enzyme';
import { Table, Icon, Checkbox, Popup } from 'semantic-ui-react';
import { DateAndTime } from 'components/common';
import DatabaseCommentPopup from 'components/promotion/DatabaseCommentPopup';
import PromotionTableRow from 'components/promotion/PromotionTableRow';

// TODO: update

const getInitialProps = () => ({
  database: {
    comment: 'This database is marked for autopromotion on the Live DB.',
    commentAuthor: '43535763',
    commentDate: '2019-01-23T08:43:49.773',
    confirmedBy: '00355799',
    creationDate: '2019-01-16T08:43:49.773',
    id: 3,
    internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
    internalName: 'Unbundling',
    isDirty: false,
    isMarkedForPromotion: false,
    isPreselected: false,
    isOldDatabase: false,
    isPromotedToLive: true,
    isUsedInLoadOnStaging: true,
    name: 'UNBUNDLING',
    source: 'NZUR18125DSQ'
  },
  isPromotionRunning: false,
  onCheckboxChange: jest.fn(),
  onEditComment: jest.fn()
});

describe('PromotionTableRow component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Row)).toHaveLength(1);
    expect(enzymeWrapper.exists('.promotionTableRowContainer')).toBe(true);
  });

  it('should render 7 Cells', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell)).toHaveLength(7);
  });

  it('should render Checkbox', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox)).toHaveLength(1);
  });

  it('should render Checkbox - checked', () => {
    // given
    const props = getInitialProps();
    props.database.isPreselected = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).prop('checked')).toBe(true);
  });

  it('should render Checkbox - not checked', () => {
    // given
    const props = getInitialProps();
    props.database.isPreselected = false;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).prop('checked')).toBe(false);
  });

  it('should render Checkbox - disabled - isPromotionRunning', () => {
    // given
    const props = getInitialProps();
    props.isPromotionRunning = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).prop('disabled')).toBe(true);
  });

  it('should render Checkbox - disabled - database.isPromotedToLive', () => {
    // given
    const props = getInitialProps();
    props.database.isPromotedToLive = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).prop('disabled')).toBe(true);
  });

  it('should render Checkbox - disabled - !database.isUsedInLoadOnStaging', () => {
    // given
    const props = getInitialProps();
    props.database.isUsedInLoadOnStaging = false;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).prop('disabled')).toBe(true);
  });

  it('should render Checkbox - enabled', () => {
    // given
    const props = getInitialProps();
    props.isPromotionRunning = false;
    props.database.isPromotedToLive = false;
    props.database.isUsedInLoadOnStaging = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).prop('disabled')).toBe(false);
  });

  it('should render Checkbox - onChange', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    enzymeWrapper.find(Table.Cell).at(0).find(Checkbox).simulate('change', {}, { checked: true });
    expect(props.onCheckboxChange).toHaveBeenCalled();
    expect(props.onCheckboxChange.mock.calls[0][0]).toEqual(true);
  });

  it('should render database.name', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(1).render().text()).toEqual('UNBUNDLING');
  });

  it('should render database.source', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(2).render().text()).toEqual('NZUR18125DSQ');
  });

  it('should render creationDate if presented', () => {
    // given
    const props = getInitialProps();
    const expectedDateAndTimeProps = {
      value: '2019-01-16T08:43:49.773'
    };

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(3).find(DateAndTime)).toHaveLength(1);
    const dateAndTimeProps = enzymeWrapper.find(Table.Cell).at(3).find(DateAndTime).props();
    expect(dateAndTimeProps.value).toEqual(expectedDateAndTimeProps.value);
  });

  it('should not render creationDate if not presented', () => {
    // given
    const props = getInitialProps();
    props.database.creationDate = null;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(3).find(DateAndTime)).toHaveLength(0);
  });

  it('should render creationDate - oldDatabase', () => {
    // given
    const props = getInitialProps();
    props.database.isOldDatabase = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(3).hasClass('oldDatabase')).toBe(true);
  });

  it('should render creationDate - !oldDatabase', () => {
    // given
    const props = getInitialProps();
    props.database.isOldDatabase = false;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(3).hasClass('oldDatabase')).toBe(false);
  });

  it('should render isPromotedToLive icon - checked', () => {
    // given
    const props = getInitialProps();
    props.database.isPromotedToLive = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(5).find(Icon)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Cell).at(5).find(Icon).prop('name'))
      .toEqual('check circle outline');
  });

  it('should render isPromotedToLive icon - not checked', () => {
    // given
    const props = getInitialProps();
    props.database.isPromotedToLive = false;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find(Table.Cell).at(5).find(Icon)).toHaveLength(1);
    expect(enzymeWrapper.find(Table.Cell).at(5).find(Icon).prop('name')).toEqual('circle outline');
  });

  it('should render commentColumn', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.exists('.commentColumn')).toBe(true);
  });

  it('should render commentColumn - comment', () => {
    // given
    const props = getInitialProps();
    const expectedPopupProps = {
      wide: true,
      hoverable: true,
      trigger: (
        <div className="comment">
          This database is marked for autopromotion on the Live DB.
        </div>
      ),
      content: <DatabaseCommentPopup database={props.database} />
    };

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find('.commentColumn').find(Popup)).toHaveLength(1);
    const popupProps = enzymeWrapper.find('.commentColumn').find(Popup).props();
    expect(popupProps.wide).toEqual(expectedPopupProps.wide);
    expect(popupProps.hoverable).toEqual(expectedPopupProps.hoverable);
    expect(popupProps.trigger).toEqual(expectedPopupProps.trigger);
    expect(popupProps.content).toEqual(expectedPopupProps.content);
  });

  it('should render commentColumn - no comment', () => {
    // given
    const props = getInitialProps();
    props.database.comment = '';

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.find('.commentColumn').find(Popup)).toHaveLength(0);
  });

  it('should render commentColumn - edit comment', () => {
    // given
    const props = getInitialProps();
    props.database.isDirty = true;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.exists('.editCommentIcon')).toBe(true);
    expect(enzymeWrapper.find('.editCommentIcon').hasClass('icon-ubs')).toBe(true);
    expect(enzymeWrapper.find('.editCommentIcon').hasClass('icon-edit')).toBe(true);
    enzymeWrapper.find('.editCommentIcon').simulate('click');
    expect(props.onEditComment).toHaveBeenCalled();
  });

  it('should render commentColumn - no edit comment', () => {
    // given
    const props = getInitialProps();
    props.database.isDirty = false;

    // when
    const enzymeWrapper = shallow(<PromotionTableRow {...props} />);

    // then
    expect(enzymeWrapper.exists('.editCommentIcon')).toBe(false);
  });
});
