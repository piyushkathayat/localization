import React, { PureComponent } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';
import { Loader, Dimmer, Breadcrumb } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import {
  APPROVAL_STATUSES,
  DECISION_STATUSES
} from 'constants/validation';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { SERVER_TYPES } from 'constants/serverInfo';
import { DecisionCommonType, DecisionItemType, SortingType } from 'components/Types';
import { NoResults, ErrorMessage } from 'components/common';
import { voidFn } from 'utils/common';
import { getSelectedDecision, getSorting } from 'selectors/validation';
import {
  getApprovalStatuses,
  getSortedAndFilteredDecisionItemsList,
  getIsLoading,
  getIsUpdating,
  getDecisionItemsIds,
  getDecisionLevel,
  getDecisionGroup,
  getQualityCheckName,
  getError
} from 'selectors/validationDetails';
import { getServerType } from 'selectors/serverInfo';
import { setSorting } from 'actions/validation';
import {
  clearValidationDetails,
  updateValidationDetails,
  clearError,
  fetchAffectedPortfolios
} from 'actions/validationDetails';
import { getColumnDefs } from './columnDefs';
import DecisionItemsTable from './DecisionItemsTable';
import './ValidationDetails.css';

const DISABLED_RELEASE_STATUSES = [
  DECISION_STATUSES.CLOSED,
  DECISION_STATUSES.RECALCULATED,
  DECISION_STATUSES.FINALIZED,
  DECISION_STATUSES.ERROR
];

export class ValidationDetails extends PureComponent {
  breadcrumbsLoader = (
    <div className="breadcrumbsLoaderContainer">
      <Loader active inline="centered" size="tiny" />
    </div>
  );

  componentWillUnmount() {
    this.props.clearValidationDetails();
  }

  getBreadcrumbsSections = () => [
    {
      key: 'Overview',
      content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
      active: false,
      as: Link,
      to: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`
    },
    {
      key: 'Details',
      content: this.props.qualityCheckName || this.breadcrumbsLoader,
      active: true
    }
  ];

  getActions = () => this.props.approvalStatuses.map(approvalStatusId => ({
    key: approvalStatusId,
    text: <FormattedMessage {...R.path([approvalStatusId, 'title'], APPROVAL_STATUSES)} />,
    value: approvalStatusId
  })).sort((a, b) =>
    R.path([a.key, 'sortOrder'], APPROVAL_STATUSES) - R.path([b.key, 'sortOrder'], APPROVAL_STATUSES)
  );

  isDisabled = () => {
    const { decisionCommon: { statusId, isLatestLoad }, serverType } = this.props;
    return !isLatestLoad
      || DISABLED_RELEASE_STATUSES.includes(statusId)
      || serverType !== SERVER_TYPES.SHADOW;
  }

  handleUpdateDecisionItems = ({ decisionItemsIds, approvalStatusId, comment, confirmedBy }) => {
    const { decisionCommon: { decisionId }, qualityCheckType } = this.props;
    this.props.updateValidationDetails({
      decisionItemsIds,
      decisionId,
      qualityCheckType,
      approvalStatusId,
      comment,
      confirmedBy
    });
  }

  handleFetchAffectedPortfolios = decisionItemId => {
    const { decisionCommon: { decisionId } } = this.props;
    this.props.fetchAffectedPortfolios({ decisionId, decisionItemId });
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderUpdater = () => (
    <div className="updaterContainer">
      <Dimmer active inverted>
        <Loader inline="centered" content="Updating" />
      </Dimmer>
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={this.getBreadcrumbsSections()}
    />
  );

  renderContent = () => {
    const {
      qualityCheckType,
      decisionLevel,
      decisionGroup,
      decisionItemsList,
      decisionItemsIds,
      sorting,
      isUpdating
    } = this.props;
    return decisionItemsList.length
      ? (
        <div className="decisionItemsListContainer">
          <DecisionItemsTable
            columnDefs={getColumnDefs({ decisionLevel, decisionGroup, qualityCheckType })}
            decisionItemsList={decisionItemsList}
            decisionItemsIds={decisionItemsIds}
            decisionGroup={decisionGroup}
            qualityCheckType={qualityCheckType}
            actions={this.getActions()}
            isDisabled={this.isDisabled()}
            sorting={sorting}
            onUpdate={this.handleUpdateDecisionItems}
            onSort={this.props.setSorting}
            onPortfoliosFetch={this.handleFetchAffectedPortfolios}
          />
          {isUpdating && this.renderUpdater()}
        </div>
      )
      : <NoResults />;
  };

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="validationDetailsContainer">
        {this.renderBreadcrumbs()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

ValidationDetails.propTypes = {
  qualityCheckType: PropTypes.number.isRequired,
  decisionCommon: DecisionCommonType.isRequired,
  approvalStatuses: PropTypes.arrayOf(PropTypes.number).isRequired,
  isLoading: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  error: PropTypes.string,
  decisionItemsList: PropTypes.arrayOf(DecisionItemType).isRequired,
  decisionItemsIds: PropTypes.arrayOf(PropTypes.number).isRequired,
  decisionLevel: PropTypes.number,
  decisionGroup: PropTypes.number,
  qualityCheckName: PropTypes.string,
  sorting: SortingType.isRequired,
  serverType: PropTypes.string.isRequired,
  clearValidationDetails: PropTypes.func.isRequired,
  setSorting: PropTypes.func.isRequired,
  updateValidationDetails: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired,
  fetchAffectedPortfolios: PropTypes.func.isRequired
};

ValidationDetails.defaultProps = {
  isLoading: false,
  decisionCommon: {},
  decisionItemsList: [],
  decisionItemsIds: [],
  approvalStatuses: [],
  clearValidationDetails: voidFn,
  setSorting: voidFn,
  updateValidationDetails: voidFn,
  clearError: voidFn,
  fetchAffectedPortfolios: voidFn
};

const mapStateToProps = state => ({
  decisionCommon: getSelectedDecision(state),
  isLoading: getIsLoading(state),
  isUpdating: getIsUpdating(state),
  decisionItemsList: getSortedAndFilteredDecisionItemsList(state),
  decisionItemsIds: getDecisionItemsIds(state),
  approvalStatuses: getApprovalStatuses(state),
  decisionLevel: getDecisionLevel(state),
  decisionGroup: getDecisionGroup(state),
  qualityCheckName: getQualityCheckName(state),
  serverType: getServerType(state),
  sorting: getSorting(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearValidationDetails,
  setSorting,
  updateValidationDetails,
  clearError,
  fetchAffectedPortfolios
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(ValidationDetails);
