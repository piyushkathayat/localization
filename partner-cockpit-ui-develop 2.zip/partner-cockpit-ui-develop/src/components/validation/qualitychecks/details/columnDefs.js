import * as R from 'ramda';
import { DECISION_LEVELS_IDS, DECISION_GROUPS_IDS } from 'constants/validation';
import { QUALITY_CHECKS } from 'constants/qualityCheck';
import { voidFn } from 'utils/common';

export const issueSinceColumnDef = {
  label: {
    id: 'validation.details.issue_since',
    defaultMessage: 'Issue Since'
  },
  dataKey: 'issueSince',
  width: 13,
  maxWidth: 13
};

export const getDisplayLabels = decisionLevel => {
  switch (decisionLevel) {
    case DECISION_LEVELS_IDS.INSTRUMENT:
      return {
        displayKeyLabel: {
          id: 'validation.details.isin',
          defaultMessage: 'ISIN'
        },
        displayDescriptionLabel: {
          id: 'validation.details.instrument_name',
          defaultMessage: 'Instrument Name'
        }
      };
    case DECISION_LEVELS_IDS.PORTFOLIO:
      return {
        displayKeyLabel: {
          id: 'validation.details.assetId',
          defaultMessage: 'Asset ID'
        },
        displayDescriptionLabel: {
          id: 'validation.details.portfolio',
          defaultMessage: 'Portfolio'
        }
      };
    case DECISION_LEVELS_IDS.ISSUER:
      return {
        displayKeyLabel: {
          id: 'validation.details.issuerId',
          defaultMessage: 'Issuer ID'
        },
        displayDescriptionLabel: {
          id: 'validation.details.issuer_name',
          defaultMessage: 'Issuer Name'
        }
      };
    default:
      return {
        displayKeyLabel: {
          id: 'validation.details.unknown_display_key',
          defaultMessage: 'Display Key'
        },
        displayDescriptionLabel: {
          id: 'validation.details.unknown_display_description',
          defaultMessage: 'Display Description'
        }
      };
  }
};

export const getDescriptionalColumnDefs = decisionLevel => {
  const { displayKeyLabel, displayDescriptionLabel } = getDisplayLabels(decisionLevel);
  return [
    {
      label: displayKeyLabel,
      dataKey: 'displayKey',
      width: 10,
      maxWidth: 10
    },
    {
      label: displayDescriptionLabel,
      dataKey: 'displayDescription',
      width: 31,
      maxWidth: 31,
      isLink: decisionLevel === DECISION_LEVELS_IDS.PORTFOLIO,
      onClick: decisionLevel === DECISION_LEVELS_IDS.PORTFOLIO
        ? (clientId, assetId) => window.open(`/details/${clientId}/${assetId}`, '_blank')
        : voidFn
    }
  ];
};

export const getNumberColumnDef = ({ decisionGroup, qualityCheckType }) => {
  return {
    label: decisionGroup === DECISION_GROUPS_IDS.FIRST
      ? R.pathOr(
        {
          id: 'validation.details.breaching_unknown',
          defaultMessage: 'Number of Breaches'
        },
        [qualityCheckType, 'validationBreachingLabel'],
        QUALITY_CHECKS
      )
      : {
        id: 'validation.details.affected_portfolios',
        defaultMessage: 'Affected Portfolios'
      },
    dataKey: 'affectedPortfolios',
    width: 14,
    maxWidth: 14,
    className: 'middleAligned',
    headerClassName: 'middleAligned'
  };
};

export const getColumnDefs = ({ decisionGroup, decisionLevel, qualityCheckType }) => {
  return [
    ...getDescriptionalColumnDefs(decisionLevel),
    issueSinceColumnDef,
    getNumberColumnDef({ decisionGroup, qualityCheckType })
  ];
};

export const getPortfoliosColumnDefs = () => [
  {
    headerName: 'Asset ID',
    field: 'assetId'
  },
  {
    headerName: 'Portfolio',
    field: 'portfolioCode',
    cellClass: 'clickableCell',
    onCellClicked: params => {
      const { assetId, clientId } = params.data;
      window.open(`/details/${clientId}/${assetId}`, '_blank');
    }
  },
  {
    headerName: 'Currency',
    field: 'portfolioCcy'
  },
  {
    headerName: 'Strategy',
    field: 'investmentStrategyDesc'
  }
];
