import React, { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { Popup, Checkbox, Dropdown, Loader } from 'semantic-ui-react';
import { WindowScroller, AutoSizer, Column, Table } from 'react-virtualized';
import { FormattedMessage, injectIntl, defineMessages } from 'react-intl';
import { toggleItem } from '@ubs.partner/shared-ui';
import {
  APPROVAL_STATUSES_IDS,
  SORTABLE_KEYS,
  DECISION_GROUPS_IDS
} from 'constants/validation';
import { SORT_DIRECTIONS, MODAL_TYPES } from 'constants/common';
import {
  DropdownOptionsType,
  DecisionItemType,
  SortingType,
  DecisionItemColumnDefType,
  IntlType
} from 'components/Types';
import { ReasonModal, AgGridTable } from 'components/common';
import { QC_TYPE_IDS } from 'constants/qualityCheck';
import {
  HEADER_HEIGHT,
  BORDER_HEIGHT,
  ROW_HEIGHT
} from 'components/common/aggridtable/AgGridTable';
import { voidFn } from 'utils/common';
import { getPortfoliosColumnDefs } from './columnDefs';
import './DecisionItemsTable.css';

const messages = defineMessages({
  comment: {
    id: 'validation.details.comment',
    defaultMessage: 'Comment'
  }
});

const MAX_PORTFOLIOS_HEIGHT = 600;
const PORTFOLIOS_VERTICAL_MARGIN = 10;
const DECISION_ROW_HEIGHT = 60;

const QC_TYPES_WITH_AFFECTED_PORTFOLIOS = [
  QC_TYPE_IDS.BULK_RISK,
  QC_TYPE_IDS.ISSUER_RISK,
  QC_TYPE_IDS.ITALIAN_GOV_RISK
];

export class DecisionItemsTable extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      selectedDecisionItemsIds: [],
      openedDecisionItemsIds: [],
      reasonModal: {
        isOpen: false,
        decisionItemsIds: null,
        approvalStatusId: null
      }
    };
    this.tableRef = React.createRef();
  }

  componentDidUpdate(prevProps, prevState) {
    const changedItems = R.symmetricDifference(
      prevState.openedDecisionItemsIds,
      this.state.openedDecisionItemsIds
    );
    if (changedItems.length || prevProps.decisionItemsList !== this.props.decisionItemsList) {
      this.tableRef.current.recomputeRowHeights();
    }
  }

  getColumnWidth = (width, percent) => width * percent / 100;

  getSelectedDetailsCount = () => this.state.selectedDecisionItemsIds.length;

  getAllDetailsCount = () => this.props.decisionItemsIds.length;

  getOpenedRowHeight = decisionItem => {
    const portfoliosListLength = R.prop('affectedPortfolios', decisionItem);
    return R.min(
      DECISION_ROW_HEIGHT
      + PORTFOLIOS_VERTICAL_MARGIN * 2
      + HEADER_HEIGHT
      + ROW_HEIGHT * R.max(portfoliosListLength, 2)
      + BORDER_HEIGHT * 2,
      MAX_PORTFOLIOS_HEIGHT
    );
  };

  getRowHeight = ({ index }) => {
    const { decisionItemsList } = this.props;
    return R.includes(
      R.path([index, 'decisionKey'], decisionItemsList),
      this.state.openedDecisionItemsIds
    )
      ? this.getOpenedRowHeight(R.prop(index, decisionItemsList))
      : DECISION_ROW_HEIGHT;
  };

  isDataKeySortable = dataKey => SORTABLE_KEYS.includes(dataKey);

  isDetailChecked = detailId => this.state.selectedDecisionItemsIds.includes(detailId);

  isNoDetailsChecked = () => this.getSelectedDetailsCount() === 0;

  isSomeDetailsChecked = () => this.getSelectedDetailsCount() !== this.getAllDetailsCount()
    && this.getSelectedDetailsCount() > 0;

  isEveryDetailChecked = () => this.getSelectedDetailsCount() === this.getAllDetailsCount();

  isExplanationNeeded = approvalStatusId => [
    APPROVAL_STATUSES_IDS.INVALIDATE,
    APPROVAL_STATUSES_IDS.POSTPONE,
    APPROVAL_STATUSES_IDS.REJECT
  ].includes(approvalStatusId);

  isDecisionItemOpened = decisionItemId =>
    this.state.openedDecisionItemsIds.includes(decisionItemId);

  hasAffectedPortfolios = () => {
    const { decisionGroup, qualityCheckType } = this.props;
    return decisionGroup === DECISION_GROUPS_IDS.SECOND
      || QC_TYPES_WITH_AFFECTED_PORTFOLIOS.includes(qualityCheckType);
  }

  handleAllCheckboxChange = () => {
    const { selectedDecisionItemsIds } = this.state;
    if (selectedDecisionItemsIds.length) {
      this.setState({ selectedDecisionItemsIds: [] });
    } else {
      const { decisionItemsIds } = this.props;
      this.setState({ selectedDecisionItemsIds: decisionItemsIds });
    }
  }

  handleSingleCheckboxChange = decisionKey => event => {
    event.stopPropagation();
    const selectedDecisionItemsIds = toggleItem(decisionKey, this.state.selectedDecisionItemsIds);
    this.setState({ selectedDecisionItemsIds });
  }

  handleHeaderClick = ({ dataKey }) => {
    if (this.isDataKeySortable(dataKey)) {
      this.props.onSort(dataKey);
    }
  }

  handleDropdownChange = ({ decisionItemsIds, approvalStatusId }) => {
    if (this.isExplanationNeeded(approvalStatusId)) {
      this.setState({
        reasonModal: {
          isOpen: true,
          decisionItemsIds,
          approvalStatusId
        }
      });
    } else {
      this.props.onUpdate({ decisionItemsIds, approvalStatusId });
    }
  };

  handleSingleDropdownChange = decisionKey => (event, { value: approvalStatusId }) => {
    const decisionItemsIds = [decisionKey];
    this.handleDropdownChange({ decisionItemsIds, approvalStatusId });
  }

  handleAllDropdownChange = (event, { value: approvalStatusId }) => {
    const decisionItemsIds = this.state.selectedDecisionItemsIds;
    this.handleDropdownChange({ decisionItemsIds, approvalStatusId });
  };

  handleModalClose = () => this.setState({
    reasonModal: {
      isOpen: false,
      decisionItemsIds: null,
      approvalStatusId: null
    }
  });

  handleSubmitModal = ({ decisionItemsIds, approvalStatusId }) =>
    ({ confirmedBy, explanationText }) => {
      this.handleModalClose();
      this.props.onUpdate({
        decisionItemsIds,
        approvalStatusId,
        confirmedBy,
        comment: explanationText
      });
    };

  renderSortableHeader = ({ dataKey, label }) => {
    const { sorting: { sortBy, sortDirection } } = this.props;
    const sortIcon = sortDirection === SORT_DIRECTIONS.ASC
      ? 'icon-disclosureup'
      : 'icon-disclosuredown';
    return (
      <div
        className="headerCell"
        title={label}
      >
        {label}
        {sortBy === dataKey &&
          <i className={`sortIcon icon-ubs ${sortIcon}`} />
        }
      </div>
    );
  }

  renderSingleCheckbox = ({ rowData: { decisionKey } }) => (
    <Checkbox
      checked={this.isDetailChecked(decisionKey)}
      onChange={this.handleSingleCheckboxChange(decisionKey)}
      disabled={this.props.isDisabled}
    />
  );

  renderAllCheckbox = () => (
    <Checkbox
      indeterminate={this.isSomeDetailsChecked()}
      checked={this.isEveryDetailChecked()}
      onChange={this.handleAllCheckboxChange}
      disabled={this.props.isDisabled}
    />
  );

  renderSingleActionDropdown = ({ rowData: { approvalStatus, decisionKey } }) => {
    const actionValue = this.props.actions.some(({ value }) => approvalStatus === value)
      ? approvalStatus
      : null;
    return (
      <Dropdown
        className="actionDropdown"
        placeholder="Select action"
        fluid
        selection
        selectOnBlur={false}
        selectOnNavigation={false}
        options={this.props.actions}
        onChange={this.handleSingleDropdownChange(decisionKey)}
        value={actionValue}
        disabled={this.props.isDisabled}
      />
    );
  }

  renderAllActionDropdown = () => (
    <Dropdown
      className="actionDropdown"
      placeholder="Select action for checked"
      fluid
      selection
      selectOnBlur={false}
      selectOnNavigation={false}
      options={this.props.actions}
      onChange={this.handleAllDropdownChange}
      disabled={this.props.isDisabled || this.isNoDetailsChecked()}
    />
  );

  renderComment = (comment, confirmedBy) => !!comment && !!confirmedBy && (
    <Popup
      wide
      hoverable
      trigger={this.renderTableCell({
        value: comment,
        hasTitle: false
      })}
      content={(
        <div className="commentPopupContainer">
          <div className="commentRow">
            <div className="label">
              <FormattedMessage
                defaultMessage="Confirmed by"
                id="validation.details.confirmedBy"
              />:
            </div>
            <div className="value">
              {confirmedBy}
            </div>
          </div>
          <div className="commentRow comment">
            {comment}
          </div>
        </div>
      )}
    />
  );

  handleRowClick = ({ decisionKey: decisionItemId, portfoliosList = [] }) => () => {
    if (!portfoliosList.length) {
      this.props.onPortfoliosFetch(decisionItemId);
    }
    const openedDecisionItemsIds = toggleItem(decisionItemId, this.state.openedDecisionItemsIds);
    this.setState({ openedDecisionItemsIds });
  };

  renderPortfoliosList = (portfoliosList = []) => (
    <div className="affectedPortfoliosList">
      {portfoliosList.length
        ? (
          <AgGridTable
            columnDefs={getPortfoliosColumnDefs()}
            tableData={portfoliosList}
            isSelectable={false}
          />
        )
        : <Loader active inline="centered" size="small" />
      }
    </div>
  );

  renderTableRow = ({ rowData, className, columns, style, index }) => (
    <Fragment key={rowData.decisionKey}>
      <div
        className={`${className} expandableRow`}
        role="row"
        tabIndex={index}
        style={style}
      >
        <div
          className="columns"
          onClick={this.handleRowClick(rowData)}
        >
          {columns}
        </div>
        {this.isDecisionItemOpened(rowData.decisionKey)
          && this.renderPortfoliosList(rowData.portfoliosList)
        }
      </div>
    </Fragment>
  );

  renderTableCell = ({ value, hasTitle = true, isLink = false, onClick, rowData }) => (
    <div
      title={hasTitle ? value : ''}
      className={`ReactVirtualized__Table__cell ${isLink ? 'clickable' : ''}`}
      onClick={isLink
        ? () => onClick(rowData.clientId, rowData.displayKey)
        : undefined
      }
    >
      {value}
    </div>
  );

  renderDetailsTable = () => {
    const { decisionItemsList, columnDefs, intl: { formatMessage } } = this.props;
    return (
      <WindowScroller>
        {({ height, scrollTop }) => (
          <AutoSizer disableHeight>
            {({ width }) => (
              <Table
                className="decisionItemsTable celledTable"
                autoHeight
                ref={this.tableRef}
                height={height}
                overscanRowCount={20}
                rowCount={decisionItemsList.length}
                headerHeight={65}
                rowHeight={this.getRowHeight}
                scrollTop={scrollTop}
                width={width}
                rowGetter={({ index }) => decisionItemsList[index]}
                rowRenderer={this.hasAffectedPortfolios()
                  ? this.renderTableRow
                  : undefined
                }
                onHeaderClick={this.handleHeaderClick}
              >
                <Column
                  width={this.getColumnWidth(width, 3)}
                  maxWidth={this.getColumnWidth(width, 3)}
                  dataKey="checkbox"
                  className="middleAligned"
                  headerClassName="middleAligned"
                  flexGrow={1}
                  flexShrink={0}
                  cellRenderer={this.renderSingleCheckbox}
                  headerRenderer={this.renderAllCheckbox}
                />
                <Column
                  width={this.getColumnWidth(width, 17)}
                  maxWidth={this.getColumnWidth(width, 17)}
                  dataKey="actionDropdown"
                  className="middleAligned overflowVisible"
                  headerClassName="middleAligned overflowVisible"
                  flexGrow={1}
                  flexShrink={0}
                  cellRenderer={this.renderSingleActionDropdown}
                  headerRenderer={this.renderAllActionDropdown}
                />
                {columnDefs.map(column => (
                  <Column
                    key={column.dataKey}
                    label={column.label
                      ? formatMessage(column.label)
                      : column.dataKey
                    }
                    dataKey={column.dataKey}
                    headerClassName={`
                      ${column.headerClassName}
                      ${this.isDataKeySortable(column.dataKey) ? 'sortable' : ''}
                    `}
                    width={this.getColumnWidth(width, column.width)}
                    maxWidth={this.getColumnWidth(width, column.maxWidth)}
                    className={column.className}
                    flexGrow={1}
                    flexShrink={0}
                    cellRenderer={({ rowData }) => this.renderTableCell({
                      rowData,
                      value: rowData[column.dataKey],
                      isLink: column.isLink,
                      onClick: column.onClick
                    })}
                    headerRenderer={this.isDataKeySortable(column.dataKey)
                      ? this.renderSortableHeader
                      : undefined
                    }
                  />
                ))}
                <Column
                  label={formatMessage(messages.comment)}
                  dataKey="comment"
                  width={this.getColumnWidth(width, 12)}
                  maxWidth={this.getColumnWidth(width, 12)}
                  flexGrow={1}
                  flexShrink={0}
                  cellRenderer={({ rowData }) =>
                    this.renderComment(rowData.commentLast, rowData.confirmedBy)}
                />
              </Table>
            )}
          </AutoSizer>
        )}
      </WindowScroller>
    );
  }

  render() {
    const { isOpen: isModalOpen, decisionItemsIds, approvalStatusId } = this.state.reasonModal;
    return (
      <div className="decisionItemsTableContainer">
        {this.renderDetailsTable()}
        {isModalOpen && (
          <ReasonModal
            isOpen
            type={MODAL_TYPES.VALIDATION_DECISION}
            onClose={this.handleModalClose}
            onSubmit={this.handleSubmitModal({ decisionItemsIds, approvalStatusId })}
          />
        )}
      </div>
    );
  }
}

DecisionItemsTable.propTypes = {
  columnDefs: PropTypes.arrayOf(DecisionItemColumnDefType).isRequired,
  decisionItemsList: PropTypes.arrayOf(DecisionItemType).isRequired,
  decisionItemsIds: PropTypes.arrayOf(PropTypes.number).isRequired,
  decisionGroup: PropTypes.number.isRequired,
  qualityCheckType: PropTypes.number.isRequired,
  actions: PropTypes.arrayOf(DropdownOptionsType).isRequired,
  isDisabled: PropTypes.bool.isRequired,
  sorting: SortingType.isRequired,
  onUpdate: PropTypes.func.isRequired,
  onSort: PropTypes.func.isRequired,
  onPortfoliosFetch: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

DecisionItemsTable.defaultProps = {
  columnDefs: [],
  decisionItemsList: [],
  decisionItemsIds: [],
  actions: [],
  isDisabled: false,
  sorting: {
    sortBy: '',
    sortDirection: SORT_DIRECTIONS.ASC
  },
  onUpdate: voidFn,
  onSort: voidFn,
  onPortfoliosFetch: voidFn
};

export default injectIntl(DecisionItemsTable);
