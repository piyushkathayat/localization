import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { Button } from 'semantic-ui-react';
import { DecisionCommonType } from 'components/Types';
import { voidFn } from 'utils/common';
import { DECISION_STATUSES } from 'constants/validation';
import { MODAL_TYPES } from 'constants/common';
import { DateAndTime, ReasonModal, ConfirmModal } from 'components/common';
import './ValidationRelease.css';

export default class ValidationRelease extends PureComponent {
  state = {
    modalOpen: null
  };

  isButtonDisabled = () => !this.props.isReleaseAllowed || this.props.decisionCommon.isFreezed;

  showModal = modalType => () => {
    this.setState({ modalOpen: modalType });
  };

  handleModalClose = () => this.setState({ modalOpen: null });

  handleReasonModalSubmit = ({ confirmedBy, explanationText }) => {
    const { decisionCommon: { decisionId }, onRecalculate } = this.props;
    onRecalculate({ decisionId, confirmedBy, comment: explanationText });
    this.handleModalClose();
  };

  handleConfirmationSubmit = () => {
    const { decisionCommon: { decisionId }, onValidate } = this.props;
    onValidate(decisionId);
    this.handleModalClose();
  };

  renderRecalculateButton = (isLoading = false) => (
    <Button
      className="decisionButton ubs-primary-button"
      disabled={this.isButtonDisabled() || isLoading}
      loading={isLoading}
      onClick={this.showModal(MODAL_TYPES.VALIDATION_RELEASE)}
    >
      <FormattedMessage
        defaultMessage="Recalculate"
        id="validation.overview.recalculate_button"
      />
    </Button>
  );

  renderValidateButton = (isLoading = false) => (
    <Button
      className="decisionButton ubs-tertiary-button"
      disabled={this.isButtonDisabled() || isLoading}
      loading={isLoading}
      onClick={this.showModal(MODAL_TYPES.CONFIRMATION)}
    >
      <FormattedMessage
        defaultMessage="Validate"
        id="validation.overview.validate_button"
      />
    </Button>
  );

  renderLabel = () => (
    <div className="validatedLabel">
      <FormattedMessage
        defaultMessage="Validated"
        id="validation.overview.validated"
      />
    </div>
  );

  renderValidateOption = () => {
    const { decisionCommon: { statusId } } = this.props;
    switch (statusId) {
      case DECISION_STATUSES.GENERATED:
      case DECISION_STATUSES.ONGOING:
      case DECISION_STATUSES.ERROR:
        return this.renderRecalculateButton();
      case DECISION_STATUSES.CLOSED:
        return this.renderRecalculateButton(true);
      case DECISION_STATUSES.RECALCULATED:
        return this.renderValidateButton();
      case DECISION_STATUSES.FINALIZED:
        return this.renderLabel();
      default:
        return this.renderRecalculateButton();
    }
  };

  renderReasonModal = () => (
    <ReasonModal
      isOpen
      type={MODAL_TYPES.VALIDATION_RELEASE}
      onClose={this.handleModalClose}
      onSubmit={this.handleReasonModalSubmit}
    />
  );

  renderConfirmation = () => (
    <ConfirmModal
      onCancel={this.handleModalClose}
      onConfirm={this.handleConfirmationSubmit}
    />
  );

  renderLastValidationDate = () => {
    const { lastSuccessfulValidationDate } = this.props;
    return lastSuccessfulValidationDate && (
      <div className="lastValidation">
        <FormattedMessage
          defaultMessage="Last Successful Validation"
          id="validation.overview.last_successful_validation"
        />:
        <div className="date">
          <DateAndTime value={lastSuccessfulValidationDate} />
        </div>
      </div>
    );
  }

  render() {
    const { modalOpen } = this.state;
    return (
      <div className="releaseContainer">
        {this.renderLastValidationDate()}
        <div className="validateOption">
          {this.renderValidateOption()}
        </div>
        {modalOpen === MODAL_TYPES.VALIDATION_RELEASE && this.renderReasonModal()}
        {modalOpen === MODAL_TYPES.CONFIRMATION && this.renderConfirmation()}
      </div>
    );
  }
}

ValidationRelease.propTypes = {
  decisionCommon: DecisionCommonType.isRequired,
  isReleaseAllowed: PropTypes.bool.isRequired,
  lastSuccessfulValidationDate: PropTypes.string,
  onRecalculate: PropTypes.func.isRequired,
  onValidate: PropTypes.func.isRequired
};

ValidationRelease.defaultProps = {
  decisionCommon: {},
  isReleaseAllowed: false,
  onRecalculate: voidFn,
  onValidate: voidFn
};
