import React from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { Popup } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { APPROVAL_STATUSES_IDS } from 'constants/validation';
import { DecisionQualityCheckType } from 'components/Types';
import { voidFn } from 'utils/common';
import './QualityCheckTile.css';

const BAR_HEIGHT = 30;

export default function QualityCheckTile(props) {
  const {
    qualityCheck: {
      qualityCheckType,
      totalIssues,
      newIssues,
      oldIssues,
      approvals,
      description
    },
    onClick
  } = props;

  const getCountOf = statusId => R.propOr(
    0,
    'distinctIssues',
    R.find(approval => approval.approvalStatusId === statusId, approvals)
  );

  const acceptCount = getCountOf(APPROVAL_STATUSES_IDS.ACCEPT);
  const invalidateCount = getCountOf(APPROVAL_STATUSES_IDS.INVALIDATE);
  const postponeCount = getCountOf(APPROVAL_STATUSES_IDS.POSTPONE);
  const rejectCount = getCountOf(APPROVAL_STATUSES_IDS.REJECT);
  const actionMadeCount = acceptCount + invalidateCount + postponeCount + rejectCount;
  const noDecisionCount = totalIssues - actionMadeCount;

  const calculateBarWidthInPercents = issuesCount => totalIssues && issuesCount / totalIssues * 100;

  /**
   * Calculating coordinates for the bar
   * We get array of issue's counts and calculate 'x' coordinate and width for every sub-bar
   * Example:
   * We have 20 issues, 5 issues for four types (accept, postpone, reject, and noDecision)
   * and 0 for invalidate
   *
   * [5, 0, 5, 5, 5] => [
   *  { x: '0%', width: '25%', className: 'accept' },
   *  { x: '25%', width: '0%', className: 'invalidate' },
   *  { x: '25%', width: '25%', className: 'postpone' },
   *  { x: '50%', width: '25%', className: 'reject' },
   *  { x: '75%', width: '25%', className: 'noDecision' },
   * ]
  */
  const barCoordinates = R.prop(
    1,
    R.mapAccum(
      (x, { issuesCount, className }) => {
        const width = calculateBarWidthInPercents(issuesCount);
        return [x + width, { x: `${x}%`, width: `${width}%`, className }];
      },
      0,
      [
        { issuesCount: acceptCount, className: 'accept' },
        { issuesCount: invalidateCount, className: 'invalidate' },
        { issuesCount: postponeCount, className: 'postpone' },
        { issuesCount: rejectCount, className: 'reject' },
        { issuesCount: noDecisionCount, className: 'noDecision' }
      ]
    )
  );

  const handleTileClick = () => onClick(qualityCheckType);

  const renderBar = ({ x, width, className }) => (
    <rect
      key={className}
      className={className}
      x={x}
      y={0}
      width={width}
      height={BAR_HEIGHT}
    />
  );

  const renderEmptyBar = () => renderBar({ x: 0, width: '100%', className: 'noIssues' });

  const renderTileBar = () => (
    <svg width="100%" height={BAR_HEIGHT}>
      <g>
        {totalIssues
          ? barCoordinates.map(renderBar)
          : renderEmptyBar()
        }
      </g>
    </svg>
  );

  const renderTooltipRow = ({ className, defaultMessage, messageId, value }) => (
    <div className={`tooltipRow ${className}`}>
      <div className="tooptipRowName">
        <FormattedMessage defaultMessage={defaultMessage} id={messageId} />
        {': '}
      </div>
      <div className="tooptipRowValue">
        {value}
      </div>
    </div>
  );

  const renderTooltip = () => (
    <div>
      {renderTooltipRow({
        className: 'accept',
        defaultMessage: 'Accept',
        messageId: 'validation.accept',
        value: acceptCount
      })}
      {renderTooltipRow({
        className: 'invalidate',
        defaultMessage: 'Invalidate',
        messageId: 'validation.invalidate',
        value: invalidateCount
      })}
      {renderTooltipRow({
        className: 'postpone',
        defaultMessage: 'Postpone',
        messageId: 'validation.postpone',
        value: postponeCount
      })}
      {renderTooltipRow({
        className: 'reject',
        defaultMessage: 'Reject',
        messageId: 'validation.reject',
        value: rejectCount
      })}
      {renderTooltipRow({
        className: 'noDecision',
        defaultMessage: 'No decision yet',
        messageId: 'validation.no_decision',
        value: noDecisionCount
      })}
    </div>
  );

  return (
    <div
      className="qualityCheckTileContainer"
      onClick={handleTileClick}
    >
      <div className="description">
        {description}
      </div>
      <div className="noDecisionCount">
        {noDecisionCount}
      </div>
      <div className="newAndOld">
        <div className="new">
          <FormattedMessage defaultMessage="New" id="validation.overview.new" />
          {': '}
          {newIssues}
        </div>
        <div className="old">
          <FormattedMessage defaultMessage="Old" id="validation.overview.old" />
          {': '}
          {oldIssues}
        </div>
      </div>
      <div className="tileBar">
        {totalIssues
          ? (
            <Popup
              className="tileBarTooltip"
              basic
              position="bottom center"
              trigger={renderTileBar()}
              content={renderTooltip()}
            />
          )
          : renderTileBar()
        }
      </div>
    </div>
  );
}

QualityCheckTile.propTypes = {
  qualityCheck: DecisionQualityCheckType.isRequired,
  onClick: PropTypes.func.isRequired
};

QualityCheckTile.defaultProps = {
  qualityCheck: {
    qualityCheckType: '',
    totalIssues: 0,
    newIssues: 0,
    oldIssues: 0,
    statusList: []
  },
  onClick: voidFn
};
