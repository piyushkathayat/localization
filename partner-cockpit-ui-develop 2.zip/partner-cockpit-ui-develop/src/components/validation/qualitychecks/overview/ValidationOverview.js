import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Grid, Loader, Breadcrumb } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { DecisionCommonType, DecisionOverviewType, EmptyObjectType } from 'components/Types';
import { NoResults } from 'components/common';
import { voidFn } from 'utils/common';
import {
  getSelectedDecision,
  getLastSuccessfulValidationDate
} from 'selectors/validation';
import {
  getSelectedDecisionOverview,
  getIsLoading
} from 'selectors/validationOverview';
import { recalculateDecision, validateDecision } from 'actions/validation';
import { clearValidationOverview } from 'actions/validationOverview';
import QualityCheckTile from './QualityCheckTile';
import ValidationLegend from './ValidationLegend';
import ValidationRelease from './ValidationRelease';
import './ValidationOverview.css';

export class ValidationOverview extends PureComponent {
  breadcrumbsSections = [
    {
      key: 'Overview',
      content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
      active: true
    }
  ];

  componentWillUnmount() {
    this.props.clearValidationOverview();
  }

  renderQualityChecksTable = () => {
    const { decisionOverview: { qualityChecks = [] }, onQualityCheckTileClick } = this.props;
    return (
      <Grid columns={4} className="qualityChecksTable">
        <Grid.Row>
          {qualityChecks.map(qualityCheck => (
            <Grid.Column key={qualityCheck.qualityCheckType}>
              <QualityCheckTile
                qualityCheck={qualityCheck}
                onClick={onQualityCheckTileClick}
              />
            </Grid.Column>
          ))}
        </Grid.Row>
      </Grid>
    );
  };

  renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={this.breadcrumbsSections}
    />
  );

  renderContent = () => {
    const {
      decisionCommon,
      decisionOverview: {
        qualityChecks = [],
        isReleaseAllowed
      },
      lastSuccessfulValidationDate
    } = this.props;
    return qualityChecks.length
      ? (
        <div className="qualityChecksTableContainer">
          {this.renderQualityChecksTable()}
          <div className="validationOverviewFooter">
            <ValidationLegend />
            <ValidationRelease
              decisionCommon={decisionCommon}
              isReleaseAllowed={isReleaseAllowed}
              lastSuccessfulValidationDate={lastSuccessfulValidationDate}
              onRecalculate={this.props.recalculateDecision}
              onValidate={this.props.validateDecision}
            />
          </div>
        </div>
      )
      : <NoResults />;
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  render() {
    const { isLoading } = this.props;
    return (
      <div className="validationOverviewContainer">
        {this.renderBreadcrumbs()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
      </div>
    );
  }
}

ValidationOverview.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  decisionCommon: PropTypes.oneOfType([DecisionCommonType, EmptyObjectType]).isRequired,
  decisionOverview: PropTypes.oneOfType([DecisionOverviewType, EmptyObjectType]).isRequired,
  lastSuccessfulValidationDate: PropTypes.string,
  onQualityCheckTileClick: PropTypes.func.isRequired,
  clearValidationOverview: PropTypes.func.isRequired,
  recalculateDecision: PropTypes.func.isRequired
};

ValidationOverview.defaultProps = {
  isLoading: false,
  decisionCommon: {},
  decisionOverview: {},
  onQualityCheckTileClick: voidFn,
  clearValidationOverview: voidFn,
  recalculateDecision: voidFn,
  validateDecision: voidFn
};

const mapStateToProps = state => ({
  isLoading: getIsLoading(state),
  decisionCommon: getSelectedDecision(state),
  decisionOverview: getSelectedDecisionOverview(state),
  lastSuccessfulValidationDate: getLastSuccessfulValidationDate(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearValidationOverview,
  recalculateDecision,
  validateDecision
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(ValidationOverview);
