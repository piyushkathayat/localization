import React from 'react';
import { FormattedMessage } from 'react-intl';
import './ValidationLegend.css';

export default function ValidationLegend() {
  return (
    <div className="validationLegendContainer">
      <div className="legendBlock accept">
        <FormattedMessage defaultMessage="Accept" id="validation.accept" />
      </div>
      <div className="legendBlock invalidate postpone">
        <FormattedMessage defaultMessage="Invalidate" id="validation.invalidate" />
        /
        <FormattedMessage defaultMessage="Postpone" id="validation.postpone" />
      </div>
      <div className="legendBlock reject">
        <FormattedMessage defaultMessage="Reject" id="validation.reject" />
      </div>
      <div className="legendBlock noDecision">
        <FormattedMessage defaultMessage="No decision yet" id="validation.no_decision" />
      </div>
    </div>
  );
}
