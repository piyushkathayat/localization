import React from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { Popup } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { TriggerThemeType } from 'components/Types';
import { voidFn } from 'utils/common';
import './TriggerThemeTile.css';

const BAR_HEIGHT = 30;

export default function TriggerThemeTile(props) {
  const {
    triggerTheme: {
      triggerThemeId,
      triggerTheme,
      triggerCount = 0,
      triggerLocked = 0
    },
    onClick
  } = props;

  const triggerUnlocked = triggerCount - triggerLocked;

  const calculateBarWidthInPercents = issuesCount =>
    triggerCount && issuesCount / triggerCount * 100;

  /**
   * Calculating coordinates for the bar
   * We get array of trigger's counts and calculate 'x' coordinate and width for every sub-bar
   * Example:
   * We have 20 triggers, 15 - unlocked (accepted), 5 of them are locked (rejected)
   * [15, 5] => [
   *  { x: '0%', width: '25%', className: 'accept' },
   *  { x: '25%', width: '75%', className: 'reject' }
   * ]
  */
  const barCoordinates = R.prop(
    1,
    R.mapAccum(
      (x, { issuesCount, className }) => {
        const width = calculateBarWidthInPercents(issuesCount);
        return [x + width, { x: `${x}%`, width: `${width}%`, className }];
      },
      0,
      [
        { issuesCount: triggerUnlocked, className: 'accept' },
        { issuesCount: triggerLocked, className: 'reject' }
      ]
    )
  );

  const handleTileClick = () => onClick(triggerThemeId);

  const renderBar = ({ x, width, className }) => (
    <rect
      key={className}
      className={className}
      x={x}
      y={0}
      width={width}
      height={BAR_HEIGHT}
    />
  );

  const renderEmptyBar = () => renderBar({ x: 0, width: '100%', className: 'noIssues' });

  const renderTileBar = () => (
    <svg width="100%" height={BAR_HEIGHT}>
      <g>
        {triggerCount
          ? barCoordinates.map(renderBar)
          : renderEmptyBar()
        }
      </g>
    </svg>
  );

  const renderTooltipRow = ({ className, defaultMessage, messageId, value }) => (
    <div className={`tooltipRow ${className}`}>
      <div className="tooptipRowName">
        <FormattedMessage defaultMessage={defaultMessage} id={messageId} />
        {': '}
      </div>
      <div className="tooptipRowValue">
        {value}
      </div>
    </div>
  );

  const renderTooltip = () => (
    <div>
      {renderTooltipRow({
        className: 'accept',
        defaultMessage: 'Accept',
        messageId: 'validation.brokerage.overview.accept',
        value: triggerUnlocked
      })}
      {renderTooltipRow({
        className: 'reject',
        defaultMessage: 'Reject',
        messageId: 'validation.brokerage.overview.reject',
        value: triggerLocked
      })}
    </div>
  );

  return (
    <div
      className="triggerThemeTileContainer"
      onClick={handleTileClick}
    >
      <div className="description">
        {triggerTheme}
      </div>
      <div className="totalCount">
        {triggerCount}
      </div>
      <div className="tileBar">
        {triggerCount
          ? (
            <Popup
              className="tileBarTooltip"
              basic
              position="bottom center"
              trigger={renderTileBar()}
              content={renderTooltip()}
            />
          )
          : renderTileBar()
        }
      </div>
    </div>
  );
}

TriggerThemeTile.propTypes = {
  triggerTheme: TriggerThemeType.isRequired,
  onClick: PropTypes.func.isRequired
};

TriggerThemeTile.defaultProps = {
  triggerTheme: {},
  onClick: voidFn
};
