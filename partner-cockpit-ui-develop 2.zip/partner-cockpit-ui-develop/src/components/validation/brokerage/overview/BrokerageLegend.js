import React from 'react';
import { FormattedMessage } from 'react-intl';
import './BrokerageLegend.css';

export default function BrokerageLegend() {
  return (
    <div className="brokerageLegendContainer">
      <div className="legendBlock accept">
        <FormattedMessage defaultMessage="Accept" id="validation.brokerage.overview.accept" />
      </div>
      <div className="legendBlock reject">
        <FormattedMessage defaultMessage="Reject" id="validation.brokerage.overview.reject" />
      </div>
    </div>
  );
}
