import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { voidFn } from 'utils/common';
import { Grid, Loader, Breadcrumb, Button } from 'semantic-ui-react';
import { ErrorMessage, NoResults } from 'components/common';
import { FormattedMessage } from 'react-intl';
import {
  finalizeBrokerage,
  clearBrokerageOverview,
  clearError
} from 'actions/brokerageOverview';
import {
  getIsLoading,
  getIsFinalizing,
  getError,
  getTriggerThemesList
} from 'selectors/brokerageOverview';
import { TriggerThemeType } from 'components/Types';
import BrokerageLegend from './BrokerageLegend';
import TriggerThemeTile from './TriggerThemeTile';
import './BrokerageOverview.css';

export class BrokerageOverview extends PureComponent {
  breadcrumbsSections = [
    {
      key: 'Overview',
      content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
      active: true
    }
  ];

  componentWillUnmount() {
    this.props.clearBrokerageOverview();
  }

  renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={this.breadcrumbsSections}
    />
  );

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  renderTriggerThemesTable = () => {
    const { triggerThemesList, onTriggerThemeTileClick } = this.props;
    return (
      <Grid columns={4} className="triggerThemesTable">
        <Grid.Row>
          {triggerThemesList.map(triggerTheme => (
            <Grid.Column key={triggerTheme.triggerThemeId}>
              <TriggerThemeTile
                triggerTheme={triggerTheme}
                onClick={onTriggerThemeTileClick}
              />
            </Grid.Column>
          ))}
        </Grid.Row>
      </Grid>
    );
  };

  renderContent = () => {
    const { triggerThemesList, isFinalizing } = this.props;
    return triggerThemesList.length
      ? (
        <div className="triggerThemesTableContainer">
          {this.renderTriggerThemesTable()}
          <div className="brokerageOverviewFooter">
            <BrokerageLegend />
            <Button
              className="finalizeButton ubs-primary-button"
              disabled={isFinalizing}
              loading={isFinalizing}
              onClick={this.props.finalizeBrokerage}
            >
              <FormattedMessage defaultMessage="Finalize" id="validation.brokerage.overview.finalize" />
            </Button>
          </div>
        </div>
      )
      : <NoResults />;
  };

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="brokerageOverviewContainer">
        {this.renderBreadcrumbs()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

BrokerageOverview.propTypes = {
  triggerThemesList: PropTypes.arrayOf(TriggerThemeType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  isFinalizing: PropTypes.bool.isRequired,
  error: PropTypes.string,
  onTriggerThemeTileClick: PropTypes.func.isRequired,
  finalizeBrokerage: PropTypes.func.isRequired,
  clearBrokerageOverview: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

BrokerageOverview.defaultProps = {
  triggerThemesList: [],
  isLoading: false,
  isFinalizing: false,
  error: null,
  onTriggerThemeTileClick: voidFn,
  finalizeBrokerage: voidFn,
  cleanBrokerageOverview: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  triggerThemesList: getTriggerThemesList(state),
  isLoading: getIsLoading(state),
  isFinalizing: getIsFinalizing(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  finalizeBrokerage,
  clearBrokerageOverview,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(BrokerageOverview);
