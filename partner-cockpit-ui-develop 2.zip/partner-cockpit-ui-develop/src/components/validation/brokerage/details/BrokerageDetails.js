import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';
import { Loader, Dimmer, Breadcrumb } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { TriggerType, SortingType } from 'components/Types';
import { NoResults, ErrorMessage } from 'components/common';
import { voidFn } from 'utils/common';
import { getSorting } from 'selectors/validation';
import {
  getTriggerThemeNameById,
  getSortedAndFilteredTriggersList,
  getIsLoading,
  getIsUpdating,
  getError
} from 'selectors/brokerageDetails';
import { setSorting } from 'actions/validation';
import {
  updateBrokerageTrigger,
  fetchBrokeragePortfolios,
  clearBrokerageDetails,
  clearError
} from 'actions/brokerageDetails';
import { getColumnDefs } from './columnDefs';
import TriggersTable from './TriggersTable';
import './BrokerageDetails.css';

export class BrokerageDetails extends PureComponent {
  breadcrumbsLoader = (
    <div className="breadcrumbsLoaderContainer">
      <Loader active inline="centered" size="tiny" />
    </div>
  );

  componentWillUnmount() {
    this.props.clearBrokerageDetails();
  }

  getBreadcrumbsSections = () => [
    {
      key: 'Overview',
      content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
      active: false,
      as: Link,
      to: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}`
    },
    {
      key: 'Details',
      content: this.props.isLoading
        ? this.breadcrumbsLoader
        : this.props.triggerThemeName,
      active: true
    }
  ];

  handleUpdateTrigger = (triggerId, isLocked) => this.props.updateBrokerageTrigger({
    triggerThemeId: this.props.triggerThemeId,
    triggerId,
    isLocked
  });

  renderUpdater = () => (
    <div className="updaterContainer">
      <Dimmer active inverted>
        <Loader inline="centered" content="Updating" />
      </Dimmer>
    </div>
  );

  renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={this.getBreadcrumbsSections()}
    />
  );

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  renderContent = () => {
    const { triggersList, sorting, isUpdating } = this.props;

    return triggersList.length
      ? (
        <div className="triggersListContainer">
          <TriggersTable
            columnDefs={getColumnDefs()}
            triggersList={this.props.triggersList}
            sorting={sorting}
            onUpdate={this.handleUpdateTrigger}
            onSort={this.props.setSorting}
            onPortfoliosFetch={this.props.fetchBrokeragePortfolios}
          />
          {isUpdating && this.renderUpdater()}
        </div>
      )
      : <NoResults />;
  }

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="brokerageDetailsContainer">
        {this.renderBreadcrumbs()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

BrokerageDetails.propTypes = {
  triggerThemeName: PropTypes.string.isRequired,
  triggersList: PropTypes.arrayOf(TriggerType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  sorting: SortingType.isRequired,
  error: PropTypes.string,
  updateBrokerageTrigger: PropTypes.func.isRequired,
  fetchBrokeragePortfolios: PropTypes.func.isRequired,
  setSorting: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

BrokerageDetails.defaultProps = {
  triggersList: [],
  isLoading: false,
  isUpdating: false,
  error: null,
  updateBrokerageTrigger: voidFn,
  fetchBrokeragePortfolios: voidFn,
  setSorting: voidFn,
  clearError: voidFn
};

const mapStateToProps = (state, ownProps) => ({
  triggersList: getSortedAndFilteredTriggersList(state, ownProps.triggerThemeId),
  triggerThemeName: getTriggerThemeNameById(state, ownProps.triggerThemeId),
  isLoading: getIsLoading(state),
  isUpdating: getIsUpdating(state),
  sorting: getSorting(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  updateBrokerageTrigger,
  fetchBrokeragePortfolios,
  clearBrokerageDetails,
  setSorting,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(BrokerageDetails);
