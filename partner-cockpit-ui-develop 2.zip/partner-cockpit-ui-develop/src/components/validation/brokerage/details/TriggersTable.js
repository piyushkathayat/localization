import React, { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { Loader, Radio } from 'semantic-ui-react';
import { WindowScroller, AutoSizer, Column, Table } from 'react-virtualized';
import { injectIntl } from 'react-intl';
import { toggleItem } from '@ubs.partner/shared-ui';
import { SORT_DIRECTIONS } from 'constants/common';
import { BROKERAGE_SORTABLE_KEYS } from 'constants/validation';
import {
  SortingType,
  TriggerType,
  DecisionItemColumnDefType,
  IntlType
} from 'components/Types';
import { AgGridTable } from 'components/common';
import {
  HEADER_HEIGHT,
  BORDER_HEIGHT,
  ROW_HEIGHT
} from 'components/common/aggridtable/AgGridTable';
import { voidFn } from 'utils/common';
import { getPortfoliosColumnDefs } from './columnDefs';
import './TriggersTable.css';

const MAX_PORTFOLIOS_HEIGHT = 600;
const PORTFOLIOS_VERTICAL_MARGIN = 10;
const TRIGGER_ROW_HEIGHT = 60;

export class TriggersTable extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      openedTriggersIds: []
    };
    this.tableRef = React.createRef();
  }

  componentDidUpdate(prevProps, prevState) {
    const changedItems = R.symmetricDifference(
      prevState.openedTriggersIds,
      this.state.openedTriggersIds
    );
    if (changedItems.length || prevProps.triggersList !== this.props.triggersList) {
      this.tableRef.current.recomputeRowHeights();
    }
  }

  getColumnWidth = (width, percent) => width * percent / 100;

  getAllDetailsCount = () => this.props.triggersList.length;

  getOpenedRowHeight = trigger => {
    const portfoliosListLength = R.prop('affectedPortfolios', trigger);
    return R.min(
      TRIGGER_ROW_HEIGHT
      + PORTFOLIOS_VERTICAL_MARGIN * 2
      + HEADER_HEIGHT
      + ROW_HEIGHT * R.max(portfoliosListLength, 2)
      + BORDER_HEIGHT * 2,
      MAX_PORTFOLIOS_HEIGHT
    );
  };

  getRowHeight = ({ index }) => {
    const { triggersList } = this.props;
    return R.includes(
      R.path([index, 'triggerId'], triggersList),
      this.state.openedTriggersIds
    )
      ? this.getOpenedRowHeight(R.prop(index, triggersList))
      : TRIGGER_ROW_HEIGHT;
  };

  isDataKeySortable = dataKey => BROKERAGE_SORTABLE_KEYS.includes(dataKey);

  isTriggerOpened = triggerId =>
    this.state.openedTriggersIds.includes(triggerId);

  handleRadioClick = triggerId => (event, { checked }) => {
    event.stopPropagation();
    this.props.onUpdate(triggerId, !checked);
  }

  handleHeaderClick = ({ dataKey }) => this.props.onSort(dataKey);

  renderSortableHeader = ({ dataKey, label }) => {
    const { sorting: { sortBy, sortDirection } } = this.props;
    const sortIcon = sortDirection === SORT_DIRECTIONS.ASC
      ? 'icon-disclosureup'
      : 'icon-disclosuredown';
    return (
      <div
        className="headerCell"
        title={label}
      >
        {label}
        {sortBy === dataKey &&
          <i className={`sortIcon icon-ubs ${sortIcon}`} />
        }
      </div>
    );
  }

  renderRadio = ({ rowData: { triggerId, isLocked } }) => (
    <Radio
      toggle
      checked={!isLocked}
      onChange={this.handleRadioClick(triggerId)}
    />
  );

  handleRowClick = ({ triggerId, portfoliosList = [] }) => () => {
    if (!portfoliosList.length) {
      this.props.onPortfoliosFetch(triggerId);
    }
    const openedTriggersIds = toggleItem(triggerId, this.state.openedTriggersIds);
    this.setState({ openedTriggersIds });
  };

  renderPortfoliosList = (portfoliosList = []) => (
    <div className="affectedPortfoliosList">
      {portfoliosList.length
        ? (
          <AgGridTable
            columnDefs={getPortfoliosColumnDefs()}
            tableData={portfoliosList}
            isSelectable={false}
          />
        )
        : <Loader active inline="centered" size="small" />
      }
    </div>
  );

  renderTableRow = ({ rowData, className, columns, style, index }) => (
    <Fragment key={rowData.triggerId}>
      <div
        className={`${className} expandableRow`}
        role="row"
        tabIndex={index}
        style={style}
      >
        <div
          className="columns"
          onClick={this.handleRowClick(rowData)}
        >
          {columns}
        </div>
        {this.isTriggerOpened(rowData.triggerId)
          && this.renderPortfoliosList(rowData.portfoliosList)
        }
      </div>
    </Fragment>
  );

  renderTableCell = ({ value }) => (
    <div
      title={value}
      className="ReactVirtualized__Table__cell"
    >
      {value}
    </div>
  );

  renderDetailsTable = () => {
    const { triggersList, columnDefs, intl: { formatMessage } } = this.props;
    return (
      <WindowScroller>
        {({ height, scrollTop }) => (
          <AutoSizer disableHeight>
            {({ width }) => (
              <Table
                className="triggersTable celledTable"
                autoHeight
                ref={this.tableRef}
                height={height}
                overscanRowCount={20}
                rowCount={triggersList.length}
                headerHeight={65}
                rowHeight={this.getRowHeight}
                scrollTop={scrollTop}
                width={width}
                rowGetter={({ index }) => triggersList[index]}
                rowRenderer={this.renderTableRow}
                onHeaderClick={this.handleHeaderClick}
              >
                <Column
                  width={this.getColumnWidth(width, 6)}
                  maxWidth={this.getColumnWidth(width, 6)}
                  dataKey="checkbox"
                  className="middleAligned"
                  headerClassName="middleAligned"
                  flexGrow={1}
                  flexShrink={0}
                  cellRenderer={this.renderRadio}
                />
                {columnDefs.map(column => (
                  <Column
                    key={column.dataKey}
                    label={column.label
                      ? formatMessage(column.label)
                      : column.dataKey
                    }
                    dataKey={column.dataKey}
                    headerClassName={`
                      ${column.headerClassName}
                      ${this.isDataKeySortable(column.dataKey) ? 'sortable' : ''}
                    `}
                    width={this.getColumnWidth(width, column.width) - 1}
                    maxWidth={this.getColumnWidth(width, column.maxWidth) - 1}
                    className={column.className}
                    flexGrow={1}
                    flexShrink={0}
                    cellRenderer={({ rowData }) => this.renderTableCell({
                      rowData,
                      value: rowData[column.dataKey]
                    })}
                    headerRenderer={this.isDataKeySortable(column.dataKey)
                      ? this.renderSortableHeader
                      : undefined
                    }
                  />
                ))}
              </Table>
            )}
          </AutoSizer>
        )}
      </WindowScroller>
    );
  }

  render() {
    return (
      <div className="triggersTableContainer">
        {this.renderDetailsTable()}
      </div>
    );
  }
}

TriggersTable.propTypes = {
  columnDefs: PropTypes.arrayOf(DecisionItemColumnDefType).isRequired,
  triggersList: PropTypes.arrayOf(TriggerType).isRequired,
  sorting: SortingType.isRequired,
  onUpdate: PropTypes.func.isRequired,
  onSort: PropTypes.func.isRequired,
  onPortfoliosFetch: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

TriggersTable.defaultProps = {
  columnDefs: [],
  triggersList: [],
  sorting: {
    sortBy: '',
    sortDirection: SORT_DIRECTIONS.ASC
  },
  onUpdate: voidFn,
  onSort: voidFn,
  onPortfoliosFetch: voidFn
};

export default injectIntl(TriggersTable);
