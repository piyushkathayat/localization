export const getColumnDefs = () => {
  return [
    {
      label: {
        id: 'validation.brokerage.details.buyInstrument',
        defaultMessage: 'Buy Instrument'
      },
      dataKey: 'buyInstrumentName',
      width: 40,
      maxWidth: 40,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    },
    {
      label: {
        id: 'validation.brokerage.details.sellInstrument',
        defaultMessage: 'Sell Instrument'
      },
      dataKey: 'sellInstrumentName',
      width: 40,
      maxWidth: 40,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    },
    {
      label: {
        id: 'validation.brokerage.details.affected_portfolios',
        defaultMessage: 'Affected Portfolios'
      },
      dataKey: 'affectedPortfolios',
      width: 14,
      maxWidth: 14,
      className: 'middleAligned',
      headerClassName: 'middleAligned'
    }
  ];
};

export const getPortfoliosColumnDefs = () => [
  {
    headerName: 'Asset ID',
    field: 'assetId'
  },
  {
    headerName: 'Portfolio',
    field: 'portfolioCode',
    cellClass: 'clickableCell',
    onCellClicked: params => {
      const { assetId, clientId } = params.data;
      window.open(`/details/${clientId}/${assetId}`, '_blank');
    }
  },
  {
    headerName: 'Currency',
    field: 'portfolioCcy'
  },
  {
    headerName: 'Strategy',
    field: 'investmentStrategyDesc'
  }
];
