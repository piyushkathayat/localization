import * as R from 'ramda';
import {
  QUALITY_CHECKS,
  UNKNOWN_QUALITY_CHECK,
  QUALITY_CHECKS_LEVELS,
  ALTERNATIVE_LEVEL_LABEL
} from 'constants/qualityCheck';

export const getQualityCheckSettings = type => R.propOr(
  UNKNOWN_QUALITY_CHECK,
  type,
  QUALITY_CHECKS
);

export const isQualityCheckHasAlternativeLevel = qualityCheckLevel =>
  qualityCheckLevel !== QUALITY_CHECKS_LEVELS.PORTFOLIO;

export const getAlternativeLevelLabel = qualityCheckLevel =>
  ALTERNATIVE_LEVEL_LABEL[qualityCheckLevel] || ALTERNATIVE_LEVEL_LABEL.UNKNOWN;

export const newIssuesColor = '#007099';

export const failIssuesColor = '#9a3d37';
