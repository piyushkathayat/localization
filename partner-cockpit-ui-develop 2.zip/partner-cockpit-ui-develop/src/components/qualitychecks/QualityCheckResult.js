import React from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';
import { QualityCheckType } from 'components/Types';
import { NoResults } from 'components/common';
import QualityCheckSummary from './QualityCheckSummary';
import QualityCheckLineGraph from './QualityCheckLineGraph';
import './QualityCheckResult.css';

export default function QualityCheckResult(props) {
  const { qualityCheckList } = props;

  const getSummaryData = qualityCheck => isNonEmptyArray(qualityCheck.data)
    ? R.last(qualityCheck.data)
    : undefined;

  const renderQualityCheckList = () => qualityCheckList.map(qualityCheck => (
    <div className="qcRow" key={qualityCheck.type}>
      <div className="title">
        {qualityCheck.description}
      </div>
      <div className="columnWrapper">
        <div className="qcColumns">
          <div className="left">
            <QualityCheckLineGraph
              qualityCheck={qualityCheck}
            />
          </div>
          <div className="right">
            <QualityCheckSummary
              data={getSummaryData(qualityCheck)}
              qualityCheckLevel={qualityCheck.qualityCheckLevel}
              isFailureEnabled={qualityCheck.isFailureEnabled}
            />
          </div>
        </div>
      </div>
    </div>
  ));

  return (
    <div className="qualityCheckResultContainer">
      {isNonEmptyArray(qualityCheckList)
        ? renderQualityCheckList()
        : <NoResults />
      }
    </div>
  );
}

QualityCheckResult.propTypes = {
  qualityCheckList: PropTypes.arrayOf(QualityCheckType).isRequired
};

QualityCheckResult.defaultProps = {
  qualityCheckList: []
};
