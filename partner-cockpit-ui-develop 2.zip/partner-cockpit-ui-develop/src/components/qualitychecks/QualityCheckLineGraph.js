import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  Line,
  Tooltip,
  CartesianGrid
} from 'recharts';
import moment from 'moment';
import { FormattedMessage, FormattedNumber, defineMessages, injectIntl } from 'react-intl';
import { QualityCheckType } from 'components/Types';
import {
  isQualityCheckHasAlternativeLevel,
  getAlternativeLevelLabel,
  newIssuesColor,
  failIssuesColor
} from './common';
import './QualityCheckLineGraph.css';

const messages = defineMessages({
  total: { id: 'qualityCheck.total', defaultMessage: 'Total' },
  newFail: { id: 'qualityCheck.new_fail', defaultMessage: 'New/Fail' }
});

// Coefficient of margin bars in the graph. 0.2 equals to 20%
const BAR_CATEGORY_GAP = 0.2;
// Coefficient of cursor's width. 1.5 equals to 150% of bar's width
const CURSOR_WIDTH_COEF = 1.5;

function CustomizedCursor(props) {
  const { barsCount, width, height, points = [] } = props;
  const { x, y } = points[0];
  const barWidth = (width / barsCount) * (1 - 2 * BAR_CATEGORY_GAP);
  return (
    <rect
      className="barHover"
      x={x - barWidth * (CURSOR_WIDTH_COEF / 2)}
      y={y}
      width={barWidth * CURSOR_WIDTH_COEF}
      height={height}
    />
  );
}

export function QualityCheckLineGraph(props) {
  const {
    qualityCheck: {
      data: chartData,
      isFailureEnabled,
      qualityCheckLevel
    },
    intl: { formatMessage, formatNumber }
  } = props;

  const barsCount = chartData.length;

  const xAxisFormat = data => moment(data).format('MM-DD');
  const yAxisFormat = data => formatNumber(data);

  const hasAlternativeLevel = isQualityCheckHasAlternativeLevel(qualityCheckLevel);

  const getPortfoliosIssuesBarHeight = data => {
    const { height, alternativeLevelTotalIssues, portfoliosTotalIssues } = data;
    if (alternativeLevelTotalIssues === 0) {
      return 0;
    }
    return (height / alternativeLevelTotalIssues) * portfoliosTotalIssues;
  };

  const renderBar = data => {
    const { x, y, width, height } = data;
    const portfoliosIssuesBarHeight = getPortfoliosIssuesBarHeight(data);
    const portfoliosIssuesBarY = y + (height - portfoliosIssuesBarHeight);
    return (
      <g>
        {hasAlternativeLevel && (
          <rect
            className="alternativeIssuesBar"
            x={x}
            y={y}
            width={width}
            height={height}
          />
        )}
        <rect
          className="portfoliosIssuesBar"
          x={x}
          y={portfoliosIssuesBarY}
          width={width}
          height={portfoliosIssuesBarHeight}
        />
      </g>
    );
  };

  const renderToolTip = data => {
    const { payload = [] } = data;
    if (!payload.length) {
      return null;
    }
    const { payload: qualityCheckData = {} } = payload[0];
    const {
      portfoliosTotalIssues,
      alternativeLevelTotalIssues,
      portfoliosNewIssues,
      portfoliosFailIssues,
      date
    } = qualityCheckData;
    return (
      <div className="customTooltip">
        <div className="tooltipRow">
          <div className="tooltipLabel">
            <FormattedMessage default="New" id="qualityCheck.new" />
          </div>
          <div className="tooltipValue">
            <FormattedNumber value={portfoliosNewIssues} />
          </div>
        </div>
        <div className="tooltipRow">
          <div className="tooltipLabel">
            <FormattedMessage default="Breaching portfolios" id="qualityCheck.breaching_portfolios" />
          </div>
          <div className="tooltipValue">
            <FormattedNumber value={portfoliosTotalIssues} />
          </div>
        </div>
        {hasAlternativeLevel && (
          <div className="tooltipRow">
            <div className="tooltipLabel">
              <FormattedMessage {...getAlternativeLevelLabel(qualityCheckLevel)} />
            </div>
            <div className="tooltipValue">
              <FormattedNumber value={alternativeLevelTotalIssues} />
            </div>
          </div>
        )}
        {isFailureEnabled && (
          <div className="tooltipRow">
            <div className="tooltipLabel">
              <FormattedMessage default="Fail" id="qualityCheck.fail" />
            </div>
            <div className="tooltipValue">
              <FormattedNumber value={portfoliosFailIssues} />
            </div>
          </div>
        )}
        <div className="date">{moment(date).format('LL')}</div>
      </div>
    );
  };

  return (
    <ResponsiveContainer className="qualityCheckGraph" width="100%" height={220}>
      <ComposedChart
        data={chartData}
        margin={{ top: 20 }}
        barCategoryGap={formatNumber(BAR_CATEGORY_GAP, { style: 'percent' })}
      >
        <XAxis
          dataKey="date"
          tickLine={false}
          tickFormatter={xAxisFormat}
        />
        <YAxis
          yAxisId="left"
          orientation="left"
          label={{
            value: formatMessage(messages.total),
            position: 'top',
            offset: 10
          }}
          stroke="#bebebe"
          tickFormatter={yAxisFormat}
        />
        <YAxis
          yAxisId="right"
          orientation="right"
          label={{
            value: formatMessage(messages.newFail),
            position: 'top',
            offset: 10
          }}
          stroke="#bebebe"
          tickFormatter={yAxisFormat}
        />

        <CartesianGrid strokeDasharray="3 3" />

        <Bar
          yAxisId="left"
          dataKey="alternativeLevelTotalIssues"
          shape={renderBar}
          isAnimationActive={false}
        />

        <Line
          dataKey="portfoliosNewIssues"
          type="monotone"
          connectNulls={false}
          stroke={newIssuesColor}
          strokeWidth={2}
          yAxisId="right"
          isAnimationActive={false}
        />
        {isFailureEnabled && (
          <Line
            dataKey="portfoliosFailIssues"
            type="monotone"
            connectNulls={false}
            stroke={failIssuesColor}
            strokeWidth={2}
            yAxisId="right"
            isAnimationActive={false}
          />
        )}

        <Tooltip
          cursor={<CustomizedCursor barsCount={barsCount} />}
          position={{ y: -45 }}
          content={renderToolTip}
        />

      </ComposedChart>
    </ResponsiveContainer>
  );
}

QualityCheckLineGraph.propTypes = {
  qualityCheck: QualityCheckType.isRequired
};

QualityCheckLineGraph.defaultProps = {
  qualityCheck: {}
};

export default injectIntl(QualityCheckLineGraph);
