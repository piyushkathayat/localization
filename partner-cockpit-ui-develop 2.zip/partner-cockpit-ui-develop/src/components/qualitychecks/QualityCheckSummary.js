import React from 'react';
import PropTypes from 'prop-types';
import { FormattedNumber, FormattedMessage } from 'react-intl';
import { QualityCheckDataType } from 'components/Types';
import {
  isQualityCheckHasAlternativeLevel,
  getAlternativeLevelLabel,
  newIssuesColor,
  failIssuesColor
} from './common';
import './QualityCheckSummary.css';

export default function QualityCheckSummary(props) {
  const { data, qualityCheckLevel, isFailureEnabled } = props;

  const hasAlternativeLevel = isQualityCheckHasAlternativeLevel(qualityCheckLevel);

  const renderSvg = (color) => {
    return (
      <svg height="20" className="summaryIcon">
        <line x1="0" y1="10" x2="100" y2="10" strokeWidth="2" stroke={color} />
        <circle cx="25" cy="10" r="4" stroke={color} strokeWidth="2" fill="white" />
      </svg>
    );
  };

  const renderOutOf = value => (
    <span className="outOf">
      {'('}
      <FormattedMessage defaultMessage="out of" id="qualityCheck.out_of" />
      {' '}
      <FormattedNumber value={value} />
      {')'}
    </span>
  );

  return (
    <div className="summaryMenu">
      <div className="summaryRow newIssuesRow">
        {renderSvg(newIssuesColor)}
        <div className="summaryLabel">
          <FormattedMessage defaultMessage="New" id="qualityCheck.new" />
        </div>
        <div className="summaryValue">
          <FormattedNumber value={data.portfoliosNewIssues} />
        </div>
      </div>

      <div className="summaryRow">
        <div className="summaryIcon summaryBar breachingPortfolios" />
        <div className="summaryLabel">
          <FormattedMessage defaultMessage="Breaching portfolios" id="qualityCheck.breaching_portfolios" />
        </div>
        <div className="summaryValue">
          <div className="currentValue">
            <FormattedNumber value={data.portfoliosTotalIssues} />
          </div>
          {renderOutOf(data.maxPortfoliosTotalIssues)}
        </div>
      </div>

      {hasAlternativeLevel && (
        <div className="summaryRow">
          <div className="summaryIcon summaryBar breachingAlternative" />
          <div className="summaryLabel">
            <FormattedMessage {...getAlternativeLevelLabel(qualityCheckLevel)} />
          </div>
          <div className="summaryValue">
            <div className="currentValue">
              <FormattedNumber value={data.alternativeLevelTotalIssues} />
            </div>
            {renderOutOf(data.maxAlternativeLevelTotalIssues)}
          </div>
        </div>
      )}

      {isFailureEnabled && (
        <div className="summaryRow failIssuesRow">
          {renderSvg(failIssuesColor)}
          <div className="summaryLabel">
            <FormattedMessage defaultMessage="Fail" id="qualityCheck.fail" />
          </div>
          <div className="summaryValue">
            <FormattedNumber value={data.portfoliosFailIssues} />
          </div>
        </div>
      )}
    </div>
  );
}

QualityCheckSummary.propTypes = {
  data: QualityCheckDataType.isRequired,
  qualityCheckLevel: PropTypes.number.isRequired,
  isFailureEnabled: PropTypes.bool.isRequired
};

QualityCheckSummary.defaultProps = {
  data: {}
};
