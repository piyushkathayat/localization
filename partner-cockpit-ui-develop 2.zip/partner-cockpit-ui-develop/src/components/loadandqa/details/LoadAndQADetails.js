import React, { PureComponent, Fragment } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';
import { Loader, Breadcrumb } from 'semantic-ui-react';
import { voidFn } from 'utils/common';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import LoadAndQAActions from 'components/loadandqa/actions/LoadAndQAActions';
import LoadAndQADrilldown from 'components/loadandqa/drilldown/LoadAndQADrilldown';
import {
  clearLoadAndQAActions
} from 'actions/loadAndQAActions';
import { getActivityById } from 'selectors/loadAndQA';
import { getActionByDrilldownTypeAndKey } from 'selectors/loadAndQADrilldown';
import { ActivityType, ActionType, EmptyObjectType } from 'components/Types';

const LOAD_AND_QA_DETAILS_LEVELS = {
  ACTIONS: 'ACTIONS',
  DRILLDOWN: 'DRILLDOWN'
};

export class LoadAndQADetails extends PureComponent {
  breadcrumbsLoader = (
    <div className="breadcrumbsLoaderContainer">
      <Loader active inline="centered" size="tiny" />
    </div>
  );

  componentWillUnmount() {
    this.props.clearLoadAndQAActions();
  }

  getBreadcrumbsSections = () => {
    const {
      activity: { activityName = null },
      action: { actionDescription = null },
      match: { params: { id } }
    } = this.props;

    const isActionsLevel = this.getLoadAndQADetailsLevel() === LOAD_AND_QA_DETAILS_LEVELS.ACTIONS;

    const breadcrumbsSections = [
      {
        key: 'Overview',
        content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
        active: false,
        as: Link,
        to: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`
      },
      {
        key: 'Activity',
        content: activityName || this.breadcrumbsLoader,
        active: isActionsLevel,
        as: !isActionsLevel ? Link : undefined,
        to: !isActionsLevel ? `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/${id}` : undefined
      }
    ];

    if (!isActionsLevel) {
      breadcrumbsSections.push({
        key: 'Drilldown',
        content: actionDescription || this.breadcrumbsLoader,
        active: true
      });
    }

    return breadcrumbsSections;
  };

  getLoadAndQADetailsLevel = () => {
    const { match: { params: { drilldownType } } } = this.props;
    if (R.isNil(drilldownType)) {
      return LOAD_AND_QA_DETAILS_LEVELS.ACTIONS;
    }
    return LOAD_AND_QA_DETAILS_LEVELS.DRILLDOWN;
  };

  renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={this.getBreadcrumbsSections()}
    />
  );

  renderContent = () => {
    const level = this.getLoadAndQADetailsLevel();
    return (
      <Fragment>
        {level === LOAD_AND_QA_DETAILS_LEVELS.ACTIONS && <LoadAndQAActions />}
        {level === LOAD_AND_QA_DETAILS_LEVELS.DRILLDOWN && <LoadAndQADrilldown />}
      </Fragment>
    );
  };

  render() {
    return (
      <div className="loadAndQADetailsContainer">
        {this.renderBreadcrumbs()}
        {this.renderContent()}
      </div>
    );
  }
}

LoadAndQADetails.propTypes = {
  activity: PropTypes.oneOfType([ActivityType, EmptyObjectType]).isRequired,
  action: PropTypes.oneOfType([ActionType, EmptyObjectType]).isRequired,
  clearLoadAndQAActions: PropTypes.func.isRequired,
  match: PropTypes.shape({
    params: PropTypes.shape({
      id: PropTypes.string,
      drilldownType: PropTypes.string,
      drilldownKey: PropTypes.string
    }).isRequired
  }).isRequired
};

LoadAndQADetails.defaultProps = {
  activity: {},
  action: {},
  clearLoadAndQAActions: voidFn
};

const mapStateToProps = (state, ownProps) => {
  const { id, drilldownType, drilldownKey } = R.path(['match', 'params'], ownProps);
  return {
    activity: getActivityById(state, id),
    action: getActionByDrilldownTypeAndKey(state, drilldownType, drilldownKey)
  };
};

const mapDispatchToProps = dispatch => bindActionCreators({
  clearLoadAndQAActions
}, dispatch);

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(LoadAndQADetails));
