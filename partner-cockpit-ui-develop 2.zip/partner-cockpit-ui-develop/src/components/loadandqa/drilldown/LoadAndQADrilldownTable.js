import React from 'react';
import PropTypes from 'prop-types';
import { Table } from 'semantic-ui-react';
import { formatGraphData } from 'components/loadandqa/common/util';
import { LineGraph, ExcelLink } from 'components/common';
import { DRILLDOWN_COLUMN_TYPES } from 'constants/loadAndQA';
import { voidFn } from 'utils/common';
import { DrilldownType, ColumnDefsType } from 'components/Types';

export default function LoadAndQADrilldownTable(props) {
  const { columnDefs, drilldowns, onFileFetch } = props;

  const handleFileFetch = drilldownId => () => onFileFetch(drilldownId);

  const renderHeaderCell = columnDef => (
    <Table.HeaderCell key={columnDef.field} textAlign={columnDef.textAlign}>
      {columnDef.header}
    </Table.HeaderCell>
  );

  const renderHeader = () => (
    <Table.Header className="tableHeader activityDetailsTableHeader">
      <Table.Row>
        {columnDefs.map(renderHeaderCell)}
      </Table.Row>
    </Table.Header>
  );

  const renderBodyCell = (columnDef, drilldown) => (
    <Table.Cell
      key={columnDef.field}
      width={columnDef.width}
      textAlign={columnDef.textAlign}
      className={columnDef.className}
    >
      {columnDef.type === DRILLDOWN_COLUMN_TYPES.TEXT && drilldown[columnDef.field]}
      {columnDef.type === DRILLDOWN_COLUMN_TYPES.LINE_GRAPH && (
        <LineGraph chartData={formatGraphData(drilldown[columnDef.field])} />
      )}
      {columnDef.type === DRILLDOWN_COLUMN_TYPES.DOCUMENT_LINK && !!drilldown[columnDef.field] && (
        <ExcelLink
          isLoading={drilldown.isFileLoading}
          onFileFetch={handleFileFetch(drilldown.drilldownId)}
        />
      )}
    </Table.Cell>
  );

  const renderDrilldownRow = drilldown => (
    <Table.Row key={drilldown.drilldownId} className="actionRow">
      {columnDefs.map(columnDef => renderBodyCell(columnDef, drilldown))}
    </Table.Row>
  );

  const renderBody = () => (
    <Table.Body className="tableBody activityDetailsTableBody">
      {drilldowns.map(renderDrilldownRow)}
    </Table.Body>
  );

  return (
    <Table celled className="cockpitTable drilldownTable">
      {renderHeader()}
      {renderBody()}
    </Table>
  );
}

LoadAndQADrilldownTable.propTypes = {
  columnDefs: PropTypes.arrayOf(ColumnDefsType).isRequired,
  drilldowns: PropTypes.arrayOf(DrilldownType).isRequired,
  onFileFetch: PropTypes.func.isRequired
};

LoadAndQADrilldownTable.defaultProps = {
  columnDef: [],
  drilldowns: [],
  onFileFetch: voidFn
};
