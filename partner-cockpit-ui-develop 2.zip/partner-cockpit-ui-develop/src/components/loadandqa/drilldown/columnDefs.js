import React from 'react';
import { FormattedMessage } from 'react-intl';
import { DRILLDOWN_TYPES, DRILLDOWN_COLUMN_TYPES } from 'constants/loadAndQA';

const fileColumnDefs = [
  {
    header: <FormattedMessage defaultMessage="File Name" id="load_and_qa.drilldown.file_name" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'fileName',
    width: 8
  },
  {
    header: <FormattedMessage defaultMessage="File Size" id="load_and_qa.drilldown.file_size" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'fileSize',
    width: 2,
    textAlign: 'right'
  },
  {
    header: <FormattedMessage defaultMessage="Records Count" id="load_and_qa.drilldown.records_count" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'recordCount',
    width: 2,
    textAlign: 'right'
  },
  {
    header: <FormattedMessage defaultMessage="Issue History" id="load_and_qa.issue_history" />,
    type: DRILLDOWN_COLUMN_TYPES.LINE_GRAPH,
    field: 'issueHistory',
    width: 3,
    className: 'issueHistoryGraph'
  },
  {
    header: <FormattedMessage defaultMessage="Details" id="load_and_qa.details" />,
    type: DRILLDOWN_COLUMN_TYPES.DOCUMENT_LINK,
    field: 'hasDetail',
    width: 1,
    textAlign: 'center'
  }
];

const validationColumnDefs = [
  {
    header: <FormattedMessage defaultMessage="Database Name" id="load_and_qa.drilldown.database_name" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'databaseName',
    width: 3
  },
  {
    header: <FormattedMessage defaultMessage="Scheme Name" id="load_and_qa.drilldown.scheme_name" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'schemaName',
    width: 2
  },
  {
    header: <FormattedMessage defaultMessage="Table Name" id="load_and_qa.drilldown.table_name" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'tableName',
    width: 5
  },
  {
    header: <FormattedMessage defaultMessage="Issues" id="load_and_qa.issues" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'invalidRows',
    width: 2,
    textAlign: 'right'
  },
  {
    header: <FormattedMessage defaultMessage="Issue History" id="load_and_qa.issue_history" />,
    type: DRILLDOWN_COLUMN_TYPES.LINE_GRAPH,
    field: 'issueHistory',
    width: 3,
    className: 'issueHistoryGraph'
  },
  {
    header: <FormattedMessage defaultMessage="Details" id="load_and_qa.details" />,
    type: DRILLDOWN_COLUMN_TYPES.DOCUMENT_LINK,
    field: 'hasDetail',
    width: 1,
    textAlign: 'center'
  }
];

const qaColumnDefs = [
  {
    header: <FormattedMessage defaultMessage="QA Check Code" id="load_and_qa.qa_check_code" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'brsCode',
    width: 2
  },
  {
    header: <FormattedMessage defaultMessage="Description" id="load_and_qa.description" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'description',
    width: 8
  },
  {
    header: <FormattedMessage defaultMessage="Issues" id="load_and_qa.issues" />,
    type: DRILLDOWN_COLUMN_TYPES.TEXT,
    field: 'numberOfIssues',
    width: 2,
    textAlign: 'right'
  },
  {
    header: <FormattedMessage defaultMessage="Issue History" id="load_and_qa.issue_history" />,
    type: DRILLDOWN_COLUMN_TYPES.LINE_GRAPH,
    field: 'issueHistory',
    width: 3,
    className: 'issueHistoryGraph'
  },
  {
    header: <FormattedMessage defaultMessage="Details" id="load_and_qa.details" />,
    type: DRILLDOWN_COLUMN_TYPES.DOCUMENT_LINK,
    field: 'hasDetail',
    width: 1,
    textAlign: 'center'
  }
];

export function getColumnDefs(drilldownType) {
  switch (drilldownType) {
    case DRILLDOWN_TYPES.FILE:
      return fileColumnDefs;
    case DRILLDOWN_TYPES.VALIDATION:
      return validationColumnDefs;
    case DRILLDOWN_TYPES.QA:
      return qaColumnDefs;
    default:
      return null;
  }
}
