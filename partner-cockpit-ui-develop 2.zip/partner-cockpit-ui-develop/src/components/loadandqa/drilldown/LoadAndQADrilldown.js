import React, { Fragment, PureComponent } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Loader } from 'semantic-ui-react';
import { ErrorMessage, NoResults } from 'components/common';
import {
  getDrilldowns,
  getDrilldownType,
  getIsLoading,
  getError
} from 'selectors/loadAndQADrilldown';
import {
  clearLoadAndQADrilldown,
  clearError,
  fetchDrilldownFile
} from 'actions/loadAndQADrilldown';
import { DrilldownType } from 'components/Types';
import { getColumnDefs } from './columnDefs';
import LoadAndQADrilldownTable from './LoadAndQADrilldownTable';
import './LoadAndQADrilldown.css';

export class LoadAndQADrilldown extends PureComponent {
  componentWillUnmount() {
    this.props.clearLoadAndQADrilldown();
  }

  renderDrilldownTable = () => {
    const { drilldowns, drilldownType } = this.props;

    return (
      <LoadAndQADrilldownTable
        columnDefs={getColumnDefs(drilldownType)}
        drilldowns={drilldowns}
        onFileFetch={this.props.fetchDrilldownFile}
      />
    );
  };

  renderContent = () => (
    <Fragment>
      {R.isEmpty(this.props.drilldowns)
        ? <NoResults />
        : (
          <div className="drilldownContent">
            {this.renderDrilldownTable()}
          </div>
        )}
    </Fragment>
  );


  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="drilldownContainer">
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

LoadAndQADrilldown.propTypes = {
  drilldowns: PropTypes.arrayOf(DrilldownType).isRequired,
  drilldownType: PropTypes.string.isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  clearError: PropTypes.func.isRequired,
  clearLoadAndQADrilldown: PropTypes.func.isRequired
};

LoadAndQADrilldown.defaultProps = {
  drilldowns: []
};

const mapStateToProps = state => ({
  drilldowns: getDrilldowns(state),
  drilldownType: getDrilldownType(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  fetchDrilldownFile,
  clearLoadAndQADrilldown,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(LoadAndQADrilldown);
