export function formatGraphData(daysList = []) {
  return daysList.map(day => ({
    date: day.activityDate,
    value: day.sumIssues
  }));
}
