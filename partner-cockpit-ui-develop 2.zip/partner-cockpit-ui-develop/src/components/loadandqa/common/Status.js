import React from 'react';
import PropTypes from 'prop-types';
import CircularProgressbar from 'react-circular-progressbar';
import { Popup } from 'semantic-ui-react';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import 'react-circular-progressbar/dist/styles.css';
import './Status.css';

export default function Status(props) {
  const { status, percentage, errorMessage, showErrorPopup } = props;

  const renderErrorIcon = () => (
    <div className="statusIconContainer error">
      <i className="icon-ubs icon-flash" />
    </div>
  );

  const renderErrorPopup = () => (
    <Popup
      className="errorPopup"
      size="large"
      wide
      hoverable
      trigger={renderErrorIcon()}
      content={errorMessage}
      position="bottom center"
    />
  );

  switch (status) {
    case ACTIVITY_STATUSES.FINISHED:
      return (
        <div className="statusIconContainer success">
          <i className="icon-ubs icon-ok" />
        </div>
      );
    case ACTIVITY_STATUSES.ERROR:
      return showErrorPopup
        ? renderErrorPopup()
        : renderErrorIcon();
    case ACTIVITY_STATUSES.RUNNING:
      return (
        <CircularProgressbar
          percentage={percentage}
          strokeWidth={5}
          background
          backgroundPadding={0}
        />
      );
    case ACTIVITY_STATUSES.DELTA:
      return (
        <div className="statusIconContainer delta">
          <i className="icon-ubs icon-flag" />
        </div>
      );
    case ACTIVITY_STATUSES.INIT:
      return (
        <div className="statusIconContainer init" />
      );
    case ACTIVITY_STATUSES.STOPPED:
      return (
        <div className="statusIconContainer stopped">
          <i className="icon-ubs icon-stop" />
        </div>
      );
    case ACTIVITY_STATUSES.WARNING:
      return (
        <div className="statusIconContainer warning">
          <i className="icon-ubs icon-ok" />
        </div>
      );
    default:
      return null;
  }
}

Status.propTypes = {
  status: PropTypes.string.isRequired,
  percentage: PropTypes.number,
  errorMessage: PropTypes.string,
  showErrorPopup: PropTypes.bool
};

Status.defaultProps = {
  showErrorPopup: false
};
