import React, { Fragment } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import { Loader, Table } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { ErrorMessage, NoResults, LineGraph, DateAndTime } from 'components/common';
import Status from 'components/loadandqa/common/Status';
import { formatGraphData } from 'components/loadandqa/common/util';
import {
  getActions,
  getIsLoading,
  getError
} from 'selectors/loadAndQAActions';
import { clearError } from 'actions/loadAndQAActions';
import { ActionType } from 'components/Types';
import './LoadAndQAActions.css';

export function LoadAndQAActions(props) {
  const { actions, isLoading, error, match: { url } } = props;

  const getActionDescription = action => action.drillDownType && action.drillDownKey
    ? (
      <Link
        className="description"
        to={`${url}/${action.drillDownType}/${action.drillDownKey}`}
      >
        {action.actionDescription}
      </Link>
    )
    : action.actionDescription;

  const renderHeader = () => (
    <Table.Header className="tableHeader">
      <Table.Row>
        <Table.HeaderCell textAlign="center">
          <FormattedMessage defaultMessage="Status" id="load_and_qa.status" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Description" id="load_and_qa.description" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Last Run" id="load_and_qa.last_run" />
        </Table.HeaderCell>
        <Table.HeaderCell textAlign="right">
          <FormattedMessage defaultMessage="Issues" id="load_and_qa.issues" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Issue History" id="load_and_qa.issue_history" />
        </Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );

  const renderActionRow = action => (
    <Table.Row key={action.actionId} className="actionRow">
      <Table.Cell width={1} textAlign="center">
        <Status
          status={action.statusCode}
          percentage={action.percentage}
          errorMessage={action.message}
          showErrorPopup
        />
      </Table.Cell>
      <Table.Cell width={7}>
        {getActionDescription(action)}
      </Table.Cell>
      <Table.Cell width={3}>
        {action.endTime && (
          <DateAndTime
            relative
            value={Date.now() - action.elapsedSec * 1000}
          />
        )}
      </Table.Cell>
      <Table.Cell width={2} textAlign="right" className="issuesColumn">
        {action.issues}
      </Table.Cell>
      <Table.Cell width={3} className="issueHistoryGraph">
        <LineGraph
          chartData={formatGraphData(action.issueHistory)}
          styles={{
            width: 230,
            height: 60,
            padding: { top: 10, right: 10, bottom: 10, left: 10 }
          }}
        />
      </Table.Cell>
    </Table.Row>
  );

  const renderBody = () => (
    <Table.Body className="tableBody">
      {actions.map(renderActionRow)}
    </Table.Body>
  );

  const renderDetailsTable = () => (
    <Table celled className="cockpitTable actionsTable">
      {renderHeader()}
      {renderBody()}
    </Table>
  );

  const renderLegend = () => (
    <div className="legend">
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.ERROR} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Error" id="load_and_qa.error" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.FINISHED} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Finished" id="load_and_qa.finished" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.INIT} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Init" id="load_and_qa.init" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.STOPPED} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Stopped" id="load_and_qa.stopped" />
        </span>
      </span>
    </div>
  );

  const renderContent = () => (
    <Fragment>
      {R.isEmpty(actions)
        ? <NoResults />
        : (
          <div className="actionsContent">
            {renderDetailsTable()}
            {renderLegend()}
          </div>
        )}
    </Fragment>
  );

  const renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  const renderError = () => <ErrorMessage message={props.error} onDismiss={props.clearError} />;

  return (
    <div className="loadAndQAActionsContainer">
      {isLoading
        ? renderLoader()
        : renderContent()
      }
      {error !== null && renderError()}
    </div>
  );
}

LoadAndQAActions.propTypes = {
  actions: PropTypes.arrayOf(ActionType),
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string
};

LoadAndQAActions.defaultProps = {
  actions: []
};

const mapStateToProps = state => ({
  actions: getActions(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearError
}, dispatch);

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(LoadAndQAActions));
