import React from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { FormattedMessage } from 'react-intl';
import { Loader, Breadcrumb, Dimmer } from 'semantic-ui-react';
import { voidFn } from 'utils/common';
import { ErrorMessage, NoResults } from 'components/common';
import { DB_TYPES, SERVER_TYPES } from 'constants/serverInfo';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { ActivityType, JobType } from 'components/Types';
import {
  clearError
} from 'actions/loadAndQA';
import {
  getActivitiesByDatabase,
  getIsLoading,
  getError,
  getJobsByDatabase,
  getIsJobStarting
} from 'selectors/loadAndQA';
import { getServerType } from 'selectors/serverInfo';
import Status from '../common/Status';
import ServerTable from './ServerTable';
import './LoadAndQAOverview.css';

export function LoadAndQAOverview(props) {
  const {
    centralDBData,
    partnerDBData,
    isLoading,
    error,
    centralJobs,
    partnerJobs,
    isJobStarting,
    serverType
  } = props;

  const breadcrumbsSections = [
    {
      key: 'Overview',
      content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
      active: true
    }
  ];

  const getPartnerTitle = () => {
    switch (serverType) {
      case SERVER_TYPES.CENTRAL:
        return <FormattedMessage defaultMessage="Data Central" id="load_and_qa.data_central" />;
      case SERVER_TYPES.STAGING:
        return <FormattedMessage defaultMessage="Data Staging" id="load_and_qa.data_staging" />;
      case SERVER_TYPES.SHADOW:
        return <FormattedMessage defaultMessage="Data Shadow" id="load_and_qa.data_shadow" />;
      case SERVER_TYPES.LIVE:
        return <FormattedMessage defaultMessage="Data Live" id="load_and_qa.data_live" />;
      default:
        return undefined;
    }
  };

  const renderLegend = () => (
    <div className="legend">
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.ERROR} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Load failed" id="load_and_qa.status.load_failed" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.FINISHED} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Load passed" id="load_and_qa.status.load_passed" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.WARNING} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Load passed with warnings" id="load_and_qa.status.load_warning" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.DELTA} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Delta review required" id="load_and_qa.status.delta_review" />
        </span>
      </span>
      <span className="legendStatus">
        <Status status={ACTIVITY_STATUSES.STOPPED} />
        <span className="legendStatusLabel">
          <FormattedMessage defaultMessage="Load stopped" id="load_and_qa.status.stopped" />
        </span>
      </span>
    </div>
  );

  const renderDimmer = () => (
    <div className="dimmerContainer">
      <Dimmer active inverted>
        <Loader inline="centered" content="Starting a job..." />
      </Dimmer>
    </div>
  );

  const renderOverviewTables = () => (
    <div className="loadAndQATables">
      {isJobStarting && renderDimmer()}

      {!R.isEmpty(centralDBData) && (
        <ServerTable
          title={<FormattedMessage defaultMessage="Central DB" id="load_and_qa.central_db" />}
          activities={centralDBData}
          dbType={DB_TYPES.CENTRAL}
          jobs={centralJobs}
        />
      )}
      {!R.isEmpty(partnerDBData) && (
        <ServerTable
          title={getPartnerTitle()}
          activities={partnerDBData}
          dbType={DB_TYPES.PARTNER}
          jobs={partnerJobs}
        />
      )}
      {renderLegend()}
    </div>
  );

  const renderContent = () => R.isEmpty(centralDBData) && R.isEmpty(partnerDBData)
    ? <NoResults />
    : renderOverviewTables();

  const renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  const renderError = () => <ErrorMessage message={error} onDismiss={props.clearError} />;

  const renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={breadcrumbsSections}
    />
  );

  return (
    <div className="loadAndQAOverviewContainer">
      {renderBreadcrumbs()}
      {isLoading
        ? renderLoader()
        : renderContent()
      }
      {error !== null && renderError()}
    </div>
  );
}

LoadAndQAOverview.propTypes = {
  centralDBData: PropTypes.arrayOf(ActivityType).isRequired,
  partnerDBData: PropTypes.arrayOf(ActivityType).isRequired,
  partnerJobs: PropTypes.arrayOf(JobType).isRequired,
  centralJobs: PropTypes.arrayOf(JobType).isRequired,
  serverType: PropTypes.string.isRequired,
  isJobStarting: PropTypes.bool.isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string
};

LoadAndQAOverview.defaultProps = {
  centralDBData: [],
  partnerDBData: [],
  partnerJobs: [],
  centralJobs: [],
  isJobStarting: false,
  clearError: voidFn
};

const mapStateToProps = state => ({
  centralDBData: getActivitiesByDatabase(state, DB_TYPES.CENTRAL),
  partnerDBData: getActivitiesByDatabase(state, DB_TYPES.PARTNER),
  partnerJobs: getJobsByDatabase(state, DB_TYPES.PARTNER),
  centralJobs: getJobsByDatabase(state, DB_TYPES.CENTRAL),
  serverType: getServerType(state),
  isJobStarting: getIsJobStarting(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(LoadAndQAOverview);
