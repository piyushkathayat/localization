import React, { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Button, Popup, Table, Dropdown } from 'semantic-ui-react';
import { FormattedMessage, FormattedNumber } from 'react-intl';
import { Link } from 'react-router-dom';
import { DateAndTime, LineGraph, ConfirmModal } from 'components/common';
import { formatGraphData } from 'components/loadandqa/common/util';
import { SERVER_TYPES } from 'constants/serverInfo';
import { ACTIVITY_STATUSES, JOB_ACTION_TYPE } from 'constants/loadAndQA';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import { ActivityType, JobType } from 'components/Types';
import { startJob, stopJob } from 'actions/loadAndQA';
import { getServerType } from 'selectors/serverInfo';
import Status from '../common/Status';
import './ServerTable.css';

export class ServerTable extends PureComponent {
  state = {
    selectedJob: '',
    isConfirmationVisible: false,
    jobType: ''
  };

  isCentralServer = () => {
    const { serverType } = this.props;
    return serverType === SERVER_TYPES.CENTRAL;
  };

  getPopupRow = (label, value) => (
    <div className="popupRow">
      <div className="label">
        {label}:
      </div>
      <div className="value">
        {value}
      </div>
    </div>
  );

  getPopupContent = activity => (
    <span>
      {this.getPopupRow(
        <FormattedMessage defaultMessage="Number of runs" id="load_and_qa.popup.number_of_runs" />,
        activity.activityInstance
      )}
      {this.getPopupRow(
        <FormattedMessage defaultMessage="Started" id="load_and_qa.popup.started" />,
        <DateAndTime value={activity.startTime} hour="numeric" minute="numeric" />
      )}
      {activity.endTime && this.getPopupRow(
        <FormattedMessage defaultMessage="Ended" id="load_and_qa.popup.ended" />,
        <DateAndTime value={activity.endTime} hour="numeric" minute="numeric" />
      )}
      {this.getPopupRow(
        <FormattedMessage defaultMessage="Scheduled load" id="load_and_qa.popup.scheduled_load" />,
        activity.scheduledFrequency ? activity.scheduledFrequency : <FormattedMessage defaultMessage="Not scheduled" id="load_and_qa.popup.no_scheduled_load" />
      )}
      {activity.hasFeedAgeCheck && this.getPopupRow(
        <FormattedMessage defaultMessage="Feed date" id="load_and_qa.popup.youngest_feed_date" />,
        <DateAndTime value={activity.feedAgeDate} hour="numeric" minute="numeric" />
      )}
    </span>
  );

  showConfirmation = jobType => () => {
    this.setState({
      isConfirmationVisible: true,
      jobType
    });
  };

  handleYesConfirmation = () => {
    const { selectedJob, jobType } = this.state;
    const { dbType: database } = this.props;

    if (jobType === JOB_ACTION_TYPE.START) {
      this.props.startJob(selectedJob, database);
    } else {
      this.props.stopJob(selectedJob, database);
    }

    this.setState({
      isConfirmationVisible: false,
      jobType: '',
      selectedJob: ''
    });
  };

  getJobsDropdownOptions = () => this.props.jobs.map(job => ({
    text: job.value,
    value: job.key
  }));

  handleDropDownChange = (event, data) =>
    this.setState({ selectedJob: data.value });

  handleCancel = () => this.setState({ isConfirmationVisible: false });

  renderHeader = () => (
    <Table.Header className="tableHeader serverTableHeader">
      <Table.Row>
        <Table.HeaderCell width={1} textAlign="center">
          <FormattedMessage defaultMessage="Status" id="load_and_qa.status" />
        </Table.HeaderCell>
        <Table.HeaderCell width={3}>
          <FormattedMessage defaultMessage="Name" id="load_and_qa.name" />
        </Table.HeaderCell>
        <Table.HeaderCell width={2}>
          <FormattedMessage defaultMessage="Last Run" id="load_and_qa.last_run" />
        </Table.HeaderCell>
        <Table.HeaderCell width={2} textAlign="right">
          <FormattedMessage defaultMessage="Issues / Warnings" id="load_and_qa.issues_warnings" />
        </Table.HeaderCell>
        <Table.HeaderCell width={3} textAlign="center">
          <FormattedMessage defaultMessage="Issue History" id="load_and_qa.issue_history" />
        </Table.HeaderCell>
        {!this.isCentralServer() &&
          (
            <Table.HeaderCell width={5} textAlign="center">
              <FormattedMessage defaultMessage="Selection" id="load_and_qa.selection" />
            </Table.HeaderCell>
          )
        }
      </Table.Row>
    </Table.Header>
  );

  isAnyFeedCheckViolated = activity =>
    activity.isFeedAgeCheckViolated || activity.isOutdatedCheckViolated;

  resolveStatusCode = activity => {
    if (activity.statusCode === ACTIVITY_STATUSES.FINISHED
        && this.isAnyFeedCheckViolated(activity)) {
      return ACTIVITY_STATUSES.WARNING;
    }
    return activity.statusCode;
  };

  renderActivityRow = activity => (
    <Table.Row key={activity.id} className="activityRow">
      <Table.Cell textAlign="center">
        <Status
          status={this.resolveStatusCode(activity)}
          percentage={activity.percentage}
          errorMessage={activity.message}
          showErrorPopup
        />
      </Table.Cell>
      <Table.Cell>
        <Popup
          className="activityPopup"
          basic
          flowing
          trigger={(
            <Link
              className="nameTitle"
              to={`/${APP_PREFIX}/${MENU_ITEMS.LOAD}/${activity.id}`}
            >
              {activity.activityName}
            </Link>
          )}
          content={this.getPopupContent(activity)}
          position="bottom center"
        />
      </Table.Cell>
      <Table.Cell>
        {activity.endTime && (
          <DateAndTime
            relative
            value={Date.now() - activity.elapsedSec * 1000}
          />
        )}
      </Table.Cell>
      <Table.Cell textAlign="right">
        <FormattedNumber value={activity.issues} />
      </Table.Cell>
      <Table.Cell textAlign="center" className="issueHistoryGraph">
        <LineGraph chartData={formatGraphData(activity.issueHistory)} />
      </Table.Cell>
      {!this.isCentralServer() && <Table.Cell />}
    </Table.Row>
  );

  renderBody = () => {
    const { activities } = this.props;
    return (
      <Table.Body className="tableBody serverTableBody">
        {activities.map(this.renderActivityRow)}
      </Table.Body>
    );
  };

  renderTitle = () => (
    <div className="title">
      {this.props.title}
    </div>
  );

  renderTable = () => (
    <Table fixed celled className="cockpitTable serverTable">
      {this.renderHeader()}
      {this.renderBody()}
    </Table>
  );

  renderFooter = () => {
    const { selectedJob } = this.state;
    return (
      <div className="footer">
        <Dropdown
          className="jobsDropdown"
          placeholder="Select a job"
          selection
          selectOnBlur={false}
          selectOnNavigation={false}
          options={this.getJobsDropdownOptions()}
          onChange={this.handleDropDownChange}
          value={selectedJob}
        />
        <Button
          className="ubs-primary-button"
          disabled={!selectedJob}
          onClick={this.showConfirmation(JOB_ACTION_TYPE.START)}
        >
          <FormattedMessage
            defaultMessage="Start"
            id="load_and_qa.jobs.start"
          />
        </Button>
        <Button
          className="ubs-secondary-button"
          disabled={!selectedJob}
          onClick={this.showConfirmation(JOB_ACTION_TYPE.STOP)}
        >
          <FormattedMessage
            defaultMessage="Stop"
            id="load_and_qa.jobs.stop"
          />
        </Button>
      </div>
    );
  };

  renderConfirmation = () => (
    <ConfirmModal
      onCancel={this.handleCancel}
      onConfirm={this.handleYesConfirmation}
    />
  );

  render() {
    const { isConfirmationVisible } = this.state;
    return (
      <div className="serverTableContainer">
        {this.renderTitle()}
        <Fragment>
          {this.renderTable()}
          {this.renderFooter()}
        </Fragment>
        {isConfirmationVisible && this.renderConfirmation()}
      </div>
    );
  }
}

ServerTable.propTypes = {
  title: PropTypes.element.isRequired,
  dbType: PropTypes.string.isRequired,
  activities: PropTypes.arrayOf(ActivityType).isRequired,
  jobs: PropTypes.arrayOf(JobType).isRequired,
  serverType: PropTypes.string.isRequired
};

ServerTable.defaultProps = {
  title: '',
  dbType: '',
  activities: [],
  jobs: []
};

const mapStateToProps = state => ({
  serverType: getServerType(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  startJob,
  stopJob
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(ServerTable);
