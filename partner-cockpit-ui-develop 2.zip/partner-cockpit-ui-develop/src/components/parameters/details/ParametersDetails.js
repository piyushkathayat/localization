import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { voidFn } from 'utils/common';
import { Loader } from 'semantic-ui-react';
import { ErrorMessage, TablesList } from 'components/common';
import {
  getFilteredTablesList,
  getIsLoading,
  getError
} from 'selectors/parametersDetails';
import { clearParametersDetails, clearError } from 'actions/parametersDetails';
import { TableType } from 'components/Types';
import ParametersDetailsStatus from './ParametersDetailsStatus';
import './ParametersDetails.css';

export class ParametersDetails extends PureComponent {
  componentWillUnmount() {
    this.props.clearParametersDetails();
  }

  renderContent = () => {
    const { tablesList, feedName } = this.props;
    return (
      <div className="parametersDetailsContent">
        <TablesList tablesList={tablesList} />
        <ParametersDetailsStatus feedName={feedName} />
      </div>
    );
  }

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="parametersDetailsContainer">
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

ParametersDetails.propTypes = {
  feedName: PropTypes.string.isRequired,
  tablesList: PropTypes.arrayOf(TableType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  clearParametersDetails: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

ParametersDetails.defaultProps = {
  tablesList: [],
  isLoading: false,
  clearParametersDetails: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  tablesList: getFilteredTablesList(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearParametersDetails,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(ParametersDetails);
