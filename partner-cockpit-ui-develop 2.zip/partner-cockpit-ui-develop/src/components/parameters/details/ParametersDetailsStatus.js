import React from 'react';
import PropTypes from 'prop-types';
import ParameterStatus from '../common/ParameterStatus';
import './ParametersDetailsStatus.css';

export default function ParametersDetailsStatus(props) {
  const { feedName } = props;
  return (
    <div className="parametersDetailsStatus">
      <ParameterStatus feedName={feedName} isParametersDetails />
    </div>
  );
}

ParametersDetailsStatus.propTypes = {
  feedName: PropTypes.string.isRequired
};
