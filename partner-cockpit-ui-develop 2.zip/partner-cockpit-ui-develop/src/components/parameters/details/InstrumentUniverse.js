import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { voidFn } from 'utils/common';
import { Loader, Dimmer } from 'semantic-ui-react';
import { PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE } from 'constants/parameters';
import { ErrorMessage, PaginationBar, AgGridTable } from 'components/common';
import { InstrumentUniverseType } from 'components/Types';
import { changePage, clearParametersUniverse, clearError } from 'actions/parametersUniverse';
import {
  getInstrumentsList,
  getTotalCount,
  getCurrentPage,
  getIsLoading,
  getIsUpdating,
  getError
} from 'selectors/parametersUniverse';
import ParametersDetailsStatus from './ParametersDetailsStatus';
import './InstrumentUniverse.css';

export class InstrumentUniverse extends PureComponent {
  componentWillUnmount() {
    this.props.clearParametersUniverse();
  }

  renderInstrumentsTable = () => {
    const { instrumentsList } = this.props;
    return (
      <AgGridTable
        className="parametersUniverseGrid"
        tableData={instrumentsList}
        enableFilter={false}
        hasFixedHeight
      />
    );
  };

  renderPagination = () => {
    const { currentPage, totalCount } = this.props;
    const totalPages = Math.ceil(totalCount / PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE);
    return (
      <div className="parametersUniversePagination">
        <PaginationBar
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={this.props.changePage}
        />
      </div>
    );
  };

  renderCheckOutStatus = () => {
    const { feedName } = this.props;
    return <ParametersDetailsStatus feedName={feedName} />;
  }

  renderUpdater = () => (
    <div className="updaterContainer">
      <Dimmer active inverted>
        <Loader inline="centered" content="Updating" />
      </Dimmer>
    </div>
  );

  renderContent = () => (
    <div className="parametersUniverseContent">
      {this.renderInstrumentsTable()}
      {this.renderPagination()}
      {this.renderCheckOutStatus()}
    </div>
  );

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { isLoading, isUpdating, error } = this.props;
    return (
      <div className="parametersUniverseContainer">
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
        {isUpdating && this.renderUpdater()}
      </div>
    );
  }
}

InstrumentUniverse.propTypes = {
  feedName: PropTypes.string.isRequired,
  instrumentsList: PropTypes.arrayOf(InstrumentUniverseType).isRequired,
  totalCount: PropTypes.number.isRequired,
  currentPage: PropTypes.number.isRequired,
  isLoading: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  error: PropTypes.string,
  changePage: PropTypes.func.isRequired,
  clearParametersUniverse: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

InstrumentUniverse.defaultProps = {
  instrumentsList: [],
  clearParametersUniverse: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  instrumentsList: getInstrumentsList(state),
  totalCount: getTotalCount(state),
  currentPage: getCurrentPage(state),
  isLoading: getIsLoading(state),
  isUpdating: getIsUpdating(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  changePage,
  clearParametersUniverse,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(InstrumentUniverse);
