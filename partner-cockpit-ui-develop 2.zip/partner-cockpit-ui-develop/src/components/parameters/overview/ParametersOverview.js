import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Grid, Loader } from 'semantic-ui-react';
import { CheckoutStatusType } from 'components/Types';
import { NoResults, ErrorMessage } from 'components/common';
import { voidFn } from 'utils/common';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';
import {
  getParametersList,
  getIsLoading,
  getError
} from 'selectors/parameters';
import ParameterTile from './ParameterTile';
import './ParametersOverview.css';

export class ParametersOverview extends PureComponent {
  renderParametersTable = () => {
    const { parametersList, onParameterTileClick } = this.props;
    return (
      <Grid columns={4} className="parametersTable">
        <Grid.Row>
          {parametersList.map(parameter => (
            <Grid.Column key={parameter.feedName}>
              <ParameterTile
                feedName={parameter.feedName}
                isUpdating={parameter.isUpdating}
                onTileClick={onParameterTileClick}
              />
            </Grid.Column>
          ))}
        </Grid.Row>
      </Grid>
    );
  };

  renderContent = () => {
    const { parametersList } = this.props;
    return isNonEmptyArray(parametersList)
      ? this.renderParametersTable()
      : <NoResults />;
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="parametersOverviewContainer">
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

ParametersOverview.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  parametersList: PropTypes.arrayOf(CheckoutStatusType).isRequired,
  onParameterTileClick: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

ParametersOverview.defaultProps = {
  isLoading: false,
  parametersList: [],
  onParameterTileClick: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  isLoading: getIsLoading(state),
  error: getError(state),
  parametersList: getParametersList(state)
});

export default connect(mapStateToProps, null)(ParametersOverview);
