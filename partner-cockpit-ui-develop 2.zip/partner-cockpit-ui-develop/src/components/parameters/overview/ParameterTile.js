import React from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { Loader, Dimmer } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { PARAMETERS } from 'constants/parameters';
import { voidFn } from 'utils/common';
import ParameterStatus from '../common/ParameterStatus';
import './ParameterTile.css';

export default function ParameterTile(props) {
  const { feedName, isUpdating, onTileClick } = props;

  const formattedFeedName = R.pathOr(
    null,
    [feedName, 'title'],
    PARAMETERS
  );

  const handleTileClick = () => onTileClick(feedName);

  const renderParameterName = () => (
    <div className="parameterName">
      {formattedFeedName
        ? <FormattedMessage {...formattedFeedName} />
        : feedName
      }
    </div>
  );

  const renderUpdater = () => (
    <div className="updaterContainer">
      <Dimmer active inverted>
        <Loader inline="centered" content="Updating" />
      </Dimmer>
    </div>
  );

  return (
    <div className="parameterTileContainer" onClick={handleTileClick}>
      {renderParameterName()}
      <ParameterStatus feedName={feedName} />
      {isUpdating && renderUpdater()}
    </div>
  );
}

ParameterTile.propTypes = {
  feedName: PropTypes.string.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  onTileClick: PropTypes.func.isRequired
};

ParameterTile.defaultProps = {
  isUpdating: false,
  onTileClick: voidFn
};
