import React, { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { FormattedMessage } from 'react-intl';
import { Button } from 'semantic-ui-react';
import { PARAMETERS_STATUSES, PARAMETERS_TYPES } from 'constants/parameters';
import { SERVER_TYPES } from 'constants/serverInfo';
import { DateAndTime } from 'components/common';
import { ParameterTileType } from 'components/Types';
import { feedCheckIn, feedCheckOut, feedCancel } from 'actions/parameters';
import { getLoggedInUser, getServerType } from 'selectors/serverInfo';
import { getParameterTile } from 'selectors/parameters';

export class ParameterStatus extends PureComponent {
  isButtonsDisabled = () =>
    this.props.serverType !== SERVER_TYPES.STAGING || this.props.parameter.isUpdating;

  isReferenceFeed = () => this.props.feedName === PARAMETERS_TYPES.REFERENCE_PORTFOLIOS;

  handleCheckInClick = e => {
    e.stopPropagation();
    this.fileInput.click();
  }

  handleFileCheckIn = event => {
    const file = event.target.files[0];
    this.props.feedCheckIn(this.props.feedName, file);
  };

  handleCheckOutClick = e => {
    e.stopPropagation();
    this.props.feedCheckOut(this.props.feedName);
  }

  handleCancelClick = e => {
    e.stopPropagation();
    this.props.feedCancel(this.props.feedName);
  }

  renderCancelButton = () => (
    <Button
      className="statusButton ubs-secondary-button"
      disabled={this.isButtonsDisabled()}
      onClick={this.handleCancelClick}
    >
      <div className="label">
        <FormattedMessage id="parameters.overview.cancel" defaultMessage="Cancel" />
      </div>
    </Button>
  );

  renderCheckInButton = () => (
    <Button
      className="statusButton ubs-tertiary-button"
      onClick={this.handleCheckInClick}
      disabled={this.isButtonsDisabled()}
    >
      <div className="label">
        <FormattedMessage id="parameters.overview.check_in" defaultMessage="Check In" />
      </div>
      <input
        className="hidden"
        type="file"
        onChange={this.handleFileCheckIn}
        ref={fileInput => {
          this.fileInput = fileInput;
        }}
      />
    </Button>
  );

  renderCheckInButtons = () => {
    const { parameter: { lastUpdatedBy }, loggedInUser } = this.props;
    return (
      <Fragment>
        {this.renderCancelButton()}
        {lastUpdatedBy === loggedInUser && this.renderCheckInButton()}
      </Fragment>
    );
  }

  renderCheckOutButton = () => (
    <Button
      className="statusButton ubs-primary-button"
      disabled={this.isButtonsDisabled() || this.isReferenceFeed()}
      onClick={this.handleCheckOutClick}
    >
      <div className="label">
        <FormattedMessage id="parameters.overview.check_out" defaultMessage="Check Out" />
      </div>
    </Button>
  );

  renderButtons = () => {
    const { parameter: { status } } = this.props;
    return (
      <div className="parameterButtons">
        {status === PARAMETERS_STATUSES.CHECKED_IN
          ? this.renderCheckOutButton()
          : this.renderCheckInButtons()
        }
      </div>
    );
  };

  renderUpdatedBy = () => {
    const { parameter: { lastUpdatedBy }, loggedInUser, isParametersDetails } = this.props;
    if (!lastUpdatedBy && !isParametersDetails) {
      return null;
    }
    return (
      <div className="updatedBy">
        {isParametersDetails
          ? <i className="icon-ubs icon-user statusInfoIcon" />
          : (
            <Fragment>
              <FormattedMessage id="parameters.overview.by" defaultMessage="By" />
              {' '}
            </Fragment>
          )
        }
        {lastUpdatedBy === loggedInUser
          ? <FormattedMessage id="parameters.overview.you" defaultMessage="You" />
          : lastUpdatedBy || '-'
        }
      </div>
    );
  }

  renderUpdatedAt = () => {
    const { parameter: { lastUpdatedAt }, isParametersDetails } = this.props;
    return (
      <div className="updatedAt">
        {isParametersDetails && <i className="icon-ubs icon-calendar statusInfoIcon" />}
        {lastUpdatedAt
          ? (
            <DateAndTime
              value={lastUpdatedAt}
              hour="numeric"
              minute="numeric"
            />
          )
          : '-'
        }
      </div>
    );
  }

  renderStatus = () => {
    const { parameter: { status } } = this.props;
    return (
      <div className="status">
        {status === PARAMETERS_STATUSES.CHECKED_IN
          ? <FormattedMessage id="parameters.overview.checked_in" defaultMessage="Checked In" />
          : <FormattedMessage id="parameters.overview.checked_out" defaultMessage="Checked Out" />
        }
      </div>
    );
  }

  render() {
    return (
      <Fragment>
        <div className="parameterStatus">
          {this.renderStatus()}
          {this.renderUpdatedAt()}
          {this.renderUpdatedBy()}
        </div>
        {this.renderButtons()}
      </Fragment>
    );
  }
}

ParameterStatus.propTypes = {
  feedName: PropTypes.string.isRequired,
  parameter: ParameterTileType.isRequired,
  serverType: PropTypes.string.isRequired,
  loggedInUser: PropTypes.string.isRequired,
  isParametersDetails: PropTypes.bool,
  feedCheckIn: PropTypes.func.isRequired,
  feedCheckOut: PropTypes.func.isRequired,
  feedCancel: PropTypes.func.isRequired
};

ParameterStatus.defaultProps = {
  parameter: {},
  isParametersDetails: false
};

const mapStateToProps = (state, ownProps) => ({
  parameter: getParameterTile(state, ownProps.feedName),
  loggedInUser: getLoggedInUser(state),
  serverType: getServerType(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  feedCheckIn,
  feedCheckOut,
  feedCancel
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(ParameterStatus);
