import React, { PureComponent } from 'react';
import * as R from 'ramda';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Table, Button } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { PromotionDatabaseType, DependencyType } from 'components/Types';
import PropTypes from 'prop-types';
import { DateAndTime, ReasonModal, ConfirmModal } from 'components/common';
import {
  getPromotionDatabases,
  getIsPromotionRunning,
  getLastPromotion,
  getDependencies,
  getCanPromote
} from 'selectors/promotion';
import { updateDatabases, promoteToLiveDB } from 'actions/promotion';
import PromotionTableRow from 'components/promotion/PromotionTableRow';
import { MODAL_TYPES } from 'constants/common';
import './PromotionTable.css';

export class PromotionTable extends PureComponent {
  state = {
    openModal: null,
    openConfirm: false,
    selectedDatabaseId: null
  };

  getSelectedDatabase = () => this.props.databases[this.state.selectedDatabaseId];

  getDependents = databaseId => R.propOr(
    [],
    'dependents',
    R.find(
      dependency => dependency.databaseId === databaseId,
      this.props.dependencies
    )
  );

  getDependenciesIds = databaseId => {
    const dependenciesIds = [];
    let dependents = this.getDependents(databaseId);
    while (R.length(dependents)) {
      dependents.forEach(dependent => {
        if (!dependenciesIds.includes(dependent)) {
          dependenciesIds.push(dependent);
        }
      });
      dependents = this.getDependents(dependents[0]);
    }
    return dependenciesIds;
  };

  getDependentDatabases = database => {
    const { databases } = this.props;
    const dependentDatabaseIds = this.getDependenciesIds(database.id);
    return dependentDatabaseIds.map(databaseId => databases[databaseId]);
  };

  getDependentsNames = database => R.compose(
    R.join(', '),
    R.pluck('name'),
    this.getDependentDatabases
  )(database);

  getModalProps = () => {
    const { openModal } = this.state;
    const database = this.getSelectedDatabase();
    switch (openModal) {
      case MODAL_TYPES.PROMOTE_DATABASE:
        return {
          firstTextVariable: database.name,
          onSubmit: this.handlePromoteDatabase
        };
      case MODAL_TYPES.DEMOTE_DATABASE:
        return {
          firstTextVariable: database.name,
          secondTextVariable: this.getDependentsNames(database),
          onSubmit: this.handleDemoteDatabase
        };
      case MODAL_TYPES.EDIT_COMMENT:
        return {
          confirmedBy: database.confirmedBy,
          explanationText: database.comment,
          onSubmit: this.handleEditComment
        };
      default:
        return null;
    }
  };

  isMainDataLoadRunning = () => Object.values(this.props.databases)
    .some(database => !database.internalKey);

  isAnyDatabaseSelected = () => Object.values(this.props.databases)
    .some(database => database.isPreselected);

  isPromoteButtonDisabled = () => this.props.isPromotionRunning
    || this.isMainDataLoadRunning()
    || !this.props.canPromote
    || !this.isAnyDatabaseSelected();

  handlePromoteDatabase = ({ confirmedBy, explanationText }) => {
    const database = this.getSelectedDatabase();
    const updatedDatabase = {
      ...database,
      isDirty: true,
      isPreselected: true,
      oldComment: database.comment,
      oldConfirmedBy: database.confirmedBy,
      oldInfo: database.info,
      comment: explanationText,
      confirmedBy,
      info: ''
    };
    this.props.updateDatabases([updatedDatabase]);
    this.handleModalClose();
  };

  handleDemoteDatabase = ({ confirmedBy, explanationText }) => {
    const database = this.getSelectedDatabase();
    const updatedDatabase = {
      ...database,
      isDirty: true,
      isPreselected: false,
      oldComment: database.comment,
      oldConfirmedBy: database.confirmedBy,
      oldInfo: database.info,
      comment: explanationText,
      confirmedBy,
      info: ''
    };
    const dependentDatabases = this.getDependentDatabases(database);
    const updatedDependentDatabases = dependentDatabases.map(dependentDatabase => ({
      ...dependentDatabase,
      isDirty: true,
      isPreselected: false,
      oldComment: dependentDatabase.comment,
      oldConfirmedBy: dependentDatabase.confirmedBy,
      oldInfo: dependentDatabase.info,
      comment: explanationText,
      confirmedBy,
      info: ''
    }));
    this.props.updateDatabases(R.prepend(updatedDatabase, updatedDependentDatabases));
    this.handleModalClose();
  };

  handleRevertChanges = database => {
    const updatedDatabase = {
      ...database,
      isDirty: false,
      isPreselected: !database.isPreselected,
      comment: database.oldComment,
      confirmedBy: database.oldConfirmedBy,
      info: database.oldInfo,
      oldComment: undefined,
      oldConfirmedBy: undefined,
      oldInfo: undefined
    };
    this.props.updateDatabases([updatedDatabase]);
  };

  handleEditComment = ({ confirmedBy, explanationText }) => {
    const database = this.getSelectedDatabase();
    const updatedDatabase = {
      ...database,
      comment: explanationText,
      confirmedBy
    };
    this.props.updateDatabases([updatedDatabase]);
    this.handleModalClose();
  };

  handleChange = (database, checked) => this.handleModalOpen(
    checked ? MODAL_TYPES.PROMOTE_DATABASE : MODAL_TYPES.DEMOTE_DATABASE,
    database.id
  );

  handleCheckboxChange = database => checked => database.isDirty
    ? this.handleRevertChanges(database)
    : this.handleChange(database, checked);

  handleEditCommentClick = database => () => this.handleModalOpen(
    MODAL_TYPES.EDIT_COMMENT,
    database.id
  );

  handleConfirmSubmit = () => {
    this.props.promoteToLiveDB(Object.values(this.props.databases));
    this.handleConfirmClose();
  };

  handleConfirmOpen = () => this.setState({
    openConfirm: true
  });

  handleConfirmClose = () => this.setState({
    openConfirm: false
  });

  handleModalOpen = (modalType, databaseId) => this.setState({
    openModal: modalType,
    selectedDatabaseId: databaseId
  });

  handleModalClose = () => this.setState({
    openModal: null,
    selectedDatabaseId: null
  });

  renderLastPromoted = () => {
    const { lastPromotion } = this.props;
    return lastPromotion && (
      <div className="lastPromotedDate">
        <FormattedMessage
          id="promotion.last_promotion"
          defaultMessage="Last promotion: "
        />
        <DateAndTime value={lastPromotion} hour="numeric" minute="numeric" />
      </div>
    );
  };

  renderPromoteButton = () => (
    <Button
      className="ubs-primary-button promoteButton"
      floated="right"
      size="small"
      loading={this.props.isPromotionRunning}
      disabled={this.isPromoteButtonDisabled()}
      onClick={this.handleConfirmOpen}
    >
      <FormattedMessage defaultMessage="Promote" id="promotion.promote" />
    </Button>
  );

  renderHeader = () => (
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell />
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Name" id="promotion.name" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Source" id="promotion.source" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Creation date" id="promotion.creation_date" />
        </Table.HeaderCell>
        <Table.HeaderCell textAlign="center">
          <FormattedMessage defaultMessage="Marked" id="promotion.marked" />
        </Table.HeaderCell>
        <Table.HeaderCell textAlign="center">
          <FormattedMessage defaultMessage="Live DB" id="promotion.live_db" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Comment" id="promotion.comment" />
        </Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );

  renderBody = () => {
    const { databases, isPromotionRunning } = this.props;
    return (
      <Table.Body>
        {Object.values(databases).map(database => (
          <PromotionTableRow
            key={database.id}
            database={database}
            isPromotionRunning={isPromotionRunning}
            onCheckboxChange={this.handleCheckboxChange(database)}
            onEditComment={this.handleEditCommentClick(database)}
          />
        ))}
      </Table.Body>
    );
  }

  renderFooter = () => (
    <Table.Footer fullWidth>
      <Table.Row>
        <Table.HeaderCell colSpan={7}>
          <div className="footerCell">
            {this.renderLastPromoted()}
            {this.renderPromoteButton()}
          </div>
        </Table.HeaderCell>
      </Table.Row>
    </Table.Footer>
  );

  renderTable = () => (
    <Table celled className="databases">
      {this.renderHeader()}
      {this.renderBody()}
      {this.renderFooter()}
    </Table>
  );

  renderModal = () => {
    const { openModal } = this.state;
    return (
      <ReasonModal
        type={openModal}
        isOpen
        onClose={this.handleModalClose}
        {...this.getModalProps()}
      />
    );
  };

  renderConfirmation = () => (
    <ConfirmModal
      onCancel={this.handleConfirmClose}
      onConfirm={this.handleConfirmSubmit}
    />
  );

  render() {
    const { openModal, openConfirm } = this.state;
    return (
      <div className="promotionTableContainer">
        {this.renderTable()}
        {openModal && this.renderModal()}
        {openConfirm && this.renderConfirmation()}
      </div>
    );
  }
}

PromotionTable.propTypes = {
  databases: PropTypes.objectOf(PromotionDatabaseType).isRequired,
  dependencies: PropTypes.arrayOf(DependencyType).isRequired,
  isPromotionRunning: PropTypes.bool.isRequired,
  canPromote: PropTypes.bool.isRequired,
  lastPromotion: PropTypes.string,
  updateDatabases: PropTypes.func.isRequired,
  promoteToLiveDB: PropTypes.func.isRequired
};

PromotionTable.defaultProps = {
  databases: {},
  dependencies: [],
  isPromotionRunning: false
};

const mapStateToProps = state => ({
  databases: getPromotionDatabases(state),
  isPromotionRunning: getIsPromotionRunning(state),
  lastPromotion: getLastPromotion(state),
  dependencies: getDependencies(state),
  canPromote: getCanPromote(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  updateDatabases,
  promoteToLiveDB
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(PromotionTable);
