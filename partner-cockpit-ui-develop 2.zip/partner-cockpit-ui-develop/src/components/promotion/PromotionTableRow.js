import React from 'react';
import PropTypes from 'prop-types';
import { Table, Icon, Checkbox, Popup } from 'semantic-ui-react';
import { PromotionDatabaseType } from 'components/Types';
import { voidFn } from 'utils/common';
import { DateAndTime } from 'components/common';
import DatabaseCommentPopup from 'components/promotion/DatabaseCommentPopup';
import './PromotionTableRow.css';

export default function PromotionTableRow(props) {
  const { database, isPromotionRunning, onCheckboxChange, onEditComment } = props;

  const isDatabaseDisabledFromPromotion = () => isPromotionRunning
    || database.isPromotedToLive
    || !database.isUsedInLoadOnStaging;

  const renderInfo = () => (
    <div className="comment">{database.info}</div>
  );

  const renderComment = () => (
    <Popup
      key={database.id}
      wide
      hoverable
      trigger={<div className="comment">{database.comment}</div>}
      content={<DatabaseCommentPopup database={database} />}
    />
  );

  const renderEditComment = () => (
    <i className="icon-ubs icon-edit editCommentIcon" onClick={onEditComment} />
  );

  return (
    <Table.Row key={database.id} className="promotionTableRowContainer">
      <Table.Cell textAlign="center">
        <Checkbox
          disabled={isDatabaseDisabledFromPromotion()}
          onChange={(event, { checked }) => onCheckboxChange(checked)}
          checked={database.isPreselected}
        />
      </Table.Cell>
      <Table.Cell>
        {database.name}
      </Table.Cell>
      <Table.Cell>
        {database.source}
      </Table.Cell>
      <Table.Cell
        className={database.isOldDatabase ? 'oldDatabase' : ''}
      >
        {database.creationDate && <DateAndTime value={database.creationDate} />}
      </Table.Cell>
      <Table.Cell textAlign="center">
        <Icon
          size="large"
          name={database.isMarkedForPromotion ? 'check circle outline' : 'circle outline'}
        />
      </Table.Cell>
      <Table.Cell textAlign="center">
        <Icon
          size="large"
          name={database.isPromotedToLive ? 'check circle outline' : 'circle outline'}
        />
      </Table.Cell>
      <Table.Cell width={6}>
        <div className="commentColumn">
          {database.comment
            ? renderComment()
            : renderInfo()}
          {database.isDirty && renderEditComment()}
        </div>
      </Table.Cell>
    </Table.Row>
  );
}

PromotionTableRow.propTypes = {
  database: PromotionDatabaseType.isRequired,
  isPromotionRunning: PropTypes.bool,
  onCheckboxChange: PropTypes.func,
  onEditComment: PropTypes.func
};

PromotionTableRow.defaultProps = {
  database: {},
  isPromotionRunning: false,
  onCheckboxChange: voidFn,
  onEditComment: voidFn
};
