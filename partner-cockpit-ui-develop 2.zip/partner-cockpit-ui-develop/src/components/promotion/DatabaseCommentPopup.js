import React from 'react';
import { DateAndTime } from 'components/common';
import { PromotionDatabaseType } from 'components/Types';
import { FormattedMessage } from 'react-intl';

const getPromotionReason = database => {
  if (database.isPromotedToLive) {
    return (
      <FormattedMessage
        id="promotion.reason"
        defaultMessage="Reason:"
      />
    );
  }
  if (database.isPreselected) {
    return (
      <FormattedMessage
        id="promotion.reason_to_promote"
        defaultMessage="Reason to promote:"
      />
    );
  }
  return (
    <FormattedMessage
      id="promotion.reason_not_to_promote"
      defaultMessage="Reason not to promote:"
    />
  );
};

export default function DatabaseCommentPopup(props) {
  const { database } = props;

  const renderRow = (label, value, className) => (
    <div className={`commentRow ${className}`}>
      <div className="label">
        {label}
      </div>
      <div className="value">
        {value}
      </div>
    </div>
  );

  return (
    <div className="commentPopupContainer">
      {database.commentDate && renderRow(
        <FormattedMessage id="promotion.date" defaultMessage="Date:" />,
        <DateAndTime value={database.commentDate} />,
        'commentDate'
      )}
      {database.confirmedBy && renderRow(
        <FormattedMessage id="promotion.confirmedBy" defaultMessage="Confirmed by:" />,
        database.confirmedBy,
        'confirmedBy'
      )}
      {database.commentAuthor && renderRow(
        <FormattedMessage id="promotion.cockpit_member" defaultMessage="Cockpit member:" />,
        database.commentAuthor,
        'commentAuthor'
      )}
      {renderRow(
        getPromotionReason(database),
        database.comment,
        'comment'
      )}
    </div>
  );
}

DatabaseCommentPopup.propTypes = {
  database: PromotionDatabaseType.isRequired
};

DatabaseCommentPopup.defaultProps = {
  databases: {}
};
