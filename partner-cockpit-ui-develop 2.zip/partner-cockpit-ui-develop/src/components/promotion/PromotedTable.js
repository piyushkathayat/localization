import React from 'react';
import { Table } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { DateAndTime } from 'components/common';
import './PromotedTable.css';
import { PromotionDatabaseType } from 'components/Types';

export default function PromotedTable(props) {
  const { databases } = props;

  const renderHeader = () => (
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Name" id="promotion.name" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Source" id="promotion.source" />
        </Table.HeaderCell>
        <Table.HeaderCell>
          <FormattedMessage defaultMessage="Creation date" id="promotion.creation_date" />
        </Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );

  const renderRow = database => (
    <Table.Row key={database.id}>
      <Table.Cell>
        {database.name}
      </Table.Cell>
      <Table.Cell>
        {database.source}
      </Table.Cell>
      <Table.Cell className={database.isOldDatabase ? 'oldDatabase' : ''}>
        {database.creationDate && <DateAndTime value={database.creationDate} />}
      </Table.Cell>
    </Table.Row>
  );

  return (
    <div className="promotedTableContainer">
      <Table className="databases">
        {renderHeader()}
        <Table.Body>
          {Object.values(databases).map(database => renderRow(database))}
        </Table.Body>
      </Table>
    </div>
  );
}

PromotedTable.propTypes = {
  databases: PropTypes.objectOf(PromotionDatabaseType).isRequired
};

PromotedTable.defaultProps = {
  databases: []
};
