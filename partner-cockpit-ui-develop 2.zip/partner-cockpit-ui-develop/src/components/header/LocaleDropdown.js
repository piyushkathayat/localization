import React from 'react';
import { Dropdown } from 'semantic-ui-react';
import { LOCALES } from 'constants/common';
import { getSelectedLanguage } from 'utils/common';

export default function LocaleDropdown() {
  const onLocaleChange = (selectedLanguage) => {
    window.sessionStorage.setItem('selectedLanguage', selectedLanguage);
    window.location.reload(true);
  };

  return (
    <Dropdown
      value={getSelectedLanguage()}
      selection
      onChange={(e, data) => onLocaleChange(data.value)}
      options={LOCALES}
    />
  );
}
