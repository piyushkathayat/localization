import React from 'react';
import './HeaderTitle.css';
import LocaleDropdown from './LocaleDropdown';

export default function HeaderTitle(props) {
  const { productName = 'Partner Cockpit' } = props;
  // Cockpit team decided that there is no need of localization for now.
  const isInternationalizationNeeded = false;
  return (
    <div className="headerTitleContainer">
      <div className="headerTitleLeft">
        <div className="bankLogo" />
        <span className="productName">
          { productName }
        </span>
      </div>
      {isInternationalizationNeeded && (
        <div className="headerTitleRight">
          <div className="localDropdown">
            <LocaleDropdown />
          </div>
        </div>
      )}
    </div>
  );
}
