import React from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { Menu, Popup, Loader } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import { withRouter } from 'react-router';
import { FormattedMessage } from 'react-intl';
import { SERVER } from 'constants/serverInfo';
import { APP_PREFIX } from 'constants/common';
import { MAIN_MENU, MENU_CONFIGURATION } from 'constants/menu';
import { LayersVersionsType } from 'components/Types';
import './HeaderMenu.css';

export function HeaderMenu(props) {
  const { serverType, layersVersions, isLoading } = props;

  const isActive = name => props.location.pathname.includes(name);

  const renderLoader = () => (
    <div className="serverTypeLoader">
      <Loader active inline size="small" />
    </div>
  );

  const renderServerType = () => (
    <span className="serverType">
      {SERVER[serverType]
        ? SERVER[serverType].name
        : <FormattedMessage defaultMessage="Unknown server" id="menu.unknown_server" />
      }
    </span>
  );

  const renderLayerRow = (layerName, layerVersion) => (
    <div className="layerRow commentRow">
      <div className="layerName label">
        {layerName}:
      </div>
      <div className="layerVersion value">
        {layerVersion}
      </div>
    </div>
  );

  const renderLayersVersions = () => (
    <div className="layersVersions commentPopupContainer celled">
      {renderLayerRow('UI', layersVersions.ui)}
      {renderLayerRow('GW', layersVersions.gatewayService)}
      {renderLayerRow('BL', layersVersions.cockpitService)}
      {renderLayerRow('DB', layersVersions.database)}
    </div>
  );

  const isMenuItemEnabled = menuItemId =>
    R.compose(
      R.not,
      R.includes(menuItemId),
      R.propOr([], 'disabledMenuItems')
    )(MENU_CONFIGURATION[serverType]);

  const renderMainMenu = () => MAIN_MENU
    .filter(menu => isMenuItemEnabled(menu.id))
    .map(menu => (
      <Menu.Item key={menu.id} active={isActive(menu.id)} as={Link} to={`/${APP_PREFIX}/${menu.id}`}>
        <FormattedMessage {...menu.translation} />
      </Menu.Item>
    ));

  return (
    <div className="headerMenuContainer">
      <Menu pointing secondary className="headerMenu">
        {renderMainMenu()}
        <Menu.Item position="right">
          {isLoading
            ? renderLoader()
            : (
              <Popup
                trigger={renderServerType()}
                content={renderLayersVersions()}
                on="click"
                position="bottom center"
                wide
              />
            )
          }
        </Menu.Item>
      </Menu>
    </div>
  );
}

HeaderMenu.propTypes = {
  serverType: PropTypes.string,
  layersVersions: LayersVersionsType.isRequired,
  isLoading: PropTypes.bool.isRequired,
  location: PropTypes.shape({
    pathname: PropTypes.string.isRequired
  })
};

export default withRouter(HeaderMenu);
