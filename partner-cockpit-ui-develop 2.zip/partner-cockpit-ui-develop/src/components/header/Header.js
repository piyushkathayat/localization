import React from 'react';
import PropTypes from 'prop-types';
import { ErrorMessage } from 'components/common';
import { LayersVersionsType } from 'components/Types';
import HeaderTitle from './HeaderTitle';
import HeaderMenu from './HeaderMenu';

export default function Header(props) {
  const { serverType, layersVersions, isLoading, error, onErrorDismiss } = props;
  return (
    <div className="headerContainer">
      <HeaderTitle />
      <HeaderMenu
        serverType={serverType}
        layersVersions={layersVersions}
        isLoading={isLoading}
      />
      {error !== null && <ErrorMessage message={error} onDismiss={onErrorDismiss} />}
    </div>
  );
}

Header.propTypes = {
  serverType: PropTypes.string,
  layersVersions: LayersVersionsType.isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  onErrorDismiss: PropTypes.func.isRequired
};
