import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { NoResults } from 'components/common';
import ReactJson from 'react-json-view';

import {
  checkMutationDecorations,
  findDecorableElements,
  decorateElement
} from './utils/decorate';

import './Viewer.css';

const viewOptions = {
  name: null,
  collapsed: 6,
  iconStyle: 'triangle',
  enableClipboard: false,
  displayObjectSize: false,
  displayDataTypes: false
};

export default class Viewer extends PureComponent {
  constructor(props) {
    super(props);

    this.mutationObserver = null;
  }

  componentDidUpdate(prevProps) {
    if (this.mutationObserver && !R.equals(prevProps.json, this.props.json)) {
      this.mutationObserver.disconnect();
      this.mutationObserver = null;
    }
    const jsonElement = document.querySelector('.react-json-view');
    if (jsonElement && !this.mutationObserver) {
      const decorableElements = findDecorableElements(jsonElement);
      decorableElements.forEach(decorateElement);
      // We create a mutation observer to check for the later updates in the
      // JSON tree (such as collapse/open nodes)
      const config = { attributes: false, childList: true, subtree: true };
      this.mutationObserver = new MutationObserver(checkMutationDecorations);
      this.mutationObserver.observe(jsonElement, config);
    }
  }

  componentWillUnmount() {
    if (this.mutationObserver) {
      this.mutationObserver.disconnect();
    }
  }

  render() {
    const { json } = this.props;

    return (
      <div className="loggerViewerContainer">
        {R.isEmpty(json)
          ? <NoResults />
          : <ReactJson src={json} {...viewOptions} />
        }
      </div>
    );
  }
}

Viewer.propTypes = {
  json: PropTypes.array
};

Viewer.defaultProps = {
  json: []
};
