import * as R from 'ramda';

const DECORABLE_TEXTS = /(^"Warning"$)|(^"Error"$)|( buy )|( sell )/i;

export const decorateElement = element => {
  element.classList.add('highlight');
  const decorableMatch = DECORABLE_TEXTS.exec(element.textContent);
  if (decorableMatch) {
    const className = `highlight-${decorableMatch[0]
      .replace(/[" ]/g, '')
      .toLowerCase()}`;
    element.classList.add(className);
  }
};

export const findDecorableElements = (node, filter = '') => {
  if (!node || !node.querySelectorAll) {
    return [];
  }

  const searchRegexp = filter ? new RegExp(filter, 'i') : null;

  return R.uniq(
    Array.from(node.querySelectorAll('.variable-value')).filter(
      s =>
        (searchRegexp && searchRegexp.exec(s.textContent)) ||
        DECORABLE_TEXTS.exec(s.textContent)
    )
  );
};

export const checkMutationDecorations = mutationsList => {
  // We only care about added nodes, since we want to potentially decorate them
  const addedNodes = mutationsList
    .filter(list => list.addedNodes)
    .map(list => Array.from(list.addedNodes))
    .reduce((array, node) => array.concat(node), []);

  const decorableElements = R.flatten(
    addedNodes.reduce(
      (elements, node) => findDecorableElements(node),
      []
    )
  );

  if (decorableElements.length > 0) {
    decorableElements.forEach(decorateElement);
  }
};
