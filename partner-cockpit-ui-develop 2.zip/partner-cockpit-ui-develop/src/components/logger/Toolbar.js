import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import * as R from 'ramda';
import { FormattedMessage, injectIntl, defineMessages } from 'react-intl';
import { Button, Dropdown, Input } from 'semantic-ui-react';
import { voidFn } from 'utils/common';
import { CONTEXT, CONTEXT_TYPES } from 'constants/logger';
import { DropdownOptionsType, IntlType } from 'components/Types';
import './Toolbar.css';

const messages = defineMessages({
  assetId: {
    id: 'logger.input.assetId',
    defaultMessage: 'Input Asset ID'
  },
  context: {
    id: 'logger.input.context',
    defaultMessage: 'Select Context'
  },
  issueIds: {
    id: 'logger.input.issueIds',
    defaultMessage: 'Select Issue ID(s)'
  }
});

export class Toolbar extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      assetId: '',
      context: '',
      issueIds: []
    };

    this.contextOptions = R.values(
      R.mapObjIndexed(
        (value, key) => ({
          key,
          value: key,
          text: <FormattedMessage {...value.title} />
        }),
        CONTEXT
      )
    );
  }

  isMultipleIssueIds = () => this.state.context === CONTEXT_TYPES.SOLVE_SELECTED;

  isIssueIdsRequired = () => R.path([this.state.context, 'isIssueIdsRequired'], CONTEXT);

  isLoadButtonDisabled = () => {
    const { isLoading } = this.props;
    const { assetId, context, issueIds } = this.state;

    if (isLoading || !assetId || !context) {
      return true;
    }

    return this.isIssueIdsRequired()
      ? !issueIds.length
      : false;
  };

  isExtractButtonDisabled = () => this.props.isLoading || !this.state.assetId;

  handleAssetIdChange = (e, { value }) => this.setState(
    {
      assetId: value,
      context: '',
      issueIds: []
    },
    () => {
      if (this.props.issueIdsOptions.length) {
        this.props.onIssueIdsClear();
      }
    }
  );

  handleContextChange = (e, { value }) => this.setState(
    {
      context: value,
      issueIds: []
    },
    () => {
      if (this.isIssueIdsRequired() && !this.props.issueIdsOptions.length) {
        this.props.onIssueIdsRequest(this.state.assetId);
      }
    }
  );

  handleIssueIdsChange = (e, { value }) => {
    const issueIds = this.isMultipleIssueIds()
      ? value
      : this.formatSingleIssueIdsValue(value);
    this.setState({ issueIds });
  }

  handleLoadButtonClick = () => this.props.onJsonRequest(this.state);

  handleExtractButtonClick = () => this.props.onExtractRequest(this.state.assetId);

  formatSingleIssueIdsValue = issueId => issueId
    ? [issueId]
    : [];

  getIssueIdsValue = () => this.isMultipleIssueIds()
    ? this.state.issueIds
    : this.state.issueIds[0];

  render() {
    const { intl: { formatMessage }, issueIdsOptions, isLoading } = this.props;
    const { assetId, context } = this.state;
    return (
      <div className="loggerToolbarContainer">
        <div className="toolbarInput assetIdInput">
          <FormattedMessage id="logger.assetId" defaultMessage="Asset ID" />
          <Input
            placeholder={formatMessage(messages.assetId)}
            onChange={this.handleAssetIdChange}
            value={assetId}
          />
        </div>
        <div className="toolbarInput contextDropdown">
          <FormattedMessage id="logger.context" defaultMessage="Context" />
          <Dropdown
            clearable
            selection
            selectOnBlur={false}
            placeholder={formatMessage(messages.context)}
            options={this.contextOptions}
            disabled={!assetId}
            onChange={this.handleContextChange}
            value={context}
          />
        </div>
        <div className="toolbarInput issueIdsDropdown">
          <FormattedMessage id="logger.issueIds" defaultMessage="Issue IDs" />
          <Dropdown
            clearable
            selection
            selectOnBlur={false}
            multiple={this.isMultipleIssueIds()}
            placeholder={formatMessage(messages.issueIds)}
            options={issueIdsOptions}
            loading={isLoading}
            disabled={!assetId || !context || !this.isIssueIdsRequired()}
            onChange={this.handleIssueIdsChange}
            value={this.getIssueIdsValue()}
          />
        </div>
        <div className="toolbarButton">
          <Button
            className="ubs-primary-button"
            disabled={this.isLoadButtonDisabled()}
            onClick={this.handleLoadButtonClick}
          >
            <FormattedMessage id="logger.loadData" defaultMessage="Load the data" />
          </Button>
        </div>
        <div className="toolbarButton">
          <Button
            className="ubs-secondary-button"
            disabled={this.isExtractButtonDisabled()}
            onClick={this.handleExtractButtonClick}
          >
            <FormattedMessage id="logger.extract" defaultMessage="Extract" />
          </Button>
        </div>
      </div>
    );
  }
}

Toolbar.propTypes = {
  issueIdsOptions: PropTypes.arrayOf(DropdownOptionsType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  onJsonRequest: PropTypes.func.isRequired,
  onExtractRequest: PropTypes.func.isRequired,
  onIssueIdsRequest: PropTypes.func.isRequired,
  onIssueIdsClear: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

Toolbar.defaultProps = {
  issueIdsOptions: [],
  isLoading: false,
  onJsonRequest: voidFn,
  onExtractRequest: voidFn,
  onIssueIdsRequest: voidFn,
  onIssueIdsClear: voidFn
};

export default injectIntl(Toolbar);
