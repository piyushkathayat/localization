import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { FormatNumber } from '@ubs.partner/shared-ui';
import { LineGraph } from 'components/common';
import { SummaryInfoType } from 'components/Types';
import { SUMMARY_INFO } from 'constants/summary';
import { INFINITY } from 'constants/common';
import { formatValue } from 'utils/common';
import './SummaryTile.css';

const significantPercentage = 10;

const getTrendIcon = value => {
  const percentValue = Math.round(value * 1000) / 10;
  if (percentValue < 0) {
    return 'icon-disclosuredown';
  }
  if (percentValue > 0) {
    return 'icon-disclosureup';
  }
  return '';
};

const getIsTrendWarning = value => {
  const percentValue = Math.round(value * 1000) / 10;
  return Math.abs(percentValue) >= significantPercentage;
};

export default function SummaryTile(props) {
  const {
    summaryInfo: {
      type,
      data,
      pctChange,
      format,
      marquee
    },
    currency
  } = props;

  const trendIcon = getTrendIcon(pctChange);
  const isWarning = getIsTrendWarning(pctChange);

  const renderGraph = () => (
    <div className="tileGraph">
      <LineGraph
        chartData={data}
        styles={{
          width: 230,
          height: 80,
          padding: { top: 10, right: 10, bottom: 10, left: 10 }
        }}
        format={format}
        currency={currency}
        hasOnlyStartAndEndDates={false}
      />
    </div>
  );

  const renderTrend = () => (
    <div className="trend">
      <span className={`trendLabel ${isWarning ? 'warning' : ''}`}>
        {trendIcon && <i className={`icon-ubs ${trendIcon} iconPadding`} />}
        {pctChange === INFINITY
          ? <span className="infinitySign">&infin;</span>
          : (
            <FormatNumber
              showSign
              value={pctChange}
              type="percent"
              precision={1}
              fullValuePrecision={1}
            />
          )
        }
      </span>
    </div>
  );

  const renderTotalCount = () => (
    <div className="total">
      {formatValue(marquee, format, currency)}
    </div>
  );

  const renderTileName = () => (
    <div className="description">
      {SUMMARY_INFO[type]
        ? <FormattedMessage {...SUMMARY_INFO[type].title} />
        : type
      }
    </div>
  );

  return (
    <div className="summaryTile">
      {renderTileName()}
      {renderTotalCount()}
      {renderTrend()}
      {renderGraph()}
    </div>
  );
}

SummaryTile.propTypes = {
  summaryInfo: SummaryInfoType.isRequired,
  currency: PropTypes.string.isRequired
};
