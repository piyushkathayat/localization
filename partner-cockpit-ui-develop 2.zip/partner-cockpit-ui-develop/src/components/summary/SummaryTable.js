import React from 'react';
import PropTypes from 'prop-types';
import { Grid } from 'semantic-ui-react';
import { SummaryInfoType } from 'components/Types';
import SummaryTile from './SummaryTile';
import './SummaryTable.css';

export default function SummaryTable(props) {
  const { summaryInfo, currency } = props;
  return (
    <Grid columns={4} className="summaryTable">
      <Grid.Row>
        {summaryInfo.map(info => (
          <Grid.Column key={info.recNo}>
            <SummaryTile summaryInfo={info} currency={currency} />
          </Grid.Column>
        ))}
      </Grid.Row>
    </Grid>
  );
}

SummaryTable.propTypes = {
  summaryInfo: PropTypes.arrayOf(SummaryInfoType).isRequired,
  currency: PropTypes.string.isRequired
};

SummaryTable.defaultProps = {
  summaryInfo: []
};
