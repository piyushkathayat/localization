import React from 'react';
import * as R from 'ramda';
import { FORMATS, SORT_DIRECTIONS } from 'constants/common';
import { FormatNumber, FormatCurrency, handleJsonResponse } from '@ubs.partner/shared-ui';

export const getSelectedLanguage = () =>
  (!!window.sessionStorage && window.sessionStorage.getItem('selectedLanguage'))
  || 'en';

export const voidFn = () => {};

export const formatValue = (value, format, currency) => {
  switch (format) {
    case FORMATS.CURRENCY:
      return <FormatCurrency value={value} currency={currency} />;
    case FORMATS.NUMBER:
      return <FormatNumber value={value} precision={0} />;
    case FORMATS.PERCENTAGE:
      return (
        <FormatNumber
          value={value}
          type="percent"
          precision={1}
          fullValuePrecision={1}
        />
      );
    default:
      return <FormatNumber value={value} precision={0} />;
  }
};

export const getNewSorting = ({
  initialSorting,
  oldSortBy,
  oldSortDirection,
  newSortBy
}) => {
  if (oldSortBy === newSortBy) {
    return oldSortDirection === SORT_DIRECTIONS.ASC
      ? {
        sortBy: oldSortBy,
        sortDirection: SORT_DIRECTIONS.DESC
      }
      : initialSorting;
  }
  return {
    sortBy: newSortBy,
    sortDirection: SORT_DIRECTIONS.ASC
  };
};

export const indexKeys = decodedKeysList => R.map(
  R.prop('Value'),
  R.indexBy(
    R.prop('Key'),
    decodedKeysList
  )
);

export const flatKeys = keysList => keysList
  .filter(k => k)
  .map((value, idx) => `k${idx}=${value}`)
  .join('&');

export const getInjectorBody = anonymizedKeys => ({
  method: 'POST',
  credentials: 'include',
  headers: {
    Accept: 'application/x-www-form-urlencoded',
    'Content-Type': 'application/x-www-form-urlencoded'
  },
  body: flatKeys(anonymizedKeys)
});

export const getDecodedKeys = ({ anonymizedKeys, server, api = '/api/lookup' }) =>
  fetch(`${server}${api}`, getInjectorBody(anonymizedKeys)).then(handleJsonResponse).then(indexKeys);

export const decodeField = decodedKeys => value => decodedKeys[value] || value;

export const decodeItemsList = ({ fieldsList, itemsList, decodedKeys }) => R.map(
  item => R.evolve(
    R.fromPairs(
      R.map(
        field => [field, decodeField(decodedKeys)],
        fieldsList
      )
    ),
    item
  ),
  itemsList
);
