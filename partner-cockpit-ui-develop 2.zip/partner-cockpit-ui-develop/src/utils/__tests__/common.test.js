import React from 'react';
import { FORMATS } from 'constants/common';
import { FormatNumber, FormatCurrency } from '@ubs.partner/shared-ui';
import {
  getSelectedLanguage,
  formatValue
} from '../common';

// TODO: update

describe('utils common', () => {
  it('Should getSelectedLanguage - with sessionStorage', () => {
    // given
    global.window.sessionStorage = {
      getItem: jest.fn(fieldName => global.window.sessionStorage[fieldName]),
      selectedLanguage: 'de'
    };

    // when
    const result = getSelectedLanguage();

    // then
    expect(global.window.sessionStorage.getItem).toHaveBeenCalled();
    expect(result).toEqual('de');
  });

  it('Should getSelectedLanguage - default', () => {
    // given
    global.window.sessionStorage = undefined;

    // when
    const result = getSelectedLanguage();

    // then
    expect(result).toEqual('en');
  });

  it('Should formatValue', () => {
    // given

    // when

    // then
    expect(formatValue(3, FORMATS.CURRENCY, 'USD')).toEqual(
      <FormatCurrency value={3} currency="USD" />
    );
    expect(formatValue(3, FORMATS.NUMBER)).toEqual(
      <FormatNumber value={3} precision={0} />
    );
    expect(formatValue(0.3, FORMATS.PERCENTAGE)).toEqual(
      <FormatNumber
        value={0.3}
        type="percent"
        precision={1}
        fullValuePrecision={1}
      />
    );
    expect(formatValue(3, 'some different format')).toEqual(
      <FormatNumber value={3} precision={0} />
    );
  });
});
