import { SOCKET_STATUS } from 'constants/common';
import {
  validateDecisionInProgress,
  validateDecisionFinished,
  validateDecisionFailed
} from 'actions/validation';
import {
  loadAndQaJobsProgressInProgress,
  loadAndQaJobsProgressFailed,
  loadAndQaJobsProgressFinished
} from 'actions/loadAndQA';
import {
  handleValidationProgress,
  handleLoadAndQaJobsProgress
} from '../socketHandlers';

describe('utils socketHandlers', () => {
  it('Should handleValidationProgress - SOCKET_STATUS.IN_PROGRESS', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: SOCKET_STATUS.IN_PROGRESS,
      data: 'some data'
    };

    // when
    handleValidationProgress(message, dispatch);

    // then
    expect(dispatch).toHaveBeenCalled();
    expect(dispatch.mock.calls[0][0]).toEqual(validateDecisionInProgress(message));
  });

  it('Should handleValidationProgress - SOCKET_STATUS.FINISHED', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: SOCKET_STATUS.FINISHED,
      data: 'some data'
    };

    // when
    handleValidationProgress(message, dispatch);

    // then
    expect(dispatch).toHaveBeenCalled();
    expect(dispatch.mock.calls[0][0]).toEqual(validateDecisionFinished(message));
  });

  it('Should handleValidationProgress - SOCKET_STATUS.FAILED', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: SOCKET_STATUS.FAILED,
      data: 'some data'
    };

    // when
    handleValidationProgress(message, dispatch);

    // then
    expect(dispatch).toHaveBeenCalled();
    expect(dispatch.mock.calls[0][0]).toEqual(validateDecisionFailed(message));
  });

  it('Should handleValidationProgress - default', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: 'some other type',
      data: 'some data'
    };

    // when
    handleValidationProgress(message, dispatch);

    // then
    expect(dispatch).not.toHaveBeenCalled();
  });

  it('Should handleLoadAndQaJobsProgress - SOCKET_STATUS.IN_PROGRESS', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: SOCKET_STATUS.IN_PROGRESS,
      data: 'some data'
    };

    // when
    handleLoadAndQaJobsProgress(message, dispatch);

    // then
    expect(dispatch).toHaveBeenCalled();
    expect(dispatch.mock.calls[0][0]).toEqual(loadAndQaJobsProgressInProgress(message));
  });

  it('Should handleLoadAndQaJobsProgress - SOCKET_STATUS.FINISHED', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: SOCKET_STATUS.FINISHED,
      data: 'some data'
    };

    // when
    handleLoadAndQaJobsProgress(message, dispatch);

    // then
    expect(dispatch).toHaveBeenCalled();
    expect(dispatch.mock.calls[0][0]).toEqual(loadAndQaJobsProgressFinished(message));
  });

  it('Should handleLoadAndQaJobsProgress - SOCKET_STATUS.FAILED', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: SOCKET_STATUS.FAILED,
      data: 'some data'
    };

    // when
    handleLoadAndQaJobsProgress(message, dispatch);

    // then
    expect(dispatch).toHaveBeenCalled();
    expect(dispatch.mock.calls[0][0]).toEqual(loadAndQaJobsProgressFailed(message));
  });

  it('Should handleLoadAndQaJobsProgress - default', () => {
    // given
    const dispatch = jest.fn();
    const message = {
      type: 'some other type',
      data: 'some data'
    };

    // when
    handleLoadAndQaJobsProgress(message, dispatch);

    // then
    expect(dispatch).not.toHaveBeenCalled();
  });
});
