import { call } from 'redux-saga/effects';
import { getByteData } from '@ubs.partner/shared-ui';
import {
  getCreateFileParams,
  getUploadFileParams,
  uploadFile
} from '../uploadFile';

describe('utils uploadFile', () => {
  it('Should getCreateFileParams', () => {
    // given

    // when

    // then
    expect(getCreateFileParams(1024)).toEqual({
      method: 'PUT',
      headers: {
        'x-ms-type': 'file',
        'x-ms-content-length': 1024
      }
    });
  });

  it('Should getUploadFileParams', () => {
    // given
    const body = {
      someField: 'some value'
    };

    // when

    // then
    expect(getUploadFileParams(1024, body)).toEqual({
      method: 'PUT',
      body,
      headers: {
        'x-ms-write': 'update',
        'x-ms-range': 'bytes=0-1023',
        'content-length': 1024
      }
    });
  });

  it('Should uploadFile - response.ok === true', () => {
    // given
    const file = {
      size: 1024
    };
    const feedsourceResponse = {
      createUrl: 'some/url/to/file',
      putRangeUrl: 'some/other/url'
    };
    const byteData = 'BYTE_DATA';

    // when
    const generator = uploadFile(feedsourceResponse, file);

    // then
    expect(generator.next().value).toEqual(
      call(getByteData, file)
    );
    expect(generator.next(byteData).value).toEqual(
      call(fetch, 'some/url/to/file', getCreateFileParams(1024))
    );
    expect(generator.next({ ok: true }).value).toEqual(
      call(fetch, 'some/other/url', getUploadFileParams(1024, byteData))
    );
    expect(generator.next({ ok: true }).value).toEqual(true);
    expect(generator.next().done).toEqual(true);
  });

  it('Should uploadFile - response.ok === false', () => {
    // given
    const file = {
      size: 1024
    };
    const feedsourceResponse = {
      createUrl: 'some/url/to/file',
      putRangeUrl: 'some/other/url'
    };

    // when
    const generator = uploadFile(feedsourceResponse, file);

    // then
    expect(generator.next().value).toEqual(call(getByteData, file));
    expect(generator.next().value).toEqual(call(fetch, 'some/url/to/file', getCreateFileParams(1024)));
    expect(generator.next({ ok: false }).value).toEqual(false);
    expect(generator.next().done).toEqual(true);
  });
});
