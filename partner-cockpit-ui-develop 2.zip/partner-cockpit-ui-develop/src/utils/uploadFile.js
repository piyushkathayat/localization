import * as R from 'ramda';
import { call } from 'redux-saga/effects';
import { getByteData } from '@ubs.partner/shared-ui';

export const getCreateFileParams = fileSize => ({
  method: 'PUT',
  headers: {
    'x-ms-type': 'file',
    'x-ms-content-length': fileSize
  }
});

export const getUploadFileParams = (fileSize, body) => ({
  method: 'PUT',
  body,
  headers: {
    'x-ms-write': 'update',
    'x-ms-range': `bytes=0-${fileSize - 1}`,
    'content-length': fileSize
  }
});

export function* uploadFile(feedsourceResponse, file) {
  const createFileUrl = R.prop('createUrl', feedsourceResponse);
  const byteData = yield call(getByteData, file);

  const createFileParams = getCreateFileParams(file.size);
  let response = yield call(fetch, createFileUrl, createFileParams);

  if (response.ok) {
    const uploadFileUrl = R.prop('putRangeUrl', feedsourceResponse);
    const uploadFileParams = getUploadFileParams(file.size, byteData);
    response = yield call(fetch, uploadFileUrl, uploadFileParams);
  }
  return response.ok;
}
