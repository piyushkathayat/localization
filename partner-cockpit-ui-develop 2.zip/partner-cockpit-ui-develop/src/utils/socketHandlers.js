import { SOCKET_STATUS } from 'constants/common';
import {
  validateDecisionInProgress,
  validateDecisionFinished,
  validateDecisionFailed
} from 'actions/validation';
import {
  loadAndQaJobsProgressInProgress,
  loadAndQaJobsProgressFailed,
  loadAndQaJobsProgressFinished
} from 'actions/loadAndQA';

export function handleValidationProgress(message, dispatch) {
  switch (message.type) {
    case SOCKET_STATUS.IN_PROGRESS:
      return dispatch(validateDecisionInProgress(message));
    case SOCKET_STATUS.FINISHED:
      return dispatch(validateDecisionFinished(message));
    case SOCKET_STATUS.FAILED:
      return dispatch(validateDecisionFailed(message));
    default:
      break;
  }
}

export function handleLoadAndQaJobsProgress(message, dispatch) {
  switch (message.type) {
    case SOCKET_STATUS.IN_PROGRESS:
      return dispatch(loadAndQaJobsProgressInProgress(message));
    case SOCKET_STATUS.FINISHED:
      return dispatch(loadAndQaJobsProgressFinished(message));
    case SOCKET_STATUS.FAILED:
      return dispatch(loadAndQaJobsProgressFailed(message));
    default:
      break;
  }
}
