import React from 'react';
import { shallow } from 'enzyme';
import { Switch, Redirect } from 'react-router-dom';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { VALIDATION_COMPONENTS } from 'constants/validation';
import QualityChecks from 'containers/QualityCheck';
import Validation from 'containers/Validation';
import Promotion from 'containers/Promotion';
import Summary from 'containers/Summary';
import LoadAndQA from 'containers/LoadAndQA';
import Parameters from 'containers/Parameters';
import Logger from 'containers/Logger';
import Routes from 'Routes';

const getInitialProps = () => ({
  serverType: 'STAGING'
});

describe('Routes component', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper.find(Switch)).toHaveLength(1);
  });

  it('should render proper component based on URL: Summary', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.SUMMARY}']`)
      .prop('component')
    ).toBe(Summary);
  });

  it('should render proper component based on URL: LoadAndQA', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.LOAD}']`)
      .prop('component')
    ).toBe(LoadAndQA);
  });

  it('should render proper component based on URL: LoadAndQA - Actions', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id']`)
      .prop('component')
    ).toBe(LoadAndQA);
  });

  it('should render proper component based on URL: LoadAndQA - Drilldown', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id/:drilldownType/:drilldownKey']`)
      .prop('component')
    ).toBe(LoadAndQA);
  });

  it('should render proper component based on URL: QualityChecks', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.QUALITY_CHECK}']`)
      .prop('component')
    ).toBe(QualityChecks);
  });

  it('should redirect to Validation - QualityChecks - Overview', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/']`)
      .prop('render')()
    ).toEqual(<Redirect to={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`} />);
  });

  it('should render proper component based on URL: Validation - QualityChecks - Overview', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}']`)
      .prop('render')()
    ).toEqual(<Validation activeComponent={VALIDATION_COMPONENTS.QUALITY_CHECKS_OVERVIEW} />);
  });

  it('should render proper component based on URL: Validation - QualityChecks - Details', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}/:decisionId/:qualityCheckType']`)
      .prop('render')()
    ).toEqual(<Validation activeComponent={VALIDATION_COMPONENTS.QUALITY_CHECKS_DETAILS} />);
  });

  it('should render proper component based on URL: Validation - Brokerage - Overview', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}']`)
      .prop('render')()
    ).toEqual(<Validation activeComponent={VALIDATION_COMPONENTS.BROKERAGE_OVERVIEW} />);
  });

  it('should render proper component based on URL: Validation - Brokerage - Details', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}/:triggerThemeId']`)
      .prop('render')()
    ).toEqual(<Validation activeComponent={VALIDATION_COMPONENTS.BROKERAGE_DETAILS} />);
  });

  it('should render proper component based on URL: Promotion', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.PROMOTION}']`)
      .prop('component')
    ).toBe(Promotion);
  });

  it('should render proper component based on URL: Parameters', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}']`)
      .prop('component')
    ).toBe(Parameters);
  });

  it('should render proper component based on URL: Parameters - Details', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/:feedName']`)
      .prop('component')
    ).toBe(Parameters);
  });

  it('should render proper component based on URL: Logger', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find(`Route[exact=true][path='/${APP_PREFIX}/${MENU_ITEMS.LOGGER}']`)
      .prop('component')
    ).toBe(Logger);
  });

  it('should render proper component based on URL: default fallback', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Routes {...props} />);

    // then
    expect(enzymeWrapper
      .find('Route')
      .findWhere(n => n.props().path === undefined)
    ).toHaveLength(1);
  });
});
