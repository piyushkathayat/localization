import React from 'react';
import { shallow } from 'enzyme';
import DocumentTitle from 'react-document-title';
import Header from 'components/header/Header';
import Routes from 'Routes';
import { App } from 'App';

const getInitialProps = () => ({
  serverType: 'STAGING',
  partnerDBKey: 'WS004',
  environment: 'T',
  isLoading: false,
  error: null,
  layersVersions: {
    database: '2.0.1',
    cockpitService: '2.0.2',
    gatewayService: '2.0.3',
    ui: '2.0.4'
  },
  fetchServerInfo: jest.fn(),
  clearError: jest.fn()
});

describe('App container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<App {...props} />);

    // then
    expect(enzymeWrapper.exists('.app')).toBe(true);
    expect(enzymeWrapper.exists('.screen')).toBe(true);
    expect(enzymeWrapper.exists('.infoContainer')).toBe(true);
  });

  it('should fetchServerInfo on mounting', () => {
    // given
    const props = getInitialProps();

    // when
    // eslint-disable-next-line no-unused-vars
    const enzymeWrapper = shallow(<App {...props} />);

    // then
    expect(props.fetchServerInfo.mock.calls.length).toBe(1);
  });

  it('should set DocumentTitle', () => {
    // given
    const props = getInitialProps();
    const expectedDocumentTitleProps = {
      title: 'WS004-T-STAGING'
    };

    // when
    const enzymeWrapper = shallow(<App {...props} />);

    // then
    expect(enzymeWrapper.find(DocumentTitle)).toHaveLength(1);
    const documentTitleProps = enzymeWrapper.find(DocumentTitle).props();
    expect(documentTitleProps.title).toEqual(expectedDocumentTitleProps.title);
  });

  it('should render Header', () => {
    // given
    const props = getInitialProps();
    const expectedHeaderProps = {
      serverType: props.serverType,
      layersVersions: props.layersVersions,
      isLoading: props.isLoading,
      error: props.error,
      onErrorDismiss: props.clearError
    };

    // when
    const enzymeWrapper = shallow(<App {...props} />);

    // then
    expect(enzymeWrapper.find(Header)).toHaveLength(1);
    const headerProps = enzymeWrapper.find(Header).props();
    expect(headerProps.serverType).toEqual(expectedHeaderProps.serverType);
    expect(headerProps.layersVersions).toEqual(expectedHeaderProps.layersVersions);
    expect(headerProps.isLoading).toEqual(expectedHeaderProps.isLoading);
    expect(headerProps.error).toEqual(expectedHeaderProps.error);
    expect(headerProps.onErrorDismiss).toEqual(expectedHeaderProps.onErrorDismiss);
  });

  it('should render no Router if no serverType is specified', () => {
    // given
    const props = getInitialProps();
    props.serverType = '';

    // when
    const enzymeWrapper = shallow(<App {...props} />);

    // then
    expect(enzymeWrapper.find(Routes)).toHaveLength(0);
  });

  it('should render Router if serverType is specified', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<App {...props} />);

    // then
    expect(enzymeWrapper.find(Routes)).toHaveLength(1);
  });
});
