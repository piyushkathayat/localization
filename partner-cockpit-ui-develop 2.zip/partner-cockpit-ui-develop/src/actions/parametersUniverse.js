import { PARAMETERS_UNIVERSE } from './ActionTypes';

export function clearParametersUniverse() {
  return {
    type: PARAMETERS_UNIVERSE.CLEAR
  };
}

export function clearError() {
  return {
    type: PARAMETERS_UNIVERSE.ERROR.CLEAR
  };
}

export function changePage(nextPage) {
  return {
    type: PARAMETERS_UNIVERSE.PAGE.CHANGE,
    nextPage
  };
}

export function setSearch(isin) {
  return {
    type: PARAMETERS_UNIVERSE.SEARCH.SET,
    isin
  };
}

export function clearSearch() {
  return {
    type: PARAMETERS_UNIVERSE.SEARCH.CLEAR
  };
}
