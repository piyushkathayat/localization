import { CORE_ENGINE } from './ActionTypes';

export function filterTables(filter) {
  return {
    type: CORE_ENGINE.FILTER,
    filter
  };
}

export function clearCoreEngine() {
  return {
    type: CORE_ENGINE.CLEAR
  };
}

export function clearError() {
  return {
    type: CORE_ENGINE.ERROR.CLEAR
  };
}
