import { LOAD_AND_QA_DRILLDOWN } from './ActionTypes';

export function clearLoadAndQADrilldown() {
  return {
    type: LOAD_AND_QA_DRILLDOWN.CLEAR
  };
}

export function clearError() {
  return {
    type: LOAD_AND_QA_DRILLDOWN.ERROR.CLEAR
  };
}

export function fetchDrilldownFile(drilldownId) {
  return {
    type: LOAD_AND_QA_DRILLDOWN.FILE.REQUEST,
    drilldownId
  };
}
