import { SERVER_INFO } from 'actions/ActionTypes';

export function fetchServerInfo() {
  return {
    type: SERVER_INFO.FETCH.REQUEST
  };
}

export function clearError() {
  return {
    type: SERVER_INFO.ERROR.CLEAR
  };
}

export function changeServerType(serverType) {
  return {
    type: SERVER_INFO.SERVER_TYPE.CHANGE,
    serverType
  };
}
