import { PARAMETERS_UNIVERSE } from '../ActionTypes';
import {
  clearParametersUniverse,
  clearError,
  changePage,
  setSearch,
  clearSearch
} from '../parametersUniverse';

describe('parametersUniverse actions', () => {
  it('Should clearParametersUniverse', () => {
    // given
    const expectedResult = {
      type: PARAMETERS_UNIVERSE.CLEAR
    };

    // when
    const actualResult = clearParametersUniverse();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: PARAMETERS_UNIVERSE.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should changePage', () => {
    // given
    const nextPage = 2;
    const expectedResult = {
      type: PARAMETERS_UNIVERSE.PAGE.CHANGE,
      nextPage
    };

    // when
    const actualResult = changePage(nextPage);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should setSearch', () => {
    // given
    const isin = 'TX000';
    const expectedResult = {
      type: PARAMETERS_UNIVERSE.SEARCH.SET,
      isin
    };

    // when
    const actualResult = setSearch(isin);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearSearch', () => {
    // given
    const expectedResult = {
      type: PARAMETERS_UNIVERSE.SEARCH.CLEAR
    };

    // when
    const actualResult = clearSearch();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
