import { PROMOTION } from '../ActionTypes';
import {
  clearPromotion,
  updateDatabases,
  promoteToLiveDB,
  clearError
} from '../promotion';

describe('promotion actions', () => {
  it('Should clearPromotion', () => {
    // given
    const expectedAction = {
      type: PROMOTION.CLEAR
    };

    // when
    const action = clearPromotion();

    // then
    expect(action).toEqual(expectedAction);
  });

  it('Should updateDatabases', () => {
    // given
    const databases = [
      {
        oldComment: 'This database is marked for autopromotion on the Live DB.',
        comment: 'some new comment',
        commentAuthor: '',
        commentDate: '',
        oldConfirmedBy: '00355799',
        confirmedBy: '0035579',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isDirty: true,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: false,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      }
    ];
    const expectedAction = {
      type: PROMOTION.DATABASES.UPDATE,
      databases: [
        {
          oldComment: 'This database is marked for autopromotion on the Live DB.',
          comment: 'some new comment',
          commentAuthor: '',
          commentDate: '',
          oldConfirmedBy: '00355799',
          confirmedBy: '0035579',
          creationDate: '2019-01-16T08:43:49.773',
          id: 3,
          internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
          internalName: 'Unbundling',
          isDirty: true,
          isMarkedForPromotion: false,
          isOldDatabase: false,
          isPromotedToLive: false,
          isUsedInLoadOnStaging: true,
          name: 'UNBUNDLING',
          source: 'NZUR18125DSQ'
        }
      ]
    };

    // when
    const action = updateDatabases(databases);

    // then
    expect(action).toEqual(expectedAction);
  });

  it('Should promoteToLiveDB', () => {
    // given
    const databases = [
      {
        comment: 'This database is marked for autopromotion on the Live DB.',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '00355799',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isDirty: false,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      },
      {
        comment: 'This database is marked for autopromotion on the Live DB.',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '00355799',
        creationDate: '2019-01-16T05:00:20.783',
        id: 4,
        internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
        internalName: 'BBS',
        isDirty: false,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'BBS',
        source: 'NZUR18125DSQ'
      },
      {
        comment: '',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '',
        creationDate: '2019-01-16T08:53:35.09',
        id: 15,
        internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
        internalName: 'LK',
        isDirty: false,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: false,
        isUsedInLoadOnStaging: true,
        name: 'Lookup Tables',
        source: 'NZUR18130DSQ'
      }
    ];
    const expectedAction = {
      type: PROMOTION.PROMOTE.REQUEST,
      databases
    };

    // when
    const action = promoteToLiveDB(databases);

    // then
    expect(action).toEqual(expectedAction);
  });

  it('Should clearError', () => {
    // given
    const expectedAction = {
      type: PROMOTION.ERROR.CLEAR
    };

    // when
    const action = clearError();

    // then
    expect(action).toEqual(expectedAction);
  });
});
