import { CORE_ENGINE } from '../ActionTypes';
import {
  filterTables,
  clearCoreEngine,
  clearError
} from '../coreEngine';

describe('coreEngine actions', () => {
  it('Should filterTables', () => {
    // given
    const filter = ['cortex_extract'];
    const expectedResult = {
      type: CORE_ENGINE.FILTER,
      filter
    };

    // when
    const actualResult = filterTables(filter);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearCoreEngine', () => {
    // given
    const expectedResult = {
      type: CORE_ENGINE.CLEAR
    };

    // when
    const actualResult = clearCoreEngine();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: CORE_ENGINE.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
