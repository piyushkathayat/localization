import { LOAD_AND_QA_DRILLDOWN } from '../ActionTypes';
import {
  clearLoadAndQADrilldown,
  clearError
} from '../loadAndQADrilldown';

// TODO: update

describe('loadAndQADrilldown actions', () => {
  it('Should clearLoadAndQADrilldown', () => {
    // given
    const expectedResult = {
      type: LOAD_AND_QA_DRILLDOWN.CLEAR
    };

    // when
    const actualResult = clearLoadAndQADrilldown();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: LOAD_AND_QA_DRILLDOWN.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
