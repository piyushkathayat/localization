import { VALIDATION_DETAILS } from '../ActionTypes';
import {
  clearValidationDetails,
  updateValidationDetails,
  fetchAffectedPortfolios,
  clearError
} from '../validationDetails';

describe('validationDetails actions', () => {
  it('Should clearValidationDetails', () => {
    // given
    const expectedResult = {
      type: VALIDATION_DETAILS.CLEAR
    };

    // when
    const actualResult = clearValidationDetails();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  // it('Should setSearch', () => {
  //   // given
  //   const search = 'TX000';
  //   const expectedResult = {
  //     type: VALIDATION_DETAILS.SEARCH.SET,
  //     search
  //   };

  //   // when
  //   const actualResult = setSearch(search);

  //   // then
  //   expect(actualResult).toEqual(expectedResult);
  // });

  // it('Should clearSearch', () => {
  //   // given
  //   const expectedResult = {
  //     type: VALIDATION_DETAILS.SEARCH.CLEAR
  //   };

  //   // when
  //   const actualResult = clearSearch();

  //   // then
  //   expect(actualResult).toEqual(expectedResult);
  // });

  // it('Should sortValidationDetails', () => {
  //   // given
  //   const sortBy = 'isin';
  //   const expectedResult = {
  //     type: VALIDATION_DETAILS.SORT_BY,
  //     sortBy
  //   };

  //   // when
  //   const actualResult = sortValidationDetails(sortBy);

  //   // then
  //   expect(actualResult).toEqual(expectedResult);
  // });

  it('Should updateValidationDetails', () => {
    // given
    const decisionItemsIds = [1, 2, 3];
    const decisionId = 25;
    const qualityCheckType = 2;
    const approvalStatusId = 12;
    const comment = 'oh my';
    const confirmedBy = '43535763';
    const expectedResult = {
      type: VALIDATION_DETAILS.UPDATE.REQUEST,
      decisionItemsIds,
      decisionId,
      qualityCheckType,
      approvalStatusId,
      comment,
      confirmedBy
    };

    // when
    const actualResult = updateValidationDetails({
      decisionItemsIds,
      decisionId,
      qualityCheckType,
      approvalStatusId,
      comment,
      confirmedBy
    });

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should fetchAffectedPortfolios', () => {
    // given
    const decisionItemId = 7139;
    const decisionId = 51;

    const expectedResult = {
      type: VALIDATION_DETAILS.PORTFOLIOS.FETCH.REQUEST,
      decisionItemId,
      decisionId
    };

    // when
    const actualResult = fetchAffectedPortfolios({ decisionId, decisionItemId });

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: VALIDATION_DETAILS.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
