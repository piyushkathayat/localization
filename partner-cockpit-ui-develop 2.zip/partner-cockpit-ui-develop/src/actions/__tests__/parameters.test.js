import { PARAMETERS } from '../ActionTypes';
import {
  feedCheckIn,
  feedCheckOut,
  feedCancel,
  clearParameters,
  clearError
} from '../parameters';

describe('parameters actions', () => {
  it('Should feedCheckIn', () => {
    // given
    const feedName = 'saa';
    const file = 'path/to/file';
    const expectedResult = {
      type: PARAMETERS.CHECK_IN.REQUEST,
      feedName,
      file
    };

    // when
    const actualResult = feedCheckIn(feedName, file);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should feedCheckOut', () => {
    // given
    const feedName = 'saa';
    const expectedResult = {
      type: PARAMETERS.CHECK_OUT.REQUEST,
      feedName
    };

    // when
    const actualResult = feedCheckOut(feedName);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should feedCancel', () => {
    // given
    const feedName = 'saa';
    const expectedResult = {
      type: PARAMETERS.CANCEL.REQUEST,
      feedName
    };

    // when
    const actualResult = feedCancel(feedName);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearParameters', () => {
    // given
    const expectedResult = {
      type: PARAMETERS.CLEAR
    };

    // when
    const actualResult = clearParameters();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: PARAMETERS.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
