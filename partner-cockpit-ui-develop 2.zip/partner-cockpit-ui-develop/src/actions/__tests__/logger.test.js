import { CONTEXT_TYPES } from 'constants/logger';
import { LOGGER } from '../ActionTypes';
import {
  fetchJson,
  fetchIssueIds,
  clearIssueIds,
  clearError,
  clearLogger
} from '../logger';

describe('logger actions', () => {
  it('Should fetchJson', () => {
    // given
    const parameters = {
      assetId: '1041845',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: [1, 2]
    };
    const expectedResult = {
      type: LOGGER.JSON.FETCH.REQUEST,
      parameters
    };

    // when
    const actualResult = fetchJson(parameters);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should fetchIssueIds', () => {
    // given
    const assetId = '1041845';
    const expectedResult = {
      type: LOGGER.ISSUE_IDS.FETCH.REQUEST,
      assetId
    };

    // when
    const actualResult = fetchIssueIds(assetId);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearIssueIds', () => {
    // given
    const expectedResult = {
      type: LOGGER.ISSUE_IDS.CLEAR
    };

    // when
    const actualResult = clearIssueIds();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: LOGGER.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearLogger', () => {
    // given
    const expectedResult = {
      type: LOGGER.CLEAR
    };

    // when
    const actualResult = clearLogger();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
