import { PARAMETERS_DETAILS } from '../ActionTypes';
import {
  clearParametersDetails,
  clearError,
  filterTables
} from '../parametersDetails';

describe('parametersDetails actions', () => {
  it('Should clearParametersDetails', () => {
    // given
    const expectedResult = {
      type: PARAMETERS_DETAILS.CLEAR
    };

    // when
    const actualResult = clearParametersDetails();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: PARAMETERS_DETAILS.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should filterTables', () => {
    // given
    const filter = ['ST_SAA'];
    const expectedResult = {
      type: PARAMETERS_DETAILS.FILTER,
      filter
    };

    // when
    const actualResult = filterTables(filter);

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
