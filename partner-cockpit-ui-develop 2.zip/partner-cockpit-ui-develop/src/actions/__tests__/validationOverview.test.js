import { VALIDATION_OVERVIEW } from '../ActionTypes';
import {
  clearValidationOverview,
  clearError
} from '../validationOverview';

describe('validationOverview actions', () => {
  it('Should clearValidationOverview', () => {
    // given
    const expectedResult = {
      type: VALIDATION_OVERVIEW.CLEAR
    };

    // when
    const actualResult = clearValidationOverview();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: VALIDATION_OVERVIEW.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
