import { LOAD_AND_QA_ACTIONS } from '../ActionTypes';
import {
  clearLoadAndQAActions,
  clearError
} from '../loadAndQAActions';

describe('loadAndQAActions actions', () => {
  it('Should clearLoadAndQAActions', () => {
    // given
    const expectedResult = {
      type: LOAD_AND_QA_ACTIONS.CLEAR
    };

    // when
    const actualResult = clearLoadAndQAActions();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: LOAD_AND_QA_ACTIONS.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
