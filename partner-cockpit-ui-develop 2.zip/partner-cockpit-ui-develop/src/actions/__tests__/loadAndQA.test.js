import { LOAD_AND_QA } from '../ActionTypes';
import {
  clearLoadAndQA,
  clearError,
  startJob,
  stopJob,
  loadAndQaJobsProgressInProgress,
  loadAndQaJobsProgressFinished,
  loadAndQaJobsProgressFailed
} from '../loadAndQA';

describe('loadAndQA actions', () => {
  it('Should clearLoadAndQA', () => {
    // given
    const expectedResult = {
      type: LOAD_AND_QA.CLEAR
    };

    // when
    const actualResult = clearLoadAndQA();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: LOAD_AND_QA.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should startJob', () => {
    // given
    const jobId = '123';
    const database = 'CENTRAL';
    const expectedResult = {
      type: LOAD_AND_QA.JOBS.START,
      jobId,
      database,
      command: 'START'
    };

    // when
    const actualResult = startJob(jobId, database);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should stopJob', () => {
    // given
    const jobId = '123';
    const database = 'CENTRAL';
    const expectedResult = {
      type: LOAD_AND_QA.JOBS.STOP,
      jobId,
      database,
      command: 'STOP'
    };

    // when
    const actualResult = stopJob(jobId, database);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should loadAndQaJobsProgressInProgress', () => {
    // given
    const message = 'some message';
    const expectedResult = {
      type: LOAD_AND_QA.SOCKET.IN_PROGRESS,
      message
    };

    // when
    const actualResult = loadAndQaJobsProgressInProgress(message);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should loadAndQaJobsProgressFinished', () => {
    // given
    const message = 'some message';
    const expectedResult = {
      type: LOAD_AND_QA.SOCKET.FINISHED,
      message
    };

    // when
    const actualResult = loadAndQaJobsProgressFinished(message);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should loadAndQaJobsProgressFailed', () => {
    // given
    const message = 'some message';
    const expectedResult = {
      type: LOAD_AND_QA.SOCKET.FAILED,
      message
    };

    // when
    const actualResult = loadAndQaJobsProgressFailed(message);

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
