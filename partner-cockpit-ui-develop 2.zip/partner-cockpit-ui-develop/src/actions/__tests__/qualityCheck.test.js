import { QUALITY_CHECK } from '../ActionTypes';
import {
  filterQualityChecks,
  fetchQualityChecks,
  clearQualityChecks,
  clearError
} from '../qualityCheck';

describe('qualityCheck actions', () => {
  it('Should filterQualityChecks', () => {
    // given
    const filter = [2];
    const expectedResult = {
      type: QUALITY_CHECK.FILTER,
      filter
    };

    // when
    const actualResult = filterQualityChecks(filter);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should fetchQualityChecks', () => {
    // given
    const days = 21;
    const expectedResult = {
      type: QUALITY_CHECK.FETCH.REQUEST,
      days
    };

    // when
    const actualResult = fetchQualityChecks(days);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearQualityChecks', () => {
    // given
    const expectedResult = {
      type: QUALITY_CHECK.CLEAR
    };

    // when
    const actualResult = clearQualityChecks();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: QUALITY_CHECK.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
