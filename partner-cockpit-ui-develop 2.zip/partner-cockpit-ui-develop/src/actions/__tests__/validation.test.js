import { VALIDATION } from '../ActionTypes';
import {
  clearValidation,
  clearError,
  selectDecisionId,
  recalculateDecision,
  validateDecision,
  validateDecisionInProgress,
  validateDecisionFinished,
  validateDecisionFailed
} from '../validation';

describe('validation actions', () => {
  it('Should clearValidation', () => {
    // given
    const expectedResult = {
      type: VALIDATION.CLEAR
    };

    // when
    const actualResult = clearValidation();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: VALIDATION.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should selectDecisionId', () => {
    // given
    const decisionId = 23;
    const expectedResult = {
      type: VALIDATION.DECISION.SELECT,
      decisionId
    };

    // when
    const actualResult = selectDecisionId(decisionId);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should recalculateDecision', () => {
    // given
    const params = {
      decisionId: 23,
      comment: 'comment',
      confirmedBy: '43535763'
    };
    const expectedResult = {
      type: VALIDATION.DECISION.RECALCULATE.REQUEST,
      decisionId: 23,
      comment: 'comment',
      confirmedBy: '43535763'
    };

    // when
    const actualResult = recalculateDecision(params);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should validateDecision', () => {
    // given
    const params = 23;
    const expectedResult = {
      type: VALIDATION.DECISION.VALIDATE.REQUEST,
      decisionId: 23
    };

    // when
    const actualResult = validateDecision(params);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should validateDecisionInProgress', () => {
    // given
    const message = 'some message';
    const expectedResult = {
      type: VALIDATION.SOCKET.IN_PROGRESS,
      message
    };

    // when
    const actualResult = validateDecisionInProgress(message);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should validateDecisionFinished', () => {
    // given
    const message = 'some message';
    const expectedResult = {
      type: VALIDATION.SOCKET.FINISHED,
      message
    };

    // when
    const actualResult = validateDecisionFinished(message);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should validateDecisionFailed', () => {
    // given
    const message = 'some message';
    const expectedResult = {
      type: VALIDATION.SOCKET.FAILED,
      message
    };

    // when
    const actualResult = validateDecisionFailed(message);

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
