import { SERVER_INFO } from '../ActionTypes';
import {
  fetchServerInfo,
  clearError,
  changeServerType
} from '../serverInfo';

describe('serverInfo actions', () => {
  it('Should fetchServerInfo', () => {
    // given
    const expectedResult = {
      type: SERVER_INFO.FETCH.REQUEST
    };

    // when
    const actualResult = fetchServerInfo();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: SERVER_INFO.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should changeServerType', () => {
    // given
    const serverType = 'PARTNER';
    const expectedResult = {
      type: SERVER_INFO.SERVER_TYPE.CHANGE,
      serverType
    };

    // when
    const actualResult = changeServerType(serverType);

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
