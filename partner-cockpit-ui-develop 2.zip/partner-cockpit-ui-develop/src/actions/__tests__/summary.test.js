import { SUMMARY } from '../ActionTypes';
import {
  setFilter,
  clearSummary,
  clearError
} from '../summary';

describe('summary actions', () => {
  it('Should setFilter', () => {
    // given
    const filter = ['Asset'];
    const expectedResult = {
      type: SUMMARY.FILTER,
      filter
    };

    // when
    const actualResult = setFilter(filter);

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearSummary', () => {
    // given
    const expectedResult = {
      type: SUMMARY.CLEAR
    };

    // when
    const actualResult = clearSummary();

    // then
    expect(actualResult).toEqual(expectedResult);
  });

  it('Should clearError', () => {
    // given
    const expectedResult = {
      type: SUMMARY.ERROR.CLEAR
    };

    // when
    const actualResult = clearError();

    // then
    expect(actualResult).toEqual(expectedResult);
  });
});
