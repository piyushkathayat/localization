import { VALIDATION_OVERVIEW } from './ActionTypes';

export function clearValidationOverview() {
  return {
    type: VALIDATION_OVERVIEW.CLEAR
  };
}

export function clearError() {
  return {
    type: VALIDATION_OVERVIEW.ERROR.CLEAR
  };
}
