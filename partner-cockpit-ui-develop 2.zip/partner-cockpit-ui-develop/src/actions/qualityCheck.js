import { QUALITY_CHECK } from './ActionTypes';

export function filterQualityChecks(filter) {
  return {
    type: QUALITY_CHECK.FILTER,
    filter
  };
}

export function fetchQualityChecks(days) {
  return {
    type: QUALITY_CHECK.FETCH.REQUEST,
    days
  };
}

export function clearQualityChecks() {
  return {
    type: QUALITY_CHECK.CLEAR
  };
}

export function clearError() {
  return {
    type: QUALITY_CHECK.ERROR.CLEAR
  };
}
