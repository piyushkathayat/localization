import { VALIDATION_DETAILS } from './ActionTypes';

export function clearValidationDetails() {
  return {
    type: VALIDATION_DETAILS.CLEAR
  };
}

export function updateValidationDetails({
  decisionItemsIds,
  decisionId,
  qualityCheckType,
  approvalStatusId,
  comment,
  confirmedBy
}) {
  return {
    type: VALIDATION_DETAILS.UPDATE.REQUEST,
    decisionItemsIds,
    decisionId,
    qualityCheckType,
    approvalStatusId,
    comment,
    confirmedBy
  };
}

export function fetchAffectedPortfolios({ decisionId, decisionItemId }) {
  return {
    type: VALIDATION_DETAILS.PORTFOLIOS.FETCH.REQUEST,
    decisionId,
    decisionItemId
  };
}

export function clearError() {
  return {
    type: VALIDATION_DETAILS.ERROR.CLEAR
  };
}
