import { PARAMETERS } from './ActionTypes';

export function feedCheckIn(feedName, file) {
  return {
    type: PARAMETERS.CHECK_IN.REQUEST,
    feedName,
    file
  };
}

export function feedCheckOut(feedName) {
  return {
    type: PARAMETERS.CHECK_OUT.REQUEST,
    feedName
  };
}

export function feedCancel(feedName) {
  return {
    type: PARAMETERS.CANCEL.REQUEST,
    feedName
  };
}

export function clearParameters() {
  return {
    type: PARAMETERS.CLEAR
  };
}

export function clearError() {
  return {
    type: PARAMETERS.ERROR.CLEAR
  };
}
