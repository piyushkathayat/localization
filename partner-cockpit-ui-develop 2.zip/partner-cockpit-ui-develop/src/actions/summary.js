import { SUMMARY } from './ActionTypes';

export function setFilter(filter) {
  return {
    type: SUMMARY.FILTER,
    filter
  };
}

export function clearSummary() {
  return {
    type: SUMMARY.CLEAR
  };
}

export function clearError() {
  return {
    type: SUMMARY.ERROR.CLEAR
  };
}
