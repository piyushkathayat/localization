import { LOGGER } from './ActionTypes';

export function fetchJson(parameters) {
  return {
    type: LOGGER.JSON.FETCH.REQUEST,
    parameters
  };
}

export function extractData(assetId) {
  return {
    type: LOGGER.EXTRACT.FETCH.REQUEST,
    assetId
  };
}

export function fetchIssueIds(assetId) {
  return {
    type: LOGGER.ISSUE_IDS.FETCH.REQUEST,
    assetId
  };
}

export function clearIssueIds() {
  return {
    type: LOGGER.ISSUE_IDS.CLEAR
  };
}

export function clearError() {
  return {
    type: LOGGER.ERROR.CLEAR
  };
}

export function clearLogger() {
  return {
    type: LOGGER.CLEAR
  };
}
