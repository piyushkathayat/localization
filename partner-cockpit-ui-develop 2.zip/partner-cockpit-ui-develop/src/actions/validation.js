import { VALIDATION } from './ActionTypes';

export function clearValidation() {
  return {
    type: VALIDATION.CLEAR
  };
}

export function clearError() {
  return {
    type: VALIDATION.ERROR.CLEAR
  };
}

export function selectDecisionId(decisionId) {
  return {
    type: VALIDATION.DECISION.SELECT,
    decisionId
  };
}

export function recalculateDecision({ decisionId, confirmedBy, comment }) {
  return {
    type: VALIDATION.DECISION.RECALCULATE.REQUEST,
    decisionId,
    confirmedBy,
    comment
  };
}

export function validateDecision(decisionId) {
  return {
    type: VALIDATION.DECISION.VALIDATE.REQUEST,
    decisionId
  };
}

export function validateDecisionInProgress(message) {
  return {
    type: VALIDATION.SOCKET.IN_PROGRESS,
    message
  };
}

export function validateDecisionFinished(message) {
  return {
    type: VALIDATION.SOCKET.FINISHED,
    message
  };
}

export function validateDecisionFailed(message) {
  return {
    type: VALIDATION.SOCKET.FAILED,
    message
  };
}

export function setSearch(search) {
  return {
    type: VALIDATION.SEARCH.SET,
    search
  };
}

export function clearSearch() {
  return {
    type: VALIDATION.SEARCH.CLEAR
  };
}

export function setSorting(sortBy) {
  return {
    type: VALIDATION.SORT_BY,
    sortBy
  };
}
