import { PARAMETERS_DETAILS } from './ActionTypes';

export function clearParametersDetails() {
  return {
    type: PARAMETERS_DETAILS.CLEAR
  };
}

export function clearError() {
  return {
    type: PARAMETERS_DETAILS.ERROR.CLEAR
  };
}

export function filterTables(filter) {
  return {
    type: PARAMETERS_DETAILS.FILTER,
    filter
  };
}
