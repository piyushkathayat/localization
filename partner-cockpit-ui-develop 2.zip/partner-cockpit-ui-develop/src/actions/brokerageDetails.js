import { BROKERAGE_DETAILS } from './ActionTypes';

export function updateBrokerageTrigger({ triggerThemeId, triggerId, isLocked }) {
  return {
    type: BROKERAGE_DETAILS.UPDATE.REQUEST,
    triggerThemeId,
    triggerId,
    isLocked
  };
}

export function fetchBrokeragePortfolios(triggerId) {
  return {
    type: BROKERAGE_DETAILS.PORTFOLIOS.FETCH.REQUEST,
    triggerId
  };
}

export function clearBrokerageDetails() {
  return {
    type: BROKERAGE_DETAILS.CLEAR
  };
}

export function clearError() {
  return {
    type: BROKERAGE_DETAILS.ERROR.CLEAR
  };
}
