import { LOAD_AND_QA } from './ActionTypes';

export function clearLoadAndQA() {
  return {
    type: LOAD_AND_QA.CLEAR
  };
}

export function clearError() {
  return {
    type: LOAD_AND_QA.ERROR.CLEAR
  };
}

export function startJob(jobId, database) {
  return {
    type: LOAD_AND_QA.JOBS.START,
    jobId,
    database,
    command: 'START'
  };
}

export function stopJob(jobId, database) {
  return {
    type: LOAD_AND_QA.JOBS.STOP,
    jobId,
    database,
    command: 'STOP'
  };
}


export function loadAndQaJobsProgressInProgress(message) {
  return {
    type: LOAD_AND_QA.SOCKET.IN_PROGRESS,
    message
  };
}

export function loadAndQaJobsProgressFinished(message) {
  return {
    type: LOAD_AND_QA.SOCKET.FINISHED,
    message
  };
}

export function loadAndQaJobsProgressFailed(message) {
  return {
    type: LOAD_AND_QA.SOCKET.FAILED,
    message
  };
}
