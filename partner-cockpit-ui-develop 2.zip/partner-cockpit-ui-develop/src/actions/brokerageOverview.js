import { BROKERAGE_OVERVIEW } from './ActionTypes';

export function finalizeBrokerage() {
  return {
    type: BROKERAGE_OVERVIEW.FINALIZE.REQUEST
  };
}

export function clearBrokerageOverview() {
  return {
    type: BROKERAGE_OVERVIEW.CLEAR
  };
}

export function clearError() {
  return {
    type: BROKERAGE_OVERVIEW.ERROR.CLEAR
  };
}
