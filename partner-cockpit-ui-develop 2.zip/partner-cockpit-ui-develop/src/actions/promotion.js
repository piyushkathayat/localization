import { PROMOTION } from './ActionTypes';

export function clearPromotion() {
  return {
    type: PROMOTION.CLEAR
  };
}

export function updateDatabases(databases) {
  return {
    type: PROMOTION.DATABASES.UPDATE,
    databases
  };
}

export function promoteToLiveDB(databases) {
  return {
    type: PROMOTION.PROMOTE.REQUEST,
    databases
  };
}

export function clearError() {
  return {
    type: PROMOTION.ERROR.CLEAR
  };
}
