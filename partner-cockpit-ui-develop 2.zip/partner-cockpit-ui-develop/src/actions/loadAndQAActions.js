import { LOAD_AND_QA_ACTIONS } from './ActionTypes';

export function clearLoadAndQAActions() {
  return {
    type: LOAD_AND_QA_ACTIONS.CLEAR
  };
}

export function clearError() {
  return {
    type: LOAD_AND_QA_ACTIONS.ERROR.CLEAR
  };
}
