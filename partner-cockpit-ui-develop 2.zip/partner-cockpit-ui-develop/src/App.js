import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { ConnectedRouter } from 'connected-react-router';
import DocumentTitle from 'react-document-title';
import { bindActionCreators } from 'redux';
import { history } from 'store';
import { voidFn } from 'utils/common';
import Header from 'components/header/Header';
import { fetchServerInfo, clearError } from 'actions/serverInfo';
import {
  getServerType,
  getIsLoading,
  getError,
  getEnvironment,
  getPartnerDBKey,
  getLayersVersions
} from 'selectors/serverInfo';
import { LayersVersionsType } from 'components/Types';
import Routes from './Routes';
import 'react-virtualized/styles.css';
import 'assets/css/Main.css';
import './App.css';

export class App extends PureComponent {
  componentDidMount() {
    this.props.fetchServerInfo();
  }

  applicationTitle = () => `${this.props.partnerDBKey}-${this.props.environment}-${this.props.serverType}`;

  render() {
    const { serverType, layersVersions, isLoading, error } = this.props;
    return (
      <DocumentTitle title={this.applicationTitle()}>
        <ConnectedRouter history={history}>
          <div className="app">
            <div className="screen">
              <Header
                serverType={serverType}
                layersVersions={layersVersions}
                isLoading={isLoading}
                error={error}
                onErrorDismiss={this.props.clearError}
              />
              <div className="infoContainer">
                {serverType && <Routes serverType={serverType} />}
              </div>
            </div>
          </div>
        </ConnectedRouter>
      </DocumentTitle>
    );
  }
}

App.propTypes = {
  serverType: PropTypes.string,
  partnerDBKey: PropTypes.string,
  environment: PropTypes.string,
  layersVersions: LayersVersionsType.isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  fetchServerInfo: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

App.defaultProps = {
  fetchServerInfo: voidFn,
  changeServerType: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  serverType: getServerType(state),
  partnerDBKey: getPartnerDBKey(state),
  environment: getEnvironment(state),
  layersVersions: getLayersVersions(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  fetchServerInfo,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(App);
