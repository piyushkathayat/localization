import React, { PureComponent } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withRouter } from 'react-router';
import { FormattedMessage } from 'react-intl';
import { voidFn } from 'utils/common';
import LoadAndQAOverview from 'components/loadandqa/overview/LoadAndQAOverview';
import LoadAndQADetails from 'components/loadandqa/details/LoadAndQADetails';
import {
  clearLoadAndQA
} from 'actions/loadAndQA';

const LOAD_AND_QA_LEVELS = {
  OVERVIEW: 'OVERVIEW',
  DETAILS: 'DETAILS'
};

export class LoadAndQA extends PureComponent {
  componentWillUnmount() {
    this.props.clearLoadAndQA();
  }

  getLoadAndQALevel = () => {
    const { match: { params: { id } } } = this.props;
    if (R.isNil(id)) {
      return LOAD_AND_QA_LEVELS.OVERVIEW;
    }
    return LOAD_AND_QA_LEVELS.DETAILS;
  };

  renderHeader = () => (
    <span className="pageHeader">
      <span className="title">
        <FormattedMessage defaultMessage="Load and QA Results" id="load_and_qa.header" />
      </span>
    </span>
  );

  renderContent = () => {
    const level = this.getLoadAndQALevel();
    return (
      <div className="content">
        {level === LOAD_AND_QA_LEVELS.OVERVIEW && <LoadAndQAOverview />}
        {level === LOAD_AND_QA_LEVELS.DETAILS && <LoadAndQADetails />}
      </div>
    );
  };

  render() {
    return (
      <div className="pageContainer loadAndQAContainer">
        {this.renderHeader()}
        {this.renderContent()}
      </div>
    );
  }
}

LoadAndQA.propTypes = {
  clearLoadAndQA: PropTypes.func.isRequired,
  match: PropTypes.shape({
    params: PropTypes.shape({
      id: PropTypes.string,
      actionId: PropTypes.string
    }).isRequired
  }).isRequired
};

LoadAndQA.defaultProps = {
  clearLoadAndQA: voidFn
};

const mapDispatchToProps = dispatch => bindActionCreators({
  clearLoadAndQA
}, dispatch);

export default withRouter(connect(null, mapDispatchToProps)(LoadAndQA));
