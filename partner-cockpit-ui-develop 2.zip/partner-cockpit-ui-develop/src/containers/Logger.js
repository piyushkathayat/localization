import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Dimmer, Loader } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { bindActionCreators } from 'redux';
import { voidFn } from 'utils/common';
import { ErrorMessage } from 'components/common';
import Toolbar from 'components/logger/Toolbar';
import Viewer from 'components/logger/Viewer';
import {
  fetchJson,
  extractData,
  fetchIssueIds,
  clearIssueIds,
  clearLogger,
  clearError
} from 'actions/logger';
import {
  getJson,
  getIssueIdsOptions,
  getIsLoading,
  getIsUpdating,
  getError
} from 'selectors/logger';
import { DropdownOptionsType } from 'components/Types';
import './Logger.css';

export class Logger extends PureComponent {
  componentWillUnmount() {
    this.props.clearLogger();
  }

  renderHeader = () => (
    <span className="pageHeader">
      <span className="title">
        <FormattedMessage defaultMessage="Logger" id="logger.header" />
      </span>
    </span>
  );

  renderContent = () => {
    const { json, issueIdsOptions, isLoading, isUpdating } = this.props;
    return (
      <div className="content">
        <Toolbar
          issueIdsOptions={issueIdsOptions}
          isLoading={isLoading}
          onJsonRequest={this.props.fetchJson}
          onExtractRequest={this.props.extractData}
          onIssueIdsRequest={this.props.fetchIssueIds}
          onIssueIdsClear={this.props.clearIssueIds}
        />
        <Viewer json={json} />
        {isUpdating && this.renderUpdater()}
      </div>
    );
  };

  renderUpdater = () => (
    <div className="updaterContainer">
      <Dimmer active inverted>
        <Loader inline="centered" content="Loading" />
      </Dimmer>
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { error } = this.props;
    return (
      <div className="pageContainer loggerContainer">
        {this.renderHeader()}
        {this.renderContent()}
        {error !== null && this.renderError()}
      </div>
    );
  }
}

Logger.propTypes = {
  json: PropTypes.array,
  issueIdsOptions: PropTypes.arrayOf(DropdownOptionsType),
  isLoading: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  error: PropTypes.string,
  fetchJson: PropTypes.func.isRequired,
  extractData: PropTypes.func.isRequired,
  fetchIssueIds: PropTypes.func.isRequired,
  clearIssueIds: PropTypes.func.isRequired,
  clearLogger: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

Logger.defaultProps = {
  json: [],
  issueIdsOptions: [],
  isLoading: false,
  isUpdating: false,
  fetchJson: voidFn,
  extractData: voidFn,
  fetchIssueIds: voidFn,
  clearIssueIds: voidFn,
  clearLogger: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  json: getJson(state),
  issueIdsOptions: getIssueIdsOptions(state),
  isLoading: getIsLoading(state),
  isUpdating: getIsUpdating(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  fetchJson,
  extractData,
  fetchIssueIds,
  clearIssueIds,
  clearLogger,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(Logger);
