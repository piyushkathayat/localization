// import React from 'react';
// import { shallow } from 'enzyme';
// import { APP_PREFIX } from 'constants/common';
// import { MENU_ITEMS } from 'constants/menu';
// import { SearchInput, DateAndTime, ErrorMessage } from 'components/common';
// import { Loader, Dropdown } from 'semantic-ui-react';
// import ValidationOverview from 'components/validation/qualitychecks/overview/ValidationOverview';
// import ValidationDetails from 'components/validation/qualitychecks/details/ValidationDetails';
// import { Validation } from '../Validation';

// const getInitialProps = () => ({
//   match: {
//     params: {
//       qualityCheckType: undefined
//     }
//   },
//   history: {
//     push: jest.fn()
//   },
//   isLoading: false,
//   error: null,
//   decisionsDates: [
//     {
//       key: 27,
//       text: <DateAndTime value="2018-12-14T00:00:00" />,
//       value: 27
//     },
//     {
//       key: 25,
//       text: <DateAndTime value="2018-12-06T00:00:00" />,
//       value: 25
//     },
//     {
//       key: 23,
//       text: <DateAndTime value="2018-11-28T00:00:00" />,
//       value: 23
//     }
//   ],
//   selectedDecisionId: 27,
//   search: '',
//   clearValidation: jest.fn(),
//   selectDecisionId: jest.fn(),
//   setSearch: jest.fn(),
//   clearSearch: jest.fn(),
//   clearError: jest.fn()
// });

describe('Validation container', () => {
  it('should be adjusted', () => {
    expect(true).toBe(true);
  });

  // it('should render self and subcomponents', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
  //   expect(enzymeWrapper.find('.pageContainer').hasClass('validationContainer')).toBe(true);

  //   expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
  //   expect(enzymeWrapper.exists('.title')).toBe(true);

  //   expect(enzymeWrapper.exists('.content')).toBe(true);
  // });

  // it('should render no options with no selectedDecisionId', () => {
  //   // given
  //   const props = getInitialProps();
  //   props.selectedDecisionId = null;

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.options')).toBe(false);
  // });

  // it('should render options with selectedDecisionId set', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.options')).toBe(true);
  // });

  // it('should render date Dropdown with props with selectedDecisionId set', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.dateDropdown')).toBe(true);
  //   expect(enzymeWrapper.find('.dateDropdown').hasClass('optionsItem')).toBe(true);
  //   expect(enzymeWrapper.find(Dropdown)).toHaveLength(1);

  //   const dropdownProps = enzymeWrapper.find(Dropdown).props();
  //   expect(dropdownProps.options).toEqual(props.decisionsDates);
  //   expect(dropdownProps.value).toEqual(props.selectedDecisionId);

  //   dropdownProps.onChange(null, { value: 25 });
  //   expect(props.selectDecisionId.mock.calls.length).toBe(1);
  // });

  // it('
  // should call only selectDecisionId on date
  // Dropdown change with no qualityCheckType set', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   const dropdown = enzymeWrapper.find(Dropdown);
  //   dropdown.props().onChange(null, { value: 25 });
  //   expect(props.selectDecisionId.mock.calls.length).toBe(1);
  //   expect(props.history.push.mock.calls.length).toBe(0);
  // });

  // it('
  // should call selectDecisionId and history.push on date
  // Dropdown change with qualityCheckType set', () => {
  //   // given
  //   const props = getInitialProps();
  //   props.match.params.qualityCheckType = '1';

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   const dropdown = enzymeWrapper.find(Dropdown);
  //   dropdown.props().onChange(null, { value: 25 });
  //   expect(props.selectDecisionId.mock.calls.length).toBe(1);
  //   expect(props.history.push.mock.calls.length).toBe(1);
  //   expect(props.history.push.mock.calls[0][0])
  //     .toBe(`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/25/1`);
  // });

  // it('should render no SearchInput with no qualityCheckType param set', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.find(SearchInput)).toHaveLength(0);
  // });

  // it('should render SearchInput with props with qualityCheckType param set', () => {
  //   // given
  //   const props = getInitialProps();
  //   props.match.params.qualityCheckType = '1';

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.find(SearchInput)).toHaveLength(1);

  //   const searchInputProps = enzymeWrapper.find(SearchInput).props();
  //   expect(searchInputProps.className).toEqual('optionsItem');
  //   expect(searchInputProps.value).toEqual(props.search);
  //   expect(searchInputProps.onChange).toEqual(props.setSearch);
  //   expect(searchInputProps.onClear).toEqual(props.clearSearch);
  // });

  // it('should render Loader instead of content if isLoading === true', () => {
  //   // given
  //   const props = {
  //     ...getInitialProps(),
  //     isLoading: true
  //   };

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.content')).toBe(false);

  //   expect(enzymeWrapper.exists('.loaderContainer')).toBe(true);
  //   expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  // });

  // it('should render only ValidationOverview with click handler if no params set', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.loaderContainer')).toBe(false);
  //   expect(enzymeWrapper.find(ValidationOverview)).toHaveLength(1);
  //   expect(enzymeWrapper.find(ValidationDetails)).toHaveLength(0);

  //   const validationOverview = enzymeWrapper.find(ValidationOverview);
  //   validationOverview.props().onQualityCheckTileClick('1');
  //   expect(props.history.push.mock.calls.length).toBe(1);
  //   expect(props.history.push.mock.calls[0][0])
  //     .toBe(`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/27/1`);
  // });

  // it('should render only ValidationDetails with props if qualityCheckType param set', () => {
  //   // given
  //   const props = getInitialProps();
  //   props.match.params.qualityCheckType = '1';

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.exists('.loaderContainer')).toBe(false);
  //   expect(enzymeWrapper.find(ValidationOverview)).toHaveLength(0);
  //   expect(enzymeWrapper.find(ValidationDetails)).toHaveLength(1);

  //   const validationDetails = enzymeWrapper.find(ValidationDetails);
  //   expect(validationDetails.props().qualityCheckType).toEqual(1);
  //   expect(validationDetails.key()).toEqual(`${props.selectedDecisionId}`);
  // });

  // it('should render ErrorMessage with props if error !== null', () => {
  //   // given
  //   const props = {
  //     ...getInitialProps(),
  //     error: 'some error'
  //   };

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);

  //   // then
  //   expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

  //   const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
  //   expect(errorMessageProps.message).toEqual('some error');
  //   expect(errorMessageProps.onDismiss).toBe(props.clearError);
  // });

  // it('should execute clear function on Unmount', () => {
  //   // given
  //   const props = getInitialProps();

  //   // when
  //   const enzymeWrapper = shallow(<Validation {...props} />);
  //   enzymeWrapper.unmount();

  //   // then
  //   expect(props.clearValidation).toHaveBeenCalled();
  // });
});
