import React from 'react';
import { shallow } from 'enzyme';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import { PARAMETERS_TYPES } from 'constants/parameters';
import { Link } from 'react-router-dom';
import { FormattedMessage } from 'react-intl';
import { SearchInput, SearchDropdown, ErrorMessage } from 'components/common';
import { Breadcrumb } from 'semantic-ui-react';
import ParametersOverview from 'components/parameters/overview/ParametersOverview';
import ParametersDetails from 'components/parameters/details/ParametersDetails';
import InstrumentUniverse from 'components/parameters/details/InstrumentUniverse';
import { Parameters } from '../Parameters';

const getInitialProps = () => ({
  match: {
    params: {
      feedName: undefined
    }
  },
  history: {
    push: jest.fn()
  },
  tablesList: [
    {
      id: 0,
      tableData: [],
      tableDisplayName: 'SAA',
      tableName: 'ST_SAA'
    },
    {
      id: 1,
      tableData: [],
      tableDisplayName: 'SAA Risk Return',
      tableName: 'ST_SAARiskReturn'
    },
    {
      id: 2,
      tableData: [],
      tableDisplayName: 'ST_SAAWeights',
      tableName: 'ST_SAAWeights'
    }
  ],
  isin: '',
  error: null,
  clearParameters: jest.fn(),
  clearError: jest.fn(),
  filterTables: jest.fn(),
  setSearch: jest.fn(),
  clearSearch: jest.fn()
});

describe('Parameters container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('parametersContainer')).toBe(true);

    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.exists('.title')).toBe(true);

    expect(enzymeWrapper.exists('.content')).toBe(true);
  });

  it('should render no options with no feedName', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.exists('.options')).toBe(false);
  });

  it('should render options with feedName set', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = 'saa';

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.exists('.options')).toBe(true);
  });

  it('should render SearchInput with props if feedName === universe', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = PARAMETERS_TYPES.INSTRUMENT_UNIVERSE;

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(SearchInput)).toHaveLength(1);

    const searchInputProps = enzymeWrapper.find(SearchInput).props();
    expect(searchInputProps.className).toEqual('optionsItem');
    expect(searchInputProps.value).toEqual(props.isin);
    expect(searchInputProps.onChange).toEqual(props.setSearch);
    expect(searchInputProps.onClear).toEqual(props.clearSearch);
  });

  it('should render SearchDropdown with props if feedName !== universe', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = 'saa';

    const expectedSearchDropdownProps = {
      className: 'optionsItem',
      options: [
        {
          key: 0,
          text: 'SAA',
          value: 'ST_SAA'
        },
        {
          key: 1,
          text: 'SAA Risk Return',
          value: 'ST_SAARiskReturn'
        },
        {
          key: 2,
          text: 'ST_SAAWeights',
          value: 'ST_SAAWeights'
        }
      ],
      onChange: props.filterTables
    };

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(SearchDropdown)).toHaveLength(1);

    const searchDropdownProps = enzymeWrapper.find(SearchDropdown).props();
    expect(searchDropdownProps.className).toEqual(expectedSearchDropdownProps.className);
    expect(searchDropdownProps.options).toEqual(expectedSearchDropdownProps.options);
    expect(searchDropdownProps.onChange).toEqual(expectedSearchDropdownProps.onChange);
  });

  it('should render Breadcrumbs', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(Breadcrumb)).toHaveLength(1);

    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.className).toEqual('breadcrumbsContainer');
    expect(breadcrumbsProps.icon).toEqual('right angle');
  });

  it('should render Breadcrumbs - Overview if no feedName set', () => {
    // given
    const props = getInitialProps();
    const expectedBreadcrumbsSections = [
      {
        key: 'Overview',
        content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
        active: true
      }
    ];

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsSections);
  });

  it('should render Breadcrumbs - Details if feedName set and found', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = 'saa';
    const expectedBreadcrumbsSections = [
      {
        key: 'Overview',
        content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
        active: false,
        as: Link,
        to: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/`
      },
      {
        key: 'Parameter',
        content: <FormattedMessage id="parameters.saa" defaultMessage="SAA" />,
        active: true
      }
    ];

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsSections);
  });

  it('should render Breadcrumbs - Details (null) if feedName set and not found', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = 'someStrangeFeedName';
    const expectedBreadcrumbsSections = [
      {
        key: 'Overview',
        content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
        active: false,
        as: Link,
        to: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/`
      },
      {
        key: 'Parameter',
        content: null,
        active: true
      }
    ];

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    const breadcrumbsProps = enzymeWrapper.find(Breadcrumb).props();
    expect(breadcrumbsProps.sections).toEqual(expectedBreadcrumbsSections);
  });

  it('should render ParametersOverview with props if no feedName set', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(ParametersOverview)).toHaveLength(1);

    const parametersOverview = enzymeWrapper.find(ParametersOverview);
    parametersOverview.props().onParameterTileClick('saa');
    expect(props.history.push.mock.calls.length).toBe(1);
    expect(props.history.push.mock.calls[0][0])
      .toBe(`/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/saa`);
  });

  it('should render InstrumentUniverse with props if feedName === universe', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = 'universe';

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(InstrumentUniverse)).toHaveLength(1);

    const instrumentUniverseProps = enzymeWrapper.find(InstrumentUniverse).props();
    expect(instrumentUniverseProps.feedName).toEqual('universe');
  });

  it('should render ParametersDetails with props if feedName is set and !== universe', () => {
    // given
    const props = getInitialProps();
    props.match.params.feedName = 'lk';

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(ParametersDetails)).toHaveLength(1);

    const parametersDetailsProps = enzymeWrapper.find(ParametersDetails).props();
    expect(parametersDetailsProps.feedName).toEqual('lk');
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    expect(errorMessageProps.onDismiss).toBe(props.clearError);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Parameters {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearParameters).toHaveBeenCalled();
  });
});
