import React from 'react';
import { shallow } from 'enzyme';
import LoadAndQAOverview from 'components/loadandqa/overview/LoadAndQAOverview';
import LoadAndQADetails from 'components/loadandqa/details/LoadAndQADetails';
import { LoadAndQA } from '../LoadAndQA';

const getInitialProps = () => ({
  match: {
    params: {
      id: undefined,
      actionId: undefined
    }
  },
  clearLoadAndQA: jest.fn()
});

describe('LoadAndQA container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQA {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('loadAndQAContainer')).toBe(true);

    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.exists('.title')).toBe(true);

    expect(enzymeWrapper.exists('.content')).toBe(true);
  });

  it('should render LoadAndQAOverview with no params', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQA {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQAOverview)).toHaveLength(1);
  });

  it('should render LoadAndQADetails when id param is set', () => {
    // given
    const props = getInitialProps();
    props.match.params.id = '16-central';

    // when
    const enzymeWrapper = shallow(<LoadAndQA {...props} />);

    // then
    expect(enzymeWrapper.find(LoadAndQADetails)).toHaveLength(1);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<LoadAndQA {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearLoadAndQA).toHaveBeenCalled();
  });
});
