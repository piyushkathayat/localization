import React from 'react';
import { shallow } from 'enzyme';
import { SearchDropdown, TablesList, ErrorMessage } from 'components/common';
import { Loader } from 'semantic-ui-react';
import { CoreEngine } from '../CoreEngine';

const getInitialProps = () => ({
  tablesList: [
    {
      id: 0,
      tableData: [],
      tableDisplayName: 'allowed_document_language',
      tableName: 'allowed_document_language_tableName'
    },
    {
      id: 1,
      tableData: [],
      tableDisplayName: 'application',
      tableName: 'application_tableName'
    },
    {
      id: 2,
      tableData: [],
      tableDisplayName: 'cortex_extract',
      tableName: 'cortex_extract_tableName'
    }
  ],
  filteredTablesList: [
    {
      id: 0,
      tableData: [],
      tableDisplayName: 'allowed_document_language',
      tableName: 'allowed_document_language_tableName'
    },
    {
      id: 1,
      tableData: [],
      tableDisplayName: 'application',
      tableName: 'application_tableName'
    },
    {
      id: 2,
      tableData: [],
      tableDisplayName: 'cortex_extract',
      tableName: 'cortex_extract_tableName'
    }
  ],
  isLoading: false,
  error: null,
  filterTables: jest.fn(),
  clearCoreEngine: jest.fn(),
  clearError: jest.fn()
});

describe('CoreEngine container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<CoreEngine {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('coreEngineContainer')).toBe(true);

    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.exists('.title')).toBe(true);
    expect(enzymeWrapper.exists('.options')).toBe(true);
    expect(enzymeWrapper.find(SearchDropdown)).toHaveLength(1);

    expect(enzymeWrapper.exists('.content')).toBe(true);
    expect(enzymeWrapper.find(TablesList)).toHaveLength(1);
  });

  it('should render Loader instead of content if isLoading === true', () => {
    // given
    const props = {
      ...getInitialProps(),
      isLoading: true
    };

    // when
    const enzymeWrapper = shallow(<CoreEngine {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(false);

    expect(enzymeWrapper.exists('.loaderContainer')).toBe(true);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<CoreEngine {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    expect(errorMessageProps.onDismiss).toBe(props.clearError);
  });

  it('should populate SearchDropdown with options', () => {
    // given
    const props = getInitialProps();
    const expectedSearchDropdownProps = {
      className: 'optionsItem',
      options: [
        {
          key: 0,
          text: 'allowed_document_language',
          value: 'allowed_document_language_tableName'
        },
        {
          key: 1,
          text: 'application',
          value: 'application_tableName'
        },
        {
          key: 2,
          text: 'cortex_extract',
          value: 'cortex_extract_tableName'
        }
      ],
      onChange: props.filterTables
    };

    // when
    const enzymeWrapper = shallow(<CoreEngine {...props} />);

    // then
    const searchDropdownProps = enzymeWrapper.find(SearchDropdown).props();
    expect(searchDropdownProps.className).toBe(expectedSearchDropdownProps.className);
    expect(searchDropdownProps.options).toEqual(expectedSearchDropdownProps.options);
    expect(searchDropdownProps.onChange).toBe(expectedSearchDropdownProps.onChange);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<CoreEngine {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearCoreEngine).toHaveBeenCalled();
  });
});
