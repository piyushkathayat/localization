import React from 'react';
import { shallow } from 'enzyme';
import { SearchDropdown, NoResults, ErrorMessage } from 'components/common';
import { FormattedDate } from 'react-intl';
import { Loader } from 'semantic-ui-react';
import SummaryTable from 'components/summary/SummaryTable';
import { Summary } from '../Summary';

const getInitialProps = () => ({
  date: '2018-12-14T00:00:00',
  currency: 'EUR',
  summaryInfo: [
    {
      data: [],
      format: 'CURRENCY',
      group: 'Asset',
      marquee: 7035663855,
      pctChange: 0,
      recNo: 0,
      type: 'TOTAL_ASSET_VALUE_GROSS'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 1,
      type: 'CORTEX_INSTRUMENT'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 2,
      type: 'ST_COUNT_INSTRUMENT'
    }
  ],
  filteredSummaryInfo: [
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 1,
      type: 'CORTEX_INSTRUMENT'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 2,
      type: 'ST_COUNT_INSTRUMENT'
    }
  ],
  isLoading: false,
  error: null,
  setFilter: jest.fn(),
  clearSummary: jest.fn(),
  clearError: jest.fn()
});

describe('Summary container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('summaryContainer')).toBe(true);

    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.exists('.title')).toBe(true);
    expect(enzymeWrapper.exists('.options')).toBe(true);
  });

  it('should render SearchDropdown option with props', () => {
    // given
    const props = getInitialProps();
    const expectedSearchDropdownProps = {
      className: 'optionsItem',
      options: [
        {
          key: 'Asset',
          text: 'Asset',
          value: 'Asset'
        },
        {
          key: 'Instrument',
          text: 'Instrument',
          value: 'Instrument'
        }
      ],
      onChange: props.setFilter
    };

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.find(SearchDropdown)).toHaveLength(1);

    const searchDropdownProps = enzymeWrapper.find(SearchDropdown).props();
    expect(searchDropdownProps.className).toEqual(expectedSearchDropdownProps.className);
    expect(searchDropdownProps.options).toEqual(expectedSearchDropdownProps.options);
    expect(searchDropdownProps.onChange).toEqual(expectedSearchDropdownProps.onChange);
  });

  it('should render no dateInfo if no date in props', () => {
    // given
    const props = getInitialProps();
    props.date = '';

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.exists('.dateInfo')).toBe(false);
  });

  it('should render dateInfo if there is a date in props', () => {
    // given
    const props = getInitialProps();
    const expectedFormattedDateProps = {
      value: new Date(props.date),
      year: 'numeric',
      month: 'long',
      day: '2-digit'
    };

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.exists('.dateInfo')).toBe(true);
    expect(enzymeWrapper.find('.dateInfo').hasClass('optionsItem')).toBe(true);
    expect(enzymeWrapper.find(FormattedDate)).toHaveLength(1);

    const formattedDateProps = enzymeWrapper.find(FormattedDate).props();
    expect(formattedDateProps.value).toEqual(expectedFormattedDateProps.value);
    expect(formattedDateProps.year).toEqual(expectedFormattedDateProps.year);
    expect(formattedDateProps.month).toEqual(expectedFormattedDateProps.month);
    expect(formattedDateProps.day).toEqual(expectedFormattedDateProps.day);
  });

  it('should render Loader instead of content if isLoading === true', () => {
    // given
    const props = {
      ...getInitialProps(),
      isLoading: true
    };

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(false);

    expect(enzymeWrapper.exists('.loaderContainer')).toBe(true);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });

  it('should render SummaryTable with props if filteredSummaryInfo.length > 0', () => {
    // given
    const props = getInitialProps();
    const expectedSummaryTableProps = {
      summaryInfo: props.filteredSummaryInfo,
      currency: props.currency
    };

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(true);
    expect(enzymeWrapper.find(SummaryTable)).toHaveLength(1);

    const summaryTableProps = enzymeWrapper.find(SummaryTable).props();
    expect(summaryTableProps.summaryInfo).toEqual(expectedSummaryTableProps.summaryInfo);
    expect(summaryTableProps.currency).toEqual(expectedSummaryTableProps.currency);
  });

  it('should render NoResults if filteredSummaryInfo.length === 0', () => {
    // given
    const props = getInitialProps();
    props.filteredSummaryInfo = [];

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(true);
    expect(enzymeWrapper.find(SummaryTable)).toHaveLength(0);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    expect(errorMessageProps.onDismiss).toBe(props.clearError);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Summary {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearSummary).toHaveBeenCalled();
  });
});
