import React from 'react';
import { shallow } from 'enzyme';
import { SERVER_TYPES } from 'constants/serverInfo';
import { FormattedMessage } from 'react-intl';
import { NoResults, ErrorMessage } from 'components/common';
import PromotedTable from 'components/promotion/PromotedTable';
import PromotionTable from 'components/promotion/PromotionTable';
import { Loader } from 'semantic-ui-react';
import { Promotion } from '../Promotion';

const getInitialProps = () => ({
  isLoading: false,
  databases: {
    3: {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T08:43:49.773',
      id: 3,
      internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
      internalName: 'Unbundling',
      isDirty: false,
      isMarkedForPromotion: false,
      isPreselected: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      name: 'UNBUNDLING',
      source: 'NZUR18125DSQ'
    },
    4: {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T05:00:20.783',
      id: 4,
      internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
      internalName: 'BBS',
      isDirty: false,
      isMarkedForPromotion: false,
      isPreselected: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      name: 'BBS',
      source: 'NZUR18125DSQ'
    },
    15: {
      comment: '',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '',
      creationDate: '2019-01-16T08:53:35.09',
      id: 15,
      internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
      internalName: 'LK',
      isDirty: false,
      isMarkedForPromotion: false,
      isPreselected: true,
      isOldDatabase: false,
      isPromotedToLive: false,
      isUsedInLoadOnStaging: true,
      name: 'Lookup Tables',
      source: 'NZUR18130DSQ'
    }
  },
  serverType: SERVER_TYPES.STAGING,
  error: null,
  clearPromotion: jest.fn(),
  clearError: jest.fn(),
  intl: {
    formatMessage: ({ defaultMessage }) => defaultMessage
  }
});

describe('Promotion container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('promotionContainer')).toBe(true);
  });

  it('should render header', () => {
    // given
    const props = getInitialProps();
    const expectedMessageProps = {
      id: 'promotion.header',
      defaultMessage: 'Promotion'
    };

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.find('.pageHeader').find(FormattedMessage)).toHaveLength(1);
    const messageProps = enzymeWrapper.find('.pageHeader').find(FormattedMessage).props();
    expect(messageProps.id).toEqual(expectedMessageProps.id);
    expect(messageProps.defaultMessage).toEqual(expectedMessageProps.defaultMessage);
  });

  it('should render Loader instead of content if isLoading === true', () => {
    // given
    const props = {
      ...getInitialProps(),
      isLoading: true
    };

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(false);
    expect(enzymeWrapper.exists('.loaderContainer')).toBe(true);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });

  it('should render NoResults if there are no databases', () => {
    // given
    const props = {
      ...getInitialProps(),
      databases: {}
    };

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(false);
    expect(enzymeWrapper.exists('.loaderContainer')).toBe(false);
    expect(enzymeWrapper.find(NoResults)).toHaveLength(1);
  });

  it('should render PromotionTable if serverType === STAGING', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.find(PromotionTable)).toHaveLength(1);
    expect(enzymeWrapper.find(PromotedTable)).toHaveLength(0);
  });

  it('should render PromotedTable with props if serverType !== STAGING', () => {
    // given
    const props = {
      ...getInitialProps(),
      serverType: SERVER_TYPES.LIVE
    };
    const expectedTableProps = {
      databases: props.databases
    };

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.find(PromotionTable)).toHaveLength(0);
    expect(enzymeWrapper.find(PromotedTable)).toHaveLength(1);
    const tableProps = enzymeWrapper.find(PromotedTable).props();
    expect(tableProps.databases).toEqual(expectedTableProps.databases);
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };
    const expectedErrorProps = {
      message: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual(expectedErrorProps.message);
    errorMessageProps.onDismiss();
    expect(props.clearError).toHaveBeenCalled();
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Promotion {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearPromotion).toHaveBeenCalled();
  });
});
