import React from 'react';
import { shallow } from 'enzyme';
// import { IntlProvider, addLocaleData } from 'react-intl';
import * as RI from 'react-intl';
import deLocaleData from 'react-intl/locale-data/de';
import enLocaleData from 'react-intl/locale-data/en';
import itLocaleData from 'react-intl/locale-data/it';
import * as deMessages from 'translations/de-DE.json';
import * as enMessages from 'translations/en-US.json';
import * as itMessages from 'translations/it-IT.json';
import { IntlWrapper, getTranslationMessages } from '../IntlWrapper';

const getInitialProps = () => ({
  children: <div id="child" />,
  locale: 'en'
});

describe('IntlWrapper container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<IntlWrapper {...props} />);

    // then
    expect(enzymeWrapper.find(RI.IntlProvider)).toHaveLength(1);
  });

  it('should addLocaleData', () => {
    // given
    const props = getInitialProps();
    RI.addLocaleData = jest.fn();

    // when
    // eslint-disable-next-line no-unused-vars
    const enzymeWrapper = shallow(<IntlWrapper {...props} />);

    // then
    expect(RI.addLocaleData).toHaveBeenCalledTimes(3);
    expect(RI.addLocaleData).toHaveBeenCalledWith(deLocaleData);
    expect(RI.addLocaleData).toHaveBeenCalledWith(enLocaleData);
    expect(RI.addLocaleData).toHaveBeenCalledWith(itLocaleData);
  });

  it('should render IntlProvider with props', () => {
    // given
    const props = getInitialProps();
    const expectedIntlProps = {
      locale: 'en',
      messages: enMessages
    };

    // when
    const enzymeWrapper = shallow(<IntlWrapper {...props} />);

    // then
    const intlProps = enzymeWrapper.find(RI.IntlProvider).props();
    expect(intlProps.locale).toEqual(expectedIntlProps.locale);
    expect(intlProps.messages).toEqual(expectedIntlProps.messages);
    expect(enzymeWrapper.exists('#child')).toBe(true);
  });

  it('should getTranslationMessages', () => {
    // given

    // when

    // then
    expect(getTranslationMessages('en')).toEqual(enMessages);
    expect(getTranslationMessages('de')).toEqual(deMessages);
    expect(getTranslationMessages('it')).toEqual(itMessages);
  });
});
