import React from 'react';
import { shallow } from 'enzyme';
import { SearchDropdown, ErrorMessage } from 'components/common';
import { Dropdown, Loader } from 'semantic-ui-react';
import QualityCheckResult from 'components/qualitychecks/QualityCheckResult';
import { QualityCheck, TIME_PERIODS } from '../QualityCheck';

const getInitialProps = () => ({
  qualityCheckList: [
    {
      type: 1,
      data: []
    },
    {
      type: 2,
      data: []
    },
    {
      type: 4,
      data: []
    }
  ],
  filteredQualityCheckList: [
    {
      type: 1,
      data: []
    },
    {
      type: 2,
      data: []
    }
  ],
  isLoading: false,
  error: null,
  filterQualityChecks: jest.fn(),
  fetchQualityChecks: jest.fn(),
  clearQualityChecks: jest.fn(),
  clearError: jest.fn(),
  intl: {
    formatMessage: ({ defaultMessage }) => defaultMessage
  }
});

describe('QualityCheck container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('qualityCheckContainer')).toBe(true);

    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.exists('.title')).toBe(true);
    expect(enzymeWrapper.exists('.options')).toBe(true);
  });

  it('should render SearchDropdown option with props', () => {
    // given
    const props = getInitialProps();
    const expectedSearchDropdownProps = {
      className: 'optionsItem',
      options: [
        {
          key: 1,
          text: 'Strategic Asset Allocation',
          value: 1
        },
        {
          key: 2,
          text: 'Bulk Risk',
          value: 2
        },
        {
          key: 4,
          text: 'Outside Universe',
          value: 4
        }
      ],
      onChange: props.filterQualityChecks
    };

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);

    // then
    expect(enzymeWrapper.find(SearchDropdown)).toHaveLength(1);

    const searchDropdownProps = enzymeWrapper.find(SearchDropdown).props();
    expect(searchDropdownProps.className).toEqual(expectedSearchDropdownProps.className);
    expect(searchDropdownProps.options).toEqual(expectedSearchDropdownProps.options);
    expect(searchDropdownProps.onChange).toEqual(expectedSearchDropdownProps.onChange);
  });

  it('should render daysDropdown option with props', () => {
    // given
    const props = getInitialProps();
    const expectedDropdownProps = {
      options: TIME_PERIODS,
      defaultValue: 10
    };

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);

    // then
    expect(enzymeWrapper.exists('.daysDropdown')).toBe(true);
    expect(enzymeWrapper.find('.daysDropdown').hasClass('optionsItem')).toBe(true);
    expect(enzymeWrapper.find(Dropdown)).toHaveLength(1);

    const dropdownProps = enzymeWrapper.find(Dropdown).props();
    expect(dropdownProps.options).toEqual(expectedDropdownProps.options);
    expect(dropdownProps.defaultValue).toEqual(expectedDropdownProps.defaultValue);

    const dropdown = enzymeWrapper.find(Dropdown);
    dropdown.props().onChange(null, { value: 21 });
    expect(props.fetchQualityChecks.mock.calls.length).toBe(1);
    expect(props.fetchQualityChecks.mock.calls[0][0]).toBe(21);
  });

  it('should render Loader instead of content if isLoading === true', () => {
    // given
    const props = {
      ...getInitialProps(),
      isLoading: true
    };

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(false);

    expect(enzymeWrapper.exists('.loaderContainer')).toBe(true);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });

  it('should render QualityCheckResult with props', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(true);
    expect(enzymeWrapper.find(QualityCheckResult)).toHaveLength(1);

    const qualityCheckResultsProps = enzymeWrapper.find(QualityCheckResult).props();
    expect(qualityCheckResultsProps.qualityCheckList).toEqual(props.filteredQualityCheckList);
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    expect(errorMessageProps.onDismiss).toBe(props.clearError);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<QualityCheck {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearQualityChecks).toHaveBeenCalled();
  });
});
