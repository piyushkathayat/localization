import React from 'react';
import { shallow } from 'enzyme';
import { ErrorMessage } from 'components/common';
import { Loader } from 'semantic-ui-react';
import Toolbar from 'components/logger/Toolbar';
import Viewer from 'components/logger/Viewer';
import { Logger } from '../Logger';

const getInitialProps = () => ({
  json: [
    {
      data: {
        '@mt': 'Remediation starting for portfolio {AssetId} where profile is {ClientProfile}, SAA is {SAA_Id} {SAA_Name}',
        AssetId: 1041845,
        ClientProfile: null,
        SAA_Id: 502,
        SAA_Name: 'Prof Desk'
      }
    },
    {
      data: {
        '@mt': 'Remediation finished in {elapsedTotalSeconds}',
        elapsedTotalSeconds: 0.026562799999999998
      }
    }
  ],
  issueIdsOptions: [
    {
      key: 0,
      text: 'Strategic Asset Allocation - -101',
      value: -101
    },
    {
      key: 1,
      text: 'Strategic Asset Allocation - -102',
      value: -102
    },
    {
      key: 2,
      text: 'Bulk Risk - 54',
      value: 54
    }
  ],
  isLoading: false,
  isUpdating: false,
  error: null,
  fetchJson: jest.fn(),
  fetchIssueIds: jest.fn(),
  clearIssueIds: jest.fn(),
  clearLogger: jest.fn(),
  clearError: jest.fn()
});

describe('Logger container', () => {
  it('should render self and subcomponents', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Logger {...props} />);

    // then
    expect(enzymeWrapper.exists('.pageContainer')).toBe(true);
    expect(enzymeWrapper.find('.pageContainer').hasClass('loggerContainer')).toBe(true);

    expect(enzymeWrapper.exists('.pageHeader')).toBe(true);
    expect(enzymeWrapper.exists('.title')).toBe(true);

    expect(enzymeWrapper.exists('.content')).toBe(true);
    expect(enzymeWrapper.find(Toolbar)).toHaveLength(1);
    expect(enzymeWrapper.find(Viewer)).toHaveLength(1);
  });

  it('should render Updater with the content if isUpdating === true', () => {
    // given
    const props = {
      ...getInitialProps(),
      isUpdating: true
    };

    // when
    const enzymeWrapper = shallow(<Logger {...props} />);

    // then
    expect(enzymeWrapper.exists('.content')).toBe(true);

    expect(enzymeWrapper.exists('.updaterContainer')).toBe(true);
    expect(enzymeWrapper.find(Loader)).toHaveLength(1);
  });

  it('should render ErrorMessage with props if error !== null', () => {
    // given
    const props = {
      ...getInitialProps(),
      error: 'some error'
    };

    // when
    const enzymeWrapper = shallow(<Logger {...props} />);

    // then
    expect(enzymeWrapper.find(ErrorMessage)).toHaveLength(1);

    const errorMessageProps = enzymeWrapper.find(ErrorMessage).props();
    expect(errorMessageProps.message).toEqual('some error');
    expect(errorMessageProps.onDismiss).toBe(props.clearError);
  });

  it('should populate Toolbar with the props', () => {
    // given
    const props = getInitialProps();
    const expectedToolbarProps = {
      issueIdsOptions: [
        {
          key: 0,
          text: 'Strategic Asset Allocation - -101',
          value: -101
        },
        {
          key: 1,
          text: 'Strategic Asset Allocation - -102',
          value: -102
        },
        {
          key: 2,
          text: 'Bulk Risk - 54',
          value: 54
        }
      ],
      isLoading: false,
      onJsonRequest: props.fetchJson,
      onIssueIdsRequest: props.fetchIssueIds,
      onIssueIdsClear: props.clearIssueIds
    };

    // when
    const enzymeWrapper = shallow(<Logger {...props} />);

    // then
    const toolbarProps = enzymeWrapper.find(Toolbar).props();
    expect(toolbarProps.issueIdsOptions).toEqual(expectedToolbarProps.issueIdsOptions);
    expect(toolbarProps.isLoading).toEqual(expectedToolbarProps.isLoading);
    expect(toolbarProps.onIssueIdsRequest).toEqual(expectedToolbarProps.onIssueIdsRequest);
    expect(toolbarProps.onIssueIdsRequest).toEqual(expectedToolbarProps.onIssueIdsRequest);
    expect(toolbarProps.onIssueIdsClear).toEqual(expectedToolbarProps.onIssueIdsClear);
  });

  it('should populate Viewer with the props', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Logger {...props} />);

    // then
    const viewerProps = enzymeWrapper.find(Viewer).props();
    expect(viewerProps.json).toBe(props.json);
  });

  it('should execute clear function on Unmount', () => {
    // given
    const props = getInitialProps();

    // when
    const enzymeWrapper = shallow(<Logger {...props} />);
    enzymeWrapper.unmount();

    // then
    expect(props.clearLogger).toHaveBeenCalled();
  });
});
