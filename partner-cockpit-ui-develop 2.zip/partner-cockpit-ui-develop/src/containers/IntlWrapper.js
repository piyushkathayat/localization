import React, { Component } from 'react';
import { connect } from 'react-redux';
import { IntlProvider, addLocaleData } from 'react-intl';
import deLocaleData from 'react-intl/locale-data/de';
import enLocaleData from 'react-intl/locale-data/en';
import itLocaleData from 'react-intl/locale-data/it';
import * as deMessages from 'translations/de-DE.json';
import * as enMessages from 'translations/en-US.json';
import * as itMessages from 'translations/it-IT.json';

export const getTranslationMessages = locale => ({
  de: deMessages,
  en: enMessages,
  it: itMessages
})[locale];

export class IntlWrapper extends Component {
  constructor(props) {
    super(props);
    addLocaleData(deLocaleData);
    addLocaleData(enLocaleData);
    addLocaleData(itLocaleData);
    this.messages = getTranslationMessages(this.props.locale);
  }

  render() {
    const { children, locale } = this.props;

    return (
      <IntlProvider key={locale} locale={locale} messages={this.messages}>
        {children}
      </IntlProvider>
    );
  }
}

const mapStateToProps = state => {
  return ({
    locale: state.internationalization.locale
  });
};

export default connect(mapStateToProps)(IntlWrapper);
