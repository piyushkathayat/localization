import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Dropdown, Loader } from 'semantic-ui-react';
import { FormattedMessage, injectIntl } from 'react-intl';
import { bindActionCreators } from 'redux';
import { ErrorMessage, SearchDropdown } from 'components/common';
import { getQualityCheckSettings } from 'components/qualitychecks/common';
import QualityCheckResult from 'components/qualitychecks/QualityCheckResult';
import { voidFn } from 'utils/common';
import {
  filterQualityChecks,
  fetchQualityChecks,
  clearQualityChecks,
  clearError
} from 'actions/qualityCheck';
import {
  getIsLoading,
  getQualityCheckList,
  getFilteredQualityChecks,
  getError
} from 'selectors/qualityCheck';
import { QualityCheckType, IntlType } from 'components/Types';

const TIME_PERIODS_VALUES = [10, 21, 28, 35];

export const TIME_PERIODS = TIME_PERIODS_VALUES.map(timePeriod => ({
  key: timePeriod,
  text: <FormattedMessage default="{value} days" id="qualityCheck.days" values={{ value: timePeriod }} />,
  value: timePeriod
}));

export class QualityCheck extends PureComponent {
  componentWillUnmount() {
    this.props.clearQualityChecks();
  }

  getFilterDropdownList = qualityCheckList => {
    const { intl: { formatMessage } } = this.props;

    return qualityCheckList.map(qualityCheck => ({
      key: qualityCheck.type,
      text: formatMessage(getQualityCheckSettings(qualityCheck.type).title),
      value: qualityCheck.type
    }));
  };

  renderSearchDropdown = () => {
    const { qualityCheckList } = this.props;
    return (
      <SearchDropdown
        className="optionsItem"
        options={this.getFilterDropdownList(qualityCheckList)}
        onChange={this.props.filterQualityChecks}
      />
    );
  };

  renderDaysDropdown = () => (
    <div className="optionsItem daysDropdown">
      <Dropdown
        fluid
        selection
        selectOnBlur={false}
        selectOnNavigation={false}
        options={TIME_PERIODS}
        defaultValue={10}
        onChange={(event, { value }) => this.props.fetchQualityChecks(value)}
      />
    </div>
  );

  renderHeader = () => (
    <span className="pageHeader">
      <span className="title">
        <FormattedMessage defaultMessage="Quality Checks" id="qualityCheck.header" />
      </span>
      <div className="options">
        {this.renderSearchDropdown()}
        {this.renderDaysDropdown()}
      </div>
    </span>
  );

  renderContent = () => {
    const { filteredQualityCheckList } = this.props;
    return (
      <div className="content">
        <QualityCheckResult qualityCheckList={filteredQualityCheckList} />
      </div>
    );
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="pageContainer qualityCheckContainer">
        {this.renderHeader()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

QualityCheck.propTypes = {
  qualityCheckList: PropTypes.arrayOf(QualityCheckType).isRequired,
  filteredQualityCheckList: PropTypes.arrayOf(QualityCheckType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  filterQualityChecks: PropTypes.func.isRequired,
  fetchQualityChecks: PropTypes.func.isRequired,
  clearQualityChecks: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired,
  intl: IntlType.isRequired
};

QualityCheck.defaultProps = {
  qualityCheckList: [],
  filteredQualityCheckList: [],
  isLoading: false,
  filterQualityChecks: voidFn,
  fetchQualityChecks: voidFn,
  clearQualityChecks: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  qualityCheckList: getQualityCheckList(state),
  filteredQualityCheckList: getFilteredQualityChecks(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  filterQualityChecks,
  fetchQualityChecks,
  clearQualityChecks,
  clearError
}, dispatch
);

export default injectIntl(connect(mapStateToProps, mapDispatchToProps)(QualityCheck));
