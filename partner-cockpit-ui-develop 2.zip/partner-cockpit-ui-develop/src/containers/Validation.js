import React, { PureComponent } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { FormattedMessage } from 'react-intl';
import { Dropdown, Loader, Menu } from 'semantic-ui-react';
import { ErrorMessage, SearchInput } from 'components/common';
import { voidFn } from 'utils/common';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { VALIDATION_COMPONENTS } from 'constants/validation';
import {
  getIsLoading,
  getError,
  getSelectedDecisionId,
  getDecisionsDates,
  getSearch
} from 'selectors/validation';
import {
  clearValidation,
  selectDecisionId,
  clearError,
  setSearch,
  clearSearch
} from 'actions/validation';
import ValidationOverview from 'components/validation/qualitychecks/overview/ValidationOverview';
import ValidationDetails from 'components/validation/qualitychecks/details/ValidationDetails';
import BrokerageOverview from 'components/validation/brokerage/overview/BrokerageOverview';
import BrokerageDetails from 'components/validation/brokerage/details/BrokerageDetails';
import { DropdownOptionsType } from 'components/Types';
import './Validation.css';

export class Validation extends PureComponent {
  componentWillUnmount() {
    this.props.clearValidation();
  }

  getParameter = parameter => Number(R.path(['match', 'params', parameter], this.props));

  getActiveComponent = () => {
    switch (this.props.activeComponent) {
      case VALIDATION_COMPONENTS.QUALITY_CHECKS_OVERVIEW:
        return (
          <ValidationOverview onQualityCheckTileClick={this.handleQualityCheckTileClick} />
        );
      case VALIDATION_COMPONENTS.QUALITY_CHECKS_DETAILS:
        return (
          <ValidationDetails
            key={this.props.selectedDecisionId}
            qualityCheckType={this.getParameter('qualityCheckType')}
          />
        );
      case VALIDATION_COMPONENTS.BROKERAGE_OVERVIEW:
        return (
          <BrokerageOverview onTriggerThemeTileClick={this.handleTriggerThemeTileClick} />
        );
      case VALIDATION_COMPONENTS.BROKERAGE_DETAILS:
        return (
          <BrokerageDetails
            triggerThemeId={this.getParameter('triggerThemeId')}
          />
        );
      default:
        return null;
    }
  }

  isQualityChecksTabActive = () => R.includes(
    this.props.activeComponent,
    [
      VALIDATION_COMPONENTS.QUALITY_CHECKS_OVERVIEW,
      VALIDATION_COMPONENTS.QUALITY_CHECKS_DETAILS
    ]
  );

  isBrokerageTabActive = () => R.includes(
    this.props.activeComponent,
    [
      VALIDATION_COMPONENTS.BROKERAGE_OVERVIEW,
      VALIDATION_COMPONENTS.BROKERAGE_DETAILS
    ]
  );

  hasSearchInput = () => R.includes(
    this.props.activeComponent,
    [
      VALIDATION_COMPONENTS.QUALITY_CHECKS_DETAILS,
      VALIDATION_COMPONENTS.BROKERAGE_DETAILS
    ]
  );

  handleQualityCheckTileClick = qualityCheckType => {
    const { history, selectedDecisionId } = this.props;
    return history.push(`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}/${selectedDecisionId}/${qualityCheckType}`);
  }

  handleTriggerThemeTileClick = triggerId => this.props.history.push(
    `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}/${triggerId}`
  );

  handleDateDropdownChange = (event, { value: decisionId }) => {
    this.props.selectDecisionId(decisionId);
    if (this.props.activeComponent === VALIDATION_COMPONENTS.QUALITY_CHECKS_DETAILS) {
      const { history } = this.props;
      const qualityCheckType = this.getSelectedQualityCheckType();
      history.push(`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}/${decisionId}/${qualityCheckType}`);
    }
  }

  renderSearchInput = () => {
    const { search } = this.props;
    return (
      <SearchInput
        className="optionsItem"
        value={search}
        onChange={this.props.setSearch}
        onClear={this.props.clearSearch}
      />
    );
  }

  renderDateDropdown = () => {
    const { decisionsDates, selectedDecisionId, isLoading } = this.props;
    return isLoading
      ? this.renderLoader()
      : !R.isEmpty(decisionsDates) && (
        <Dropdown
          placeholder="Date"
          className="optionsItem dateDropdown"
          fluid
          selection
          selectOnBlur={false}
          options={decisionsDates}
          value={selectedDecisionId}
          onChange={this.handleDateDropdownChange}
        />
      );
  }

  renderOptions = () => (
    <div className="options">
      {this.hasSearchInput() && this.renderSearchInput()}
      {this.isQualityChecksTabActive() && this.renderDateDropdown()}
    </div>
  );

  renderHeader = () => (
    <div className="pageHeader">
      <div className="validationTabs">
        <Menu pointing secondary className="subHeaderMenu">
          <Menu.Item
            active={this.isQualityChecksTabActive()}
            as={Link}
            to={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`}
          >
            <FormattedMessage defaultMessage="Portfolio Quality Checks" id="validation.menu.quality_checks" />
          </Menu.Item>
          <Menu.Item
            active={this.isBrokerageTabActive()}
            as={Link}
            to={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}`}
          >
            <FormattedMessage defaultMessage="Brokerage" id="validation.menu.brokerage" />
          </Menu.Item>
        </Menu>
      </div>
      {this.renderOptions()}
    </div>
  );

  renderContent = () => (
    <div className="content">
      {this.getActiveComponent()}
    </div>
  );

  renderLoader = () => (
    <div className="optionsItem loader">
      <Loader active inline="centered" size="small" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { error } = this.props;
    return (
      <div className="pageContainer validationContainer">
        {this.renderHeader()}
        {this.renderContent()}
        {error !== null && this.renderError()}
      </div>
    );
  }
}

Validation.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  activeComponent: PropTypes.string,
  decisionsDates: PropTypes.arrayOf(DropdownOptionsType),
  selectedDecisionId: PropTypes.number,
  search: PropTypes.string,
  clearValidation: PropTypes.func.isRequired,
  selectDecisionId: PropTypes.func.isRequired,
  setSearch: PropTypes.func.isRequired,
  clearSearch: PropTypes.func.isRequired,
  match: PropTypes.shape({
    params: PropTypes.shape({
      qualityCheckType: PropTypes.string
    }).isRequired
  }).isRequired,
  history: PropTypes.shape({
    push: PropTypes.func.isRequired
  }).isRequired
};

Validation.defaultProps = {
  isLoading: false,
  activeComponent: VALIDATION_COMPONENTS.QUALITY_CHECKS_OVERVIEW,
  decisionsDates: [],
  selectedDecisionId: null,
  selectDecisionId: voidFn,
  clearValidationDetails: voidFn,
  setSearch: voidFn,
  clearSearch: voidFn
};

const mapStateToProps = state => ({
  isLoading: getIsLoading(state),
  error: getError(state),
  decisionsDates: getDecisionsDates(state),
  selectedDecisionId: getSelectedDecisionId(state),
  search: getSearch(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearValidation,
  selectDecisionId,
  setSearch,
  clearSearch,
  clearError
}, dispatch);

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Validation));
