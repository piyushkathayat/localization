import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Loader } from 'semantic-ui-react';
import { FormattedMessage } from 'react-intl';
import { bindActionCreators } from 'redux';
import { voidFn } from 'utils/common';
import { ErrorMessage, TablesList, SearchDropdown } from 'components/common';
import {
  filterTables,
  clearCoreEngine,
  clearError
} from 'actions/coreEngine';
import {
  getTablesList,
  getFilteredTablesList,
  getIsLoading,
  getError
} from 'selectors/coreEngine';
import { TableType } from 'components/Types';

export class CoreEngine extends PureComponent {
  componentWillUnmount() {
    this.props.clearCoreEngine();
  }

  getFilterDropdownList = tablesList => {
    return tablesList.map(table => ({
      key: table.id,
      text: table.tableDisplayName,
      value: table.tableName
    }));
  };

  renderSearchDropdown = () => {
    const { tablesList } = this.props;
    return (
      <SearchDropdown
        className="optionsItem"
        options={this.getFilterDropdownList(tablesList)}
        onChange={this.props.filterTables}
      />
    );
  }

  renderHeader = () => (
    <span className="pageHeader">
      <span className="title">
        <FormattedMessage defaultMessage="Core Engine" id="core.header" />
      </span>
      <div className="options">
        {this.renderSearchDropdown()}
      </div>
    </span>
  );

  renderContent = () => {
    const { filteredTablesList } = this.props;
    return (
      <div className="content">
        <TablesList tablesList={filteredTablesList} />
      </div>
    );
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="pageContainer coreEngineContainer">
        {this.renderHeader()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

CoreEngine.propTypes = {
  tablesList: PropTypes.arrayOf(TableType).isRequired,
  filteredTablesList: PropTypes.arrayOf(TableType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  filterTables: PropTypes.func.isRequired,
  clearCoreEngine: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

CoreEngine.defaultProps = {
  tablesList: [],
  filteredTablesList: [],
  isLoading: false,
  filterTables: voidFn,
  clearCoreEngine: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  tablesList: getTablesList(state),
  filteredTablesList: getFilteredTablesList(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  filterTables,
  clearCoreEngine,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(CoreEngine);
