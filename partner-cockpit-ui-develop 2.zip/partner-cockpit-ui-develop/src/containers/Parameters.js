import React, { PureComponent } from 'react';
import * as R from 'ramda';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { FormattedMessage } from 'react-intl';
import { Breadcrumb } from 'semantic-ui-react';
import { voidFn } from 'utils/common';
import { ErrorMessage, SearchDropdown, SearchInput } from 'components/common';
import { PARAMETERS, PARAMETERS_TYPES } from 'constants/parameters';
import { APP_PREFIX } from 'constants/common';
import { MENU_ITEMS } from 'constants/menu';
import ParametersOverview from 'components/parameters/overview/ParametersOverview';
import ParametersDetails from 'components/parameters/details/ParametersDetails';
import InstrumentUniverse from 'components/parameters/details/InstrumentUniverse';
import { getError } from 'selectors/parameters';
import { getTablesList } from 'selectors/parametersDetails';
import { getIsin } from 'selectors/parametersUniverse';
import { clearParameters, clearError } from 'actions/parameters';
import { setSearch, clearSearch } from 'actions/parametersUniverse';
import { filterTables } from 'actions/parametersDetails';
import { TableType } from 'components/Types';

export class Parameters extends PureComponent {
  componentWillUnmount() {
    this.props.clearParameters();
  }

  getOverviewBreadcrumbs = () => [
    {
      key: 'Overview',
      content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
      active: true
    }
  ];

  getDetailsBreadcrumbs = () => {
    const { match: { params: { feedName } } } = this.props;
    const selectedParameterName = R.pathOr(
      null,
      [feedName, 'title'],
      PARAMETERS
    );
    return [
      {
        key: 'Overview',
        content: <FormattedMessage defaultMessage="Overview" id="common.breadcrumbs.overview" />,
        active: false,
        as: Link,
        to: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/`
      },
      {
        key: 'Parameter',
        content: selectedParameterName && <FormattedMessage {...selectedParameterName} />,
        active: true
      }
    ];
  };

  getBreadcrumbsSections = () => {
    const { match: { params: { feedName } } } = this.props;
    return R.isNil(feedName)
      ? this.getOverviewBreadcrumbs()
      : this.getDetailsBreadcrumbs();
  }

  getFilterDropdownList = tablesList => {
    return tablesList.map(table => ({
      key: table.id,
      text: table.tableDisplayName,
      value: table.tableName
    }));
  };

  isUniverseFeed = () => {
    const { match: { params: { feedName } } } = this.props;
    return feedName === PARAMETERS_TYPES.INSTRUMENT_UNIVERSE;
  }

  handleParameterTileClick = parameter => this.props.history.push(`/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/${parameter}`);

  renderSearchDropdown = () => {
    const { tablesList } = this.props;
    return (
      <SearchDropdown
        className="optionsItem"
        options={this.getFilterDropdownList(tablesList)}
        onChange={this.props.filterTables}
      />
    );
  }

  renderSearchInput = () => {
    const { isin } = this.props;
    return (
      <SearchInput
        className="optionsItem"
        value={isin}
        onChange={this.props.setSearch}
        onClear={this.props.clearSearch}
      />
    );
  }

  renderOptions = () => (
    <div className="options">
      {this.isUniverseFeed()
        ? this.renderSearchInput()
        : this.renderSearchDropdown()
      }
    </div>
  );

  renderHeader = () => {
    const { match: { params: { feedName } } } = this.props;
    return (
      <span className="pageHeader">
        <span className="title">
          <FormattedMessage defaultMessage="Parameters" id="parameters.header" />
        </span>
        {feedName && this.renderOptions()}
      </span>
    );
  }

  renderBreadcrumbs = () => (
    <Breadcrumb
      className="breadcrumbsContainer"
      icon="right angle"
      sections={this.getBreadcrumbsSections()}
    />
  );

  renderDetails = () => {
    const { match: { params: { feedName } } } = this.props;
    return this.isUniverseFeed()
      ? <InstrumentUniverse feedName={feedName} />
      : <ParametersDetails feedName={feedName} />;
  }

  renderContent = () => {
    const { match: { params: { feedName } } } = this.props;
    return (
      <div className="content">
        {this.renderBreadcrumbs()}
        {R.isNil(feedName)
          ? <ParametersOverview onParameterTileClick={this.handleParameterTileClick} />
          : this.renderDetails()
        }
      </div>
    );
  }

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  render() {
    const { error } = this.props;
    return (
      <div className="pageContainer parametersContainer">
        {this.renderHeader()}
        {this.renderContent()}
        {error !== null && this.renderError()}
      </div>
    );
  }
}

Parameters.propTypes = {
  tablesList: PropTypes.arrayOf(TableType).isRequired,
  isin: PropTypes.string.isRequired,
  error: PropTypes.string,
  clearParameters: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired,
  filterTables: PropTypes.func.isRequired,
  setSearch: PropTypes.func.isRequired,
  clearSearch: PropTypes.func.isRequired,
  match: PropTypes.shape({
    params: PropTypes.shape({
      feedName: PropTypes.string
    }).isRequired
  }).isRequired,
  history: PropTypes.shape({
    push: PropTypes.func.isRequired
  }).isRequired
};

Parameters.defaultProps = {
  tablesList: [],
  clearParameters: voidFn,
  clearError: voidFn,
  filterTables: voidFn,
  setSearch: voidFn,
  clearSearch: voidFn
};

const mapStateToProps = state => ({
  tablesList: getTablesList(state),
  isin: getIsin(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearParameters,
  clearError,
  filterTables,
  setSearch,
  clearSearch
}, dispatch);

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Parameters));
