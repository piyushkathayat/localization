import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Loader } from 'semantic-ui-react';
import * as R from 'ramda';
import { FormattedDate, FormattedMessage } from 'react-intl';
import { voidFn } from 'utils/common';
import { NoResults, ErrorMessage, SearchDropdown } from 'components/common';
import SummaryTable from 'components/summary/SummaryTable';
import {
  setFilter,
  clearSummary,
  clearError
} from 'actions/summary';
import {
  getDate,
  getSummaryInfo,
  getFilteredSummaryInfo,
  getIsLoading,
  getError
} from 'selectors/summary';
import { getCurrency } from 'selectors/serverInfo';
import { SummaryInfoType } from 'components/Types';
import './Summary.css';

export class Summary extends PureComponent {
  componentWillUnmount() {
    this.props.clearSummary();
  }

  getFilterDropdownList = summaryInfo => R.uniq(
    summaryInfo.map(info => ({
      key: info.group,
      text: info.group,
      value: info.group
    }))
  );

  renderSearchDropdown = () => {
    const { summaryInfo } = this.props;
    return (
      <SearchDropdown
        className="optionsItem"
        options={this.getFilterDropdownList(summaryInfo)}
        onChange={this.props.setFilter}
      />
    );
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  renderHeader = () => {
    const { date } = this.props;

    return (
      <span className="pageHeader">
        <span className="title">
          <FormattedMessage defaultMessage="Summary" id="summary.title" />
        </span>
        <div className="options">
          {this.renderSearchDropdown()}
          {date && (
            <div className="optionsItem dateInfo">
              <FormattedDate
                value={new Date(date)}
                year="numeric"
                month="long"
                day="2-digit"
              />
            </div>
          )}
        </div>
      </span>
    );
  }

  renderContent = () => {
    const { filteredSummaryInfo, currency } = this.props;
    return (
      <div className="content">
        {filteredSummaryInfo.length
          ? <SummaryTable summaryInfo={filteredSummaryInfo} currency={currency} />
          : <NoResults />
        }
      </div>
    );
  }

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="pageContainer summaryContainer">
        {this.renderHeader()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

Summary.propTypes = {
  date: PropTypes.string.isRequired,
  currency: PropTypes.string,
  summaryInfo: PropTypes.arrayOf(SummaryInfoType).isRequired,
  filteredSummaryInfo: PropTypes.arrayOf(SummaryInfoType).isRequired,
  isLoading: PropTypes.bool.isRequired,
  error: PropTypes.string,
  setFilter: PropTypes.func.isRequired,
  clearSummary: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

Summary.defaultProps = {
  summaryInfo: [],
  filteredSummaryInfo: [],
  setFilter: voidFn,
  clearSummary: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  date: getDate(state),
  summaryInfo: getSummaryInfo(state),
  currency: getCurrency(state),
  filteredSummaryInfo: getFilteredSummaryInfo(state),
  isLoading: getIsLoading(state),
  error: getError(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  setFilter,
  clearSummary,
  clearError
}, dispatch);

export default connect(mapStateToProps, mapDispatchToProps)(Summary);
