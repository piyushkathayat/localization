import React, { PureComponent } from 'react';
import * as R from 'ramda';
import { Loader } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { ErrorMessage, NoResults } from 'components/common';
import { voidFn } from 'utils/common';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { FormattedMessage } from 'react-intl';
import { bindActionCreators } from 'redux';
import {
  getIsLoading,
  getPromotionDatabases,
  getPromotionError
} from 'selectors/promotion';
import { getServerType } from 'selectors/serverInfo';
import { clearPromotion, clearError } from 'actions/promotion';
import './Promotion.css';
import { PromotionDatabaseType } from 'components/Types';
import PromotedTable from 'components/promotion/PromotedTable';
import PromotionTable from 'components/promotion/PromotionTable';
import { SERVER_TYPES } from 'constants/serverInfo';

export class Promotion extends PureComponent {
  componentWillUnmount() {
    this.props.clearPromotion();
  }

  renderHeader = () => {
    return (
      <div className="pageHeader">
        <span className="title">
          <FormattedMessage defaultMessage="Promotion" id="promotion.header" />
        </span>
      </div>
    );
  };

  renderLoader = () => (
    <div className="loaderContainer">
      <Loader active inline="centered" content="Loading" />
    </div>
  );

  renderError = () => <ErrorMessage message={this.props.error} onDismiss={this.props.clearError} />;

  renderTables = () => {
    const { databases, serverType } = this.props;
    return serverType === SERVER_TYPES.STAGING
      ? <PromotionTable />
      : <PromotedTable databases={databases} />;
  }

  renderContent = () => {
    const { databases } = this.props;
    return !R.isEmpty(databases)
      ? (
        <div className="content">
          {this.renderTables()}
        </div>
      )
      : <NoResults />;
  };

  render() {
    const { isLoading, error } = this.props;
    return (
      <div className="pageContainer promotionContainer">
        {this.renderHeader()}
        {isLoading
          ? this.renderLoader()
          : this.renderContent()
        }
        {error !== null && this.renderError()}
      </div>
    );
  }
}

Promotion.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  databases: PropTypes.objectOf(PromotionDatabaseType).isRequired,
  serverType: PropTypes.string.isRequired,
  error: PropTypes.string,
  clearPromotion: PropTypes.func.isRequired,
  clearError: PropTypes.func.isRequired
};

Promotion.defaultProps = {
  isLoading: false,
  databases: {},
  serverType: '',
  clearPromotion: voidFn,
  clearError: voidFn
};

const mapStateToProps = state => ({
  isLoading: getIsLoading(state),
  databases: getPromotionDatabases(state),
  error: getPromotionError(state),
  serverType: getServerType(state)
});

const mapDispatchToProps = dispatch => bindActionCreators({
  clearPromotion,
  clearError
}, dispatch);

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Promotion));
