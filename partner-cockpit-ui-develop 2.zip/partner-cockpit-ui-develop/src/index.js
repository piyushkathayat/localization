import 'babel-polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import IntlWrapper from 'containers/IntlWrapper';
import App from './App';
import store from './store';

import './resources/semantic/dist/semantic.css';

ReactDOM.render(
  <Provider store={store}>
    <IntlWrapper>
      <App />
    </IntlWrapper>
  </Provider>,
  document.getElementById('root')
);
