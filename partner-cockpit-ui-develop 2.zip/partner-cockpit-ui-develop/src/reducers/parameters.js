import * as R from 'ramda';
import { PARAMETERS } from 'actions/ActionTypes';
import { mergePath } from '@ubs.partner/shared-ui';

const initialState = {
  parameters: {},
  isLoading: true,
  error: null
};

export default function parameters(state = initialState, action) {
  switch (action.type) {
    case PARAMETERS.FETCH.SUCCESS:
      return {
        ...state,
        parameters: R.indexBy(R.prop('feedName'), action.statusesList),
        isLoading: false,
        error: initialState.error
      };
    case PARAMETERS.CHECK_IN.REQUEST:
    case PARAMETERS.CHECK_OUT.REQUEST:
    case PARAMETERS.CANCEL.REQUEST:
      return R.assocPath(
        ['parameters', action.feedName, 'isUpdating'],
        true,
        state
      );
    case PARAMETERS.CHECK_IN.SUCCESS:
    case PARAMETERS.CHECK_OUT.SUCCESS:
    case PARAMETERS.CANCEL.SUCCESS:
      return mergePath(
        ['parameters', action.parameter.feedName],
        {
          ...action.parameter,
          isUpdating: false
        },
        state
      );
    case PARAMETERS.CHECK_IN.FAILURE:
    case PARAMETERS.CHECK_OUT.FAILURE:
    case PARAMETERS.CANCEL.FAILURE:
      return R.assocPath(
        ['parameters', action.feedName, 'isUpdating'],
        false,
        {
          ...state,
          isLoading: false,
          error: action.error
        }
      );
    case PARAMETERS.FETCH.FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.error
      };
    case PARAMETERS.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case PARAMETERS.CLEAR:
      return initialState;
    default:
      return state;
  }
}
