import { PARAMETERS_UNIVERSE } from 'actions/ActionTypes';

const initialState = {
  instrumentsList: [],
  totalCount: 0,
  isin: '',
  currentPage: 1,
  isLoading: true,
  isUpdating: false,
  error: null
};

export default function parametersUniverse(state = initialState, action) {
  switch (action.type) {
    case PARAMETERS_UNIVERSE.PAGE.CHANGE:
      return {
        ...state,
        isUpdating: true,
        currentPage: action.nextPage
      };
    case PARAMETERS_UNIVERSE.SEARCH.SET:
      return {
        ...state,
        isUpdating: true,
        isin: action.isin,
        currentPage: initialState.currentPage
      };
    case PARAMETERS_UNIVERSE.SEARCH.CLEAR:
      return {
        ...state,
        isUpdating: true,
        isin: initialState.isin,
        currentPage: initialState.currentPage
      };
    case PARAMETERS_UNIVERSE.FETCH.SUCCESS:
      return {
        ...state,
        instrumentsList: action.data.instruments,
        totalCount: action.data.count,
        isLoading: false,
        isUpdating: false,
        error: initialState.error
      };
    case PARAMETERS_UNIVERSE.FETCH.FAILURE:
      return {
        ...initialState,
        isLoading: false,
        isUpdating: false,
        error: action.error
      };
    case PARAMETERS_UNIVERSE.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case PARAMETERS_UNIVERSE.CLEAR:
      return initialState;
    default:
      return state;
  }
}
