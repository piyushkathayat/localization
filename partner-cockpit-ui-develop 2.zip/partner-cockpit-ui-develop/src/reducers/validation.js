import * as R from 'ramda';
import {
  VALIDATION,
  VALIDATION_OVERVIEW,
  VALIDATION_DETAILS,
  BROKERAGE_DETAILS
} from 'actions/ActionTypes';
import { getLatestLoadDecisionId } from 'selectors/validation';
import { SORT_DIRECTIONS } from 'constants/common';
import { getNewSorting } from 'utils/common';

const initialState = {
  decisions: {},
  selectedDecisionId: null,
  search: '',
  sorting: {
    sortBy: '',
    sortDirection: SORT_DIRECTIONS.ASC
  },
  isLoading: true,
  error: null
};

const latestLoadLens = validationState => R.lensPath([
  'decisions',
  getLatestLoadDecisionId({ validation: validationState })
]);

export default function validation(state = initialState, action) {
  switch (action.type) {
    case VALIDATION.FETCH.SUCCESS:
      return {
        ...state,
        decisions: R.indexBy(R.prop('decisionId'), action.decisions),
        selectedDecisionId: action.selectedDecisionId,
        isLoading: false,
        error: initialState.error
      };
    case VALIDATION.FETCH.FAILURE:
      return {
        ...initialState,
        decisions: initialState.decisions,
        selectedDecisionId: initialState.selectedDecisionId,
        isLoading: false,
        error: action.error
      };
    case VALIDATION.DECISION.SELECT:
      return {
        ...state,
        selectedDecisionId: action.decisionId
      };
    case VALIDATION.DECISION.RECALCULATE.REQUEST:
    case VALIDATION.DECISION.VALIDATE.REQUEST:
      return R.over(
        latestLoadLens(state),
        R.assoc(
          'isFreezed',
          true
        ),
        state
      );
    case VALIDATION.DECISION.RECALCULATE.FAILURE:
    case VALIDATION.DECISION.VALIDATE.FAILURE:
      return R.over(
        latestLoadLens(state),
        R.assoc(
          'isFreezed',
          false
        ),
        {
          ...state,
          error: action.error
        }
      );
    case VALIDATION.SOCKET.IN_PROGRESS:
      return R.over(
        latestLoadLens(state),
        R.assoc(
          'statusId',
          action.message.decision_status
        ),
        state
      );
    case VALIDATION.SOCKET.FINISHED:
      return R.over(
        latestLoadLens(state),
        R.mergeDeepLeft({ statusId: action.message.decision_status, isFreezed: false }),
        state
      );
    case VALIDATION.SOCKET.FAILED:
      return R.over(
        latestLoadLens(state),
        R.mergeDeepLeft({ statusId: action.message.decision_status, isFreezed: false }),
        {
          ...state,
          error: action.message.description
        }
      );
    case VALIDATION.SEARCH.SET:
      return {
        ...state,
        search: action.search
      };
    case VALIDATION.SEARCH.CLEAR:
      return {
        ...state,
        search: initialState.search
      };
    case VALIDATION.SORT_BY: {
      const { sorting: { sortBy, sortDirection } } = state;
      const newSorting = getNewSorting({
        initialSorting: initialState.sorting,
        oldSortBy: sortBy,
        oldSortDirection: sortDirection,
        newSortBy: action.sortBy
      });
      return {
        ...state,
        sorting: newSorting
      };
    }
    case VALIDATION.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case VALIDATION_DETAILS.CLEAR:
    case BROKERAGE_DETAILS.CLEAR:
      return {
        ...state,
        search: initialState.search,
        sorting: initialState.sorting
      };
    case VALIDATION_OVERVIEW.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case VALIDATION.CLEAR:
      return initialState;
    default:
      return state;
  }
}
