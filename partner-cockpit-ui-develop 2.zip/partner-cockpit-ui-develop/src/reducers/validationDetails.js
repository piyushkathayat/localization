import * as R from 'ramda';
import { VALIDATION_DETAILS } from 'actions/ActionTypes';

const initialState = {
  decisionItems: {},
  decisionItemsIds: [],
  approvalStatuses: [],
  decisionLevel: null,
  decisionGroup: null,
  qualityCheckName: null,
  isLoading: true,
  isUpdating: false,
  error: null
};

export default function validationDetails(state = initialState, action) {
  switch (action.type) {
    case VALIDATION_DETAILS.FETCH.SUCCESS:
      return {
        ...state,
        decisionItems: action.decisionItems,
        decisionItemsIds: action.decisionItemsIds,
        approvalStatuses: action.approvalStatuses,
        decisionLevel: action.decisionLevel,
        decisionGroup: action.decisionGroup,
        qualityCheckName: action.qualityCheckName,
        isLoading: false,
        error: initialState.error
      };
    case VALIDATION_DETAILS.FETCH.FAILURE:
      return {
        ...initialState,
        isLoading: false,
        error: action.error
      };
    case VALIDATION_DETAILS.UPDATE.REQUEST:
      return {
        ...state,
        isUpdating: true,
        error: initialState.error
      };
    case VALIDATION_DETAILS.UPDATE.SUCCESS:
      return R.reduce(
        (nextState, decisionItemId) => ({
          ...nextState,
          decisionItems: {
            ...nextState.decisionItems,
            [decisionItemId]: {
              ...nextState.decisionItems[decisionItemId],
              approvalStatus: action.updatedDecisions.approvalStatusId,
              commentLast: action.updatedDecisions.comment,
              confirmedBy: action.updatedDecisions.confirmedBy
            }
          }
        }),
        { ...state, isUpdating: false, error: initialState.error },
        action.updatedDecisions.decisionItemsIds
      );
    case VALIDATION_DETAILS.PORTFOLIOS.FETCH.SUCCESS:
      return R.assocPath(
        [
          'decisionItems',
          action.decisionItemId,
          'portfoliosList'
        ],
        action.portfoliosList,
        state
      );
    case VALIDATION_DETAILS.UPDATE.FAILURE:
    case VALIDATION_DETAILS.PORTFOLIOS.FETCH.FAILURE:
      return {
        ...state,
        isUpdating: false,
        error: action.error
      };
    case VALIDATION_DETAILS.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case VALIDATION_DETAILS.CLEAR:
      return initialState;
    default:
      return state;
  }
}
