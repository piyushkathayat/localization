import * as R from 'ramda';
import { LOAD_AND_QA } from 'actions/ActionTypes';

const initialState = {
  activities: {},
  activitiesIds: [],
  isLoading: true,
  error: null,
  jobs: {},
  isJobStarting: false
};

const extendActivityWithId = activity =>
  R.assoc('id', `${activity.activityId}-${activity.activityOwner}`)(activity);

export default function loadAndQA(state = initialState, action) {
  switch (action.type) {
    case LOAD_AND_QA.FETCH.SUCCESS: {
      const activities = R.compose(
        R.indexBy(R.prop('id')),
        R.map(activity => extendActivityWithId(activity))
      )(action.activities);

      return {
        ...state,
        activities,
        activitiesIds: R.keys(activities),
        isLoading: false,
        error: initialState.error
      };
    }
    case LOAD_AND_QA.FETCH.FAILURE:
      return {
        ...state,
        activities: initialState.activities,
        isLoading: false,
        error: action.error
      };
    case LOAD_AND_QA.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case LOAD_AND_QA.JOBS.FETCH.SUCCESS:
      return {
        ...state,
        jobs: action.jobs
      };
    case LOAD_AND_QA.JOBS.FETCH.FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.error
      };
    case LOAD_AND_QA.JOBS.START: {
      return {
        ...state,
        isJobStarting: true
      };
    }
    case LOAD_AND_QA.JOBS.FAILURE:
      return {
        ...state,
        isJobStarting: false,
        error: action.error
      };
    case LOAD_AND_QA.SOCKET.IN_PROGRESS: {
      if (Object.keys(state.activities).length) {
        const parsedActivities = R.compose(
          R.map(JSON.parse),
          R.path(['message', 'activities'])
        )(action);

        const runningActivities = R.compose(
          R.indexBy(R.prop('id')),
          R.map(
            R.compose(
              activity => R.mergeRight(state.activities[activity.id], activity),
              activity => extendActivityWithId(activity)
            )
          )
        )(parsedActivities);

        const waitingForNewActivityKey = R.equals(
          R.pluck('activityKey', parsedActivities),
          R.pluck('activityKey', Object.values(state.activities))
        );

        return {
          ...state,
          isJobStarting: state.isJobStarting && waitingForNewActivityKey,
          activities: R.mergeRight(state.activities, runningActivities)
        };
      }
      return state;
    }
    case LOAD_AND_QA.SOCKET.FINISHED:
      return {
        ...state,
        isJobStarting: false
      };
    case LOAD_AND_QA.SOCKET.FAILED:
      return {
        ...state,
        isJobStarting: false,
        error: action.message.message
      };
    case LOAD_AND_QA.CLEAR:
      return initialState;
    default:
      return state;
  }
}
