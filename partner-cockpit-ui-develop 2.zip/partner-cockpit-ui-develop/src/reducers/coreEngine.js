import { CORE_ENGINE } from 'actions/ActionTypes';

const initialState = {
  tablesList: [],
  filter: [],
  isLoading: true,
  error: null
};

export default function coreEngine(state = initialState, action) {
  switch (action.type) {
    case CORE_ENGINE.FILTER:
      return {
        ...state,
        filter: action.filter
      };
    case CORE_ENGINE.FETCH.SUCCESS:
      return {
        ...state,
        tablesList: action.tablesList,
        isLoading: false,
        error: initialState.error
      };
    case CORE_ENGINE.FETCH.FAILURE:
      return {
        ...state,
        tablesList: [],
        isLoading: false,
        error: action.error
      };
    case CORE_ENGINE.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case CORE_ENGINE.CLEAR:
      return initialState;
    default:
      return state;
  }
}
