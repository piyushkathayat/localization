import * as R from 'ramda';
import { LOAD_AND_QA_DRILLDOWN } from 'actions/ActionTypes';

const initialState = {
  drilldowns: [],
  dbType: '',
  drilldownType: '',
  isLoading: true,
  error: null
};

export const isFileLoadingLens = (state, drilldownId) => R.lensPath([
  'drilldowns',
  R.findIndex(
    drilldown => drilldown.drilldownId === drilldownId,
    R.prop('drilldowns', state)
  ),
  'isFileLoading'
]);

export default function loadAndQADrilldown(state = initialState, action) {
  switch (action.type) {
    case LOAD_AND_QA_DRILLDOWN.FETCH.SUCCESS:
      return {
        ...state,
        drilldowns: action.drilldowns,
        dbType: action.dbType,
        drilldownType: action.drilldownType,
        isLoading: false,
        error: initialState.error
      };
    case LOAD_AND_QA_DRILLDOWN.FETCH.FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.error
      };
    case LOAD_AND_QA_DRILLDOWN.FILE.REQUEST:
      return R.set(
        isFileLoadingLens(state, action.drilldownId),
        true,
        state
      );
    case LOAD_AND_QA_DRILLDOWN.FILE.SUCCESS:
      return R.set(
        isFileLoadingLens(state, action.drilldownId),
        false,
        state
      );
    case LOAD_AND_QA_DRILLDOWN.FILE.FAILURE:
      return R.set(
        isFileLoadingLens(state, action.drilldownId),
        false,
        {
          ...state,
          error: action.error
        }
      );
    case LOAD_AND_QA_DRILLDOWN.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case LOAD_AND_QA_DRILLDOWN.CLEAR:
      return initialState;
    default:
      return state;
  }
}
