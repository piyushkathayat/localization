import * as R from 'ramda';
import { SERVER_INFO } from 'actions/ActionTypes';

const initialState = {
  serverType: '',
  centralDBKey: 'central',
  partnerDBKey: '',
  currency: '',
  environment: '',
  loggedInUser: '',
  layersInfo: {},
  features: {},
  isLoading: true,
  error: null
};

export default function serverInfo(state = initialState, action) {
  switch (action.type) {
    case SERVER_INFO.FETCH.SUCCESS:
      return {
        ...state,
        serverType: action.data.serverType,
        partnerDBKey: action.data.activityOwner,
        currency: action.data.currency,
        environment: action.data.environment,
        loggedInUser: action.data.loggedInUserId,
        layersInfo: {
          ...action.data.version,
          ui: {
            version: process.env.REACT_APP_VERSION
          }
        },
        features: R.indexBy(R.prop('name'), action.data.features || []),
        isLoading: false,
        error: initialState.error
      };
    case SERVER_INFO.FETCH.FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.error
      };
    case SERVER_INFO.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case SERVER_INFO.SERVER_TYPE.CHANGE:
      return {
        ...state,
        serverType: action.serverType
      };
    default:
      return state;
  }
}
