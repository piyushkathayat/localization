import * as R from 'ramda';
import { VALIDATION, VALIDATION_OVERVIEW } from 'actions/ActionTypes';

const initialState = {
  decisionsOverview: {},
  isLoading: true,
  error: null
};

export default function validationOverview(state = initialState, action) {
  switch (action.type) {
    case VALIDATION_OVERVIEW.FETCH.SUCCESS:
      return {
        ...state,
        decisionsOverview: R.indexBy(R.prop('decisionId'), action.decisionsList),
        isLoading: false,
        error: initialState.error
      };
    case VALIDATION.FETCH.FAILURE:
      return {
        ...state,
        decisionsOverview: initialState.decisionsOverview,
        isLoading: false,
        error: action.error
      };
    case VALIDATION_OVERVIEW.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case VALIDATION_OVERVIEW.CLEAR:
      return initialState;
    default:
      return state;
  }
}
