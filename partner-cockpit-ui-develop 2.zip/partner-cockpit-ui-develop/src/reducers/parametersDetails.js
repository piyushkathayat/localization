import { PARAMETERS_DETAILS } from 'actions/ActionTypes';

const initialState = {
  tablesList: [],
  filter: [],
  isLoading: true,
  error: null
};

export default function parametersDetails(state = initialState, action) {
  switch (action.type) {
    case PARAMETERS_DETAILS.FETCH.SUCCESS:
      return {
        ...state,
        tablesList: action.tablesList,
        isLoading: false,
        error: initialState.error
      };
    case PARAMETERS_DETAILS.FETCH.FAILURE:
      return {
        ...initialState,
        isLoading: false,
        error: action.error
      };
    case PARAMETERS_DETAILS.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case PARAMETERS_DETAILS.FILTER:
      return {
        ...state,
        filter: action.filter
      };
    case PARAMETERS_DETAILS.CLEAR:
      return initialState;
    default:
      return state;
  }
}
