import { SUMMARY } from 'actions/ActionTypes';
import { SUMMARY_INFO } from 'constants/summary';

const initialState = {
  summaryInfo: [],
  date: '',
  filter: [],
  isLoading: true,
  error: null
};

const sortSummary = (summaryInfo = []) => summaryInfo.sort((a, b) => {
  if (!SUMMARY_INFO[a.type]) {
    return 1;
  }
  if (!SUMMARY_INFO[b.type]) {
    return -1;
  }
  return SUMMARY_INFO[a.type].sortOrder - SUMMARY_INFO[b.type].sortOrder;
});

export default function summary(state = initialState, action) {
  switch (action.type) {
    case SUMMARY.FETCH.SUCCESS:
      return {
        ...state,
        summaryInfo: sortSummary(action.data.summary),
        date: action.data.lastDate,
        isLoading: false,
        error: initialState.error
      };
    case SUMMARY.FETCH.FAILURE:
      return {
        ...initialState,
        isLoading: false,
        error: action.error
      };
    case SUMMARY.FILTER:
      return {
        ...state,
        filter: action.filter
      };
    case SUMMARY.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case SUMMARY.CLEAR:
      return initialState;
    default:
      return state;
  }
}
