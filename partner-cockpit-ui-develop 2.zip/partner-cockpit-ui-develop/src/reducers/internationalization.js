import LOCALE from '../constants/locale';
import { getSelectedLanguage } from '../utils/common';

const defaultState = {
  locale: getSelectedLanguage()
};

const internationalization = (state = defaultState, action) => {
  switch (action.type) {
    case LOCALE.SWITCH:
      return {
        ...state,
        ...action.details
      };
    default:
      return state;
  }
};

export default internationalization;
