import { LOGGER } from 'actions/ActionTypes';
import logger from '../logger';

const getInitialState = () => ({
  json: [],
  issueIdsOptions: [],
  isLoading: false,
  isUpdating: false,
  error: null
});

const jsonSample = [
  {
    data: {
      '@mt': 'Remediation starting for portfolio {AssetId} where profile is {ClientProfile}, SAA is {SAA_Id} {SAA_Name}',
      AssetId: 1041845,
      ClientProfile: null,
      SAA_Id: 502,
      SAA_Name: 'Prof Desk'
    }
  },
  {
    data: {
      '@mt': 'Remediation finished in {elapsedTotalSeconds}',
      elapsedTotalSeconds: 0.4360424
    }
  }
];

const issueIdsOptionsSample = [
  {
    key: 0,
    text: 'Strategic Asset Allocation - -101',
    value: -101
  },
  {
    key: 1,
    text: 'Strategic Asset Allocation - -102',
    value: -102
  },
  {
    key: 2,
    text: 'Bulk Risk - 54',
    value: 54
  }
];

describe('logger reducer', () => {
  it('Should set initial state', () => {
    // given
    const currentState = undefined;
    const action = {
      type: null
    };
    const expectedResult = getInitialState();

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.JSON.FETCH.REQUEST', () => {
    // given
    const currentState = {
      ...getInitialState(),
      json: jsonSample,
      error: 'some error'
    };
    const action = {
      type: LOGGER.JSON.FETCH.REQUEST
    };
    const expectedResult = {
      ...currentState,
      json: getInitialState().json,
      isUpdating: true,
      error: getInitialState().error
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.JSON.FETCH.SUCCESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isUpdating: true,
      error: 'some error'
    };
    const action = {
      type: LOGGER.JSON.FETCH.SUCCESS,
      json: jsonSample
    };
    const expectedResult = {
      ...currentState,
      json: jsonSample,
      isUpdating: false,
      error: getInitialState().error
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.JSON.FETCH.FAILURE', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isUpdating: true
    };
    const action = {
      type: LOGGER.JSON.FETCH.FAILURE,
      error: 'some error'
    };
    const expectedResult = {
      ...currentState,
      json: getInitialState().json,
      isUpdating: false,
      error: 'some error'
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.ISSUE_IDS.FETCH.REQUEST', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOGGER.ISSUE_IDS.FETCH.REQUEST
    };
    const expectedResult = {
      ...currentState,
      isLoading: true,
      error: getInitialState().error
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.ISSUE_IDS.FETCH.SUCCESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isLoading: true
    };
    const action = {
      type: LOGGER.ISSUE_IDS.FETCH.SUCCESS,
      issueIdsOptions: issueIdsOptionsSample
    };
    const expectedResult = {
      ...currentState,
      issueIdsOptions: issueIdsOptionsSample,
      isLoading: false
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.ISSUE_IDS.FETCH.FAILURE', () => {
    // given
    const currentState = {
      ...getInitialState(),
      issueIdsOptions: issueIdsOptionsSample,
      isLoading: true
    };
    const action = {
      type: LOGGER.ISSUE_IDS.FETCH.FAILURE,
      error: 'some error'
    };
    const expectedResult = {
      ...currentState,
      issueIdsOptions: getInitialState().issueIdsOptions,
      isLoading: false,
      error: 'some error'
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.ISSUE_IDS.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      issueIdsOptions: issueIdsOptionsSample
    };
    const action = {
      type: LOGGER.ISSUE_IDS.CLEAR
    };
    const expectedResult = {
      ...currentState,
      issueIdsOptions: getInitialState().issueIdsOptions
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.ERROR.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOGGER.ERROR.CLEAR
    };
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOGGER.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      json: jsonSample
    };
    const action = {
      type: LOGGER.CLEAR
    };
    const expectedResult = getInitialState();

    // when
    const result = logger(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });
});
