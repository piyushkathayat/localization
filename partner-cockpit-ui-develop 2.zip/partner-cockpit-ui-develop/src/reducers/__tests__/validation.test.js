import { VALIDATION } from 'actions/ActionTypes';
import { SORT_DIRECTIONS } from 'constants/common';
import validation from '../validation';

// TODO: update

const getInitialState = () => ({
  decisions: {},
  selectedDecisionId: null,
  search: '',
  sorting: {
    sortBy: '',
    sortDirection: SORT_DIRECTIONS.ASC
  },
  isLoading: true,
  error: null
});

const decisionsSample = [
  {
    decisionId: 25,
    date: '2018-12-06T00:00:00',
    statusId: 110,
    isLatestLoad: true
  },
  {
    decisionId: 23,
    date: '2018-11-28T00:00:00',
    statusId: 170,
    isLatestLoad: false
  },
  {
    decisionId: 14,
    date: '2018-11-26T00:00:00',
    statusId: 100,
    isLatestLoad: false
  },
  {
    decisionId: 13,
    date: '2018-11-23T00:00:00',
    statusId: 170,
    isLatestLoad: false
  }
];

const indexedDecisionsSample = {
  25: {
    decisionId: 25,
    date: '2018-12-06T00:00:00',
    statusId: 110,
    isLatestLoad: true
  },
  23: {
    decisionId: 23,
    date: '2018-11-28T00:00:00',
    statusId: 170,
    isLatestLoad: false
  },
  14: {
    decisionId: 14,
    date: '2018-11-26T00:00:00',
    statusId: 100,
    isLatestLoad: false
  },
  13: {
    decisionId: 13,
    date: '2018-11-23T00:00:00',
    statusId: 170,
    isLatestLoad: false
  }
};

describe('validation reducer', () => {
  xit('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = validation(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  xit('Should set decisions', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: VALIDATION.FETCH.SUCCESS,
      decisions: decisionsSample,
      selectedDecisionId: 25
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: indexedDecisionsSample,
      selectedDecisionId: 25,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: VALIDATION.FETCH.FAILURE,
      error: 'some error'
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: getInitialState().decisions,
      selectedDecisionId: getInitialState().selectedDecisionId,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: VALIDATION.ERROR.CLEAR
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      decisions: indexedDecisionsSample,
      selectedDecisionId: 25,
      isLoading: false
    };
    const action = {
      type: VALIDATION.CLEAR
    };
    const result = validation(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  xit('Should select decision', () => {
    const currentState = getInitialState();
    const action = {
      type: VALIDATION.DECISION.SELECT,
      decisionId: 23
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      selectedDecisionId: 23
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should change isFreezed field of released decision (the latest one) to true', () => {
    const currentState = {
      ...getInitialState(),
      decisions: indexedDecisionsSample,
      selectedDecisionId: 25
    };
    const action = {
      type: VALIDATION.DECISION.VALIDATE.REQUEST
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: {
        ...currentState.decisions,
        25: {
          ...currentState.decisions['25'],
          isFreezed: true
        }
      }
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should set isFreezed field to false in case of failure', () => {
    const currentState = {
      ...getInitialState(),
      decisions: indexedDecisionsSample,
      selectedDecisionId: 25
    };
    const action = {
      type: VALIDATION.DECISION.VALIDATE.FAILURE,
      error: 'some error'
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: {
        ...currentState.decisions,
        25: {
          ...currentState.decisions['25'],
          isFreezed: false
        }
      },
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should set statusId during the release process', () => {
    const currentState = {
      ...getInitialState(),
      decisions: indexedDecisionsSample,
      selectedDecisionId: 25
    };
    const action = {
      type: VALIDATION.SOCKET.IN_PROGRESS,
      message: {
        decision_status: 120
      }
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: {
        ...currentState.decisions,
        25: {
          ...currentState.decisions['25'],
          statusId: 120
        }
      }
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should set statusId and isFreezed on the release process finish', () => {
    const currentState = {
      ...getInitialState(),
      decisions: {
        ...indexedDecisionsSample,
        25: {
          ...indexedDecisionsSample['25'],
          isFreezed: true
        }
      },
      selectedDecisionId: 25
    };
    const action = {
      type: VALIDATION.SOCKET.FINISHED,
      message: {
        decision_status: 170
      }
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: {
        ...currentState.decisions,
        25: {
          ...currentState.decisions['25'],
          statusId: 170,
          isFreezed: false
        }
      }
    };
    expect(result).toEqual(expectedResult);
  });

  xit('Should set statusId and isFreezed on the release process failure', () => {
    const currentState = {
      ...getInitialState(),
      decisions: {
        ...indexedDecisionsSample,
        25: {
          ...indexedDecisionsSample['25'],
          isFreezed: true
        }
      },
      selectedDecisionId: 25
    };
    const action = {
      type: VALIDATION.SOCKET.FAILED,
      message: {
        decision_status: 255,
        description: 'some error'
      }
    };
    const result = validation(currentState, action);
    const expectedResult = {
      ...currentState,
      decisions: {
        ...currentState.decisions,
        25: {
          ...currentState.decisions['25'],
          statusId: 255,
          isFreezed: false
        }
      },
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });
});
