import { PARAMETERS_UNIVERSE } from 'actions/ActionTypes';
import parametersUniverse from '../parametersUniverse';

const getInitialState = () => ({
  instrumentsList: [],
  totalCount: 0,
  isin: '',
  currentPage: 1,
  isLoading: true,
  isUpdating: false,
  error: null
});

const instrumentsListSample = [
  {
    buy: false,
    comment: '0558902',
    instrumentName: 'A SCHLUMBERGER LTD.',
    isin: 'AN8068571086',
    lastUpdate: null,
    location: null,
    orgUnit: null,
    provider: null,
    ranking: 3,
    tradingCurrency: 'USD'
  },
  {
    buy: false,
    comment: '1024790',
    instrumentName: 'O AUSTRIA REPUBLIC 97-27',
    isin: 'AT0000383864',
    lastUpdate: null,
    location: null,
    orgUnit: null,
    provider: null,
    ranking: 4,
    tradingCurrency: 'EUR'
  },
  {
    buy: false,
    comment: '1049697',
    instrumentName: 'O AUSTRIA REPUBLIC 05-21',
    isin: 'AT0000A001X2',
    lastUpdate: null,
    location: null,
    orgUnit: null,
    provider: null,
    ranking: 2,
    tradingCurrency: 'EUR'
  }
];

describe('parametersUniverse reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set instrumentsList', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PARAMETERS_UNIVERSE.FETCH.SUCCESS,
      data: {
        instruments: instrumentsListSample,
        count: 3
      }
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = {
      ...currentState,
      instrumentsList: instrumentsListSample,
      totalCount: 3,
      isLoading: false,
      isUpdating: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: PARAMETERS_UNIVERSE.FETCH.FAILURE,
      error: 'some error'
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = {
      ...currentState,
      isLoading: false,
      isUpdating: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PARAMETERS_UNIVERSE.ERROR.CLEAR
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      instrumentsList: instrumentsListSample,
      totalCount: 3,
      isUpdating: false,
      isLoading: false
    };
    const action = {
      type: PARAMETERS_UNIVERSE.CLEAR
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set page number', () => {
    const currentState = {
      ...getInitialState(),
      instrumentsList: instrumentsListSample,
      totalCount: 3,
      currentPage: 1,
      isUpdating: false,
      isLoading: false
    };
    const action = {
      type: PARAMETERS_UNIVERSE.PAGE.CHANGE,
      nextPage: 2
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = {
      ...currentState,
      currentPage: 2,
      isUpdating: true
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set search', () => {
    const currentState = getInitialState();
    const action = {
      type: PARAMETERS_UNIVERSE.SEARCH.SET,
      isin: 'some isin'
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = {
      ...currentState,
      isUpdating: true,
      isin: 'some isin'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear search', () => {
    const currentState = {
      ...getInitialState(),
      isin: 'some isin',
      currentPage: 2
    };
    const action = {
      type: PARAMETERS_UNIVERSE.SEARCH.CLEAR
    };
    const result = parametersUniverse(currentState, action);
    const expectedResult = {
      ...currentState,
      isin: getInitialState().isin,
      currentPage: getInitialState().currentPage,
      isUpdating: true
    };
    expect(result).toEqual(expectedResult);
  });
});
