import { CORE_ENGINE } from 'actions/ActionTypes';
import coreEngine from '../coreEngine';

const getInitialState = () => ({
  tablesList: [],
  filter: [],
  isLoading: true,
  error: null
});

const tablesListSample = [
  {
    id: 0,
    tableData: [],
    tableDisplayName: 'allowed_document_language',
    tableName: 'allowed_document_language'
  },
  {
    id: 1,
    tableData: [
      {
        description: 'Disable final report',
        flag: true,
        short_code: 'disableFinalReport'
      },
      {
        description: 'Display Custody Account',
        flag: false,
        short_code: 'displayCustodyAccount'
      }
    ],
    tableDisplayName: 'application',
    tableName: 'application'
  },
  {
    id: 2,
    tableData: [],
    tableDisplayName: 'cortex_extract',
    tableName: 'cortex_extract'
  }
];

describe('coreEngine reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = coreEngine(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set tables list', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: CORE_ENGINE.FETCH.SUCCESS,
      tablesList: tablesListSample
    };
    const result = coreEngine(currentState, action);
    const expectedResult = {
      ...currentState,
      tablesList: tablesListSample,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set filter', () => {
    const currentState = {
      ...getInitialState(),
      tablesList: tablesListSample
    };
    const action = {
      type: CORE_ENGINE.FILTER,
      filter: ['cortex_extract']
    };
    const result = coreEngine(currentState, action);
    const expectedResult = {
      ...currentState,
      filter: ['cortex_extract']
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: CORE_ENGINE.FETCH.FAILURE,
      error: 'some error'
    };
    const result = coreEngine(currentState, action);
    const expectedResult = {
      ...currentState,
      tablesList: getInitialState().tablesList,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: CORE_ENGINE.ERROR.CLEAR
    };
    const result = coreEngine(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      tablesList: tablesListSample,
      filter: ['cortex_extract'],
      isLoading: false
    };
    const action = {
      type: CORE_ENGINE.CLEAR
    };
    const result = coreEngine(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });
});
