import { SERVER_INFO } from 'actions/ActionTypes';
import serverInfo from '../serverInfo';

const getInitialState = () => ({
  serverType: '',
  centralDBKey: 'central',
  partnerDBKey: '',
  currency: '',
  environment: '',
  loggedInUser: '',
  layersInfo: {},
  features: {},
  isLoading: true,
  error: null
});

const serverInfoSample = {
  activityOwner: 'WS004',
  currency: 'EUR',
  environment: 'T',
  loggedInUserId: '00355799',
  serverType: 'STAGING',
  version: {
    database: {
      version: '2.0.1',
      deploymentStartDate: '2018-12-06T00:00:00',
      deploymentEndDate: '2018-12-06T00:00:00'
    },
    cockpitService: {
      version: '2.0.2',
      buildDate: '2018-12-06T00:00:00'
    },
    gatewayService: {
      version: '2.0.3',
      buildDate: '2018-12-06T00:00:00'
    }
  },
  features: [
    {
      name: 'brokerage',
      isEnabled: true
    }
  ]
};

describe('serverInfo reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = serverInfo(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set server info', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    process.env.REACT_APP_VERSION = '2.0.4';
    const action = {
      type: SERVER_INFO.FETCH.SUCCESS,
      data: serverInfoSample
    };
    const result = serverInfo(currentState, action);
    const expectedResult = {
      ...currentState,
      serverType: serverInfoSample.serverType,
      partnerDBKey: serverInfoSample.activityOwner,
      currency: serverInfoSample.currency,
      environment: serverInfoSample.environment,
      loggedInUser: serverInfoSample.loggedInUserId,
      layersInfo: {
        ...serverInfoSample.version,
        ui: {
          version: '2.0.4'
        }
      },
      features: {
        brokerage: {
          name: 'brokerage',
          isEnabled: true
        }
      },
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: SERVER_INFO.FETCH.FAILURE,
      error: 'some error'
    };
    const result = serverInfo(currentState, action);
    const expectedResult = {
      ...currentState,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: SERVER_INFO.ERROR.CLEAR
    };
    const result = serverInfo(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should change serverType', () => {
    const currentState = {
      ...getInitialState(),
      serverType: serverInfoSample.serverType,
      partnerDBKey: serverInfoSample.activityOwner,
      currency: serverInfoSample.currency,
      environment: serverInfoSample.environment,
      loggedInUser: serverInfoSample.loggedInUserId,
      isLoading: false,
      error: getInitialState().error
    };
    const action = {
      type: SERVER_INFO.SERVER_TYPE.CHANGE,
      serverType: 'LIVE'
    };
    const result = serverInfo(currentState, action);
    const expectedResult = {
      ...currentState,
      serverType: 'LIVE'
    };
    expect(result).toEqual(expectedResult);
  });
});
