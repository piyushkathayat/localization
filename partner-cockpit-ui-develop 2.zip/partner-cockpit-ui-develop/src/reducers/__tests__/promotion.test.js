import { PROMOTION } from 'actions/ActionTypes';
import promotion from '../promotion';

const getInitialState = () => ({
  databases: {},
  dependencies: [],
  isPromotionRunning: false,
  lastPromotionDate: '',
  status: '',
  error: null,
  canPromote: false,
  isLoading: true
});

const responseSample = {
  canPromote: true,
  databases: [
    {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T08:43:49.773',
      id: 3,
      internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
      internalName: 'Unbundling',
      isDirty: false,
      isMarkedForPromotion: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      name: 'UNBUNDLING',
      source: 'NZUR18125DSQ'
    },
    {
      comment: 'This database is marked for autopromotion on the Live DB.',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '00355799',
      creationDate: '2019-01-16T05:00:20.783',
      id: 4,
      internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
      internalName: 'BBS',
      isDirty: false,
      isMarkedForPromotion: false,
      isOldDatabase: false,
      isPromotedToLive: true,
      isUsedInLoadOnStaging: true,
      name: 'BBS',
      source: 'NZUR18125DSQ'
    },
    {
      comment: '',
      commentAuthor: '',
      commentDate: '',
      confirmedBy: '',
      creationDate: '2019-01-16T08:53:35.09',
      id: 15,
      internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
      internalName: 'LK',
      isDirty: false,
      isMarkedForPromotion: false,
      isOldDatabase: false,
      isPromotedToLive: false,
      isUsedInLoadOnStaging: true,
      name: 'Lookup Tables',
      source: 'NZUR18130DSQ'
    }
  ],
  dependencies: [
    {
      databaseId: 3,
      dependents: [15]
    },
    {
      databaseId: 4,
      dependents: []
    },
    {
      databaseId: 15,
      dependents: []
    }
  ],
  isPromotionRunning: true,
  lastPromotionDate: '2018-10-23T16:33:21.08',
  status: null
};

const indexedDatabasesSample = {
  3: {
    comment: 'This database is marked for autopromotion on the Live DB.',
    commentAuthor: '',
    commentDate: '',
    confirmedBy: '00355799',
    creationDate: '2019-01-16T08:43:49.773',
    id: 3,
    internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
    internalName: 'Unbundling',
    isDirty: false,
    isMarkedForPromotion: false,
    isOldDatabase: false,
    isPromotedToLive: true,
    isUsedInLoadOnStaging: true,
    name: 'UNBUNDLING',
    source: 'NZUR18125DSQ'
  },
  4: {
    comment: 'This database is marked for autopromotion on the Live DB.',
    commentAuthor: '',
    commentDate: '',
    confirmedBy: '00355799',
    creationDate: '2019-01-16T05:00:20.783',
    id: 4,
    internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
    internalName: 'BBS',
    isDirty: false,
    isMarkedForPromotion: false,
    isOldDatabase: false,
    isPromotedToLive: true,
    isUsedInLoadOnStaging: true,
    name: 'BBS',
    source: 'NZUR18125DSQ'
  },
  15: {
    comment: '',
    commentAuthor: '',
    commentDate: '',
    confirmedBy: '',
    creationDate: '2019-01-16T08:53:35.09',
    id: 15,
    internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
    internalName: 'LK',
    isDirty: false,
    isMarkedForPromotion: false,
    isOldDatabase: false,
    isPromotedToLive: false,
    isUsedInLoadOnStaging: true,
    name: 'Lookup Tables',
    source: 'NZUR18130DSQ'
  }
};

describe('promotion reducer', () => {
  it('Should set initial state', () => {
    // given
    const currentState = undefined;
    const action = {
      type: null
    };
    const expectedState = getInitialState();

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.FETCH.SUCCESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PROMOTION.FETCH.SUCCESS,
      promotion: responseSample
    };
    const expectedState = {
      ...currentState,
      ...action.promotion,
      databases: indexedDatabasesSample,
      isLoading: false,
      error: getInitialState().error
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.FETCH.FAILURE', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isLoading: true
    };
    const action = {
      type: PROMOTION.FETCH.FAILURE,
      error: 'some error'
    };
    const expectedState = {
      ...currentState,
      isLoading: false,
      error: 'some error'
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.DATABASES.UPDATE', () => {
    // given
    const currentState = {
      ...getInitialState(),
      databases: indexedDatabasesSample
    };
    const action = {
      type: PROMOTION.DATABASES.UPDATE,
      databases: [
        {
          oldComment: 'This database is marked for autopromotion on the Live DB.',
          comment: 'some new comment',
          commentAuthor: '',
          commentDate: '',
          oldConfirmedBy: '00355799',
          confirmedBy: '0035579',
          creationDate: '2019-01-16T08:43:49.773',
          id: 3,
          internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
          internalName: 'Unbundling',
          isDirty: true,
          isMarkedForPromotion: false,
          isOldDatabase: false,
          isPromotedToLive: true,
          isUsedInLoadOnStaging: true,
          name: 'UNBUNDLING',
          source: 'NZUR18125DSQ'
        },
        {
          oldComment: '',
          comment: '',
          commentAuthor: '',
          commentDate: '',
          confirmedBy: '',
          oldConfirmedBy: '',
          creationDate: '2019-01-16T08:53:35.09',
          id: 15,
          internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
          internalName: 'LK',
          isDirty: false,
          isMarkedForPromotion: false,
          isOldDatabase: false,
          isPromotedToLive: false,
          isUsedInLoadOnStaging: true,
          name: 'Lookup Tables',
          source: 'NZUR18130DSQ'
        }
      ]
    };
    const expectedState = {
      ...currentState,
      databases: {
        ...currentState.databases,
        3: action.databases[0],
        15: action.databases[1]
      }
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.PROMOTE.REQUEST', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isPromotionRunning: false,
      error: 'some error'
    };
    const action = {
      type: PROMOTION.PROMOTE.REQUEST
    };
    const expectedState = {
      ...currentState,
      isPromotionRunning: true,
      error: getInitialState().error
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.PROMOTE.SUCCESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PROMOTION.PROMOTE.SUCCESS,
      databases: responseSample.databases
    };
    const expectedState = {
      ...currentState,
      databases: indexedDatabasesSample,
      error: getInitialState().error
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.PROMOTE.FAILURE', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isPromotionRunning: true,
      isLoading: true
    };
    const action = {
      type: PROMOTION.PROMOTE.FAILURE,
      error: {
        message: 'some error'
      }
    };
    const expectedState = {
      ...currentState,
      error: 'some error',
      isPromotionRunning: false,
      isLoading: false
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.ERROR.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PROMOTION.ERROR.CLEAR
    };
    const expectedState = {
      ...currentState,
      error: getInitialState().error
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should handle PROMOTION.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      databases: indexedDatabasesSample,
      progress: 50,
      isPromotionRunning: true
    };
    const action = {
      type: PROMOTION.CLEAR
    };
    const expectedState = {
      ...getInitialState(),
      progress: 50,
      isPromotionRunning: true
    };

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });

  it('Should not handle not related actions', () => {
    // given
    const currentState = {
      ...getInitialState(),
      databases: indexedDatabasesSample,
      progress: 50,
      isPromotionRunning: true
    };
    const action = {
      type: 'LOGGER.SOME_ACTION'
    };
    const expectedState = currentState;

    // when
    const nextState = promotion(currentState, action);

    // then
    expect(nextState).toEqual(expectedState);
  });
});
