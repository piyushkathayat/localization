import { LOAD_AND_QA, LOAD_AND_QA_ACTIONS } from 'actions/ActionTypes';
import loadAndQAActions from '../loadAndQAActions';

const getInitialState = () => ({
  actions: [],
  isLoading: true,
  error: null
});

const actionsSample = [
  {
    actionDescription: 'Check that files are available and correct ("OK files")',
    actionId: 126,
    activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
    averageDeviation: 0,
    averageDuration: 0,
    drillDownKey: '',
    drillDownType: '',
    duration: 1,
    endTime: '2019-01-11T07:30:25.047',
    issueHistory: [
      {
        activityDate: '2019-01-09T00:00:00',
        sumIssues: 0
      },
      {
        activityDate: '2019-01-10T00:00:00',
        sumIssues: 0
      }
    ],
    issues: 0,
    message: '',
    percentage: 100,
    startTime: '2019-01-11T07:30:24.99',
    statusCode: 'FINISHED'
  },
  {
    actionDescription: 'Create temporary tables',
    actionId: 118,
    activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
    averageDeviation: 0,
    averageDuration: 0,
    drillDownKey: '1323',
    drillDownType: 'FILE',
    duration: 0,
    endTime: '',
    issueHistory: [],
    issues: 0,
    message: '',
    percentage: 100,
    startTime: '2019-01-11T07:30:25.397',
    statusCode: 'FINISHED'
  }
];

const socketActionsSample = {
  '1ac910c9-0054-4078-a923-7429d5f0036c': [
    JSON.stringify({
      actionId: 126,
      activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
      percentage: 5,
      startTime: '2019-01-11T07:30:24.99',
      statusCode: 'RUNNING'
    }),
    JSON.stringify({
      actionId: 118,
      activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
      percentage: 0,
      startTime: '2019-01-11T07:30:25.397',
      statusCode: 'INIT'
    })
  ]
};

describe('loadAndQAActions reducer', () => {
  it('Should set initial state', () => {
    // given
    const currentState = undefined;
    const action = {
      type: null
    };
    const expectedResult = getInitialState();

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should LOAD_AND_QA_ACTIONS.FETCH.SUCCESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOAD_AND_QA_ACTIONS.FETCH.SUCCESS,
      actions: actionsSample
    };
    const expectedResult = {
      ...currentState,
      actions: actionsSample,
      isLoading: false,
      error: getInitialState().error
    };

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should LOAD_AND_QA_ACTIONS.FETCH.FAILURE', () => {
    // given
    const currentState = getInitialState();
    const action = {
      type: LOAD_AND_QA_ACTIONS.FETCH.FAILURE,
      error: 'someError'
    };
    const expectedResult = {
      ...currentState,
      actions: [],
      isLoading: false,
      error: 'someError'
    };

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should LOAD_AND_QA_ACTIONS.ERROR.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      error: 'someError'
    };
    const action = {
      type: LOAD_AND_QA_ACTIONS.ERROR.CLEAR
    };
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should LOAD_AND_QA.SOCKET.IN_PROGRESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      actions: actionsSample,
      isLoading: false
    };
    const action = {
      type: LOAD_AND_QA.SOCKET.IN_PROGRESS,
      message: {
        actions: socketActionsSample
      }
    };
    const expectedResult = {
      ...currentState,
      actions: [
        {
          actionId: 126,
          activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
          percentage: 5,
          startTime: '2019-01-11T07:30:24.99',
          statusCode: 'RUNNING'
        },
        {
          actionId: 118,
          activityKey: '1ac910c9-0054-4078-a923-7429d5f0036c',
          percentage: 0,
          startTime: '2019-01-11T07:30:25.397',
          statusCode: 'INIT'
        }
      ]
    };

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should LOAD_AND_QA.SOCKET.FAILED', () => {
    // given
    const currentState = {
      ...getInitialState(),
      actions: actionsSample,
      isLoading: false
    };
    const action = {
      type: LOAD_AND_QA.SOCKET.FAILED,
      message: {
        message: 'someError'
      }
    };
    const expectedResult = {
      ...currentState,
      error: 'someError'
    };

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should LOAD_AND_QA_ACTIONS.CLEAR', () => {
    // given
    const currentState = {
      ...getInitialState(),
      actions: actionsSample,
      isLoading: false,
      error: 'someError'
    };
    const action = {
      type: LOAD_AND_QA_ACTIONS.CLEAR
    };
    const expectedResult = getInitialState();

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should do nothing on unknown action', () => {
    // given
    const currentState = {
      ...getInitialState(),
      actions: actionsSample,
      isLoading: false,
      error: 'someError'
    };
    const action = {
      type: 'someUnknownAction'
    };
    const expectedResult = currentState;

    // when
    const result = loadAndQAActions(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });
});
