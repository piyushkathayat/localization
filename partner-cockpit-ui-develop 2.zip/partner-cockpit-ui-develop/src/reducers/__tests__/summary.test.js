import { SUMMARY } from 'actions/ActionTypes';
import summary from '../summary';

const getInitialState = () => ({
  summaryInfo: [],
  date: '',
  filter: [],
  isLoading: true,
  error: null
});

const summarySample = {
  lastDate: '2018-12-06T00:00:00',
  summary: [
    {
      data: [],
      format: 'CURRENCY',
      group: 'Asset',
      marquee: 7035663855,
      pctChange: 0,
      recNo: 0,
      type: 'TOTAL_ASSET_VALUE_GROSS'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 1,
      type: 'CORTEX_INSTRUMENT'
    },
    {
      data: [],
      format: 'NUMBER',
      group: 'Instrument',
      marquee: 22535,
      pctChange: 0,
      recNo: 2,
      type: 'ST_COUNT_INSTRUMENT'
    }
  ]
};

describe('summary reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = summary(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set summary and the date', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: SUMMARY.FETCH.SUCCESS,
      data: summarySample
    };
    const result = summary(currentState, action);
    const expectedResult = {
      ...currentState,
      summaryInfo: summarySample.summary,
      date: summarySample.lastDate,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: SUMMARY.FETCH.FAILURE,
      error: 'some error'
    };
    const result = summary(currentState, action);
    const expectedResult = {
      ...currentState,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: SUMMARY.ERROR.CLEAR
    };
    const result = summary(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      summary: summarySample.summary,
      date: summarySample.lastDate,
      isLoading: false
    };
    const action = {
      type: SUMMARY.CLEAR
    };
    const result = summary(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set filter', () => {
    const currentState = {
      ...getInitialState(),
      summary: summarySample.summary,
      date: summarySample.lastDate,
      isLoading: false
    };
    const action = {
      type: SUMMARY.FILTER,
      filter: ['Asset']
    };
    const result = summary(currentState, action);
    const expectedResult = {
      ...currentState,
      filter: ['Asset']
    };
    expect(result).toEqual(expectedResult);
  });
});
