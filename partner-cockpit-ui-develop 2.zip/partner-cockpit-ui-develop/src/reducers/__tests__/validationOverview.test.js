import { VALIDATION, VALIDATION_OVERVIEW } from 'actions/ActionTypes';
import validationOverview from '../validationOverview';

const getInitialState = () => ({
  decisionsOverview: {},
  isLoading: true,
  error: null
});

const decisionsOverviewSample = [
  {
    decisionId: 25,
    isReleaseAllowed: true,
    qualityChecks: []
  },
  {
    decisionId: 23,
    isReleaseAllowed: false,
    qualityChecks: []
  },
  {
    decisionId: 14,
    isReleaseAllowed: false,
    qualityChecks: []
  },
  {
    decisionId: 13,
    isReleaseAllowed: false,
    qualityChecks: []
  }
];

const indexedDecisionsOverviewSample = {
  25: {
    decisionId: 25,
    isReleaseAllowed: true,
    qualityChecks: []
  },
  23: {
    decisionId: 23,
    isReleaseAllowed: false,
    qualityChecks: []
  },
  14: {
    decisionId: 14,
    isReleaseAllowed: false,
    qualityChecks: []
  },
  13: {
    decisionId: 13,
    isReleaseAllowed: false,
    qualityChecks: []
  }
};

describe('validationOverview reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = validationOverview(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set decisionsOverview', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: VALIDATION_OVERVIEW.FETCH.SUCCESS,
      decisionsList: decisionsOverviewSample
    };
    const result = validationOverview(currentState, action);
    const expectedResult = {
      ...currentState,
      decisionsOverview: indexedDecisionsOverviewSample,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: VALIDATION.FETCH.FAILURE,
      error: 'some error'
    };
    const result = validationOverview(currentState, action);
    const expectedResult = {
      ...currentState,
      decisionsOverview: getInitialState().decisionsOverview,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: VALIDATION_OVERVIEW.ERROR.CLEAR
    };
    const result = validationOverview(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      decisionsOverview: indexedDecisionsOverviewSample,
      isLoading: false
    };
    const action = {
      type: VALIDATION_OVERVIEW.CLEAR
    };
    const result = validationOverview(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });
});
