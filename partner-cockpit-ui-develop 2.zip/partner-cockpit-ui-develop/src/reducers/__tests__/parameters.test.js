import * as R from 'ramda';
import { PARAMETERS } from 'actions/ActionTypes';
import parameters from '../parameters';

const getInitialState = () => ({
  parameters: {},
  isLoading: true,
  error: null
});

const parametersSample = [
  {
    checkedInAt: '2018-08-30T15:41:04.133',
    checkedInBy: '43395564',
    checkedOutAt: '2018-12-06T10:55:10.067',
    checkedOutBy: '00355799',
    feedName: 'saa'
  },
  {
    checkedInAt: '2018-08-09T15:47:50.02',
    checkedInBy: '00355799',
    checkedOutAt: '2018-12-06T10:55:12.88',
    checkedOutBy: '00355799',
    feedName: 'universe'
  },
  {
    checkedInAt: '2018-08-10T16:58:41.787',
    checkedInBy: '00355799',
    checkedOutAt: '2018-08-10T16:58:26.597',
    checkedOutBy: '00355799',
    feedName: 'lk'
  }
];

const indexedParametersSampleSample = {
  saa: {
    checkedInAt: '2018-08-30T15:41:04.133',
    checkedInBy: '43395564',
    checkedOutAt: '2018-12-06T10:55:10.067',
    checkedOutBy: '00355799',
    feedName: 'saa'
  },
  universe: {
    checkedInAt: '2018-08-09T15:47:50.02',
    checkedInBy: '00355799',
    checkedOutAt: '2018-12-06T10:55:12.88',
    checkedOutBy: '00355799',
    feedName: 'universe'
  },
  lk: {
    checkedInAt: '2018-08-10T16:58:41.787',
    checkedInBy: '00355799',
    checkedOutAt: '2018-08-10T16:58:26.597',
    checkedOutBy: '00355799',
    feedName: 'lk'
  }
};

describe('parameters reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = parameters(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set parameters', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PARAMETERS.FETCH.SUCCESS,
      statusesList: parametersSample
    };
    const result = parameters(currentState, action);
    const expectedResult = {
      ...currentState,
      parameters: indexedParametersSampleSample,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should handle PARAMETERS.[FEED_ACTION].REQUEST', () => {
    // given
    const currentState = getInitialState();
    const actionOnCheckIn = {
      type: PARAMETERS.CHECK_IN.REQUEST,
      feedName: 'saa'
    };
    const actionOnCheckOut = {
      type: PARAMETERS.CHECK_OUT.REQUEST,
      feedName: 'saa'
    };
    const actionOnCancel = {
      type: PARAMETERS.CANCEL.REQUEST,
      feedName: 'saa'
    };
    const expectedState = R.assocPath(
      ['parameters', 'saa', 'isUpdating'],
      true,
      currentState
    );

    // when
    const resultOnCheckIn = parameters(currentState, actionOnCheckIn);
    const resultOnCheckOut = parameters(currentState, actionOnCheckOut);
    const resultOnCancel = parameters(currentState, actionOnCancel);

    // then
    expect(resultOnCheckIn).toEqual(expectedState);
    expect(resultOnCheckOut).toEqual(expectedState);
    expect(resultOnCancel).toEqual(expectedState);
  });

  it('Should handle PARAMETERS.[FEED_ACTION].FAILURE', () => {
    // given
    const currentState = getInitialState();
    const actionOnCheckIn = {
      type: PARAMETERS.CHECK_IN.FAILURE,
      feedName: 'saa',
      error: 'some error'
    };
    const actionOnCheckOut = {
      type: PARAMETERS.CHECK_OUT.FAILURE,
      feedName: 'saa',
      error: 'some error'
    };
    const actionOnCancel = {
      type: PARAMETERS.CANCEL.FAILURE,
      feedName: 'saa',
      error: 'some error'
    };
    const expectedState = R.assocPath(
      ['parameters', 'saa', 'isUpdating'],
      false,
      {
        ...currentState,
        isLoading: false,
        error: 'some error'
      }
    );

    // when
    const resultOnCheckIn = parameters(currentState, actionOnCheckIn);
    const resultOnCheckOut = parameters(currentState, actionOnCheckOut);
    const resultOnCancel = parameters(currentState, actionOnCancel);

    // then
    expect(resultOnCheckIn).toEqual(expectedState);
    expect(resultOnCheckOut).toEqual(expectedState);
    expect(resultOnCancel).toEqual(expectedState);
  });

  it('Should handle PARAMETERS.FETCH.FAILURE', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isLoading: true
    };
    const action = {
      type: PARAMETERS.FETCH.FAILURE,
      error: 'some error'
    };
    const expectedResult = {
      ...currentState,
      isLoading: false,
      error: 'some error'
    };

    // when
    const result = parameters(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PARAMETERS.ERROR.CLEAR
    };
    const result = parameters(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      parameters: indexedParametersSampleSample,
      isLoading: false
    };
    const action = {
      type: PARAMETERS.CLEAR
    };
    const result = parameters(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should update parameter\'s status on checkIn', () => {
    const currentState = {
      ...getInitialState(),
      parameters: indexedParametersSampleSample,
      isLoading: false
    };
    const action = {
      type: PARAMETERS.CHECK_IN.SUCCESS,
      parameter: {
        checkedInAt: '2018-12-11T15:41:04.133',
        checkedInBy: '43535763',
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa'
      }
    };
    const result = parameters(currentState, action);
    const expectedResult = {
      ...currentState,
      parameters: {
        ...currentState.parameters,
        saa: {
          ...currentState.parameters.saa,
          isUpdating: false,
          checkedInAt: '2018-12-11T15:41:04.133',
          checkedInBy: '43535763'
        }
      }
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should update parameter\'s status on checkOut', () => {
    const currentState = {
      ...getInitialState(),
      parameters: indexedParametersSampleSample,
      isLoading: false
    };
    const action = {
      type: PARAMETERS.CHECK_OUT.SUCCESS,
      parameter: {
        checkedInAt: '2018-08-30T15:41:04.133',
        checkedInBy: '43395564',
        checkedOutAt: '2018-12-11T15:41:04.133',
        checkedOutBy: '43535763',
        feedName: 'saa'
      }
    };
    const result = parameters(currentState, action);
    const expectedResult = {
      ...currentState,
      parameters: {
        ...currentState.parameters,
        saa: {
          ...currentState.parameters.saa,
          isUpdating: false,
          checkedOutAt: '2018-12-11T15:41:04.133',
          checkedOutBy: '43535763'
        }
      }
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should update parameter\'s status on cancel', () => {
    const currentState = {
      ...getInitialState(),
      parameters: indexedParametersSampleSample,
      isLoading: false
    };
    const action = {
      type: PARAMETERS.CANCEL.SUCCESS,
      parameter: {
        checkedInAt: '2018-12-11T15:41:04.133',
        checkedInBy: '43535763',
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa'
      }
    };
    const result = parameters(currentState, action);
    const expectedResult = {
      ...currentState,
      parameters: {
        ...currentState.parameters,
        saa: {
          ...currentState.parameters.saa,
          isUpdating: false,
          checkedInAt: '2018-12-11T15:41:04.133',
          checkedInBy: '43535763'
        }
      }
    };
    expect(result).toEqual(expectedResult);
  });
});
