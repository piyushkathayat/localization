import { VALIDATION_DETAILS } from 'actions/ActionTypes';
import validationDetails from '../validationDetails';

// TODO: update

const getInitialState = () => ({
  decisionItems: {},
  decisionItemsIds: [],
  approvalStatuses: [],
  decisionLevel: null,
  decisionGroup: null,
  qualityCheckName: null,
  isLoading: true,
  isUpdating: false,
  error: null
});

const decisionItemsSample = {
  7139: {
    decisionKey: 7139,
    affectedPortfolios: 1,
    approvalStatus: 1,
    displayKey: 'US58933Y1055',
    displayDescription: 'A MERCK & CO. INC.',
    confirmedBy: null,
    commentLast: null
  },
  7140: {
    decisionKey: 7140,
    affectedPortfolios: 1,
    approvalStatus: 1,
    displayKey: 'IE00B4BNMY34',
    displayDescription: 'A ACCENTURE PLC A',
    confirmedBy: null,
    commentLast: null
  }
};

const decisionItemsIdsSample = [7139, 7140];
const approvalStatusesSample = [20, 13, 30];

const portfoliosListSample = [
  {
    assetId: 1049321,
    portfolioCode: 'code',
    portfolioCcy: 'EUR',
    investmentStrategyDesc: 'Elevated'
  }
];

describe('validationDetails reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = validationDetails(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set decisionItems', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: VALIDATION_DETAILS.FETCH.SUCCESS,
      decisionItems: decisionItemsSample,
      decisionItemsIds: decisionItemsIdsSample,
      approvalStatuses: approvalStatusesSample,
      decisionLevel: 1,
      decisionGroup: 2,
      qualityCheckName: 'Bulk Risk'
    };
    const result = validationDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      decisionItems: decisionItemsSample,
      decisionItemsIds: decisionItemsIdsSample,
      approvalStatuses: approvalStatusesSample,
      decisionLevel: 1,
      decisionGroup: 2,
      qualityCheckName: 'Bulk Risk',
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: VALIDATION_DETAILS.FETCH.FAILURE,
      error: 'some error'
    };
    const result = validationDetails(currentState, action);
    const expectedResult = {
      ...getInitialState(),
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: VALIDATION_DETAILS.ERROR.CLEAR
    };
    const result = validationDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      decisionItems: decisionItemsSample,
      decisionItemsIds: decisionItemsIdsSample,
      approvalStatuses: approvalStatusesSample,
      decisionLevel: 1,
      decisionGroup: 2,
      search: 'some search',
      isLoading: false
    };
    const action = {
      type: VALIDATION_DETAILS.CLEAR
    };
    const result = validationDetails(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  // it('Should set search', () => {
  //   const currentState = getInitialState();
  //   const action = {
  //     type: VALIDATION_DETAILS.SEARCH.SET,
  //     search: 'some search'
  //   };
  //   const result = validationDetails(currentState, action);
  //   const expectedResult = {
  //     ...currentState,
  //     search: 'some search'
  //   };
  //   expect(result).toEqual(expectedResult);
  // });

  // it('Should clear search', () => {
  //   const currentState = {
  //     ...getInitialState(),
  //     search: 'some search'
  //   };
  //   const action = {
  //     type: VALIDATION_DETAILS.SEARCH.CLEAR
  //   };
  //   const result = validationDetails(currentState, action);
  //   const expectedResult = {
  //     ...currentState,
  //     search: getInitialState().search
  //   };
  //   expect(result).toEqual(expectedResult);
  // });

  // it('Should set sorting correctly', () => {
  //   // first sorting should set only 'sortBy' field
  //   const currentState = getInitialState();
  //   const action = {
  //     type: VALIDATION_DETAILS.SORT_BY,
  //     sortBy: 'assetId'
  //   };
  //   const firstSortingState = validationDetails(currentState, action);
  //   const expectedFirstSortingState = {
  //     ...currentState,
  //     sorting: {
  //       sortBy: 'assetId',
  //       sortDirection: SORT_DIRECTIONS.ASC
  //     }
  //   };
  //   expect(firstSortingState).toEqual(expectedFirstSortingState);

  //   // second sequential sorting should set only 'sortDirection' field
  //   const secondSortingState = validationDetails(expectedFirstSortingState, action);
  //   const expectedSecondSortingState = {
  //     ...expectedFirstSortingState,
  //     sorting: {
  //       sortBy: 'assetId',
  //       sortDirection: SORT_DIRECTIONS.DESC
  //     }
  //   };
  //   expect(secondSortingState).toEqual(expectedSecondSortingState);

  //   // third sequential sorting should clear sorting to initial state
  //   const thirdSortingState = validationDetails(expectedSecondSortingState, action);
  //   const expectedThirdSortingState = {
  //     ...expectedSecondSortingState,
  //     sorting: getInitialState().sorting
  //   };
  //   expect(thirdSortingState).toEqual(expectedThirdSortingState);

  //   // sorting by the new column should set both 'sortBy' and 'sortDirection' fields
  //   const newAction = {
  //     type: VALIDATION_DETAILS.SORT_BY,
  //     sortBy: 'portfolio'
  //   };
  //   const newSortingState = validationDetails(expectedSecondSortingState, newAction);
  //   const expectedNewSortingState = {
  //     ...expectedSecondSortingState,
  //     sorting: {
  //       sortBy: 'portfolio',
  //       sortDirection: SORT_DIRECTIONS.ASC
  //     }
  //   };
  //   expect(newSortingState).toEqual(expectedNewSortingState);
  // });

  it('Should set updating', () => {
    const currentState = getInitialState();
    const action = {
      type: VALIDATION_DETAILS.UPDATE.REQUEST
    };
    const result = validationDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      isUpdating: true
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should handle VALIDATION_DETAILS.PORTFOLIOS.FETCH.SUCCESS', () => {
    // given
    const currentState = {
      ...getInitialState(),
      decisionItems: decisionItemsSample,
      decisionItemsIds: decisionItemsIdsSample,
      approvalStatuses: approvalStatusesSample,
      decisionLevel: 1,
      decisionGroup: 2,
      search: 'some search',
      isLoading: false
    };
    const action = {
      type: VALIDATION_DETAILS.PORTFOLIOS.FETCH.SUCCESS,
      decisionItemId: 7139,
      portfoliosList: portfoliosListSample
    };
    const expectedResult = currentState;
    expectedResult.decisionItems['7139'].portfoliosList = action.portfoliosList;

    // when
    const result = validationDetails(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should set error on updating failure', () => {
    const currentState = getInitialState();
    const action = {
      type: VALIDATION_DETAILS.UPDATE.FAILURE,
      error: 'some error'
    };
    const result = validationDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });
});
