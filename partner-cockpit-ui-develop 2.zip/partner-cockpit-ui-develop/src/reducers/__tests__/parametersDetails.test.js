import { PARAMETERS_DETAILS } from 'actions/ActionTypes';
import parametersDetails from '../parametersDetails';

const getInitialState = () => ({
  tablesList: [],
  filter: [],
  isLoading: true,
  error: null
});

const tablesListSample = [
  {
    id: 0,
    tableData: [],
    tableDisplayName: 'SAA',
    tableName: 'ST_SAA'
  },
  {
    id: 1,
    tableData: [],
    tableDisplayName: 'SAA Risk Return',
    tableName: 'ST_SAARiskReturn'
  },
  {
    id: 2,
    tableData: [],
    tableDisplayName: 'ST_SAAWeights',
    tableName: 'ST_SAAWeights'
  }
];

describe('parametersDetails reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = parametersDetails(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set tablesList', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PARAMETERS_DETAILS.FETCH.SUCCESS,
      tablesList: tablesListSample
    };
    const result = parametersDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      tablesList: tablesListSample,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: PARAMETERS_DETAILS.FETCH.FAILURE,
      error: 'some error'
    };
    const result = parametersDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: PARAMETERS_DETAILS.ERROR.CLEAR
    };
    const result = parametersDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      tablesList: tablesListSample,
      isLoading: false
    };
    const action = {
      type: PARAMETERS_DETAILS.CLEAR
    };
    const result = parametersDetails(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set filter', () => {
    const currentState = getInitialState();
    const action = {
      type: PARAMETERS_DETAILS.FILTER,
      filter: ['SAA']
    };
    const result = parametersDetails(currentState, action);
    const expectedResult = {
      ...currentState,
      filter: ['SAA']
    };
    expect(result).toEqual(expectedResult);
  });
});
