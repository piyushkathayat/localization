import * as R from 'ramda';
import { LOAD_AND_QA } from 'actions/ActionTypes';
import { DB_TYPES } from 'constants/serverInfo';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import loadAndQA from '../loadAndQA';

// TODO: update

const getInitialState = () => ({
  activities: {},
  activitiesIds: [],
  isLoading: true,
  error: null,
  jobs: {},
  isJobStarting: false
});

const activitiesSample = [
  {
    activityId: 3,
    activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
    activityOwner: 'WS004',
    statusCode: ACTIVITY_STATUSES.FINISHED,
    percentage: 100
  },
  {
    activityId: 7,
    activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
    activityOwner: 'WS004',
    statusCode: ACTIVITY_STATUSES.ERROR,
    percentage: 0
  },
  {
    activityId: 2,
    activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
    activityOwner: 'central',
    statusCode: ACTIVITY_STATUSES.FINISHED,
    percentage: 100
  },
  {
    activityId: 18,
    activityKey: 'a3fc6f08-ca59-44ea-bf73-66ac427aeb63',
    activityOwner: 'central',
    statusCode: ACTIVITY_STATUSES.ERROR,
    percentage: 0
  }
];

const activitiesIndexedSample = {
  '3-WS004': {
    id: '3-WS004',
    activityId: 3,
    activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
    activityOwner: 'WS004',
    statusCode: ACTIVITY_STATUSES.FINISHED,
    percentage: 100
  },
  '7-WS004': {
    id: '7-WS004',
    activityId: 7,
    activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
    activityOwner: 'WS004',
    statusCode: ACTIVITY_STATUSES.ERROR,
    percentage: 0
  },
  '2-central': {
    id: '2-central',
    activityId: 2,
    activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
    activityOwner: 'central',
    statusCode: ACTIVITY_STATUSES.FINISHED,
    percentage: 100
  },
  '18-central': {
    id: '18-central',
    activityId: 18,
    activityKey: 'a3fc6f08-ca59-44ea-bf73-66ac427aeb63',
    activityOwner: 'central',
    statusCode: ACTIVITY_STATUSES.ERROR,
    percentage: 0
  }
};

const jobsSample = {
  [DB_TYPES.PARTNER]: [
    {
      key: '23c4885f-fa30-4fcc-b2e1-2161e5742813',
      value: 'Copy Test Files'
    },
    {
      key: 'bd20617d-1ec9-449c-a3b8-79863e360deb',
      value: 'LK Tables'
    }
  ],
  [DB_TYPES.CENTRAL]: [
    {
      key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
      value: 'Get Central Instruments'
    },
    {
      key: '0085e781-e1ca-454f-965a-5201d163cd62',
      value: 'MiniCentral Extract'
    }
  ]
};

const socketActivitiesSample = [
  '{"activityId": 3, "activityKey": "840d06b2-3d8d-420c-b118-becfb6e1bba3", "activityOwner": "WS004", "statusCode": "RUNNING", "percentage": 15}',
  '{"activityId": 7, "activityKey": "2046815c-94d4-4d63-87ca-3c696eb74ab1", "activityOwner": "WS004", "statusCode": "RUNNING", "percentage": 20}',
  '{"activityId": 2, "activityKey": "7a8d464d-4c6a-462a-9b9b-e0eb694ece4b", "activityOwner": "central", "statusCode": "RUNNING", "percentage": 25}',
  '{"activityId": 18, "activityKey": "724944a6-9c46-4473-9076-b0d50d9f7564", "activityOwner": "central", "statusCode": "RUNNING", "percentage": 30}'
];

const socketActivitiesIndexedSample = {
  '3-WS004': {
    id: '3-WS004',
    activityId: 3,
    activityKey: '840d06b2-3d8d-420c-b118-becfb6e1bba3',
    activityOwner: 'WS004',
    statusCode: ACTIVITY_STATUSES.RUNNING,
    percentage: 15
  },
  '7-WS004': {
    id: '7-WS004',
    activityId: 7,
    activityKey: '2046815c-94d4-4d63-87ca-3c696eb74ab1',
    activityOwner: 'WS004',
    statusCode: ACTIVITY_STATUSES.RUNNING,
    percentage: 20
  },
  '2-central': {
    id: '2-central',
    activityId: 2,
    activityKey: '7a8d464d-4c6a-462a-9b9b-e0eb694ece4b',
    activityOwner: 'central',
    statusCode: ACTIVITY_STATUSES.RUNNING,
    percentage: 25
  },
  '18-central': {
    id: '18-central',
    activityId: 18,
    activityKey: '724944a6-9c46-4473-9076-b0d50d9f7564',
    activityOwner: 'central',
    statusCode: ACTIVITY_STATUSES.RUNNING,
    percentage: 30
  }
};

describe('loadAndQA reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set activities', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOAD_AND_QA.FETCH.SUCCESS,
      activities: activitiesSample
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      activities: activitiesIndexedSample,
      activitiesIds: R.pluck('id', Object.values(activitiesIndexedSample)),
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: LOAD_AND_QA.FETCH.FAILURE,
      error: 'some error'
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      activities: getInitialState().activities,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOAD_AND_QA.ERROR.CLEAR
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      activities: activitiesIndexedSample,
      isLoading: false
    };
    const action = {
      type: LOAD_AND_QA.CLEAR
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set jobs', () => {
    const currentState = getInitialState();
    const action = {
      type: LOAD_AND_QA.JOBS.FETCH.SUCCESS,
      jobs: jobsSample
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      jobs: jobsSample
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should start central DB job', () => {
    const currentState = getInitialState();
    const action = {
      type: LOAD_AND_QA.JOBS.START,
      database: DB_TYPES.CENTRAL
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      isJobStarting: true
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should start partner DB job', () => {
    const currentState = getInitialState();
    const action = {
      type: LOAD_AND_QA.JOBS.START,
      database: DB_TYPES.PARTNER
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      isJobStarting: true
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error on jobs failure', () => {
    const currentState = {
      ...getInitialState(),
      isJobStarting: true
    };
    const action = {
      type: LOAD_AND_QA.JOBS.FAILURE,
      error: 'some error'
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      isJobStarting: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error on sockets failure', () => {
    const currentState = {
      ...getInitialState(),
      isJobStarting: true
    };
    const action = {
      type: LOAD_AND_QA.SOCKET.FAILED,
      message: {
        message: 'some error'
      }
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      isJobStarting: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set status of the task which is affected by the job', () => {
    const currentState = {
      ...getInitialState(),
      activities: activitiesIndexedSample,
      isJobStarting: true
    };
    const action = {
      type: LOAD_AND_QA.SOCKET.IN_PROGRESS,
      message: {
        activities: socketActivitiesSample
      }
    };
    const result = loadAndQA(currentState, action);
    const expectedResult = {
      ...currentState,
      activities: R.mergeRight(activitiesIndexedSample, socketActivitiesIndexedSample),
      isJobStarting: false
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should handle LOAD_AND_QA.SOCKET.FINISHED', () => {
    // given
    const currentState = {
      ...getInitialState(),
      isJobStarting: true
    };
    const action = {
      type: LOAD_AND_QA.SOCKET.FINISHED
    };
    const expectedResult = {
      ...currentState,
      isJobStarting: false
    };

    // when
    const result = loadAndQA(currentState, action);

    // then
    expect(result).toEqual(expectedResult);
  });
});
