import { LOAD_AND_QA_DRILLDOWN } from 'actions/ActionTypes';
import loadAndQADrilldown from '../loadAndQADrilldown';

// TODO: update

const getInitialState = () => ({
  drilldowns: [],
  dbType: '',
  drilldownType: '',
  isLoading: true,
  error: null
});

const drilldownsSample = [
  {
    databaseName: 'CommonFeed',
    drilldownDetail: 'CommonFeed.panacea_benchmark',
    drilldownKey: 1338,
    drilldownType: 'VALIDATION',
    hasDetail: 0,
    invalidRows: 0,
    issueHistory: [],
    schemaName: 'datacycle',
    tableName: 'panacea_benchmark'
  },
  {
    databaseName: 'CommonFeed',
    drilldownDetail: 'CommonFeed.panacea_weight_allocation',
    drilldownKey: 1338,
    drilldownType: 'VALIDATION',
    hasDetail: 1,
    invalidRows: 4364,
    issueHistory: [],
    schemaName: 'datacycle',
    tableName: 'panacea_weight_allocation'
  }
];

describe('loadAndQADrilldown reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = loadAndQADrilldown(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set drilldowns', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOAD_AND_QA_DRILLDOWN.FETCH.SUCCESS,
      drilldowns: drilldownsSample,
      dbType: 'CENTRAL',
      drilldownType: 'VALIDATION'
    };
    const result = loadAndQADrilldown(currentState, action);
    const expectedResult = {
      ...currentState,
      drilldowns: drilldownsSample,
      dbType: 'CENTRAL',
      drilldownType: 'VALIDATION',
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: LOAD_AND_QA_DRILLDOWN.FETCH.FAILURE,
      error: 'some error'
    };
    const result = loadAndQADrilldown(currentState, action);
    const expectedResult = {
      ...currentState,
      activities: getInitialState().activities,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: LOAD_AND_QA_DRILLDOWN.ERROR.CLEAR
    };
    const result = loadAndQADrilldown(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      drilldowns: drilldownsSample,
      dbType: 'CENTRAL',
      drilldownType: 'VALIDATION',
      isLoading: false
    };
    const action = {
      type: LOAD_AND_QA_DRILLDOWN.CLEAR
    };
    const result = loadAndQADrilldown(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });
});
