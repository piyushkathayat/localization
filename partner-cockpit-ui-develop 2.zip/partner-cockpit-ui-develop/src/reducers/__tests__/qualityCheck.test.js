import { QUALITY_CHECK } from 'actions/ActionTypes';
import qualityCheck from '../qualityCheck';

const getInitialState = () => ({
  qualityCheckList: [],
  filter: [],
  isLoading: true,
  error: null
});

const qualityChecksListSample = [
  {
    type: 1,
    data: []
  },
  {
    type: 2,
    data: []
  },
  {
    type: 4,
    dataa: []
  }
];

describe('qualityCheck reducer', () => {
  it('Should set initial state', () => {
    const currentState = undefined;
    const action = {
      type: null
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set qualityCheckList', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: QUALITY_CHECK.FETCH.SUCCESS,
      data: qualityChecksListSample
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = {
      ...currentState,
      qualityCheckList: qualityChecksListSample,
      isLoading: false,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set error', () => {
    const currentState = getInitialState();
    const action = {
      type: QUALITY_CHECK.FETCH.FAILURE,
      error: 'some error'
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = {
      ...currentState,
      isLoading: false,
      error: 'some error'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear error', () => {
    const currentState = {
      ...getInitialState(),
      error: 'some error'
    };
    const action = {
      type: QUALITY_CHECK.ERROR.CLEAR
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = {
      ...currentState,
      error: getInitialState().error
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should clear state', () => {
    const currentState = {
      ...getInitialState(),
      qualityCheckList: qualityChecksListSample,
      isLoading: false
    };
    const action = {
      type: QUALITY_CHECK.CLEAR
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = getInitialState();
    expect(result).toEqual(expectedResult);
  });

  it('Should set filter', () => {
    const currentState = {
      ...getInitialState(),
      qualityCheckList: qualityChecksListSample,
      isLoading: false
    };
    const action = {
      type: QUALITY_CHECK.FILTER,
      filter: [2]
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = {
      ...currentState,
      filter: [2]
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should set isLoading on request', () => {
    const currentState = getInitialState();
    const action = {
      type: QUALITY_CHECK.FETCH.REQUEST
    };
    const result = qualityCheck(currentState, action);
    const expectedResult = {
      ...currentState,
      isLoading: true
    };
    expect(result).toEqual(expectedResult);
  });
});
