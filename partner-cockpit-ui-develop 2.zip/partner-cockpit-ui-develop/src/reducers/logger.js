import { LOGGER } from 'actions/ActionTypes';

const initialState = {
  json: [],
  issueIdsOptions: [],
  isLoading: false,
  isUpdating: false,
  error: null
};

export default function logger(state = initialState, action) {
  switch (action.type) {
    case LOGGER.JSON.FETCH.REQUEST:
      return {
        ...state,
        json: [],
        isUpdating: true,
        error: initialState.error
      };
    case LOGGER.JSON.FETCH.SUCCESS:
      return {
        ...state,
        json: action.json,
        isUpdating: false,
        error: initialState.error
      };
    case LOGGER.JSON.FETCH.FAILURE:
      return {
        ...state,
        json: initialState.json,
        isUpdating: false,
        error: action.error
      };
    case LOGGER.ISSUE_IDS.FETCH.REQUEST:
      return {
        ...state,
        isLoading: true,
        error: initialState.error
      };
    case LOGGER.ISSUE_IDS.FETCH.SUCCESS:
      return {
        ...state,
        issueIdsOptions: action.issueIdsOptions,
        isLoading: false
      };
    case LOGGER.ISSUE_IDS.FETCH.FAILURE:
      return {
        ...state,
        issueIdsOptions: initialState.issueIdsOptions,
        isLoading: false,
        error: action.error
      };
    case LOGGER.ISSUE_IDS.CLEAR:
      return {
        ...state,
        issueIdsOptions: []
      };
    case LOGGER.EXTRACT.FETCH.REQUEST:
      return {
        ...state,
        isUpdating: true
      };
    case LOGGER.EXTRACT.FETCH.SUCCESS:
      return {
        ...state,
        isUpdating: false
      };
    case LOGGER.EXTRACT.FETCH.FAILURE:
      return {
        ...state,
        isUpdating: false,
        error: action.error
      };
    case LOGGER.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case LOGGER.CLEAR:
      return initialState;
    default:
      return state;
  }
}
