import * as R from 'ramda';
import { BROKERAGE_OVERVIEW, BROKERAGE_DETAILS } from 'actions/ActionTypes';

const initialState = {
  triggerThemes: {},
  isLoading: true,
  isFinalizing: false,
  error: null
};

export default function brokerageOverview(state = initialState, action) {
  switch (action.type) {
    case BROKERAGE_OVERVIEW.FETCH.SUCCESS:
      return {
        ...state,
        triggerThemes: R.indexBy(R.prop('triggerThemeId'), action.triggerThemesList),
        isLoading: false,
        error: initialState.error
      };
    case BROKERAGE_OVERVIEW.FETCH.FAILURE:
      return {
        ...state,
        triggerThemes: initialState.triggerThemes,
        isLoading: false,
        error: action.error
      };
    case BROKERAGE_OVERVIEW.FINALIZE.REQUEST:
      return {
        ...state,
        isFinalizing: true
      };
    case BROKERAGE_OVERVIEW.FINALIZE.SUCCESS:
      return {
        ...state,
        isFinalizing: false
      };
    case BROKERAGE_OVERVIEW.FINALIZE.FAILURE:
      return {
        ...state,
        isFinalizing: false,
        error: action.error
      };
    case BROKERAGE_OVERVIEW.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case BROKERAGE_DETAILS.CLEAR:
      return {
        ...state,
        isLoading: true,
        error: initialState.error
      };
    case BROKERAGE_OVERVIEW.CLEAR:
      return initialState;
    default:
      return state;
  }
}
