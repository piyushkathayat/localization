import { LOAD_AND_QA, LOAD_AND_QA_ACTIONS } from 'actions/ActionTypes';
import * as R from 'ramda';

const initialState = {
  actions: [],
  isLoading: true,
  error: null
};

export default function loadAndQAActions(state = initialState, action) {
  switch (action.type) {
    case LOAD_AND_QA_ACTIONS.FETCH.SUCCESS: {
      return {
        ...state,
        actions: action.actions,
        isLoading: false,
        error: initialState.error
      };
    }
    case LOAD_AND_QA_ACTIONS.FETCH.FAILURE:
      return {
        ...state,
        actions: initialState.actions,
        isLoading: false,
        error: action.error
      };
    case LOAD_AND_QA_ACTIONS.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case LOAD_AND_QA.SOCKET.IN_PROGRESS: {
      if (state.actions.length) {
        const currentActivityKey = R.path([0, 'activityKey'], state.actions);
        const runningAction = R.path(['message', 'actions', currentActivityKey], action);
        if (runningAction) {
          const runningActions = runningAction.map(JSON.parse);

          return {
            ...state,
            actions: runningActions
          };
        }
      }
      return state;
    }
    case LOAD_AND_QA.SOCKET.FAILED:
      return {
        ...state,
        error: action.message.message
      };
    case LOAD_AND_QA_ACTIONS.CLEAR:
      return initialState;
    default:
      return state;
  }
}
