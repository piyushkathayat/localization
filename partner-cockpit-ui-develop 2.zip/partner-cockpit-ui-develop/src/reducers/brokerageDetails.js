import * as R from 'ramda';
import { BROKERAGE_OVERVIEW, BROKERAGE_DETAILS } from 'actions/ActionTypes';

const initialState = {
  triggers: {},
  isLoading: true,
  isUpdating: false,
  error: null
};

const triggerLens = ({ triggerThemeId, triggerId, fieldName, triggers }) => R.lensPath([
  'triggers',
  triggerId,
  R.findIndex(
    trigger => trigger.triggerId === triggerId,
    triggers[triggerThemeId]
  ),
  fieldName
]);

export default function brokerageDetails(state = initialState, action) {
  switch (action.type) {
    case BROKERAGE_OVERVIEW.FETCH.SUCCESS:
      return {
        ...state,
        triggers: action.triggers,
        isLoading: false
      };
    case BROKERAGE_OVERVIEW.FETCH.FAILURE:
      return {
        ...state,
        triggers: initialState.triggers,
        isLoading: false,
        error: action.error
      };
    case BROKERAGE_DETAILS.PORTFOLIOS.FETCH.SUCCESS:
      return R.set(
        triggerLens({
          triggerThemeId: action.triggerThemeId,
          triggerId: action.triggerId,
          fieldName: 'portfoliosList',
          triggers: state.triggers
        }),
        action.portfoliosList,
        state
      );
    case BROKERAGE_DETAILS.PORTFOLIOS.FETCH.FAILURE:
      return {
        ...state,
        error: action.error
      };
    case BROKERAGE_DETAILS.UPDATE.REQUEST:
      return {
        ...state,
        isUpdating: true
      };
    case BROKERAGE_DETAILS.UPDATE.SUCCESS:
      return R.set(
        triggerLens({
          triggerThemeId: action.triggerThemeId,
          triggerId: action.triggerId,
          fieldName: 'isLocked',
          triggers: state.triggers
        }),
        action.isLocked,
        state
      );
    case BROKERAGE_DETAILS.UPDATE.FAILURE:
      return {
        ...state,
        isUpdating: false,
        error: action.error
      };
    case BROKERAGE_DETAILS.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case BROKERAGE_DETAILS.CLEAR:
      return initialState;
    default:
      return state;
  }
}
