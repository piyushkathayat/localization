import * as R from 'ramda';
import { PROMOTION } from 'actions/ActionTypes';

const initialState = {
  databases: {},
  isPromotionRunning: false,
  lastPromotionDate: '',
  dependencies: [],
  status: '',
  error: null,
  canPromote: false,
  isLoading: true
};

export default function promotion(state = initialState, action) {
  switch (action.type) {
    case PROMOTION.FETCH.SUCCESS:
      return {
        ...state,
        ...action.promotion,
        databases: R.indexBy(R.prop('id'), action.promotion.databases),
        error: initialState.error,
        isLoading: false
      };
    case PROMOTION.FETCH.FAILURE:
      return {
        ...initialState,
        isLoading: false,
        error: action.error
      };
    case PROMOTION.DATABASES.UPDATE:
      return R.reduce(
        (intermediateState, database) => R.assocPath(
          ['databases', database.id],
          database,
          intermediateState
        ),
        state,
        action.databases
      );
    case PROMOTION.PROMOTE.REQUEST:
      return {
        ...state,
        isPromotionRunning: true,
        error: initialState.error
      };
    case PROMOTION.PROMOTE.SUCCESS:
      return {
        ...state,
        databases: R.indexBy(R.prop('id'), action.databases),
        isPromotionRunning: false,
        error: initialState.error
      };
    case PROMOTION.PROMOTE.FAILURE:
      return {
        ...state,
        error: action.error.message,
        isPromotionRunning: false,
        isLoading: false
      };
    case PROMOTION.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case PROMOTION.CLEAR: {
      return {
        ...initialState,
        progress: state.progress,
        isPromotionRunning: state.isPromotionRunning
      };
    }
    default:
      return state;
  }
}
