import { QUALITY_CHECK } from 'actions/ActionTypes';

const initialState = {
  qualityCheckList: [],
  filter: [],
  isLoading: true,
  error: null
};

export default function qualityCheck(state = initialState, action) {
  switch (action.type) {
    case QUALITY_CHECK.FILTER:
      return {
        ...state,
        filter: action.filter
      };
    case QUALITY_CHECK.FETCH.REQUEST:
      return {
        ...state,
        isLoading: true,
        error: initialState.error
      };
    case QUALITY_CHECK.FETCH.SUCCESS:
      return {
        ...state,
        qualityCheckList: action.data,
        isLoading: false,
        error: initialState.error
      };
    case QUALITY_CHECK.FETCH.FAILURE:
      return {
        ...state,
        qualityCheckList: [],
        isLoading: false,
        error: action.error
      };
    case QUALITY_CHECK.ERROR.CLEAR:
      return {
        ...state,
        error: initialState.error
      };
    case QUALITY_CHECK.CLEAR:
      return initialState;
    default:
      return state;
  }
}
