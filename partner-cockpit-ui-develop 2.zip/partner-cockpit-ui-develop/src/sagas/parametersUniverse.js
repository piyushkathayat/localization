import { PARAMETERS_UNIVERSE } from 'actions/ActionTypes';
import { PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE } from 'constants/parameters';
import { getIsin, getCurrentPage } from 'selectors/parametersUniverse';
import { delay } from 'redux-saga';
import { call, put, select, takeLatest } from 'redux-saga/effects';
import { post } from '@ubs.partner/shared-ui';

export function* fetchInstrumentUniverse(debounce = 0) {
  try {
    yield delay(debounce);
    const isin = yield select(getIsin);
    const currentPage = yield select(getCurrentPage);
    const attributes = {
      isin,
      skipRows: PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE * (currentPage - 1),
      takeRows: PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE
    };
    const response = yield call(post, '/api/v2/cockpit/universe', {
      dataToSend: attributes
    });
    yield put({
      type: PARAMETERS_UNIVERSE.FETCH.SUCCESS,
      data: response
    });
  } catch (e) {
    yield put({ type: PARAMETERS_UNIVERSE.FETCH.FAILURE, error: e.message });
  }
}

export function* instrumentUniversePageChangeSaga() {
  yield takeLatest(PARAMETERS_UNIVERSE.PAGE.CHANGE, fetchInstrumentUniverse);
}

export function* instrumentUniverseSearchChangeSaga() {
  yield takeLatest(
    [PARAMETERS_UNIVERSE.SEARCH.SET, PARAMETERS_UNIVERSE.SEARCH.CLEAR],
    fetchInstrumentUniverse,
    500
  );
}
