import { PARAMETERS_DETAILS } from 'actions/ActionTypes';
import { PARAMETERS_TYPES } from 'constants/parameters';
import { fetchInstrumentUniverse } from 'sagas/parametersUniverse';
import { call, put } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import { fetchParametersDetails } from '../parametersDetails';

describe('parametersDetails sagas', () => {
  it('should fetchParametersDetails - SUCCESS - PARAMETERS_TYPES.INSTRUMENT_UNIVERSE', () => {
    // given
    const params = {
      feedName: PARAMETERS_TYPES.INSTRUMENT_UNIVERSE
    };

    // when
    const generator = fetchParametersDetails(params);

    // then
    expect(generator.next().value).toEqual(
      call(fetchInstrumentUniverse)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchParametersDetails - SUCCESS - PARAMETERS_TYPES.INSTRUMENT_UNIVERSE', () => {
    // given
    const params = {
      feedName: PARAMETERS_TYPES.SAA
    };
    const response = {
      table: []
    };

    // when
    const generator = fetchParametersDetails(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/staticdata/saa')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: PARAMETERS_DETAILS.FETCH.SUCCESS, tablesList: response.table })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchParametersDetails - FAILURE', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchParametersDetails(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/staticdata/saa')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: PARAMETERS_DETAILS.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });
});
