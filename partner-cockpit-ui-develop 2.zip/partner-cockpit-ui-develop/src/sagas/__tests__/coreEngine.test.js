import { get } from '@ubs.partner/shared-ui';
import { call, put } from 'redux-saga/effects';
import { CORE_ENGINE } from 'actions/ActionTypes';
import { fetchCoreEngine } from '../coreEngine';

describe('coreEngine sagas', () => {
  it('should fetchCoreEngine - SUCCESS', () => {
    // given
    const response = { table: [] };

    // when
    const generator = fetchCoreEngine();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/staticdata/key')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: CORE_ENGINE.FETCH.SUCCESS, tablesList: [] })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchCoreEngine - FAILURE', () => {
    // given
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchCoreEngine();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/staticdata/key')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: CORE_ENGINE.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });
});
