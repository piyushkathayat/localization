import { call, put, select } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import { LOAD_AND_QA_ACTIONS } from 'actions/ActionTypes';
import { getActivities } from 'selectors/loadAndQA';
import { getActions } from 'selectors/loadAndQAActions';
import { getCentralDBKey } from 'selectors/serverInfo';
import { DB_TYPES } from 'constants/serverInfo';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { fetchLoadAndQAActions } from '../loadAndQAActions';

describe('loadAndQAActions sagas', () => {
  it('should fetchLoadAndQAActions - no API call if there are actions', () => {
    // given
    const params = {
      id: '3-WS004'
    };
    const activities = {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    };
    const centralDBKey = 'central';
    const actions = [
      {
        actionId: 70,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0,
        actionDescription: 'Check that files are available and correct ("OK files")',
        issues: 0,
        issueHistory: []
      },
      {
        actionId: 57,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        statusCode: ACTIVITY_STATUSES.INIT,
        percentage: 0,
        actionDescription: 'Create temporary tables',
        issues: 0,
        issueHistory: []
      }
    ];

    // when
    const generator = fetchLoadAndQAActions(params);

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      select(getCentralDBKey)
    );
    expect(generator.next(centralDBKey).value).toEqual(
      select(getActions)
    );
    expect(generator.next(actions).done).toEqual(true);
  });

  it('should fetchLoadAndQAActions - API call if there are no actions', () => {
    // given
    const params = {
      id: '3-WS004'
    };
    const activities = {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    };
    const centralDBKey = 'central';
    const actions = [];
    const response = [
      {
        actionId: 70,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0,
        actionDescription: 'Check that files are available and correct ("OK files")',
        issues: 0,
        issueHistory: []
      },
      {
        actionId: 57,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        statusCode: ACTIVITY_STATUSES.INIT,
        percentage: 0,
        actionDescription: 'Create temporary tables',
        issues: 0,
        issueHistory: []
      }
    ];

    // when
    const generator = fetchLoadAndQAActions(params);

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      select(getCentralDBKey)
    );
    expect(generator.next(centralDBKey).value).toEqual(
      select(getActions)
    );
    expect(generator.next(actions).value).toEqual(
      call(
        get,
        `/api/v3/cockpit/activities/actions/${DB_TYPES.PARTNER}/ff3914f7-8eac-4b5c-bf0e-01147df8b570`
      )
    );
    expect(generator.next(response).value).toEqual(
      put({ type: LOAD_AND_QA_ACTIONS.FETCH.SUCCESS, actions: response })
    );
    expect(generator.next(actions).done).toEqual(true);
  });

  it('should fetchLoadAndQAActions - FAILURE', () => {
    // given
    const params = {
      id: '3-WS004'
    };
    const activities = {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: 'ff3914f7-8eac-4b5c-bf0e-01147df8b570',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    };
    const centralDBKey = 'central';
    const actions = {};
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchLoadAndQAActions(params);

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      select(getCentralDBKey)
    );
    expect(generator.next(centralDBKey).value).toEqual(
      select(getActions)
    );
    expect(generator.next(actions).value).toEqual(
      call(
        get,
        `/api/v3/cockpit/activities/actions/${DB_TYPES.PARTNER}/ff3914f7-8eac-4b5c-bf0e-01147df8b570`
      )
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOAD_AND_QA_ACTIONS.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next(actions).done).toEqual(true);
  });
});
