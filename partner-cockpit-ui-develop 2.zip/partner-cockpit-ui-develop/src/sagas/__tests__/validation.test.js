import { call, put, /* select, */ takeEvery } from 'redux-saga/effects';
import { VALIDATION /* , VALIDATION_OVERVIEW */ } from 'actions/ActionTypes';
import { /* get, */post } from '@ubs.partner/shared-ui';
// import { getSelectedDecisionId } from 'selectors/validation';
import {
  getLatestDecisionId,
  getDecisionsCommonData,
  getDecisionsOverview,
  // fetchDecisions,
  validateDecision,
  validateDecisionSaga
} from '../validation';

// TODO: update

describe('validation sagas', () => {
  it('should getLatestDecisionId', () => {
    // given
    const decisionsList = [
      {
        decisionDate: '2019-02-21T00:00:00',
        decisionId: 45,
        decisionStatusId: 170,
        isReleaseAllowed: false,
        isLatestLoad: true,
        qualityChecks: []
      },
      {
        decisionDate: '2019-02-19T00:00:00',
        decisionId: 43,
        decisionStatusId: 100,
        isReleaseAllowed: false,
        isLatestLoad: false,
        qualityChecks: []
      },
      {
        decisionDate: '2019-02-18T00:00:00',
        decisionId: 42,
        decisionStatusId: 170,
        isReleaseAllowed: false,
        isLatestLoad: false,
        qualityChecks: []
      }
    ];

    // when

    // then
    expect(getLatestDecisionId(decisionsList)).toEqual(45);
  });

  it('should getDecisionsCommonData', () => {
    // given
    const decisionsList = [
      {
        decisionDate: '2019-02-21T00:00:00',
        decisionId: 45,
        decisionStatusId: 170,
        isReleaseAllowed: false,
        isLatestLoad: true,
        qualityChecks: []
      },
      {
        decisionDate: '2019-02-19T00:00:00',
        decisionId: 43,
        decisionStatusId: 100,
        isReleaseAllowed: false,
        isLatestLoad: false,
        qualityChecks: []
      },
      {
        decisionDate: '2019-02-18T00:00:00',
        decisionId: 42,
        decisionStatusId: 170,
        isReleaseAllowed: false,
        isLatestLoad: false,
        qualityChecks: []
      }
    ];

    // when

    // then
    expect(getDecisionsCommonData(decisionsList)).toEqual([
      {
        date: '2019-02-21T00:00:00',
        decisionId: 45,
        statusId: 170,
        isLatestLoad: true
      },
      {
        date: '2019-02-19T00:00:00',
        decisionId: 43,
        statusId: 100,
        isLatestLoad: false
      },
      {
        date: '2019-02-18T00:00:00',
        decisionId: 42,
        statusId: 170,
        isLatestLoad: false
      }
    ]);
  });

  it('should getDecisionsOverview', () => {
    // given
    const decisionsList = [
      {
        decisionDate: '2019-02-21T00:00:00',
        decisionId: 45,
        decisionStatusId: 170,
        isReleaseAllowed: false,
        isLatestLoad: true,
        qualityChecks: []
      },
      {
        decisionDate: '2019-02-19T00:00:00',
        decisionId: 43,
        decisionStatusId: 100,
        isReleaseAllowed: false,
        isLatestLoad: false,
        qualityChecks: []
      },
      {
        decisionDate: '2019-02-18T00:00:00',
        decisionId: 42,
        decisionStatusId: 170,
        isReleaseAllowed: false,
        isLatestLoad: false,
        qualityChecks: []
      }
    ];

    // when

    // then
    expect(getDecisionsOverview(decisionsList)).toEqual([
      {
        decisionId: 45,
        isReleaseAllowed: false,
        qualityChecks: []
      },
      {
        decisionId: 43,
        isReleaseAllowed: false,
        qualityChecks: []
      },
      {
        decisionId: 42,
        isReleaseAllowed: false,
        qualityChecks: []
      }
    ]);
  });

  // it('should fetchDecisions - SUCCESS - shouldSetOverview - decisionId', () => {
  //   // given
  //   const decisionId = 42;
  //   const response = [
  //     {
  //       decisionDate: '2019-02-21T00:00:00',
  //       decisionId: 45,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: true,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-19T00:00:00',
  //       decisionId: 43,
  //       decisionStatusId: 100,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-18T00:00:00',
  //       decisionId: 42,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     }
  //   ];
  //   const selectedDecisionId = null;

  //   // when
  //   const generator = fetchDecisions({ decisionId });

  //   // then
  //   expect(generator.next().value).toEqual(
  //     call(get, '/api/v3/cockpit/decisions')
  //   );
  //   expect(generator.next(response).value).toEqual(
  //     put({
  //       type: VALIDATION_OVERVIEW.FETCH.SUCCESS,
  //       decisionsList: getDecisionsOverview(response)
  //     })
  //   );
  //   expect(generator.next().value).toEqual(
  //     select(getSelectedDecisionId)
  //   );
  //   expect(generator.next(selectedDecisionId).value).toEqual(
  //     put({
  //       type: VALIDATION.FETCH.SUCCESS,
  //       decisions: getDecisionsCommonData(response),
  //       selectedDecisionId: 42
  //     })
  //   );
  //   expect(generator.next().done).toEqual(true);
  // });

  // it('should fetchDecisions - SUCCESS - shouldSetOverview - selectedDecisionId', () => {
  //   // given
  //   const response = [
  //     {
  //       decisionDate: '2019-02-21T00:00:00',
  //       decisionId: 45,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: true,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-19T00:00:00',
  //       decisionId: 43,
  //       decisionStatusId: 100,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-18T00:00:00',
  //       decisionId: 42,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     }
  //   ];
  //   const selectedDecisionId = 43;

  //   // when
  //   const generator = fetchDecisions({});

  //   // then
  //   expect(generator.next().value).toEqual(
  //     call(get, '/api/v3/cockpit/decisions')
  //   );
  //   expect(generator.next(response).value).toEqual(
  //     put({
  //       type: VALIDATION_OVERVIEW.FETCH.SUCCESS,
  //       decisionsList: getDecisionsOverview(response)
  //     })
  //   );
  //   expect(generator.next().value).toEqual(
  //     select(getSelectedDecisionId)
  //   );
  //   expect(generator.next(selectedDecisionId).value).toEqual(
  //     put({
  //       type: VALIDATION.FETCH.SUCCESS,
  //       decisions: getDecisionsCommonData(response),
  //       selectedDecisionId: 43
  //     })
  //   );
  //   expect(generator.next().done).toEqual(true);
  // });

  // it('should fetchDecisions - SUCCESS - shouldSetOverview - latestExecutionId', () => {
  //   // given
  //   const response = [
  //     {
  //       decisionDate: '2019-02-21T00:00:00',
  //       decisionId: 45,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: true,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-19T00:00:00',
  //       decisionId: 43,
  //       decisionStatusId: 100,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-18T00:00:00',
  //       decisionId: 42,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     }
  //   ];
  //   const selectedDecisionId = null;

  //   // when
  //   const generator = fetchDecisions({});

  //   // then
  //   expect(generator.next().value).toEqual(
  //     call(get, '/api/v3/cockpit/decisions')
  //   );
  //   expect(generator.next(response).value).toEqual(
  //     put({
  //       type: VALIDATION_OVERVIEW.FETCH.SUCCESS,
  //       decisionsList: getDecisionsOverview(response)
  //     })
  //   );
  //   expect(generator.next().value).toEqual(
  //     select(getSelectedDecisionId)
  //   );
  //   expect(generator.next(selectedDecisionId).value).toEqual(
  //     put({
  //       type: VALIDATION.FETCH.SUCCESS,
  //       decisions: getDecisionsCommonData(response),
  //       selectedDecisionId: 45
  //     })
  //   );
  //   expect(generator.next().done).toEqual(true);
  // });

  // it('should fetchDecisions - SUCCESS - !shouldSetOverview', () => {
  //   // given
  //   const decisionId = 42;
  //   const response = [
  //     {
  //       decisionDate: '2019-02-21T00:00:00',
  //       decisionId: 45,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: true,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-19T00:00:00',
  //       decisionId: 43,
  //       decisionStatusId: 100,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     },
  //     {
  //       decisionDate: '2019-02-18T00:00:00',
  //       decisionId: 42,
  //       decisionStatusId: 170,
  //       isReleaseAllowed: false,
  //       isLatestLoad: false,
  //       qualityChecks: []
  //     }
  //   ];
  //   const selectedDecisionId = null;

  //   // when
  //   const generator = fetchDecisions({ decisionId }, false);

  //   // then
  //   expect(generator.next().value).toEqual(
  //     call(get, '/api/v3/cockpit/decisions')
  //   );
  //   expect(generator.next(response).value).toEqual(
  //     select(getSelectedDecisionId)
  //   );
  //   expect(generator.next(selectedDecisionId).value).toEqual(
  //     put({
  //       type: VALIDATION.FETCH.SUCCESS,
  //       decisions: getDecisionsCommonData(response),
  //       selectedDecisionId: 42
  //     })
  //   );
  //   expect(generator.next().done).toEqual(true);
  // });

  // it('should fetchDecisions - FAILURE', () => {
  //   // given
  //   const decisionId = 42;
  //   const error = {
  //     message: 'someError'
  //   };

  //   // when
  //   const generator = fetchDecisions({ decisionId }, false);

  //   // then
  //   expect(generator.next().value).toEqual(
  //     call(get, '/api/v3/cockpit/decisions')
  //   );
  //   expect(generator.throw(error).value).toEqual(
  //     put({ type: VALIDATION.FETCH.FAILURE, error: 'someError' })
  //   );
  //   expect(generator.next().value).toEqual(
  //     put({ type: VALIDATION_OVERVIEW.FETCH.FAILURE })
  //   );
  //   expect(generator.next().done).toEqual(true);
  // });

  // TODO: add recalculate

  it('should validateDecision - SUCCESS', () => {
    // given
    const params = {
      decisionId: 42
    };

    // when
    const generator = validateDecision(params);

    // then
    expect(generator.next().value).toEqual(
      call(post, '/api/v3/cockpit/decisions/validate', {
        dataToSend: params
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should validateDecision - FAILURE', () => {
    // given
    const params = {
      decisionId: 42
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = validateDecision(params);

    // then
    expect(generator.next().value).toEqual(
      call(post, '/api/v3/cockpit/decisions/validate', {
        dataToSend: params
      })
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: VALIDATION.DECISION.VALIDATE.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should validateDecisionSaga', () => {
    // given

    // when
    const generator = validateDecisionSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(VALIDATION.DECISION.VALIDATE.REQUEST, validateDecision)
    );
    expect(generator.next().done).toEqual(true);
  });
});
