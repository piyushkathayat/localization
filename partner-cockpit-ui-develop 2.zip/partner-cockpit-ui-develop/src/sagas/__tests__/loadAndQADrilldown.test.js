import { call, put, select } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import { LOAD_AND_QA_DRILLDOWN } from 'actions/ActionTypes';
import { getActivities } from 'selectors/loadAndQA';
import { getCentralDBKey } from 'selectors/serverInfo';
import { DB_TYPES } from 'constants/serverInfo';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { fetchLoadAndQADrilldown } from '../loadAndQADrilldown';

// TODO: update

describe('loadAndQADrilldown sagas', () => {
  it('should fetchLoadAndQADrilldown - SUCCESS', () => {
    // given
    const params = {
      id: '3-WS004',
      drilldownType: 'QA',
      drilldownKey: 'LK'
    };
    const activities = {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    };
    const centralDBKey = 'central';
    const response = {
      activities: [
        {
          brsCode: 'LK-3.12',
          description: 'LK_TranslationType:',
          drilldownDetail: 30,
          drilldownKey: 'LK',
          drilldownType: 'QA',
          hasDetail: 0,
          issueHistory: [],
          numberOfIssues: 0
        },
        {
          brsCode: 'LK-3.2',
          description: 'Not all tables with a default value',
          drilldownDetail: 31,
          drilldownKey: 'LK',
          drilldownType: 'QA',
          hasDetail: 0,
          issueHistory: [],
          numberOfIssues: 0
        }
      ],
      drillDownType: 'QA',
      drillDownKey: 'LK'
    };
    const expectedDrilldowns = [
      {
        drilldownId: 0,
        brsCode: 'LK-3.12',
        description: 'LK_TranslationType:',
        drilldownDetail: 30,
        drilldownKey: 'LK',
        drilldownType: 'QA',
        hasDetail: 0,
        issueHistory: [],
        numberOfIssues: 0
      },
      {
        drilldownId: 1,
        brsCode: 'LK-3.2',
        description: 'Not all tables with a default value',
        drilldownDetail: 31,
        drilldownKey: 'LK',
        drilldownType: 'QA',
        hasDetail: 0,
        issueHistory: [],
        numberOfIssues: 0
      }
    ];

    // when
    const generator = fetchLoadAndQADrilldown(params);

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      select(getCentralDBKey)
    );
    expect(generator.next(centralDBKey).value).toEqual(
      call(get, `/api/v2/cockpit/${DB_TYPES.PARTNER}/drilldown/QA/LK`)
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: LOAD_AND_QA_DRILLDOWN.FETCH.SUCCESS,
        drilldowns: expectedDrilldowns,
        dbType: DB_TYPES.PARTNER,
        drilldownType: 'QA'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchLoadAndQADrilldown - FAILURE', () => {
    // given
    const params = {
      id: '3-WS004',
      drilldownType: 'QA',
      drilldownKey: 'LK'
    };
    const activities = {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    };
    const centralDBKey = 'central';
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchLoadAndQADrilldown(params);

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      select(getCentralDBKey)
    );
    expect(generator.next(centralDBKey).value).toEqual(
      call(get, `/api/v2/cockpit/${DB_TYPES.PARTNER}/drilldown/QA/LK`)
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOAD_AND_QA_DRILLDOWN.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });
});
