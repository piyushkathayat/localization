import { call, put, takeEvery } from 'redux-saga/effects';
import { CONTEXT_TYPES } from 'constants/logger';
import { LOGGER } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';
import {
  formatQueryParam,
  getQueryParameters,
  formatOptions,
  fetchJson,
  fetchIssueIds,
  loggerJsonSaga,
  loggerIssueIdsSaga
} from '../logger';

describe('logger sagas', () => {
  it('should formatQueryParam', () => {
    // given

    // when

    // then
    expect(formatQueryParam('assetId', '1044992')).toEqual(
      'assetId=1044992'
    );
    expect(formatQueryParam('context', CONTEXT_TYPES.SOLVE_SELECTED)).toEqual(
      `context=${CONTEXT_TYPES.SOLVE_SELECTED}`
    );
    expect(formatQueryParam('issueIds', [208020823, 208040153])).toEqual(
      'issueIds=208020823%2C208040153'
    );
  });

  it('should getQueryParameters', () => {
    // given

    // when

    // then
    expect(getQueryParameters({
      assetId: '1044992',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: [208020823, 208040153]
    })).toEqual(
      '?assetId=1044992&context=SOLVE-SELECTED&issueIds=208020823%2C208040153'
    );

    expect(getQueryParameters({
      assetId: '',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: [208020823, 208040153]
    })).toEqual(
      '?context=SOLVE-SELECTED&issueIds=208020823%2C208040153'
    );

    expect(getQueryParameters({
      assetId: '1044992',
      context: '',
      issueIds: [208020823, 208040153]
    })).toEqual(
      '?assetId=1044992&issueIds=208020823%2C208040153'
    );

    expect(getQueryParameters({
      assetId: '1044992',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: []
    })).toEqual(
      '?assetId=1044992&context=SOLVE-SELECTED'
    );

    expect(getQueryParameters({
      assetId: '',
      context: '',
      issueIds: []
    })).toEqual(
      ''
    );
  });

  it('should formatOptions', () => {
    // given
    const qualityCheckDetails = [
      {
        isIssue: true,
        issues: [
          {
            globalIssueId: null,
            isIssue: false,
            issueId: null,
            name: 'Liquiditeiten',
            shortCode: 'LIQ'
          },
          {
            globalIssueId: 208020823,
            isIssue: true,
            issueId: 208024558,
            name: 'Obligaties',
            shortCode: 'OBLI'
          },
          {
            globalIssueId: 208020823,
            isIssue: true,
            issueId: 208024559,
            name: 'Alternatieve beleggingen',
            shortCode: 'ALTERN'
          }
        ],
        name: 'Asset Allocation',
        type: 1
      },
      {
        isIssue: false,
        issues: [],
        name: 'Risk Profile',
        type: 1048576
      },
      {
        isIssue: true,
        issues: [
          {
            isIssue: true,
            issueId: 208040153,
            name: 'ALT GLOBAL OPPORTUNITIES FUND'
          }
        ],
        name: 'Outside Universe',
        type: 4
      }
    ];

    // when

    // then
    expect(formatOptions({ qualityCheckDetails })).toEqual([
      {
        key: 0,
        text: 'Asset Allocation - 208020823',
        value: 208020823
      },
      {
        key: 1,
        text: 'Outside Universe - 208040153',
        value: 208040153
      }
    ]);
  });

  it('should fetchJson - SUCCESS', () => {
    // given
    const parameters = {
      assetId: '1044992',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: [208020823, 208040153]
    };
    const response = {
      log: '[{"data":{"@mt":"Alternative"}}]'
    };

    // when
    const generator = fetchJson({ parameters });

    // then
    expect(generator.next().value).toEqual(
      call(
        get,
        '/api/v3/logger/businessLogs/?assetId=1044992&context=SOLVE-SELECTED&issueIds=208020823%2C208040153'
      )
    );
    expect(generator.next(response).value).toEqual(
      put({ type: LOGGER.JSON.FETCH.SUCCESS, json: JSON.parse(response.log) })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchJson - FAILURE', () => {
    // given
    const parameters = {
      assetId: '1044992',
      context: CONTEXT_TYPES.SOLVE_SELECTED,
      issueIds: [208020823, 208040153]
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchJson({ parameters });

    // then
    expect(generator.next().value).toEqual(
      call(
        get,
        '/api/v3/logger/businessLogs/?assetId=1044992&context=SOLVE-SELECTED&issueIds=208020823%2C208040153'
      )
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOGGER.JSON.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchIssueIds - SUCCESS', () => {
    // given
    const assetId = '1044992';
    const response = {
      qualityCheckDetails: [
        {
          isIssue: true,
          issues: [
            {
              globalIssueId: null,
              isIssue: false,
              issueId: null,
              name: 'Liquiditeiten',
              shortCode: 'LIQ'
            },
            {
              globalIssueId: 208020823,
              isIssue: true,
              issueId: 208024558,
              name: 'Obligaties',
              shortCode: 'OBLI'
            },
            {
              globalIssueId: 208020823,
              isIssue: true,
              issueId: 208024559,
              name: 'Alternatieve beleggingen',
              shortCode: 'ALTERN'
            }
          ],
          name: 'Asset Allocation',
          type: 1
        },
        {
          isIssue: false,
          issues: [],
          name: 'Risk Profile',
          type: 1048576
        },
        {
          isIssue: true,
          issues: [
            {
              isIssue: true,
              issueId: 208040153,
              name: 'ALT GLOBAL OPPORTUNITIES FUND'
            }
          ],
          name: 'Outside Universe',
          type: 4
        }
      ]
    };

    // when
    const generator = fetchIssueIds({ assetId });

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/portfolios/onlineQualityCheck/1044992')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: LOGGER.ISSUE_IDS.FETCH.SUCCESS, issueIdsOptions: formatOptions(response) })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchIssueIds - FAILURE', () => {
    // given
    const assetId = '1044992';
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchIssueIds({ assetId });

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/portfolios/onlineQualityCheck/1044992')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOGGER.ISSUE_IDS.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should loggerJsonSaga', () => {
    // given

    // when
    const generator = loggerJsonSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(LOGGER.JSON.FETCH.REQUEST, fetchJson)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should loggerIssueIdsSaga', () => {
    // given

    // when
    const generator = loggerIssueIdsSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(LOGGER.ISSUE_IDS.FETCH.REQUEST, fetchIssueIds)
    );
    expect(generator.next().done).toEqual(true);
  });
});
