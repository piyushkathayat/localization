import { call, put, takeEvery } from 'redux-saga/effects';
import { PROMOTION } from 'actions/ActionTypes';
import { post, get } from '@ubs.partner/shared-ui';
import {
  fetchPromotion,
  promoteToLiveDbHandler,
  promoteToLiveDb
} from '../promotion';

// TODO: update

describe('promotion sagas', () => {
  it('should fetchPromotion - SUCCESS', () => {
    // given
    const response = {
      canPromote: true,
      databases: [],
      dependencies: [],
      isPromotionRunning: false,
      lastPromotionDate: null,
      status: null
    };

    // when
    const generator = fetchPromotion();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/promotion')
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: PROMOTION.FETCH.SUCCESS,
        promotion: response
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchPromotion - FAILURE', () => {
    // given
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchPromotion();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/promotion')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: PROMOTION.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should promoteToLiveDbHandler - SUCCESS', () => {
    // given
    const params = {
      databases: []
    };
    const response = {
      databases: []
    };

    // when
    const generator = promoteToLiveDbHandler(params);

    // then
    expect(generator.next().value).toEqual(
      call(post, '/api/v3/cockpit/promotion', {
        dataToSend: { databases: [] }
      })
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: PROMOTION.PROMOTE.SUCCESS,
        databases: response.databases
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should promoteToLiveDbHandler - FAILURE', () => {
    // given
    const params = {
      databases: []
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = promoteToLiveDbHandler(params);

    // then
    expect(generator.next().value).toEqual(
      call(post, '/api/v3/cockpit/promotion', {
        dataToSend: { databases: [] }
      })
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: PROMOTION.PROMOTE.FAILURE, error })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should promoteToLiveDb', () => {
    // given

    // when
    const generator = promoteToLiveDb();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(PROMOTION.PROMOTE.REQUEST, promoteToLiveDbHandler)
    );
    expect(generator.next().done).toEqual(true);
  });
});
