import { PARAMETERS_UNIVERSE } from 'actions/ActionTypes';
import { PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE } from 'constants/parameters';
import { getIsin, getCurrentPage } from 'selectors/parametersUniverse';
import { delay } from 'redux-saga';
import { call, put, select, takeLatest } from 'redux-saga/effects';
import { post } from '@ubs.partner/shared-ui';
import {
  fetchInstrumentUniverse,
  instrumentUniversePageChangeSaga,
  instrumentUniverseSearchChangeSaga
} from '../parametersUniverse';

describe('parametersUniverse sagas', () => {
  it('should fetchInstrumentUniverse - SUCCESS', () => {
    // given
    const debounce = 500;
    const isin = '';
    const currentPage = 1;
    const response = {
      count: 1845,
      instruments: [],
      skipRows: 0,
      takeRows: 60
    };

    // when
    const generator = fetchInstrumentUniverse(debounce);

    // then
    expect(JSON.stringify(generator.next().value)).toEqual(
      JSON.stringify(delay(debounce))
    );
    expect(generator.next().value).toEqual(
      select(getIsin)
    );
    expect(generator.next(isin).value).toEqual(
      select(getCurrentPage)
    );
    expect(generator.next(currentPage).value).toEqual(
      call(post, '/api/v2/cockpit/universe', {
        dataToSend: {
          isin,
          skipRows: 0,
          takeRows: PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE
        }
      })
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: PARAMETERS_UNIVERSE.FETCH.SUCCESS,
        data: response
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchInstrumentUniverse - FAILURE', () => {
    // given
    const debounce = 500;
    const isin = '';
    const currentPage = 1;
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchInstrumentUniverse(debounce);

    // then
    // workaround to avoid weird behaviour of Jest
    expect(JSON.stringify(generator.next().value)).toEqual(
      JSON.stringify(delay(debounce))
    );
    expect(generator.next().value).toEqual(
      select(getIsin)
    );
    expect(generator.next(isin).value).toEqual(
      select(getCurrentPage)
    );
    expect(generator.next(currentPage).value).toEqual(
      call(post, '/api/v2/cockpit/universe', {
        dataToSend: {
          isin,
          skipRows: 0,
          takeRows: PARAMETERS_INSTRUMENT_UNIVERSE_PAGE_SIZE
        }
      })
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: PARAMETERS_UNIVERSE.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should instrumentUniversePageChangeSaga', () => {
    // given

    // when
    const generator = instrumentUniversePageChangeSaga();

    // then
    expect(generator.next().value).toEqual(
      takeLatest(PARAMETERS_UNIVERSE.PAGE.CHANGE, fetchInstrumentUniverse)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should instrumentUniverseSearchChangeSaga', () => {
    // given

    // when
    const generator = instrumentUniverseSearchChangeSaga();

    // then
    expect(generator.next().value).toEqual(
      takeLatest(
        [PARAMETERS_UNIVERSE.SEARCH.SET, PARAMETERS_UNIVERSE.SEARCH.CLEAR],
        fetchInstrumentUniverse,
        500
      )
    );
    expect(generator.next().done).toEqual(true);
  });
});
