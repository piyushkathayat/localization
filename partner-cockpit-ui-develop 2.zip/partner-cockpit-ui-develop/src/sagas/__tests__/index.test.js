import { fork, all } from 'redux-saga/effects';
import { router } from 'redux-saga-router';
import { updateValidationDetailsSaga, fetchAffectedPortfoliosSaga } from 'sagas/validationDetails';
import { recalculateDecisionSaga, validateDecisionSaga } from 'sagas/validation';
import { fetchQualityChecksSaga } from 'sagas/qualityChecks';
import { finalizeBrokerageSaga } from 'sagas/brokerageOverview';
import { updateTriggerSaga, fetchTriggerPortfoliosSaga } from 'sagas/brokerageDetails';
import { promoteToLiveDb } from 'sagas/promotion';
import { serverInfoSaga } from 'sagas/serverInfo';
import { startLoadAndQAJobSaga, stopLoadAndQAJobSaga } from 'sagas/loadAndQA';
import { fetchFileSaga } from 'sagas/loadAndQADrilldown';
import { parametersCheckInSaga, parametersCheckOutSaga, parametersCancelSaga } from 'sagas/parameters';
import { instrumentUniversePageChangeSaga, instrumentUniverseSearchChangeSaga } from 'sagas/parametersUniverse';
import { loggerJsonSaga, loggerIssueIdsSaga, loggerExtractSaga } from 'sagas/logger';
import { history } from 'store';
import routes from 'sagas/routes';
import sagas from '../index';

describe('index saga', () => {
  it('should fork all the sagas', () => {
    // given

    // when
    const generator = sagas();

    // then
    expect(generator.next().value).toEqual(
      all([
        fork(serverInfoSaga),
        fork(updateValidationDetailsSaga),
        fork(fetchAffectedPortfoliosSaga),
        fork(instrumentUniversePageChangeSaga),
        fork(instrumentUniverseSearchChangeSaga),
        fork(fetchQualityChecksSaga),
        fork(promoteToLiveDb),
        fork(recalculateDecisionSaga),
        fork(validateDecisionSaga),
        fork(finalizeBrokerageSaga),
        fork(updateTriggerSaga),
        fork(fetchTriggerPortfoliosSaga),
        fork(startLoadAndQAJobSaga),
        fork(stopLoadAndQAJobSaga),
        fork(fetchFileSaga),
        fork(parametersCheckInSaga),
        fork(parametersCheckOutSaga),
        fork(parametersCancelSaga),
        fork(loggerJsonSaga),
        fork(loggerIssueIdsSaga),
        fork(loggerExtractSaga),
        fork(router, history, routes)
      ])
    );
    expect(generator.next().done).toEqual(true);
  });
});
