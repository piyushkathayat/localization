import { call, put, takeEvery } from 'redux-saga/effects';
import { SERVER_INFO } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';
import { fetchServerInfo, serverInfoSaga } from '../serverInfo';

describe('serverInfo sagas', () => {
  it('should fetchServerInfo - SUCCESS', () => {
    // given
    const response = {};

    // when
    const generator = fetchServerInfo();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/environment_info')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: SERVER_INFO.FETCH.SUCCESS, data: response })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchServerInfo - FAILURE', () => {
    // given
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchServerInfo();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/environment_info')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: SERVER_INFO.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should serverInfoSaga', () => {
    // given

    // when
    const generator = serverInfoSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(SERVER_INFO.FETCH.REQUEST, fetchServerInfo)
    );
    expect(generator.next().done).toEqual(true);
  });
});
