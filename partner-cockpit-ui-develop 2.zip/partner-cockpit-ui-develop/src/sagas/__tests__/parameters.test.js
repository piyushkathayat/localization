import saveAs from 'file-saver';
import { call, put, takeEvery, all, select } from 'redux-saga/effects';
import { PARAMETERS } from 'actions/ActionTypes';
import { PARAMETERS_TYPES, RESPONSE_STATUSES } from 'constants/parameters';
import { uploadFile } from 'utils/uploadFile';
import { get, post } from '@ubs.partner/shared-ui';
import { getParameters } from 'selectors/parameters';
import {
  fetchParameters,
  parameterCheckIn,
  parameterCheckOut,
  parameterCancel,
  parametersCheckInSaga,
  parametersCheckOutSaga,
  parametersCancelSaga,
  sortParameters,
  getSortOrder
} from '../parameters';

describe('parameters sagas', () => {
  it('should getSortOrder', () => {
    // given
    const feedName = 'saa';

    // when
    const result = getSortOrder(feedName);
    const defaultResult = getSortOrder('unknown feedName');

    // then
    expect(result).toEqual(50);
    expect(defaultResult).toEqual(999);
  });

  it('should sortParameters', () => {
    // given
    const parametersList = [
      {
        checkedInAt: '2018-08-30T15:41:04.133',
        checkedInBy: '43395564',
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa',
        isUpdating: false
      },
      {
        checkedInAt: '2018-08-09T15:47:50.02',
        checkedInBy: '00355799',
        checkedOutAt: '2018-12-06T10:55:12.88',
        checkedOutBy: '00355799',
        feedName: 'universe',
        isUpdating: false
      },
      {
        checkedInAt: '2018-08-10T16:58:41.787',
        checkedInBy: '00355799',
        checkedOutAt: '2018-08-10T16:58:26.597',
        checkedOutBy: '00355799',
        feedName: 'lk',
        isUpdating: false
      }
    ];

    // when
    const result = sortParameters(parametersList);

    // then
    expect(result).toEqual([
      {
        checkedInAt: '2018-08-09T15:47:50.02',
        checkedInBy: '00355799',
        checkedOutAt: '2018-12-06T10:55:12.88',
        checkedOutBy: '00355799',
        feedName: 'universe',
        isUpdating: false
      },
      {
        checkedInAt: '2018-08-10T16:58:41.787',
        checkedInBy: '00355799',
        checkedOutAt: '2018-08-10T16:58:26.597',
        checkedOutBy: '00355799',
        feedName: 'lk',
        isUpdating: false
      },
      {
        checkedInAt: '2018-08-30T15:41:04.133',
        checkedInBy: '43395564',
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa',
        isUpdating: false
      }
    ]);
  });

  it('should fetchParameters - no API call if there are parameters', () => {
    // given
    const parameters = {
      saa: {
        checkedInAt: '2018-08-30T15:41:04.133',
        checkedInBy: '43395564',
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa',
        isUpdating: false
      },
      universe: {
        checkedInAt: '2018-08-09T15:47:50.02',
        checkedInBy: '00355799',
        checkedOutAt: '2018-12-06T10:55:12.88',
        checkedOutBy: '00355799',
        feedName: 'universe',
        isUpdating: false
      },
      lk: {
        checkedInAt: '2018-08-10T16:58:41.787',
        checkedInBy: '00355799',
        checkedOutAt: '2018-08-10T16:58:26.597',
        checkedOutBy: '00355799',
        feedName: 'lk',
        isUpdating: false
      }
    };

    // when
    const generator = fetchParameters();

    // then
    expect(generator.next().value).toEqual(
      select(getParameters)
    );
    expect(generator.next(parameters).done).toEqual(true);
  });

  it('should fetchParameters - API call if there are no parameters', () => {
    // given
    const parameters = {};
    const response = {
      statuses: [
        {
          checkedInAt: '2018-08-30T15:41:04.133',
          checkedInBy: '43395564',
          checkedOutAt: '2018-12-06T10:55:10.067',
          checkedOutBy: '00355799',
          feedName: 'saa'
        },
        {
          checkedInAt: '2018-08-09T15:47:50.02',
          checkedInBy: '00355799',
          checkedOutAt: '2018-12-06T10:55:12.88',
          checkedOutBy: '00355799',
          feedName: 'universe'
        },
        {
          checkedInAt: '2018-08-10T16:58:41.787',
          checkedInBy: '00355799',
          checkedOutAt: '2018-08-10T16:58:26.597',
          checkedOutBy: '00355799',
          feedName: 'lk'
        }
      ]
    };

    // when
    const generator = fetchParameters();

    // then
    expect(generator.next().value).toEqual(
      select(getParameters)
    );
    expect(generator.next(parameters).value).toEqual(
      call(post, '/api/v3/cockpit/feeds_statuses', {
        dataToSend: { feeds: Object.values(PARAMETERS_TYPES) }
      })
    );
    expect(generator.next(response).value).toEqual(
      put({ type: PARAMETERS.FETCH.SUCCESS, statusesList: sortParameters(response.statuses) })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchParameters - FAILURE', () => {
    // given
    const parameters = {};
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchParameters();

    // then
    expect(generator.next().value).toEqual(
      select(getParameters)
    );
    expect(generator.next(parameters).value).toEqual(
      call(post, '/api/v3/cockpit/feeds_statuses', {
        dataToSend: { feeds: Object.values(PARAMETERS_TYPES) }
      })
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: PARAMETERS.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckIn - SUCCESS', () => {
    // given
    const params = {
      feedName: 'saa',
      file: {
        size: 1024,
        name: 'Filename.zip'
      }
    };
    const feedsourceResponse = {
      createUrl: 'some/url/to/file',
      putRangeUrl: 'some/other/url',
      filename: 'Filename.zip'
    };
    const uploadResponse = true;
    const checkInResponse = {
      checkInResponse: {
        status: RESPONSE_STATUSES.SUCCESS
      },
      checkInStatusResponse: {
        checkinStatus: {
          checkedInAt: '2018-08-30T15:41:04.133',
          checkedInBy: '43535763',
          feedName: 'saa'
        }
      }
    };

    // when
    const generator = parameterCheckIn(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/feedsource/saa')
    );
    expect(generator.next(feedsourceResponse).value).toEqual(
      call(uploadFile, feedsourceResponse, params.file)
    );
    expect(generator.next(uploadResponse).value).toEqual(
      all({
        checkInResponse: call(get, '/api/v2/cockpit/checkin/saa'),
        checkInStatusResponse: call(get, '/api/v2/cockpit/checkinstatus/saa')
      })
    );
    expect(generator.next(checkInResponse).value).toEqual(
      put({
        type: PARAMETERS.CHECK_IN.SUCCESS,
        parameter: checkInResponse.checkInStatusResponse.checkinStatus
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckIn - FAILURE in filename', () => {
    // given
    const params = {
      feedName: 'saa',
      file: {
        size: 1024,
        name: 'wrongFileName.zip'
      }
    };
    const feedsourceResponse = {
      createUrl: 'some/url/to/file',
      putRangeUrl: 'some/other/url',
      filename: 'Filename.zip'
    };

    // when
    const generator = parameterCheckIn(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/feedsource/saa')
    );
    expect(generator.next(feedsourceResponse).value).toEqual(
      put({
        type: PARAMETERS.CHECK_IN.FAILURE,
        error: `Filename incorrect. Please use: ${feedsourceResponse.filename}`,
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckIn - FAILURE in checkInResponse', () => {
    // given
    const params = {
      feedName: 'saa',
      file: {
        size: 1024,
        name: 'Filename.zip'
      }
    };
    const feedsourceResponse = {
      createUrl: 'some/url/to/file',
      putRangeUrl: 'some/other/url',
      filename: 'Filename.zip'
    };
    const uploadResponse = true;
    const checkInResponse = {
      checkInResponse: {
        status: 'ERROR',
        message: 'checkInResponse Error'
      },
      checkInStatusResponse: {
        checkinStatus: {
          checkedInAt: '2018-08-30T15:41:04.133',
          checkedInBy: '43535763',
          feedName: 'saa'
        }
      }
    };

    // when
    const generator = parameterCheckIn(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/feedsource/saa')
    );
    expect(generator.next(feedsourceResponse).value).toEqual(
      call(uploadFile, feedsourceResponse, params.file)
    );
    expect(generator.next(uploadResponse).value).toEqual(
      all({
        checkInResponse: call(get, '/api/v2/cockpit/checkin/saa'),
        checkInStatusResponse: call(get, '/api/v2/cockpit/checkinstatus/saa')
      })
    );
    expect(generator.next(checkInResponse).value).toEqual(
      put({
        type: PARAMETERS.CHECK_IN.FAILURE,
        error: 'checkInResponse Error',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckIn - FAILURE in uploadResponse', () => {
    // given
    const params = {
      feedName: 'saa',
      file: {
        size: 1024,
        name: 'Filename.zip'
      }
    };
    const feedsourceResponse = {
      createUrl: 'some/url/to/file',
      putRangeUrl: 'some/other/url',
      filename: 'Filename.zip'
    };
    const uploadResponse = false;

    // when
    const generator = parameterCheckIn(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/feedsource/saa')
    );
    expect(generator.next(feedsourceResponse).value).toEqual(
      call(uploadFile, feedsourceResponse, params.file)
    );
    expect(generator.next(uploadResponse).value).toEqual(
      put({
        type: PARAMETERS.CHECK_IN.FAILURE,
        error: 'Error during the file upload',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckIn - FAILURE in feedsourceResponse', () => {
    // given
    const params = {
      feedName: 'saa',
      file: {
        size: 1024,
        name: 'Filename.zip'
      }
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = parameterCheckIn(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/feedsource/saa')
    );
    expect(generator.throw(error).value).toEqual(
      put({
        type: PARAMETERS.CHECK_IN.FAILURE,
        error: 'someError',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckOut - SUCCESS', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const response = {
      status: RESPONSE_STATUSES.SUCCESS,
      downloadURL: 'some/url/to/file',
      fileName: 'fileName.zip'
    };
    const checkOutStatusResponse = {
      checkoutStatus: {
        feedName: 'saa'
      }
    };

    // when
    const generator = parameterCheckOut(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/checkout/saa')
    );
    expect(generator.next(response).value).toEqual(
      call(get, '/api/v2/cockpit/checkoutstatus/saa')
    );
    expect(generator.next(checkOutStatusResponse).value).toEqual(
      put({
        type: PARAMETERS.CHECK_OUT.SUCCESS,
        parameter: checkOutStatusResponse.checkoutStatus
      })
    );
    expect(generator.next().value).toEqual(
      call(saveAs, response.downloadURL, response.fileName)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckOut - FAILURE on response', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const response = {
      status: 'ERROR',
      message: 'someError'
    };

    // when
    const generator = parameterCheckOut(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/checkout/saa')
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: PARAMETERS.CHECK_OUT.FAILURE,
        error: 'someError',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCheckOut - FAILURE', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = parameterCheckOut(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/checkout/saa')
    );
    expect(generator.throw(error).value).toEqual(
      put({
        type: PARAMETERS.CHECK_OUT.FAILURE,
        error: 'someError',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCancel - SUCCESS', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const response = {
      cancelResponse: {
        status: RESPONSE_STATUSES.SUCCESS
      },
      checkoutStatus: {
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa'
      }
    };

    // when
    const generator = parameterCancel(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/checkoutcancel/saa')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: PARAMETERS.CANCEL.SUCCESS, parameter: response.checkoutStatus })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCancel - FAILURE on response', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const response = {
      cancelResponse: {
        status: 'ERROR',
        message: 'someError'
      },
      checkoutStatus: {
        checkedOutAt: '2018-12-06T10:55:10.067',
        checkedOutBy: '00355799',
        feedName: 'saa'
      }
    };

    // when
    const generator = parameterCancel(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/checkoutcancel/saa')
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: PARAMETERS.CANCEL.FAILURE,
        error: 'someError',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parameterCancel - FAILURE', () => {
    // given
    const params = {
      feedName: 'saa'
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = parameterCancel(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v2/cockpit/checkoutcancel/saa')
    );
    expect(generator.throw(error).value).toEqual(
      put({
        type: PARAMETERS.CANCEL.FAILURE,
        error: 'someError',
        feedName: 'saa'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parametersCheckInSaga', () => {
    // given

    // when
    const generator = parametersCheckInSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(PARAMETERS.CHECK_IN.REQUEST, parameterCheckIn)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parametersCheckOutSaga', () => {
    // given

    // when
    const generator = parametersCheckOutSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(PARAMETERS.CHECK_OUT.REQUEST, parameterCheckOut)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should parametersCancelSaga', () => {
    // given

    // when
    const generator = parametersCancelSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(PARAMETERS.CANCEL.REQUEST, parameterCancel)
    );
    expect(generator.next().done).toEqual(true);
  });
});
