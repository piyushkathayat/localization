import * as R from 'ramda';
import { call, put, takeEvery, select, all } from 'redux-saga/effects';
import { get, post } from '@ubs.partner/shared-ui';
import { LOAD_AND_QA } from 'actions/ActionTypes';
import { getActivities, getJobs } from 'selectors/loadAndQA';
import { getCentralDBKey } from 'selectors/serverInfo';
import { DB_TYPES } from 'constants/serverInfo';
import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { SP_FEED } from 'sagas/__mocks__/SP';
import {
  fetchLoadAndQA,
  fetchLoadAndQAJobs,
  executeLoadAndQAJob,
  startLoadAndQAJobSaga,
  stopLoadAndQAJobSaga
} from '../loadAndQA';

describe('loadAndQA sagas', () => {
  it('should fetchLoadAndQA - no call if there are activities', () => {
    // given
    const activities = {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    };

    // when
    const generator = fetchLoadAndQA();

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).done).toEqual(true);
  });

  it('should fetchLoadAndQA - API call if there are no activities', () => {
    // given
    const activities = {};
    const response = [
      {
        activityId: 3,
        activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      {
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    ];
    const centralKey = 'central';

    // when
    const generator = fetchLoadAndQA();

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      call(get, '/api/v3/cockpit/activities')
    );
    expect(generator.next(response).value).toEqual(
      select(getCentralDBKey)
    );
    expect(generator.next(centralKey).value).toEqual(
      put({
        type: LOAD_AND_QA.FETCH.SUCCESS,
        activities: R.prepend(SP_FEED, response)
      })
    );
    expect(generator.next(activities).done).toEqual(true);
  });

  it('should fetchLoadAndQA - FAILURE', () => {
    // given
    const activities = {};
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchLoadAndQA();

    // then
    expect(generator.next().value).toEqual(
      select(getActivities)
    );
    expect(generator.next(activities).value).toEqual(
      call(get, '/api/v3/cockpit/activities')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOAD_AND_QA.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchLoadAndQAJobs - no call if there are jobs', () => {
    // given
    const jobs = {
      [DB_TYPES.PARTNER]: [
        {
          key: '23c4885f-fa30-4fcc-b2e1-2161e5742813',
          value: 'Copy Test Files'
        },
        {
          key: 'bd20617d-1ec9-449c-a3b8-79863e360deb',
          value: 'LK Tables'
        }
      ],
      [DB_TYPES.CENTRAL]: [
        {
          key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
          value: 'Get Central Instruments'
        },
        {
          key: '0085e781-e1ca-454f-965a-5201d163cd62',
          value: 'MiniCentral Extract'
        }
      ]
    };

    // when
    const generator = fetchLoadAndQAJobs();

    // then
    expect(generator.next().value).toEqual(
      select(getJobs)
    );
    expect(generator.next(jobs).done).toEqual(true);
  });

  it('should fetchLoadAndQAJobs - API call if there are no jobs', () => {
    // given
    const jobs = {};
    const response = [
      [
        {
          key: '23c4885f-fa30-4fcc-b2e1-2161e5742813',
          value: 'Copy Test Files'
        },
        {
          key: 'bd20617d-1ec9-449c-a3b8-79863e360deb',
          value: 'LK Tables'
        }
      ],
      [
        {
          key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
          value: 'Get Central Instruments'
        },
        {
          key: '0085e781-e1ca-454f-965a-5201d163cd62',
          value: 'MiniCentral Extract'
        }
      ]
    ];

    // when
    const generator = fetchLoadAndQAJobs();

    // then
    expect(generator.next().value).toEqual(
      select(getJobs)
    );
    expect(generator.next(jobs).value).toEqual(
      all([
        call(get, `/api/v2/cockpit/jobs/${DB_TYPES.PARTNER}`),
        call(get, `/api/v2/cockpit/jobs/${DB_TYPES.CENTRAL}`)
      ])
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: LOAD_AND_QA.JOBS.FETCH.SUCCESS,
        jobs: {
          [DB_TYPES.PARTNER]: [{
            key: '23c4885f-fa30-4fcc-b2e1-2161e5742813',
            value: 'Copy Test Files'
          },
          {
            key: 'bd20617d-1ec9-449c-a3b8-79863e360deb',
            value: 'LK Tables'
          }],
          [DB_TYPES.CENTRAL]: [
            {
              key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
              value: 'Get Central Instruments'
            },
            {
              key: '0085e781-e1ca-454f-965a-5201d163cd62',
              value: 'MiniCentral Extract'
            }
          ]
        }
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchLoadAndQAJobs - FAILURE', () => {
    // given
    const jobs = {};
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchLoadAndQAJobs();

    // then
    expect(generator.next().value).toEqual(
      select(getJobs)
    );
    expect(generator.next(jobs).value).toEqual(
      all([
        call(get, `/api/v2/cockpit/jobs/${DB_TYPES.PARTNER}`),
        call(get, `/api/v2/cockpit/jobs/${DB_TYPES.CENTRAL}`)
      ])
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOAD_AND_QA.JOBS.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should executeLoadAndQAJob - SUCCESS', () => {
    // given
    const params = {
      command: LOAD_AND_QA.JOBS.START,
      database: DB_TYPES.CENTRAL,
      jobId: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
    };

    // when
    const generator = executeLoadAndQAJob(params);

    // then
    expect(generator.next().value).toEqual(
      call(post, '/api/v3/cockpit/executeJob', {
        dataToSend: {
          command: LOAD_AND_QA.JOBS.START,
          database: DB_TYPES.CENTRAL,
          jobId: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
        }
      })
    );
    expect(generator.next().value).toEqual(
      put({ type: LOAD_AND_QA.JOBS.SUCCESS })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should executeLoadAndQAJob - FAILURE', () => {
    // given
    const params = {
      command: LOAD_AND_QA.JOBS.START,
      database: DB_TYPES.CENTRAL,
      jobId: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = executeLoadAndQAJob(params);

    // then
    expect(generator.next().value).toEqual(
      call(post, '/api/v3/cockpit/executeJob', {
        dataToSend: {
          command: LOAD_AND_QA.JOBS.START,
          database: DB_TYPES.CENTRAL,
          jobId: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216'
        }
      })
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: LOAD_AND_QA.JOBS.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should startLoadAndQAJobSaga', () => {
    // given

    // when
    const generator = startLoadAndQAJobSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(LOAD_AND_QA.JOBS.START, executeLoadAndQAJob)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should stopLoadAndQAJobSaga', () => {
    // given

    // when
    const generator = stopLoadAndQAJobSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(LOAD_AND_QA.JOBS.STOP, executeLoadAndQAJob)
    );
    expect(generator.next().done).toEqual(true);
  });
});
