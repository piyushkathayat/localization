import { select, call } from 'redux-saga/effects';
import { getDecisions } from 'selectors/validation';
// import { MENU_ITEMS } from 'constants/menu';
// import { APP_PREFIX } from 'constants/common';
// import { fetchCoreEngine } from '../coreEngine';
// import { fetchSummary } from '../summary';
import { fetchLoadAndQA, fetchLoadAndQAJobs } from '../loadAndQA';
import { fetchLoadAndQAActions } from '../loadAndQAActions';
import { fetchLoadAndQADrilldown } from '../loadAndQADrilldown';
// import { fetchQualityChecks } from '../qualityChecks';
import { fetchDecisions } from '../validation';
import { fetchValidationDetails } from '../validationDetails';
// import { fetchPromotion } from '../promotion';
import { fetchParameters } from '../parameters';
import { fetchParametersDetails } from '../parametersDetails';
import /* routes , */{
  handleValidationDetails,
  handleLoadAndQAOverview,
  handleLoadAndQAActions,
  handleLoadAndQADrilldown,
  handleParametersDetails
} from '../routes';

// TODO: update

describe('routes sagas', () => {
  it('should handleValidationDetails - empty decisions', () => {
    // given
    const params = {};
    const decisions = {};

    // when
    const generator = handleValidationDetails(params);

    // then
    expect(generator.next().value).toEqual(
      select(getDecisions)
    );
    expect(generator.next(decisions).value).toEqual(
      call(fetchDecisions, params, false)
    );
    expect(generator.next().value).toEqual(
      call(fetchValidationDetails, params)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should handleValidationDetails - non-empty executions', () => {
    // given
    const params = {};
    const decisions = {
      45: {
        decisionId: 45
      }
    };

    // when
    const generator = handleValidationDetails(params);

    // then
    expect(generator.next().value).toEqual(
      select(getDecisions)
    );
    expect(generator.next(decisions).value).toEqual(
      call(fetchValidationDetails, params)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should handleLoadAndQAOverview', () => {
    // given

    // when
    const generator = handleLoadAndQAOverview();

    // then
    expect(generator.next().value).toEqual(
      call(fetchLoadAndQA)
    );
    expect(generator.next().value).toEqual(
      call(fetchLoadAndQAJobs)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should handleLoadAndQAActions', () => {
    // given
    const params = {};

    // when
    const generator = handleLoadAndQAActions(params);

    // then
    expect(generator.next().value).toEqual(
      call(fetchLoadAndQA)
    );
    expect(generator.next().value).toEqual(
      call(fetchLoadAndQAActions, params)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should handleLoadAndQADrilldown', () => {
    // given
    const params = {};

    // when
    const generator = handleLoadAndQADrilldown(params);

    // then
    expect(generator.next().value).toEqual(
      call(handleLoadAndQAActions, params)
    );
    expect(generator.next().value).toEqual(
      call(fetchLoadAndQADrilldown, params)
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should handleParametersDetails', () => {
    // given
    const params = {};

    // when
    const generator = handleParametersDetails(params);

    // then
    expect(generator.next().value).toEqual(
      call(fetchParameters)
    );
    expect(generator.next().value).toEqual(
      call(fetchParametersDetails, params)
    );
    expect(generator.next().done).toEqual(true);
  });

  // it('should routes', () => {
  //   // given
  //   const expectedRoutes = [
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.SUMMARY}`, handler: fetchSummary },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`, handler: handleLoadAndQAOverview },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id`, handler: handleLoadAndQAActions },
  //     {
  //   pattern: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id/:drilldownType/:drilldownKey`,
  //   handler: handleLoadAndQADrilldown
  // },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.QUALITY_CHECK}`, handler: fetchQualityChecks },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}`, handler: fetchDecisions },
  // {
  //   pattern: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/:decisionId/:qualityCheckType`,
  //   handler: handleValidationDetails
  // },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.PROMOTION}`, handler: fetchPromotion },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}`, handler: fetchParameters },
  //     {
  //   pattern: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/:feedName`,
  //   handler: handleParametersDetails
  // },
  //     { pattern: `/${APP_PREFIX}/${MENU_ITEMS.CORE_ENGINE}`, handler: fetchCoreEngine }
  //   ];

  //   // when

  //   // then
  //   expect(routes).toEqual(expectedRoutes);
  // });
});
