import { call, put } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import { SUMMARY } from 'actions/ActionTypes';
import { fetchSummary } from '../summary';

describe('summary sagas', () => {
  it('should fetchSummary - SUCCESS', () => {
    // given
    const response = {};

    // when
    const generator = fetchSummary();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/summary')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: SUMMARY.FETCH.SUCCESS, data: response })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchSummary - FAILURE', () => {
    // given
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchSummary();

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/summary')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: SUMMARY.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });
});
