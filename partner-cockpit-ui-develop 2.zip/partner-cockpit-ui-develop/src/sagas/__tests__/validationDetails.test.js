import { call, put, takeEvery } from 'redux-saga/effects';
import { VALIDATION_DETAILS } from 'actions/ActionTypes';
import { get, put as PUT } from '@ubs.partner/shared-ui';
import {
  fetchValidationDetails,
  updateDecisionDetails,
  updateValidationDetailsSaga
} from '../validationDetails';

// TODO: update

describe('validationDetails sagas', () => {
  it('should fetchValidationDetails - SUCCESS', () => {
    // given
    const parameters = {
      qualityCheckType: 1,
      decisionId: 48
    };
    const response = {
      decisionItems: [
        {
          decisionKey: 1,
          approvalStatus: 30
        },
        {
          decisionKey: 2,
          approvalStatus: 20
        }
      ],
      approvalStatuses: [
        {
          approvalStatusId: 13,
          decisionName: 'Postponed'
        },
        {
          approvalStatusId: 20,
          decisionName: 'Accepted'
        },
        {
          approvalStatusId: 30,
          decisionName: 'Rejected'
        }
      ],
      decision: {
        decisionGroup: 2,
        decisionLevel: 1,
        qualityCheckName: 'Bulk Risk'
      }
    };
    const indexedDecisions = {
      1: {
        decisionKey: 1,
        approvalStatus: 30
      },
      2: {
        decisionKey: 2,
        approvalStatus: 20
      }
    };

    // when
    const generator = fetchValidationDetails(parameters);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/decisions/48/1')
    );
    expect(generator.next(response).value).toEqual(
      put({
        type: VALIDATION_DETAILS.FETCH.SUCCESS,
        decisionItems: indexedDecisions,
        decisionItemsIds: [1, 2],
        approvalStatuses: [13, 20, 30],
        decisionLevel: 1,
        decisionGroup: 2,
        qualityCheckName: 'Bulk Risk'
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchValidationDetails - FAILURE', () => {
    // given
    const parameters = {
      qualityCheckType: 1,
      decisionId: 48
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchValidationDetails(parameters);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/decisions/48/1')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: VALIDATION_DETAILS.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should updateDecisionDetails - SUCCESS', () => {
    // given
    const parameters = {
      decisionId: 48,
      qualityCheckType: 1,
      decisionItemsIds: [1, 2],
      approvalStatusId: 30,
      comment: 'someExplanation',
      confirmedBy: '43535763'
    };
    const requestBody = {
      approvalStatusId: 30,
      decisionItemsIds: [1, 2],
      confirmedBy: '43535763',
      comment: 'someExplanation'
    };

    // when
    const generator = updateDecisionDetails(parameters);

    // then
    expect(generator.next().value).toEqual(
      call(PUT, '/api/v3/cockpit/decisions/48/1', {
        dataToSend: requestBody
      })
    );
    expect(generator.next().value).toEqual(
      put({
        type: VALIDATION_DETAILS.UPDATE.SUCCESS,
        updatedDecisions: requestBody
      })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should updateDecisionDetails - FAILURE', () => {
    // given
    const parameters = {
      decisionId: 48,
      qualityCheckType: 1,
      decisionItemsIds: [1, 2],
      approvalStatusId: 30,
      comment: 'someExplanation',
      confirmedBy: '43535763'
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = updateDecisionDetails(parameters);

    // then
    expect(generator.next().value).toEqual(
      call(PUT, '/api/v3/cockpit/decisions/48/1', {
        dataToSend: {
          approvalStatusId: 30,
          decisionItemsIds: [1, 2],
          confirmedBy: '43535763',
          comment: 'someExplanation'
        }
      })
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: VALIDATION_DETAILS.UPDATE.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should updateValidationDetailsSaga', () => {
    // given

    // when
    const generator = updateValidationDetailsSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(VALIDATION_DETAILS.UPDATE.REQUEST, updateDecisionDetails)
    );
    expect(generator.next().done).toEqual(true);
  });
});
