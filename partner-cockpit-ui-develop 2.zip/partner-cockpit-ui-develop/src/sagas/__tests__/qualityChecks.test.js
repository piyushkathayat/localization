import { call, put, takeEvery } from 'redux-saga/effects';
import { QUALITY_CHECK } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';
import { fetchQualityChecks, fetchQualityChecksSaga } from '../qualityChecks';

describe('qualityChecks sagas', () => {
  it('should fetchQualityChecks - SUCCESS', () => {
    // given
    const params = {
      days: 21
    };
    const response = [];

    // when
    const generator = fetchQualityChecks(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/quality_checks/21')
    );
    expect(generator.next(response).value).toEqual(
      put({ type: QUALITY_CHECK.FETCH.SUCCESS, data: response })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchQualityChecks - FAILURE', () => {
    // given
    const params = {
      days: 21
    };
    const error = {
      message: 'someError'
    };

    // when
    const generator = fetchQualityChecks(params);

    // then
    expect(generator.next().value).toEqual(
      call(get, '/api/v3/cockpit/quality_checks/21')
    );
    expect(generator.throw(error).value).toEqual(
      put({ type: QUALITY_CHECK.FETCH.FAILURE, error: 'someError' })
    );
    expect(generator.next().done).toEqual(true);
  });

  it('should fetchQualityChecksSaga', () => {
    // given

    // when
    const generator = fetchQualityChecksSaga();

    // then
    expect(generator.next().value).toEqual(
      takeEvery(QUALITY_CHECK.FETCH.REQUEST, fetchQualityChecks)
    );
    expect(generator.next().done).toEqual(true);
  });
});
