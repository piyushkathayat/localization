import * as R from 'ramda';
import { delay } from 'redux-saga';
import { call, put, select } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import { LOAD_AND_QA_ACTIONS } from 'actions/ActionTypes';
import { getActivities } from 'selectors/loadAndQA';
import { getActions } from 'selectors/loadAndQAActions';
import { getCentralDBKey } from 'selectors/serverInfo';
import { DB_TYPES } from 'constants/serverInfo';
import { SP_FEED_KEY, SP_FEED_ACTIONS } from './__mocks__/SP';

export function* fetchLoadAndQAActions({ id }) {
  const activities = yield select(getActivities);
  const centralDBKey = yield select(getCentralDBKey);
  const actions = yield select(getActions);
  const selectedActivity = R.propOr({}, id, activities);
  const activityOwner = R.prop('activityOwner', selectedActivity);
  const activityKey = R.prop('activityKey', selectedActivity);
  const dbType = activityOwner === centralDBKey ? DB_TYPES.CENTRAL : DB_TYPES.PARTNER;

  if (activityKey === SP_FEED_KEY) {
    yield delay(500);
    return yield put({
      type: LOAD_AND_QA_ACTIONS.FETCH.SUCCESS,
      actions: SP_FEED_ACTIONS
    });
  }

  try {
    if (!actions.length) {
      const response = yield call(
        get,
        `/api/v3/cockpit/activities/actions/${dbType}/${activityKey}`
      );
      yield put({ type: LOAD_AND_QA_ACTIONS.FETCH.SUCCESS, actions: response });
    }
  } catch (e) {
    yield put({ type: LOAD_AND_QA_ACTIONS.FETCH.FAILURE, error: e.message });
  }
}
