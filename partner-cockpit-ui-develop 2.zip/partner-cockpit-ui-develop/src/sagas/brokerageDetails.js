import * as R from 'ramda';
import { call, put, takeEvery } from 'redux-saga/effects';
import { BROKERAGE_DETAILS } from 'actions/ActionTypes';
import { get, put as PUT } from '@ubs.partner/shared-ui';
import { getDecodedKeys, decodeItemsList } from 'utils/common';

export function* updateTrigger({ triggerThemeId, triggerId, isLocked }) {
  try {
    yield call(PUT, `/api/v3/cockpit/brokerage/triggers/${triggerId}/${isLocked}`, {
      dataToSend: {}
    });
    yield put({ type: BROKERAGE_DETAILS.UPDATE.SUCCESS, triggerThemeId, triggerId, isLocked });
  } catch (e) {
    yield put({ type: BROKERAGE_DETAILS.UPDATE.FAILURE, error: e.message });
  }
}

export function* fetchTriggerPortfolios({ triggerId }) {
  try {
    const response = yield call(get, `/api/v3/cockpit/brokerage/triggers/${triggerId}/portfolios/`);
    let portfoliosList = R.prop('portfolios', response);
    try {
      const decodedKeys = yield call(getDecodedKeys, response.injector);
      portfoliosList = decodeItemsList({
        fieldsList: ['portfolioCode'],
        itemsList: portfoliosList,
        decodedKeys
      });
    } catch (e) {
      console.warn('Fetching decoded keys failed: ', e.message);
    }
    yield put({
      type: BROKERAGE_DETAILS.PORTFOLIOS.FETCH.SUCCESS,
      triggerId,
      portfoliosList
    });
  } catch (e) {
    yield put({ type: BROKERAGE_DETAILS.PORTFOLIOS.FETCH.FAILURE, error: e.message });
  }
}

export function* updateTriggerSaga() {
  yield takeEvery(BROKERAGE_DETAILS.UPDATE.REQUEST, updateTrigger);
}

export function* fetchTriggerPortfoliosSaga() {
  yield takeEvery(BROKERAGE_DETAILS.PORTFOLIOS.FETCH.REQUEST, fetchTriggerPortfolios);
}
