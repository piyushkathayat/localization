import * as R from 'ramda';
import { call, put, takeEvery } from 'redux-saga/effects';
import { VALIDATION_DETAILS } from 'actions/ActionTypes';
import { get, put as PUT } from '@ubs.partner/shared-ui';
import { getDecodedKeys, decodeItemsList } from 'utils/common';

export function* fetchValidationDetails({ qualityCheckType, decisionId }) {
  try {
    const response = yield call(get, `/api/v3/cockpit/decisions/${decisionId}/${qualityCheckType}`);
    yield put({
      type: VALIDATION_DETAILS.FETCH.SUCCESS,
      decisionItems: R.indexBy(R.prop('decisionKey'), response.decisionItems),
      decisionItemsIds: response.decisionItems.map(({ decisionKey }) => decisionKey),
      approvalStatuses: response.approvalStatuses.map(({ approvalStatusId }) => approvalStatusId),
      decisionLevel: R.path(['decision', 'decisionLevel'], response),
      decisionGroup: R.path(['decision', 'decisionGroup'], response),
      qualityCheckName: R.path(['decision', 'qualityCheckName'], response)
    });
  } catch (e) {
    yield put({ type: VALIDATION_DETAILS.FETCH.FAILURE, error: e.message });
  }
}

export function* updateDecisionDetails({
  decisionId,
  qualityCheckType,
  decisionItemsIds,
  approvalStatusId,
  comment,
  confirmedBy
}) {
  try {
    const requestBody = {
      approvalStatusId,
      decisionItemsIds,
      comment,
      confirmedBy
    };
    yield call(PUT, `/api/v3/cockpit/decisions/${decisionId}/${qualityCheckType}`, {
      dataToSend: requestBody
    });
    yield put({ type: VALIDATION_DETAILS.UPDATE.SUCCESS, updatedDecisions: requestBody });
  } catch (e) {
    yield put({ type: VALIDATION_DETAILS.UPDATE.FAILURE, error: e.message });
  }
}

export function* fetchAffectedPortfolios({ decisionId, decisionItemId }) {
  try {
    const response = yield call(get, `/api/v2/cockpit/executions/portfolios/${decisionId}/${decisionItemId}`);
    let portfoliosList = R.prop('portfolios', response);
    try {
      const decodedKeys = yield call(getDecodedKeys, response.injector);
      portfoliosList = decodeItemsList({
        fieldsList: ['portfolioCode'],
        itemsList: portfoliosList,
        decodedKeys
      });
    } catch (e) {
      console.warn('Fetching decoded keys failed: ', e.message);
    }
    yield put({
      type: VALIDATION_DETAILS.PORTFOLIOS.FETCH.SUCCESS,
      portfoliosList: R.map(
        R.pick(['assetId', 'clientId', 'portfolioCode', 'portfolioCcy', 'investmentStrategyDesc']),
        portfoliosList
      ),
      decisionItemId
    });
  } catch (e) {
    yield put({ type: VALIDATION_DETAILS.PORTFOLIOS.FETCH.FAILURE, error: e.message });
  }
}

export function* updateValidationDetailsSaga() {
  yield takeEvery(VALIDATION_DETAILS.UPDATE.REQUEST, updateDecisionDetails);
}

export function* fetchAffectedPortfoliosSaga() {
  yield takeEvery(VALIDATION_DETAILS.PORTFOLIOS.FETCH.REQUEST, fetchAffectedPortfolios);
}
