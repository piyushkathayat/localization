import * as R from 'ramda';
import { call, put, select, takeEvery } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import saveAs from 'file-saver';
import { LOAD_AND_QA_DRILLDOWN } from 'actions/ActionTypes';
import { getActivities } from 'selectors/loadAndQA';
import { getCentralDBKey } from 'selectors/serverInfo';
import { getDbType, getDrilldownByDrilldownId } from 'selectors/loadAndQADrilldown';
import { DB_TYPES } from 'constants/serverInfo';
import { DRILLDOWN_TYPES } from 'constants/loadAndQA';

const mapIndexed = R.addIndex(R.map);

export const getLinkFileType = ({ invalidRecordCount, fileName }) => `${invalidRecordCount}/${fileName.replace('.csv', '')}`;
export const getLinkValidationType = ({ invalidRows, tableName }) => `${invalidRows}/${tableName}`;
export const getLinkQAType = ({ numberOfIssues, brsCode }) => `${numberOfIssues}/${brsCode}`;

export function getLink(drilldown) {
  switch (drilldown.drilldownType) {
    case DRILLDOWN_TYPES.FILE:
      return getLinkFileType(drilldown);
    case DRILLDOWN_TYPES.VALIDATION:
      return getLinkValidationType(drilldown);
    case DRILLDOWN_TYPES.QA:
      return getLinkQAType(drilldown);
    default:
      return null;
  }
}

export function* fetchLoadAndQADrilldown({ id, drilldownType, drilldownKey }) {
  try {
    const activities = yield select(getActivities);
    const centralDBKey = yield select(getCentralDBKey);

    const selectedActivity = R.propOr({}, id, activities);
    const activityOwner = R.prop('activityOwner', selectedActivity);

    const dbType = activityOwner === centralDBKey ? DB_TYPES.CENTRAL : DB_TYPES.PARTNER;

    const response = yield call(get, `/api/v2/cockpit/${dbType}/drilldown/${drilldownType}/${drilldownKey}`);
    yield put({
      type: LOAD_AND_QA_DRILLDOWN.FETCH.SUCCESS,
      drilldowns: mapIndexed(
        (activity, index) => R.assoc('drilldownId', index, activity),
        response.activities
      ),
      dbType,
      drilldownType
    });
  } catch (e) {
    yield put({ type: LOAD_AND_QA_DRILLDOWN.FETCH.FAILURE, error: e.message });
  }
}

export function* fetchFile({ drilldownId }) {
  try {
    const dbType = yield select(getDbType);
    const drilldown = yield select(getDrilldownByDrilldownId, drilldownId);
    const baseLink = `/api/v3/cockpit/${dbType}/drilldowndetail/${drilldown.drilldownType}/${drilldown.drilldownKey}/${drilldown.drilldownDetail}/`;
    const fileLink = `${baseLink}${getLink(drilldown)}`;

    const response = yield fetch(fileLink);
    if (!response.ok) {
      throw response;
    }

    const filename = response.headers.get('Filename') || 'Cockpit.csv';
    const blob = yield response.blob();

    yield call(saveAs, blob, filename);

    yield put({ type: LOAD_AND_QA_DRILLDOWN.FILE.SUCCESS, drilldownId });
  } catch (e) {
    yield put({ type: LOAD_AND_QA_DRILLDOWN.FILE.FAILURE, drilldownId, error: e.message });
  }
}

export function* fetchFileSaga() {
  yield takeEvery(LOAD_AND_QA_DRILLDOWN.FILE.REQUEST, fetchFile);
}
