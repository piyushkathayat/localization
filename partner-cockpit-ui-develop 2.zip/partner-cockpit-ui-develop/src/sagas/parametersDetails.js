import { PARAMETERS_DETAILS } from 'actions/ActionTypes';
import { PARAMETERS_TYPES } from 'constants/parameters';
import { fetchInstrumentUniverse } from 'sagas/parametersUniverse';
import { call, put } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';

export function* fetchParametersDetails({ feedName }) {
  try {
    if (feedName === PARAMETERS_TYPES.INSTRUMENT_UNIVERSE) {
      yield call(fetchInstrumentUniverse);
    } else {
      const response = yield call(get, `/api/v2/cockpit/staticdata/${feedName}`);
      yield put({ type: PARAMETERS_DETAILS.FETCH.SUCCESS, tablesList: response.table });
    }
  } catch (e) {
    yield put({ type: PARAMETERS_DETAILS.FETCH.FAILURE, error: e.message });
  }
}
