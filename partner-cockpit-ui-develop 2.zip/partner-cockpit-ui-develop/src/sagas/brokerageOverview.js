import * as R from 'ramda';
import { call, put, takeEvery } from 'redux-saga/effects';
import { get, put as PUT } from '@ubs.partner/shared-ui';
import { BROKERAGE_OVERVIEW } from 'actions/ActionTypes';

const setTriggerThemeName = triggerThemes => trigger => {
  const triggerThemeName = R.prop(
    'triggerTheme',
    R.find(
      triggerTheme => triggerTheme.triggerThemeId === trigger.triggerThemeId,
      triggerThemes
    )
  );
  return R.assoc(
    'triggerTheme',
    triggerThemeName,
    trigger
  );
};

const setTriggerThemeNames = (triggerThemes, triggers) => R.map(
  R.map(setTriggerThemeName(triggerThemes)),
  triggers
);

export function* fetchTriggerThemes() {
  try {
    const response = yield call(get, '/api/v3/cockpit/brokerage/triggers');
    yield put({
      type: BROKERAGE_OVERVIEW.FETCH.SUCCESS,
      triggerThemesList: response.triggerThemes,
      triggers: setTriggerThemeNames(response.triggerThemes, response.triggers)
    });
  } catch (e) {
    yield put({ type: BROKERAGE_OVERVIEW.FETCH.FAILURE, error: e.message });
  }
}

export function* finalizeBrokerage() {
  try {
    yield call(PUT, '/api/v3/cockpit/brokerage/', {
      dataToSend: {}
    });
    yield put({ type: BROKERAGE_OVERVIEW.FINALIZE.SUCCESS });
  } catch (e) {
    yield put({ type: BROKERAGE_OVERVIEW.FINALIZE.FAILURE, error: e.message });
  }
}

export function* finalizeBrokerageSaga() {
  yield takeEvery(BROKERAGE_OVERVIEW.FINALIZE.REQUEST, finalizeBrokerage);
}
