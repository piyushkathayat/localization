import * as R from 'ramda';
import { call, put, takeEvery, select, all } from 'redux-saga/effects';
import { get, post } from '@ubs.partner/shared-ui';
import { LOAD_AND_QA } from 'actions/ActionTypes';
import { getActivities, getJobs } from 'selectors/loadAndQA';
import { getCentralDBKey } from 'selectors/serverInfo';
import { DB_TYPES } from 'constants/serverInfo';
import { SP_FEED } from './__mocks__/SP';

export function* fetchLoadAndQA() {
  try {
    const activities = yield select(getActivities);
    if (!Object.keys(activities).length) {
      const response = yield call(get, '/api/v3/cockpit/activities');

      const centralDBKey = yield select(getCentralDBKey);
      const firstCentralIndex = R.findIndex(
        feed => feed.activityOwner === centralDBKey,
        response
      );
      const insertIndex = firstCentralIndex !== -1
        ? firstCentralIndex
        : 0;

      yield put({
        type: LOAD_AND_QA.FETCH.SUCCESS,
        activities: R.insert(
          insertIndex,
          SP_FEED,
          response
        )
      });
    }
  } catch (e) {
    yield put({ type: LOAD_AND_QA.FETCH.FAILURE, error: e.message });
  }
}

export function* fetchLoadAndQAJobs() {
  try {
    const jobs = yield select(getJobs);
    if (!Object.keys(jobs).length) {
      const [partnerJobs, centralJobs] = yield all([
        call(get, `/api/v2/cockpit/jobs/${DB_TYPES.PARTNER}`),
        call(get, `/api/v2/cockpit/jobs/${DB_TYPES.CENTRAL}`)
      ]);
      yield put({
        type: LOAD_AND_QA.JOBS.FETCH.SUCCESS,
        jobs: {
          [DB_TYPES.PARTNER]: partnerJobs,
          [DB_TYPES.CENTRAL]: centralJobs
        }
      });
    }
  } catch (e) {
    yield put({ type: LOAD_AND_QA.JOBS.FAILURE, error: e.message });
  }
}

export function* executeLoadAndQAJob({ command, database, jobId }) {
  try {
    yield call(post, '/api/v3/cockpit/executeJob', {
      dataToSend: { command, database, jobId }
    });
    yield put({
      type: LOAD_AND_QA.JOBS.SUCCESS
    });
  } catch (e) {
    yield put({ type: LOAD_AND_QA.JOBS.FAILURE, error: e.message });
  }
}

export function* startLoadAndQAJobSaga() {
  yield takeEvery(LOAD_AND_QA.JOBS.START, executeLoadAndQAJob);
}

export function* stopLoadAndQAJobSaga() {
  yield takeEvery(LOAD_AND_QA.JOBS.STOP, executeLoadAndQAJob);
}
