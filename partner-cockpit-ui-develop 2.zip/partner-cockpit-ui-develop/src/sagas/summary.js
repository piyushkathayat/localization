import { call, put } from 'redux-saga/effects';
import { get } from '@ubs.partner/shared-ui';
import { SUMMARY } from 'actions/ActionTypes';

export function* fetchSummary() {
  try {
    const response = yield call(get, '/api/v3/cockpit/summary');
    yield put({ type: SUMMARY.FETCH.SUCCESS, data: response });
  } catch (e) {
    yield put({ type: SUMMARY.FETCH.FAILURE, error: e.message });
  }
}
