import * as R from 'ramda';
import { call, put, takeEvery } from 'redux-saga/effects';
import { PROMOTION } from 'actions/ActionTypes';
import { post, get } from '@ubs.partner/shared-ui';

export const markDatabasesForPromotion = R.map(R.compose(
  database => !database.isMarkedForPromotion && R.isEmpty(database.comment)
    ? R.assoc('comment', database.info, database)
    : database,
  database => !database.isPromotedToLive
    ? R.assoc('isMarkedForPromotion', database.isPreselected, database)
    : database
));

export const filterOutAutoPromotedDatabases = R.reject(R.prop('isAutoPromoted'));

export function* fetchPromotion() {
  try {
    const response = yield call(get, '/api/v3/cockpit/promotion');
    yield put({
      type: PROMOTION.FETCH.SUCCESS,
      promotion: response
    });
  } catch (e) {
    yield put({ type: PROMOTION.FETCH.FAILURE, error: e.message });
  }
}

export function* promoteToLiveDbHandler({ databases }) {
  try {
    const markedDatabases = markDatabasesForPromotion(databases);
    yield call(post, '/api/v3/cockpit/promotion', {
      dataToSend: { databases: filterOutAutoPromotedDatabases(markedDatabases) }
    });
    yield put({
      type: PROMOTION.PROMOTE.SUCCESS,
      databases: markedDatabases
    });
  } catch (error) {
    yield put({ type: PROMOTION.PROMOTE.FAILURE, error });
  }
}

export function* promoteToLiveDb() {
  yield takeEvery(PROMOTION.PROMOTE.REQUEST, promoteToLiveDbHandler);
}
