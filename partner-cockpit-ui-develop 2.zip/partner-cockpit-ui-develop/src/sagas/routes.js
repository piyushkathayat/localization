import * as R from 'ramda';
import { select, call } from 'redux-saga/effects';
import { getDecisions } from 'selectors/validation';
import { getTriggerThemes } from 'selectors/brokerageOverview';
import { MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { APP_PREFIX } from 'constants/common';
import { fetchCoreEngine } from './coreEngine';
import { fetchSummary } from './summary';
import { fetchLoadAndQA, fetchLoadAndQAJobs } from './loadAndQA';
import { fetchLoadAndQAActions } from './loadAndQAActions';
import { fetchLoadAndQADrilldown } from './loadAndQADrilldown';
import { fetchQualityChecks } from './qualityChecks';
import { fetchDecisions } from './validation';
import { fetchValidationDetails } from './validationDetails';
import { fetchTriggerThemes } from './brokerageOverview';
import { fetchPromotion } from './promotion';
import { fetchParameters } from './parameters';
import { fetchParametersDetails } from './parametersDetails';

export function* handleBrokerageDetails() {
  const triggerThemes = yield select(getTriggerThemes);
  if (R.isEmpty(triggerThemes)) {
    yield call(fetchTriggerThemes);
  }
}

export function* handleValidationDetails(params) {
  const decisions = yield select(getDecisions);
  if (R.isEmpty(decisions)) {
    yield call(fetchDecisions, params, false);
  }
  yield call(fetchValidationDetails, params);
}

export function* handleLoadAndQAOverview() {
  yield call(fetchLoadAndQA);
  yield call(fetchLoadAndQAJobs);
}

export function* handleLoadAndQAActions(params) {
  yield call(fetchLoadAndQA);
  yield call(fetchLoadAndQAActions, params);
}

export function* handleLoadAndQADrilldown(params) {
  yield call(handleLoadAndQAActions, params);
  yield call(fetchLoadAndQADrilldown, params);
}

export function* handleParametersDetails(params) {
  yield call(fetchParameters);
  yield call(fetchParametersDetails, params);
}

const routes = [
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.SUMMARY}`, handler: fetchSummary },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}`, handler: handleLoadAndQAOverview },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id`, handler: handleLoadAndQAActions },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id/:drilldownType/:drilldownKey`, handler: handleLoadAndQADrilldown },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.QUALITY_CHECK}`, handler: fetchQualityChecks },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`, handler: fetchDecisions },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}/:decisionId/:qualityCheckType`, handler: handleValidationDetails },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}`, handler: fetchTriggerThemes },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}/:triggerThemeId`, handler: handleBrokerageDetails },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.PROMOTION}`, handler: fetchPromotion },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}`, handler: fetchParameters },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/:feedName`, handler: handleParametersDetails },
  { pattern: `/${APP_PREFIX}/${MENU_ITEMS.CORE_ENGINE}`, handler: fetchCoreEngine }
];

export default routes;
