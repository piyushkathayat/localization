import * as R from 'ramda';
import saveAs from 'file-saver';
import { call, put, takeEvery, all, select } from 'redux-saga/effects';
import { PARAMETERS } from 'actions/ActionTypes';
import {
  PARAMETERS as PARAMETERS_MODELS,
  PARAMETERS_TYPES,
  RESPONSE_STATUSES
} from 'constants/parameters';
import { uploadFile } from 'utils/uploadFile';
import { get, post } from '@ubs.partner/shared-ui';
import { getParameters } from 'selectors/parameters';

export const getSortOrder = feedName => R.pathOr(
  999,
  [feedName, 'sortOrder'],
  PARAMETERS_MODELS
);

export const sortParameters = parametersList => R.sort(
  (a, b) => getSortOrder(a.feedName) - getSortOrder(b.feedName),
  parametersList
);

export function* fetchParameters() {
  try {
    const parameters = yield select(getParameters);
    if (!Object.keys(parameters).length) {
      const feedNames = Object.values(PARAMETERS_TYPES);
      const response = yield call(post, '/api/v3/cockpit/feeds_statuses', {
        dataToSend: { feeds: feedNames }
      });
      yield put({
        type: PARAMETERS.FETCH.SUCCESS,
        statusesList: sortParameters(response.statuses)
      });
    }
  } catch (e) {
    yield put({ type: PARAMETERS.FETCH.FAILURE, error: e.message });
  }
}

export function* parameterCheckIn({ feedName, file }) {
  try {
    const feedsourceResponse = yield call(get, `/api/v3/cockpit/feedsource/${feedName}`);
    if (file.name !== feedsourceResponse.filename) {
      throw new Error(`Filename incorrect. Please use: ${feedsourceResponse.filename}`);
    }
    const uploadResponse = yield call(uploadFile, feedsourceResponse, file);

    if (uploadResponse) {
      const { checkInResponse, checkInStatusResponse } = yield all({
        checkInResponse: call(get, `/api/v2/cockpit/checkin/${feedName}`),
        checkInStatusResponse: call(get, `/api/v2/cockpit/checkinstatus/${feedName}`)
      });

      if (R.propEq('status', RESPONSE_STATUSES.SUCCESS, checkInResponse)) {
        yield put({
          type: PARAMETERS.CHECK_IN.SUCCESS,
          parameter: checkInStatusResponse.checkinStatus
        });
      } else {
        throw checkInResponse;
      }
    } else {
      throw new Error('Error during the file upload');
    }
  } catch (e) {
    yield put({ type: PARAMETERS.CHECK_IN.FAILURE, error: e.message, feedName });
  }
}

export function* parameterCheckOut({ feedName }) {
  try {
    const response = yield call(get, `/api/v2/cockpit/checkout/${feedName}`);
    if (R.propEq('status', RESPONSE_STATUSES.SUCCESS, response)) {
      const checkOutStatusResponse = yield call(get, `/api/v2/cockpit/checkoutstatus/${feedName}`);
      yield put({
        type: PARAMETERS.CHECK_OUT.SUCCESS,
        parameter: checkOutStatusResponse.checkoutStatus
      });
      yield call(saveAs, response.downloadURL, response.fileName);
    } else {
      throw response;
    }
  } catch (e) {
    yield put({ type: PARAMETERS.CHECK_OUT.FAILURE, error: e.message, feedName });
  }
}

export function* parameterCancel({ feedName }) {
  try {
    const response = yield call(get, `/api/v2/cockpit/checkoutcancel/${feedName}`);
    if (R.pathEq(['cancelResponse', 'status'], RESPONSE_STATUSES.SUCCESS, response)) {
      yield put({ type: PARAMETERS.CANCEL.SUCCESS, parameter: response.checkoutStatus });
    } else {
      throw response.cancelResponse;
    }
  } catch (e) {
    yield put({ type: PARAMETERS.CANCEL.FAILURE, error: e.message, feedName });
  }
}

export function* parametersCheckInSaga() {
  yield takeEvery(PARAMETERS.CHECK_IN.REQUEST, parameterCheckIn);
}

export function* parametersCheckOutSaga() {
  yield takeEvery(PARAMETERS.CHECK_OUT.REQUEST, parameterCheckOut);
}

export function* parametersCancelSaga() {
  yield takeEvery(PARAMETERS.CANCEL.REQUEST, parameterCancel);
}
