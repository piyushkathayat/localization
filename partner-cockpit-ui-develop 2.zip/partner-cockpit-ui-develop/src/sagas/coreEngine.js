import { call, put } from 'redux-saga/effects';
import { CORE_ENGINE } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';

export function* fetchCoreEngine() {
  try {
    const response = yield call(get, '/api/v2/cockpit/staticdata/key');
    yield put({ type: CORE_ENGINE.FETCH.SUCCESS, tablesList: response.table });
  } catch (e) {
    yield put({ type: CORE_ENGINE.FETCH.FAILURE, error: e.message });
  }
}
