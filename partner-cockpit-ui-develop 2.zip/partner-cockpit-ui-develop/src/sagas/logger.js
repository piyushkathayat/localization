import { call, put, takeEvery } from 'redux-saga/effects';
import saveAs from 'file-saver';
import { QC_TYPE_IDS } from 'constants/qualityCheck';
import { LOGGER } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';

const assetAllocationQualityCheck = [
  QC_TYPE_IDS.SAA_CHECK,
  QC_TYPE_IDS.TAA_CHECK
];

export const formatQueryParam = (param, value) => `${param}=${encodeURIComponent(value)}`;

export const getQueryParameters = parameters => {
  const { assetId, context, issueIds = [] } = parameters;
  const params = [
    assetId && formatQueryParam('assetId', assetId),
    context && formatQueryParam('context', context),
    issueIds.length && formatQueryParam('issueIds', issueIds)
  ].filter(Boolean);

  return params.length > 0 ? `?${params.join('&')}` : '';
};

export const formatOptions = ({ qualityCheckDetails = [] }) => {
  const issueIdsOptions = [];
  qualityCheckDetails.filter(qc => qc.isIssue).forEach((qc) => {
    if (assetAllocationQualityCheck.includes(qc.type)) {
      const firstExistingIssue = qc.issues.find(issue => issue.isIssue);
      issueIdsOptions.push({
        key: issueIdsOptions.length,
        text: `${qc.name} - ${firstExistingIssue.globalIssueId}`,
        value: firstExistingIssue.globalIssueId
      });
    } else {
      qc.issues.filter(issue => issue.isIssue).forEach(issue => {
        issueIdsOptions.push({
          key: issueIdsOptions.length,
          text: `${qc.name} - ${issue.issueId}`,
          value: issue.issueId
        });
      });
    }
  });
  return issueIdsOptions;
};

export function* fetchJson({ parameters }) {
  try {
    const queryParams = getQueryParameters(parameters);
    const response = yield call(get, `/api/v3/logger/businessLogs/${queryParams}`);
    yield put({ type: LOGGER.JSON.FETCH.SUCCESS, json: JSON.parse(response.log) });
  } catch (e) {
    yield put({ type: LOGGER.JSON.FETCH.FAILURE, error: e.message });
  }
}

export function* fetchIssueIds({ assetId }) {
  try {
    const response = yield call(get, `/api/v3/portfolios/onlineQualityCheck/${assetId}`);
    yield put({ type: LOGGER.ISSUE_IDS.FETCH.SUCCESS, issueIdsOptions: formatOptions(response) });
  } catch (e) {
    yield put({ type: LOGGER.ISSUE_IDS.FETCH.FAILURE, error: e.message });
  }
}

export function* extractLoggerData({ assetId }) {
  try {
    const response = yield fetch(`/api/v3/logger/extract/${assetId}`);
    if (!response.ok) {
      throw response;
    }

    const filename = response.headers.get('Filename') || 'Logger.zip';
    const blob = yield response.blob();

    yield call(saveAs, blob, filename);

    yield put({ type: LOGGER.EXTRACT.FETCH.SUCCESS });
  } catch (e) {
    yield put({ type: LOGGER.EXTRACT.FETCH.FAILURE, error: e.message });
  }
}

export function* loggerJsonSaga() {
  yield takeEvery(LOGGER.JSON.FETCH.REQUEST, fetchJson);
}

export function* loggerIssueIdsSaga() {
  yield takeEvery(LOGGER.ISSUE_IDS.FETCH.REQUEST, fetchIssueIds);
}

export function* loggerExtractSaga() {
  yield takeEvery(LOGGER.EXTRACT.FETCH.REQUEST, extractLoggerData);
}
