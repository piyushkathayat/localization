import * as R from 'ramda';
import { call, put, select, takeEvery } from 'redux-saga/effects';
import { VALIDATION, VALIDATION_OVERVIEW } from 'actions/ActionTypes';
import { get, post } from '@ubs.partner/shared-ui';
import { getDecisions, getSelectedDecisionId } from 'selectors/validation';

export const getLatestDecisionId = decisionsList => R.prop(
  'decisionId',
  R.find(
    decision => decision.isLatestLoad,
    decisionsList
  )
);

export const getDecisionsCommonData = decisionsList => R.map(
  decision => ({
    decisionId: decision.decisionId,
    date: decision.decisionDate,
    statusId: decision.decisionStatusId,
    isLatestLoad: decision.isLatestLoad
  }),
  decisionsList
);

export const getDecisionsOverview = decisionsList => R.map(
  decision => ({
    decisionId: decision.decisionId,
    isReleaseAllowed: decision.isReleaseAllowed,
    qualityChecks: decision.qualityChecks
  }),
  decisionsList
);

export function* fetchDecisions({ decisionId }, shouldSetOverview = true) {
  try {
    const response = yield call(get, '/api/v3/cockpit/decisions');
    if (shouldSetOverview) {
      yield put({
        type: VALIDATION_OVERVIEW.FETCH.SUCCESS,
        decisionsList: getDecisionsOverview(response)
      });
    }
    const decisions = yield select(getDecisions);
    if (R.isEmpty(decisions)) {
      const selectedDecisionId = yield select(getSelectedDecisionId);
      yield put({
        type: VALIDATION.FETCH.SUCCESS,
        decisions: getDecisionsCommonData(response),
        selectedDecisionId: selectedDecisionId
          || Number(decisionId)
          || getLatestDecisionId(response)
      });
    }
  } catch (e) {
    yield put({ type: VALIDATION.FETCH.FAILURE, error: e.message });
  }
}

export function* recalculateDecision({ decisionId, comment, confirmedBy }) {
  try {
    const requestBody = {
      decisionId,
      comment,
      confirmedBy
    };
    yield call(post, '/api/v3/cockpit/decisions/recalculate', {
      dataToSend: requestBody
    });
  } catch (e) {
    yield put({ type: VALIDATION.DECISION.RECALCULATE.FAILURE, error: e.message });
  }
}

export function* validateDecision({ decisionId }) {
  try {
    yield call(post, '/api/v3/cockpit/decisions/validate', {
      dataToSend: {
        decisionId
      }
    });
  } catch (e) {
    yield put({ type: VALIDATION.DECISION.VALIDATE.FAILURE, error: e.message });
  }
}

export function* validateDecisionSaga() {
  yield takeEvery(VALIDATION.DECISION.VALIDATE.REQUEST, validateDecision);
}

export function* recalculateDecisionSaga() {
  yield takeEvery(VALIDATION.DECISION.RECALCULATE.REQUEST, recalculateDecision);
}
