import { call, put, takeEvery } from 'redux-saga/effects';
import { SERVER_INFO } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';

export function* fetchServerInfo() {
  try {
    const response = yield call(get, '/api/v3/cockpit/environment_info');
    yield put({ type: SERVER_INFO.FETCH.SUCCESS, data: response });
  } catch (e) {
    yield put({ type: SERVER_INFO.FETCH.FAILURE, error: e.message });
  }
}

export function* serverInfoSaga() {
  yield takeEvery(SERVER_INFO.FETCH.REQUEST, fetchServerInfo);
}
