import { fork, all } from 'redux-saga/effects';
import { router } from 'redux-saga-router';
import { updateValidationDetailsSaga, fetchAffectedPortfoliosSaga } from './validationDetails';
import { recalculateDecisionSaga, validateDecisionSaga } from './validation';
import { finalizeBrokerageSaga } from './brokerageOverview';
import { updateTriggerSaga, fetchTriggerPortfoliosSaga } from './brokerageDetails';
import { fetchQualityChecksSaga } from './qualityChecks';
import { promoteToLiveDb } from './promotion';
import { serverInfoSaga } from './serverInfo';
import { startLoadAndQAJobSaga, stopLoadAndQAJobSaga } from './loadAndQA';
import { fetchFileSaga } from './loadAndQADrilldown';
import { parametersCheckInSaga, parametersCheckOutSaga, parametersCancelSaga } from './parameters';
import { instrumentUniversePageChangeSaga, instrumentUniverseSearchChangeSaga } from './parametersUniverse';
import { loggerJsonSaga, loggerIssueIdsSaga, loggerExtractSaga } from './logger';
import { history } from '../store';
import routes from './routes';

export default function* sagas() {
  yield all([
    fork(serverInfoSaga),
    fork(updateValidationDetailsSaga),
    fork(fetchAffectedPortfoliosSaga),
    fork(instrumentUniversePageChangeSaga),
    fork(instrumentUniverseSearchChangeSaga),
    fork(fetchQualityChecksSaga),
    fork(promoteToLiveDb),
    fork(recalculateDecisionSaga),
    fork(validateDecisionSaga),
    fork(finalizeBrokerageSaga),
    fork(updateTriggerSaga),
    fork(fetchTriggerPortfoliosSaga),
    fork(startLoadAndQAJobSaga),
    fork(stopLoadAndQAJobSaga),
    fork(fetchFileSaga),
    fork(parametersCheckInSaga),
    fork(parametersCheckOutSaga),
    fork(parametersCancelSaga),
    fork(loggerJsonSaga),
    fork(loggerIssueIdsSaga),
    fork(loggerExtractSaga),
    fork(router, history, routes)
  ]);
}
