import { call, put, takeEvery } from 'redux-saga/effects';
import { QUALITY_CHECK } from 'actions/ActionTypes';
import { get } from '@ubs.partner/shared-ui';

export function* fetchQualityChecks({ days = 10 }) {
  try {
    const response = yield call(get, `/api/v3/cockpit/quality_checks/${days}`);
    yield put({ type: QUALITY_CHECK.FETCH.SUCCESS, data: response });
  } catch (e) {
    yield put({ type: QUALITY_CHECK.FETCH.FAILURE, error: e.message });
  }
}

export function* fetchQualityChecksSaga() {
  yield takeEvery(QUALITY_CHECK.FETCH.REQUEST, fetchQualityChecks);
}
