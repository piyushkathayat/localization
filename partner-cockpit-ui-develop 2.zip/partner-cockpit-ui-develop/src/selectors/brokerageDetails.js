import * as R from 'ramda';
import { createSelector } from 'reselect';
import { BROKERAGE_SEARCHABLE_FIELDS } from 'constants/validation';
import { SORT_DIRECTIONS } from 'constants/common';
import { getSearch, getSorting } from 'selectors/validation';

const searchDetails = search => detailsList => search.length
  ? R.filter(
    detail => R.any(
      field => detail[field] && detail[field].toLowerCase().includes(search),
      BROKERAGE_SEARCHABLE_FIELDS
    ),
    detailsList
  )
  : detailsList;

const sortDetails = ({ sortBy, sortDirection }) => detailsList => {
  if (!sortBy.length) {
    return detailsList;
  }
  const sorting = sortDirection === SORT_DIRECTIONS.ASC
    ? R.ascend
    : R.descend;
  return R.sort(
    sorting(R.prop(sortBy)),
    detailsList
  );
};

export const getBrokerageDetails = state => R.prop('brokerageDetails', state);

export const getTriggers = state => R.prop('triggers', getBrokerageDetails(state));

export const getTriggersById = (state, triggerThemeId) =>
  R.prop(triggerThemeId, getTriggers(state));

export const getTriggersList = (state, triggerThemeId) =>
  R.values(getTriggersById(state, triggerThemeId));

export const getIsLoading = state => R.prop('isLoading', getBrokerageDetails(state));

export const getIsUpdating = state => R.prop('isUpdating', getBrokerageDetails(state));

export const getError = state => R.prop('error', getBrokerageDetails(state));

export const getSortedAndFilteredTriggersList = createSelector(
  [getTriggersList, getSearch, getSorting],
  (triggersList, search, sorting) => R.compose(
    sortDetails(sorting),
    searchDetails(search.toLowerCase())
  )(triggersList)
);

export const getTriggerThemeNameById = (state, triggerThemeId) =>
  R.path([0, 'triggerTheme'], getTriggersById(state, triggerThemeId));
