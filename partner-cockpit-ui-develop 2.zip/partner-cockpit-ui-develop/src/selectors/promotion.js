import * as R from 'ramda';

export const getPromotionOverview = state => R.prop('promotion', state);

export const getPromotionDatabases = state => R.prop('databases', getPromotionOverview(state));

export const getIsPromotionRunning = state => R.prop('isPromotionRunning', getPromotionOverview(state));

export const getCanPromote = state => R.prop('canPromote', getPromotionOverview(state));

export const getPromotionError = state => R.prop('error', getPromotionOverview(state));

export const getIsLoading = state => R.prop('isLoading', getPromotionOverview(state));

export const getLastPromotion = state => R.prop('lastPromotionDate', getPromotionOverview(state));

export const getDependencies = state => R.prop('dependencies', getPromotionOverview(state));
