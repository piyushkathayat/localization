import * as R from 'ramda';
import { getActivityById } from 'selectors/loadAndQA';
import { getLoadAndQAActions } from 'selectors/loadAndQAActions';

export const getLoadAndQADrilldown = state => R.prop('loadAndQADrilldown', state);

export const getIsLoading = state => R.prop('isLoading', getLoadAndQADrilldown(state));

export const getError = state => R.prop('error', getLoadAndQADrilldown(state));

export const getDrilldowns = state => R.prop('drilldowns', getLoadAndQADrilldown(state));

export const getDbType = state => R.prop('dbType', getLoadAndQADrilldown(state));

export const getDrilldownType = state => R.prop('drilldownType', getLoadAndQADrilldown(state));

export const getDrilldownByDrilldownId = (state, drilldownId) => R.find(
  drilldown => drilldown.drilldownId === drilldownId,
  getDrilldowns(state)
);

export const getActionByActivityIdAndActionId = (state, activityId, actionId) => R.find(
  action => action.actionId === Number(actionId),
  R.propOr(
    [],
    'actions',
    getActivityById(state, activityId)
  )
);

export const getActionByDrilldownTypeAndKey = (state, drillDownType, drillDownKey) => R.find(
  action => action.drillDownType === drillDownType && action.drillDownKey === drillDownKey,
  R.propOr(
    [],
    'actions',
    getLoadAndQAActions(state)
  )
);
