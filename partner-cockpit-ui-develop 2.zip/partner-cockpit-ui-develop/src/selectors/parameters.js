import * as R from 'ramda';
import { PARAMETERS_STATUSES } from 'constants/parameters';

export const getParametersState = state => R.prop('parameters', state);

export const getIsLoading = state => R.prop('isLoading', getParametersState(state));

export const getError = state => R.prop('error', getParametersState(state));

export const getParameters = state => R.prop('parameters', getParametersState(state));

export const getParametersList = state => R.values(getParameters(state));

export const getParameterByFeedName = (state, feedName) => R.prop(feedName, getParameters(state));

export const getParameterTile = (state, feedName) => {
  const parameter = getParameterByFeedName(state, feedName);
  const checkedInAt = parameter.checkedInAt || parameter.lastCheckedInAt || '';
  const checkedOutAt = parameter.checkedOutAt || parameter.lastCheckedOutAt || '';

  return checkedOutAt > checkedInAt
    ? {
      feedName: parameter.feedName,
      status: PARAMETERS_STATUSES.CHECKED_OUT,
      isUpdating: parameter.isUpdating,
      lastUpdatedAt: checkedOutAt,
      lastUpdatedBy: parameter.checkedOutBy || parameter.lastCheckedOutBy
    }
    : {
      feedName: parameter.feedName,
      status: PARAMETERS_STATUSES.CHECKED_IN,
      isUpdating: parameter.isUpdating,
      lastUpdatedAt: checkedInAt,
      lastUpdatedBy: parameter.checkedInBy || parameter.lastCheckedInBy
    };
};
