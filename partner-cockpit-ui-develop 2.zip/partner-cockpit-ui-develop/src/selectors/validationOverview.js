import * as R from 'ramda';
import { getSelectedDecisionId } from './validation';

export const getValidationOverview = state => R.prop('validationOverview', state);

export const getIsLoading = state => R.prop('isLoading', getValidationOverview(state));

export const getError = state => R.prop('error', getValidationOverview(state));

export const getDecisionsOverview = state => R.prop('decisionsOverview', getValidationOverview(state));

export const getSelectedDecisionOverview = state => R.prop(
  getSelectedDecisionId(state),
  getDecisionsOverview(state)
);

export const getSelectedQualityChecks = state => R.propOr(
  [],
  'qualityChecks',
  getSelectedDecisionOverview(state)
);
