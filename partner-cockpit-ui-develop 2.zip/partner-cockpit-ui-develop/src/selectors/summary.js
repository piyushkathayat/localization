import * as R from 'ramda';
import { createSelector } from 'reselect';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';

export const getSummary = state => R.prop('summary', state);

export const getSummaryInfo = state => R.prop('summaryInfo', getSummary(state));

export const getDate = state => R.prop('date', getSummary(state));

export const getFilter = state => R.prop('filter', getSummary(state));

export const getIsLoading = state => R.prop('isLoading', getSummary(state));

export const getError = state => R.prop('error', getSummary(state));

export const getFilteredSummaryInfo = createSelector(
  [
    getSummaryInfo,
    getFilter
  ],
  (summaryInfo, filter) => isNonEmptyArray(filter)
    ? summaryInfo.filter(info => filter.includes(info.group))
    : summaryInfo
);
