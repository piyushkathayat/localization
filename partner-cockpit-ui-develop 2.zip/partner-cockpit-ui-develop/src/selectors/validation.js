import React from 'react';
import * as R from 'ramda';
import { DECISION_STATUSES } from 'constants/validation';
import { DateAndTime } from 'components/common';

export const getValidation = state => R.prop('validation', state);

export const getIsLoading = state => R.prop('isLoading', getValidation(state));

export const getError = state => R.prop('error', getValidation(state));

export const getDecisions = state => R.prop('decisions', getValidation(state));

export const getDecisionsList = state => R.values(getDecisions(state));

export const getDecisionsListSortedByDate = state => R.sort(
  R.descend(R.prop('date')),
  getDecisionsList(state)
);

export const getSelectedDecisionId = state => R.prop('selectedDecisionId', getValidation(state));

export const getSelectedDecision = state => R.prop(
  getSelectedDecisionId(state),
  getDecisions(state)
);

export const getSelectedDecisionStatusId = state => R.prop(
  'statusId',
  getSelectedDecision(state)
);

export const getSelectedDecisionIsLatestLoad = state => R.prop(
  'isLatestLoad',
  getSelectedDecision(state)
);

export const getLatestLoadDecisionId = state => R.prop(
  'decisionId',
  R.find(
    decision => decision.isLatestLoad,
    getDecisionsList(state)
  )
);

export const getDecisionsDates = state => R.map(
  decision => ({
    key: decision.decisionId,
    text: <DateAndTime value={decision.date} />,
    value: decision.decisionId
  }),
  getDecisionsListSortedByDate(state)
);

export const getLastSuccessfulValidationDate = state => R.prop(
  'date',
  R.find(
    decision => decision.statusId === DECISION_STATUSES.FINALIZED,
    getDecisionsListSortedByDate(state)
  )
);

export const getSearch = state => R.prop('search', getValidation(state));

export const getSorting = state => R.prop('sorting', getValidation(state));
