import * as R from 'ramda';
import { createSelector } from 'reselect';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';

export const getParametersDetails = state => R.prop('parametersDetails', state);

export const getIsLoading = state => R.prop('isLoading', getParametersDetails(state));

export const getError = state => R.prop('error', getParametersDetails(state));

export const getFilter = state => R.prop('filter', getParametersDetails(state));

export const getTablesList = state => R.prop('tablesList', getParametersDetails(state));

export const getFilteredTablesList = createSelector(
  [
    getTablesList,
    getFilter
  ],
  (tablesList, filter) => isNonEmptyArray(filter)
    ? tablesList.filter(table => filter.includes(table.tableName))
    : tablesList
);
