import * as R from 'ramda';

export const getLogger = state => R.prop('logger', state);

export const getIsLoading = state => R.prop('isLoading', getLogger(state));

export const getIsUpdating = state => R.prop('isUpdating', getLogger(state));

export const getError = state => R.prop('error', getLogger(state));

export const getJson = state => R.prop('json', getLogger(state));

export const getIssueIdsOptions = state => R.prop('issueIdsOptions', getLogger(state));
