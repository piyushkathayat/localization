import {
  getParametersDetails,
  getIsLoading,
  getError,
  getFilter,
  getTablesList,
  getFilteredTablesList
} from '../parametersDetails';

const getStateSample = () => ({
  parametersDetails: {
    tablesList: [
      {
        tableName: 'ST_SAA',
        tableDisplayName: 'SAA',
        id: 0,
        tableData: []
      },
      {
        tableName: 'ST_SAARiskReturn',
        tableDisplayName: 'SAA Risk Return',
        id: 1,
        tableData: []
      },
      {
        tableName: 'ST_SAAWeights',
        tableDisplayName: 'ST_SAAWeights',
        id: 2,
        tableData: []
      }
    ],
    filter: ['ST_SAA'],
    isLoading: false,
    error: null
  }
});

describe('parametersDetails selector', () => {
  it('Should getParametersDetails', () => {
    const currentState = getStateSample();
    const result = getParametersDetails(currentState);
    const expectedResult = currentState.parametersDetails;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.parametersDetails.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.parametersDetails.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilter', () => {
    const currentState = getStateSample();
    const result = getFilter(currentState);
    const expectedResult = currentState.parametersDetails.filter;
    expect(result).toEqual(expectedResult);
  });

  it('Should getTablesList', () => {
    const currentState = getStateSample();
    const result = getTablesList(currentState);
    const expectedResult = currentState.parametersDetails.tablesList;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredTablesList: current filter', () => {
    const currentState = getStateSample();
    const result = getFilteredTablesList(currentState);
    const expectedResult = [
      currentState.parametersDetails.tablesList[0]
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredTablesList: empty filter', () => {
    const currentState = getStateSample();
    currentState.parametersDetails.filter = [];
    const result = getFilteredTablesList(currentState);
    const expectedResult = currentState.parametersDetails.tablesList;
    expect(result).toEqual(expectedResult);
  });
});
