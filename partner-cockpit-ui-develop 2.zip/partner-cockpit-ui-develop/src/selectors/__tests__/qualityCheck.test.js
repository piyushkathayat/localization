import {
  getQualityCheck,
  getIsLoading,
  getError,
  getFilter,
  getQualityCheckList,
  getFilteredQualityChecks
} from '../qualityCheck';

const getStateSample = () => ({
  qualityCheck: {
    qualityCheckList: [
      {
        type: 1,
        data: []
      },
      {
        type: 2,
        data: []
      },
      {
        type: 4,
        data: []
      }
    ],
    filter: [1],
    isLoading: false,
    error: null
  }
});

describe('qualityCheck selector', () => {
  it('Should getQualityCheck', () => {
    const currentState = getStateSample();
    const result = getQualityCheck(currentState);
    const expectedResult = currentState.qualityCheck;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.qualityCheck.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.qualityCheck.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilter', () => {
    const currentState = getStateSample();
    const result = getFilter(currentState);
    const expectedResult = currentState.qualityCheck.filter;
    expect(result).toEqual(expectedResult);
  });

  it('Should getQualityCheckList', () => {
    const currentState = getStateSample();
    const result = getQualityCheckList(currentState);
    const expectedResult = currentState.qualityCheck.qualityCheckList;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredQualityChecks: current filter', () => {
    const currentState = getStateSample();
    const result = getFilteredQualityChecks(currentState);
    const expectedResult = [
      currentState.qualityCheck.qualityCheckList[0]
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredQualityChecks: empty filter', () => {
    const currentState = getStateSample();
    currentState.qualityCheck.filter = [];
    const result = getFilteredQualityChecks(currentState);
    const expectedResult = currentState.qualityCheck.qualityCheckList;
    expect(result).toEqual(expectedResult);
  });
});
