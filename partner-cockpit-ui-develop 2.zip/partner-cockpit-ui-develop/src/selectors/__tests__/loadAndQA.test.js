import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import { DB_TYPES } from 'constants/serverInfo';
import {
  getLoadAndQA,
  getIsLoading,
  getError,
  getActivities,
  getActivitiesIds,
  getActivitiesList,
  getActivityById,
  getJobs,
  getActivitiesByDatabase,
  getJobsByDatabase,
  getIsJobStarting
} from '../loadAndQA';

const getStateSample = () => ({
  loadAndQA: {
    activities: {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '7-WS004': {
        id: '7-WS004',
        activityId: 7,
        activityKey: '6d4b1429-f20b-4bac-9fe2-ce4f8f5582e2',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      },
      '2-central': {
        id: '2-central',
        activityId: 2,
        activityKey: '339683cc-f6f8-42c2-ab98-9c643e265e41',
        activityOwner: 'central',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      },
      '18-central': {
        id: '18-central',
        activityId: 18,
        activityKey: 'a3fc6f08-ca59-44ea-bf73-66ac427aeb63',
        activityOwner: 'central',
        statusCode: ACTIVITY_STATUSES.ERROR,
        percentage: 0
      }
    },
    activitiesIds: [
      '3-WS004',
      '7-WS004',
      '2-central',
      '18-central'
    ],
    isLoading: true,
    error: null,
    jobs: {
      [DB_TYPES.PARTNER]: [
        {
          key: '23c4885f-fa30-4fcc-b2e1-2161e5742813',
          value: 'Copy Test Files'
        },
        {
          key: 'bd20617d-1ec9-449c-a3b8-79863e360deb',
          value: 'LK Tables'
        }
      ],
      [DB_TYPES.CENTRAL]: [
        {
          key: 'f78dc9be-e4a1-42f3-8cf8-6202b646f216',
          value: 'Get Central Instruments'
        },
        {
          key: '0085e781-e1ca-454f-965a-5201d163cd62',
          value: 'MiniCentral Extract'
        }
      ]
    },
    isJobStarting: false
  },
  serverInfo: {
    serverType: 'STAGING',
    centralDBKey: 'central',
    partnerDBKey: 'WS004',
    currency: 'EUR',
    environment: 'T',
    loggedInUser: '00355799',
    isLoading: false,
    error: null
  }
});

describe('loadAndQA selector', () => {
  it('Should getLoadAndQA', () => {
    const currentState = getStateSample();
    const result = getLoadAndQA(currentState);
    const expectedResult = currentState.loadAndQA;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.loadAndQA.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.loadAndQA.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getJobs', () => {
    const currentState = getStateSample();
    const result = getJobs(currentState);
    const expectedResult = currentState.loadAndQA.jobs;
    expect(result).toEqual(expectedResult);
  });

  it('Should getActivities', () => {
    const currentState = getStateSample();
    const result = getActivities(currentState);
    const expectedResult = currentState.loadAndQA.activities;
    expect(result).toEqual(expectedResult);
  });

  it('Should getActivitiesIds', () => {
    const currentState = getStateSample();
    const result = getActivitiesIds(currentState);
    const expectedResult = currentState.loadAndQA.activitiesIds;
    expect(result).toEqual(expectedResult);
  });

  it('Should getActivitiesList', () => {
    const currentState = getStateSample();
    const result = getActivitiesList(currentState);
    const expectedResult = [
      currentState.loadAndQA.activities['3-WS004'],
      currentState.loadAndQA.activities['7-WS004'],
      currentState.loadAndQA.activities['2-central'],
      currentState.loadAndQA.activities['18-central']
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getActivityById', () => {
    const currentState = getStateSample();
    const result = getActivityById(currentState, '7-WS004');
    const expectedResult = currentState.loadAndQA.activities['7-WS004'];
    expect(result).toEqual(expectedResult);
  });

  it('Should getActivitiesByDatabase: central', () => {
    const currentState = getStateSample();
    const result = getActivitiesByDatabase(currentState, DB_TYPES.CENTRAL);
    const expectedResult = [
      currentState.loadAndQA.activities['2-central'],
      currentState.loadAndQA.activities['18-central']
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getActivitiesByDatabase: partner', () => {
    const currentState = getStateSample();
    const result = getActivitiesByDatabase(currentState, DB_TYPES.PARTNER);
    const expectedResult = [
      currentState.loadAndQA.activities['3-WS004'],
      currentState.loadAndQA.activities['7-WS004']
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getJobsByDatabase: central', () => {
    const currentState = getStateSample();
    const result = getJobsByDatabase(currentState, DB_TYPES.CENTRAL);
    const expectedResult = currentState.loadAndQA.jobs[DB_TYPES.CENTRAL];
    expect(result).toEqual(expectedResult);
  });

  it('Should getJobsByDatabase: partner', () => {
    const currentState = getStateSample();
    const result = getJobsByDatabase(currentState, DB_TYPES.PARTNER);
    const expectedResult = currentState.loadAndQA.jobs[DB_TYPES.PARTNER];
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsPartnerJobStarting', () => {
    const currentState = getStateSample();
    const result = getIsJobStarting(currentState);
    const expectedResult = currentState.loadAndQA.isJobStarting;
    expect(result).toEqual(expectedResult);
  });
});
