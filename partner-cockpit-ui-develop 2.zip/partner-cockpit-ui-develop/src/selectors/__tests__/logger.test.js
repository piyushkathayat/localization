import {
  getLogger,
  getIsLoading,
  getIsUpdating,
  getError,
  getJson,
  getIssueIdsOptions
} from '../logger';

const getStateSample = () => ({
  logger: {
    json: [
      {
        data: {
          '@mt': 'Remediation starting for portfolio {AssetId} where profile is {ClientProfile}, SAA is {SAA_Id} {SAA_Name}',
          AssetId: 1041845,
          ClientProfile: null,
          SAA_Id: 502,
          SAA_Name: 'Prof Desk'
        }
      },
      {
        data: {
          '@mt': 'Remediation finished in {elapsedTotalSeconds}',
          elapsedTotalSeconds: 0.4360424
        }
      }
    ],
    issueIdsOptions: [
      {
        key: 0,
        text: 'Strategic Asset Allocation - -101',
        value: -101
      },
      {
        key: 1,
        text: 'Strategic Asset Allocation - -102',
        value: -102
      },
      {
        key: 2,
        text: 'Bulk Risk - 54',
        value: 54
      }
    ],
    isLoading: false,
    isUpdating: false,
    error: null
  }
});

describe('logger selector', () => {
  it('Should getLogger', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.logger;

    // when
    const result = getLogger(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.logger.isLoading;

    // when
    const result = getIsLoading(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsUpdating', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.logger.isUpdating;

    // when
    const result = getIsUpdating(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.logger.error;

    // when
    const result = getError(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getJson', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.logger.json;

    // when
    const result = getJson(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getIssueIdsOptions', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.logger.issueIdsOptions;

    // when
    const result = getIssueIdsOptions(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });
});
