import { DB_TYPES } from 'constants/serverInfo';
import {
  getServerInfo,
  getIsLoading,
  getError,
  getServerType,
  getEnvironment,
  getCurrency,
  getLoggedInUser,
  getCentralDBKey,
  getPartnerDBKey,
  getDBKeyByDBType
} from '../serverInfo';

// TODO: add layersVersions

const getStateSample = () => ({
  serverInfo: {
    serverType: 'STAGING',
    centralDBKey: 'central',
    partnerDBKey: 'WS004',
    currency: 'EUR',
    environment: 'T',
    loggedInUser: '00355799',
    isLoading: false,
    error: null
  }
});

describe('serverInfo selector', () => {
  it('Should getServerInfo', () => {
    const currentState = getStateSample();
    const result = getServerInfo(currentState);
    const expectedResult = currentState.serverInfo;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.serverInfo.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.serverInfo.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getServerType', () => {
    const currentState = getStateSample();
    const result = getServerType(currentState);
    const expectedResult = currentState.serverInfo.serverType;
    expect(result).toEqual(expectedResult);
  });

  it('Should getEnvironment', () => {
    const currentState = getStateSample();
    const result = getEnvironment(currentState);
    const expectedResult = currentState.serverInfo.environment;
    expect(result).toEqual(expectedResult);
  });

  it('Should getCurrency', () => {
    const currentState = getStateSample();
    const result = getCurrency(currentState);
    const expectedResult = currentState.serverInfo.currency;
    expect(result).toEqual(expectedResult);
  });

  it('Should getLoggedInUser', () => {
    const currentState = getStateSample();
    const result = getLoggedInUser(currentState);
    const expectedResult = currentState.serverInfo.loggedInUser;
    expect(result).toEqual(expectedResult);
  });

  it('Should getCentralDBKey', () => {
    const currentState = getStateSample();
    const result = getCentralDBKey(currentState);
    const expectedResult = currentState.serverInfo.centralDBKey;
    expect(result).toEqual(expectedResult);
  });

  it('Should getPartnerDBKey', () => {
    const currentState = getStateSample();
    const result = getPartnerDBKey(currentState);
    const expectedResult = currentState.serverInfo.partnerDBKey;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDBKeyByDBType: CENTRAL', () => {
    const currentState = getStateSample();
    const result = getDBKeyByDBType(currentState, DB_TYPES.CENTRAL);
    const expectedResult = currentState.serverInfo.centralDBKey;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDBKeyByDBType: PARTNER', () => {
    const currentState = getStateSample();
    const result = getDBKeyByDBType(currentState, DB_TYPES.PARTNER);
    const expectedResult = currentState.serverInfo.partnerDBKey;
    expect(result).toEqual(expectedResult);
  });
});
