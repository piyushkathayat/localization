import {
  getCoreEngine,
  getTablesList,
  getFilter,
  getIsLoading,
  getError,
  getFilteredTablesList
} from '../coreEngine';

const getStateSample = () => ({
  coreEngine: {
    tablesList: [
      {
        id: 0,
        tableData: [],
        tableDisplayName: 'allowed_document_language',
        tableName: 'allowed_document_language'
      },
      {
        id: 1,
        tableData: [],
        tableDisplayName: 'application',
        tableName: 'application'
      },
      {
        id: 2,
        tableData: [],
        tableDisplayName: 'cortex_extract',
        tableName: 'cortex_extract'
      }
    ],
    filter: ['cortex_extract'],
    isLoading: true,
    error: null
  }
});

describe('coreEngine selector', () => {
  it('Should getCoreEngine', () => {
    const currentState = getStateSample();
    const result = getCoreEngine(currentState);
    const expectedResult = currentState.coreEngine;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.coreEngine.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.coreEngine.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilter', () => {
    const currentState = getStateSample();
    const result = getFilter(currentState);
    const expectedResult = currentState.coreEngine.filter;
    expect(result).toEqual(expectedResult);
  });

  it('Should getTablesList', () => {
    const currentState = getStateSample();
    const result = getTablesList(currentState);
    const expectedResult = currentState.coreEngine.tablesList;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredTablesList with a filter', () => {
    const currentState = getStateSample();
    const result = getFilteredTablesList(currentState);
    const expectedResult = [currentState.coreEngine.tablesList[2]];
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredTablesList with an empty filter', () => {
    const currentState = getStateSample();
    currentState.coreEngine.filter = [];
    const result = getFilteredTablesList(currentState);
    const expectedResult = currentState.coreEngine.tablesList;
    expect(result).toEqual(expectedResult);
  });
});
