import {
  getSummary,
  getIsLoading,
  getError,
  getSummaryInfo,
  getDate,
  getFilter,
  getFilteredSummaryInfo
} from '../summary';

const getStateSample = () => ({
  summary: {
    summaryInfo: [
      {
        recNo: 7,
        type: 'DELTA_ISSUE_COUNT',
        group: 'QualityCheck',
        format: 'NUMBER',
        pctChange: 'Infinity',
        marquee: 993,
        data: []
      },
      {
        recNo: 8,
        type: 'TOTAL_ISSUE_COUNT',
        group: 'QualityCheck',
        format: 'NUMBER',
        pctChange: 0.0352184603745035,
        marquee: 27366,
        data: []
      },
      {
        recNo: 4,
        type: 'CORTEX_CLIENT_BOOK',
        group: 'Portfolio',
        format: 'NUMBER',
        pctChange: 0,
        marquee: 7550,
        data: []
      }
    ],
    date: '2018-12-14T00:00:00',
    filter: ['QualityCheck'],
    isLoading: false,
    error: null
  }
});

describe('summary selector', () => {
  it('Should getSummary', () => {
    const currentState = getStateSample();
    const result = getSummary(currentState);
    const expectedResult = currentState.summary;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.summary.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.summary.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getSummaryInfo', () => {
    const currentState = getStateSample();
    const result = getSummaryInfo(currentState);
    const expectedResult = currentState.summary.summaryInfo;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDate', () => {
    const currentState = getStateSample();
    const result = getDate(currentState);
    const expectedResult = currentState.summary.date;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilter', () => {
    const currentState = getStateSample();
    const result = getFilter(currentState);
    const expectedResult = currentState.summary.filter;
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredSummaryInfo: current filter', () => {
    const currentState = getStateSample();
    const result = getFilteredSummaryInfo(currentState);
    const expectedResult = [
      currentState.summary.summaryInfo[0],
      currentState.summary.summaryInfo[1]
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getFilteredSummaryInfo: empty filter', () => {
    const currentState = getStateSample();
    currentState.summary.filter = [];
    const result = getFilteredSummaryInfo(currentState);
    const expectedResult = currentState.summary.summaryInfo;
    expect(result).toEqual(expectedResult);
  });
});
