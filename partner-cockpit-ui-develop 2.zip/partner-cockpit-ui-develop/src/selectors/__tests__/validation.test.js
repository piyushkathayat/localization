import React from 'react';
import * as R from 'ramda';
import { DateAndTime } from 'components/common';
import {
  getValidation,
  getIsLoading,
  getError,
  getDecisions,
  getDecisionsList,
  getDecisionsListSortedByDate,
  getSelectedDecisionId,
  getSelectedDecision,
  getSelectedDecisionStatusId,
  getSelectedDecisionIsLatestLoad,
  getLatestLoadDecisionId,
  getDecisionsDates,
  getLastSuccessfulValidationDate
} from '../validation';

const getStateSample = () => ({
  validation: {
    decisions: {
      3: {
        decisionId: 3,
        date: '2018-10-19T00:00:00',
        statusId: 110,
        isLatestLoad: false
      },
      4: {
        decisionId: 4,
        date: '2018-10-23T00:00:00',
        statusId: 170,
        isLatestLoad: false
      },
      23: {
        decisionId: 23,
        date: '2018-11-28T00:00:00',
        statusId: 200,
        isLatestLoad: false
      },
      25: {
        decisionId: 25,
        date: '2018-12-06T00:00:00',
        statusId: 110,
        isLatestLoad: true
      }
    },
    selectedDecisionId: 25,
    isLoading: false,
    error: null
  }
});

describe('validation selector', () => {
  it('Should getValidation', () => {
    const currentState = getStateSample();
    const result = getValidation(currentState);
    const expectedResult = currentState.validation;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.validation.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.validation.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisions', () => {
    const currentState = getStateSample();
    const result = getDecisions(currentState);
    const expectedResult = currentState.validation.decisions;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionsList', () => {
    const currentState = getStateSample();
    const result = getDecisionsList(currentState);
    const expectedResult = R.values(currentState.validation.decisions);
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionsListSortedByDate', () => {
    const currentState = getStateSample();
    const result = getDecisionsListSortedByDate(currentState);
    const expectedResult = [
      currentState.validation.decisions['25'],
      currentState.validation.decisions['23'],
      currentState.validation.decisions['4'],
      currentState.validation.decisions['3']
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getSelectedDecisionId', () => {
    const currentState = getStateSample();
    const result = getSelectedDecisionId(currentState);
    const expectedResult = currentState.validation.selectedDecisionId;
    expect(result).toEqual(expectedResult);
  });

  it('Should getSelectedDecision', () => {
    const currentState = getStateSample();
    const result = getSelectedDecision(currentState);
    const expectedResult = currentState.validation.decisions[
      currentState.validation.selectedDecisionId
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getSelectedDecisionStatusId', () => {
    const currentState = getStateSample();
    const result = getSelectedDecisionStatusId(currentState);
    const expectedResult = currentState.validation.decisions[
      currentState.validation.selectedDecisionId
    ].statusId;
    expect(result).toEqual(expectedResult);
  });

  it('Should getSelectedDecisionIsLatestLoad', () => {
    const currentState = getStateSample();
    const result = getSelectedDecisionIsLatestLoad(currentState);
    const expectedResult = currentState.validation.decisions[
      currentState.validation.selectedDecisionId
    ].isLatestLoad;
    expect(result).toEqual(expectedResult);
  });

  it('Should getLatestLoadDecisionId', () => {
    const currentState = getStateSample();
    const result = getLatestLoadDecisionId(currentState);
    const expectedResult = 25;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionsDates', () => {
    const currentState = getStateSample();
    const result = getDecisionsDates(currentState);
    const expectedResult = [
      {
        key: 25,
        text: <DateAndTime value="2018-12-06T00:00:00" />,
        value: 25
      },
      {
        key: 23,
        text: <DateAndTime value="2018-11-28T00:00:00" />,
        value: 23
      },
      {
        key: 4,
        text: <DateAndTime value="2018-10-23T00:00:00" />,
        value: 4
      },
      {
        key: 3,
        text: <DateAndTime value="2018-10-19T00:00:00" />,
        value: 3
      }
    ];
    expect(result).toEqual(expectedResult);
  });

  it('Should getLastSuccessfulValidationDate', () => {
    const currentState = getStateSample();
    const result = getLastSuccessfulValidationDate(currentState);
    const expectedResult = '2018-11-28T00:00:00';
    expect(result).toEqual(expectedResult);
  });
});
