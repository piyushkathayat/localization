import { ACTIVITY_STATUSES } from 'constants/loadAndQA';
import {
  getLoadAndQADrilldown,
  getIsLoading,
  getError,
  getDrilldowns,
  getDbType,
  getDrilldownType,
  getActionByActivityIdAndActionId
} from '../loadAndQADrilldown';

const getStateSample = () => ({
  loadAndQADrilldown: {
    drilldowns: [
      {
        drilldownDetail: 0,
        drilldownKey: 1471,
        drilldownType: 'FILE',
        duration: 0,
        fileName: 'some_file.csv',
        filePath: '\\some_path\\some_file.zip',
        fileSize: 153992,
        hasDetail: 0,
        invalidRecordCount: 0,
        issueHistory: [],
        processedSize: 153992,
        recordCount: 1635
      },
      {
        drilldownDetail: 1,
        drilldownKey: 1471,
        drilldownType: 'FILE',
        duration: 10,
        fileName: 'another_file.csv',
        filePath: '\\some_path\\another_file.zip',
        fileSize: 2536649,
        hasDetail: 0,
        invalidRecordCount: 0,
        issueHistory: [],
        processedSize: 2536649,
        recordCount: 42436
      }
    ],
    dbType: 'CENTRAL',
    drilldownType: 'FILE',
    isLoading: false,
    error: null
  },
  loadAndQA: {
    activities: {
      '3-WS004': {
        id: '3-WS004',
        activityId: 3,
        actions: [
          {
            actionDescription: 'Check that files are available and correct ("OK files")',
            actionId: 126,
            activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
            averageDeviation: 0,
            averageDuration: 0,
            drillDownKey: '',
            drillDownType: '',
            duration: 1,
            endTime: '2018-12-06T17:48:00.633',
            issueHistory: [],
            issues: 0,
            message: '',
            percentage: 100,
            startTime: '2018-12-06T17:47:59.86',
            statusCode: 'FINISHED'
          }
        ],
        activityKey: '015c6e9e-fa29-4a36-bff4-b93c27ecda18',
        activityOwner: 'WS004',
        statusCode: ACTIVITY_STATUSES.FINISHED,
        percentage: 100
      }
    }
  }
});

describe('loadAndQADrilldown selector', () => {
  it('Should getLoadAndQADrilldown', () => {
    const currentState = getStateSample();
    const result = getLoadAndQADrilldown(currentState);
    const expectedResult = currentState.loadAndQADrilldown;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.loadAndQADrilldown.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.loadAndQADrilldown.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDrilldowns', () => {
    const currentState = getStateSample();
    const result = getDrilldowns(currentState);
    const expectedResult = currentState.loadAndQADrilldown.drilldowns;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDbType', () => {
    const currentState = getStateSample();
    const result = getDbType(currentState);
    const expectedResult = currentState.loadAndQADrilldown.dbType;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDrilldownType', () => {
    const currentState = getStateSample();
    const result = getDrilldownType(currentState);
    const expectedResult = currentState.loadAndQADrilldown.drilldownType;
    expect(result).toEqual(expectedResult);
  });

  it('Should getActionByActivityIdAndActionId', () => {
    const currentState = getStateSample();
    const result = getActionByActivityIdAndActionId(currentState, '3-WS004', 126);
    const expectedResult = currentState.loadAndQA.activities['3-WS004'].actions[0];
    expect(result).toEqual(expectedResult);
  });
});
