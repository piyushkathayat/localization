import {
  getPromotionOverview,
  getPromotionDatabases,
  getIsPromotionRunning,
  getPromotionError,
  getIsLoading,
  getLastPromotion,
  getDependencies
} from '../promotion';

// TODO: update

const getStateSample = () => ({
  promotion: {
    databases: {
      3: {
        comment: 'This database is marked for autopromotion on the Live DB.',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '00355799',
        creationDate: '2019-01-16T08:43:49.773',
        id: 3,
        internalKey: '4d0dc06e-aeb0-4465-9d71-247944179e35',
        internalName: 'Unbundling',
        isDirty: false,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'UNBUNDLING',
        source: 'NZUR18125DSQ'
      },
      4: {
        comment: 'This database is marked for autopromotion on the Live DB.',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '00355799',
        creationDate: '2019-01-16T05:00:20.783',
        id: 4,
        internalKey: 'a2384556-97f8-45ff-a15f-0642bdb66cad',
        internalName: 'BBS',
        isDirty: false,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: true,
        isUsedInLoadOnStaging: true,
        name: 'BBS',
        source: 'NZUR18125DSQ'
      },
      15: {
        comment: '',
        commentAuthor: '',
        commentDate: '',
        confirmedBy: '',
        creationDate: '2019-01-16T08:53:35.09',
        id: 15,
        internalKey: '6c7e3947-38f4-4e11-b492-ae40fb5fe730',
        internalName: 'LK',
        isDirty: false,
        isMarkedForPromotion: false,
        isOldDatabase: false,
        isPromotedToLive: false,
        isUsedInLoadOnStaging: true,
        name: 'Lookup Tables',
        source: 'NZUR18130DSQ'
      }
    },
    dependencies: [
      {
        databaseId: 3,
        dependents: [15]
      },
      {
        databaseId: 4,
        dependents: []
      },
      {
        databaseId: 15,
        dependents: []
      }
    ],
    isPromotionRunning: true,
    lastPromotionDate: '2018-10-23T16:33:21.08',
    status: null,
    error: 'some error',
    canPromote: true,
    isLoading: false,
    progress: 50
  }
});

describe('promotion selector', () => {
  it('Should getPromotionOverview', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion;

    // when
    const result = getPromotionOverview(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getPromotionDatabases', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion.databases;

    // when
    const result = getPromotionDatabases(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsPromotionRunning', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion.isPromotionRunning;

    // when
    const result = getIsPromotionRunning(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getPromotionError', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion.error;

    // when
    const result = getPromotionError(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion.isLoading;

    // when
    const result = getIsLoading(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getLastPromotion', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion.lastPromotionDate;

    // when
    const result = getLastPromotion(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getDependencies', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.promotion.dependencies;

    // when
    const result = getDependencies(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });
});
