import * as R from 'ramda';
import { PARAMETERS_STATUSES } from 'constants/parameters';
import {
  getParametersState,
  getIsLoading,
  getError,
  getParameters,
  getParametersList,
  getParameterByFeedName,
  getParameterTile
} from '../parameters';

const getStateSample = () => ({
  parameters: {
    parameters: {
      saa: {
        feedName: 'saa',
        isUpdating: true,
        checkedOutAt: '2018-08-30T15:40:57.06',
        checkedOutBy: '43395564',
        checkedInAt: '2018-08-30T15:41:04.133',
        checkedInBy: '43395564'
      },
      universe: {
        feedName: 'universe',
        checkedOutAt: '2018-12-06T10:55:12.88',
        checkedOutBy: '00355799',
        checkedInAt: null,
        checkedInBy: null,
        lastCheckedOutAt: null,
        lastCheckedOutBy: null,
        lastCheckedInAt: '2019-01-01T15:47:50.02',
        lastCheckedInBy: '43535763'
      },
      lk: {
        feedName: 'lk',
        checkedOutAt: '2018-12-17T13:09:47.49',
        checkedOutBy: '00355799',
        checkedInAt: '2018-08-10T16:58:41.787',
        checkedInBy: '00355799'
      }
    },
    isLoading: false,
    error: null
  }
});

describe('parameters selector', () => {
  it('Should getParametersState', () => {
    const currentState = getStateSample();
    const result = getParametersState(currentState);
    const expectedResult = currentState.parameters;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.parameters.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.parameters.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getParameters', () => {
    const currentState = getStateSample();
    const result = getParameters(currentState);
    const expectedResult = currentState.parameters.parameters;
    expect(result).toEqual(expectedResult);
  });

  it('Should getParametersList', () => {
    const currentState = getStateSample();
    const result = getParametersList(currentState);
    const expectedResult = R.values(currentState.parameters.parameters);
    expect(result).toEqual(expectedResult);
  });

  it('Should getParameterByFeedName', () => {
    const currentState = getStateSample();
    const result = getParameterByFeedName(currentState, 'saa');
    const expectedResult = currentState.parameters.parameters.saa;
    expect(result).toEqual(expectedResult);
  });

  it('Should getParameterTile', () => {
    const currentState = getStateSample();
    const result = getParameterTile(currentState, 'saa');
    const expectedResult = {
      feedName: 'saa',
      status: PARAMETERS_STATUSES.CHECKED_IN,
      isUpdating: true,
      lastUpdatedAt: '2018-08-30T15:41:04.133',
      lastUpdatedBy: '43395564'
    };
    expect(result).toEqual(expectedResult);
  });

  it('Should getParameterTile with lastCheckedInAt', () => {
    const currentState = getStateSample();
    const result = getParameterTile(currentState, 'universe');
    const expectedResult = {
      feedName: 'universe',
      status: PARAMETERS_STATUSES.CHECKED_IN,
      isUpdating: undefined,
      lastUpdatedAt: '2019-01-01T15:47:50.02',
      lastUpdatedBy: '43535763'
    };
    expect(result).toEqual(expectedResult);
  });
});
