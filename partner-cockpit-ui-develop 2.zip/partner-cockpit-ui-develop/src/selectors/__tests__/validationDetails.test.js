import * as R from 'ramda';
import {
  getValidationDetails,
  getIsLoading,
  getIsUpdating,
  getError,
  getApprovalStatuses,
  getDecisionLevel,
  getDecisionGroup,
  getQualityCheckName,
  getDecisionItemsIds,
  getDecisionItems,
  getDecisionItemsList
  // getSortedAndFilteredDecisionItemsList
} from '../validationDetails';

// TODO: adjust search and sorting

const getStateSample = () => ({
  validationDetails: {
    decisionItems: {
      1: {
        decisionKey: 1,
        approvalStatus: 20,
        affectedPortfolios: 3,
        displayKey: 'LU0452418154',
        displayDescription: 'ALT KEMPEN NDP F',
        commentLast: null,
        confirmedBy: null
      },
      2: {
        decisionKey: 2,
        approvalStatus: 12,
        affectedPortfolios: 5,
        displayKey: 'FR0000121964',
        displayDescription: 'A KLEPIERRE',
        commentLast: 'Some comment',
        confirmedBy: '43535763'
      }
    },
    decisionItemsIds: [1, 2],
    approvalStatuses: [20, 13, 30],
    decisionLevel: 1,
    decisionGroup: 2,
    qualityCheckName: 'Bulk Risk',
    isLoading: false,
    isUpdating: false,
    error: null
  }
});

describe('validationDetails selector', () => {
  it('Should getValidationDetails', () => {
    const currentState = getStateSample();
    const result = getValidationDetails(currentState);
    const expectedResult = currentState.validationDetails;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.validationDetails.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsUpdating', () => {
    const currentState = getStateSample();
    const result = getIsUpdating(currentState);
    const expectedResult = currentState.validationDetails.isUpdating;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.validationDetails.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getApprovalStatuses', () => {
    const currentState = getStateSample();
    const result = getApprovalStatuses(currentState);
    const expectedResult = currentState.validationDetails.approvalStatuses;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionLevel', () => {
    const currentState = getStateSample();
    const result = getDecisionLevel(currentState);
    const expectedResult = currentState.validationDetails.decisionLevel;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionGroup', () => {
    const currentState = getStateSample();
    const result = getDecisionGroup(currentState);
    const expectedResult = currentState.validationDetails.decisionGroup;
    expect(result).toEqual(expectedResult);
  });

  it('Should getQualityCheckName', () => {
    // given
    const currentState = getStateSample();
    const expectedResult = currentState.validationDetails.qualityCheckName;

    // when
    const result = getQualityCheckName(currentState);

    // then
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionItemsIds', () => {
    const currentState = getStateSample();
    const result = getDecisionItemsIds(currentState);
    const expectedResult = currentState.validationDetails.decisionItemsIds;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionItems', () => {
    const currentState = getStateSample();
    const result = getDecisionItems(currentState);
    const expectedResult = currentState.validationDetails.decisionItems;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionItemsList', () => {
    const currentState = getStateSample();
    const result = getDecisionItemsList(currentState);
    const expectedResult = R.values(currentState.validationDetails.decisionItems);
    expect(result).toEqual(expectedResult);
  });

  // it('Should getSearch', () => {
  //   const currentState = getStateSample();
  //   const result = getSearch(currentState);
  //   const expectedResult = currentState.validationDetails.search;
  //   expect(result).toEqual(expectedResult);
  // });

  // it('Should getSorting', () => {
  //   const currentState = getStateSample();
  //   const result = getSorting(currentState);
  //   const expectedResult = currentState.validationDetails.sorting;
  //   expect(result).toEqual(expectedResult);
  // });

  // it('Should getSortedAndFilteredDecisionItemsList: filtering', () => {
  //   const currentState = getStateSample();
  //   currentState.validationDetails.search = 'ALT';
  //   const result = getSortedAndFilteredDecisionItemsList(currentState);
  //   const expectedResult = [
  //     currentState.validationDetails.decisionItems['1']
  //   ];
  //   expect(result).toEqual(expectedResult);
  // });

  // it('Should getSortedAndFilteredDecisionItemsList: sorting', () => {
  //   const currentState = getStateSample();
  //   currentState.validationDetails.sorting.sortBy = 'affectedPortfolios';
  //   currentState.validationDetails.sorting.sortDirection = SORT_DIRECTIONS.DESC;
  //   const result = getSortedAndFilteredDecisionItemsList(currentState);
  //   const expectedResult = [
  //     currentState.validationDetails.decisionItems['2'],
  //     currentState.validationDetails.decisionItems['1']
  //   ];
  //   expect(result).toEqual(expectedResult);
  // });

  // it('Should getSortedAndFilteredDecisionItemsList: filtering and sorting', () => {
  //   const currentState = getStateSample();
  //   currentState.validationDetails.search = 'A';
  //   currentState.validationDetails.sorting.sortBy = 'affectedPortfolios';
  //   currentState.validationDetails.sorting.sortDirection = SORT_DIRECTIONS.DESC;
  //   const result = getSortedAndFilteredDecisionItemsList(currentState);
  //   const expectedResult = [
  //     currentState.validationDetails.decisionItems['2'],
  //     currentState.validationDetails.decisionItems['1']
  //   ];
  //   expect(result).toEqual(expectedResult);
  // });
});
