import {
  getValidationOverview,
  getIsLoading,
  getError,
  getDecisionsOverview,
  getSelectedDecisionOverview,
  getSelectedQualityChecks
} from '../validationOverview';

const getStateSample = () => ({
  validation: {
    selectedDecisionId: 23
  },
  validationOverview: {
    decisionsOverview: {
      25: {
        decisionId: 25,
        isReleaseAllowed: true,
        qualityChecks: []
      },
      23: {
        decisionId: 23,
        isReleaseAllowed: false,
        qualityChecks: [
          {
            qualityCheckType: 1,
            sortOrder: 10,
            totalIssues: 139,
            newIssues: 126,
            oldIssues: 13,
            approvals: [
              {
                distinctIssues: 139,
                approvalStatusId: 20,
                decisionRemaining: 0
              }
            ]
          },
          {
            qualityCheckType: 1048576,
            sortOrder: 11,
            totalIssues: 0,
            newIssues: 0,
            oldIssues: 0,
            approvals: [
              {
                distinctIssues: 0,
                approvalStatusId: 20,
                decisionRemaining: 0
              }
            ]
          }
        ]
      }
    },
    isLoading: false,
    error: null
  }
});

describe('validationOverview selector', () => {
  it('Should getValidationOverview', () => {
    const currentState = getStateSample();
    const result = getValidationOverview(currentState);
    const expectedResult = currentState.validationOverview;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.validationOverview.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.validationOverview.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getDecisionsOverview', () => {
    const currentState = getStateSample();
    const result = getDecisionsOverview(currentState);
    const expectedResult = currentState.validationOverview.decisionsOverview;
    expect(result).toEqual(expectedResult);
  });

  it('Should getSelectedDecisionOverview', () => {
    const currentState = getStateSample();
    const result = getSelectedDecisionOverview(currentState);
    const expectedResult = currentState.validationOverview.decisionsOverview['23'];
    expect(result).toEqual(expectedResult);
  });

  it('Should getSelectedQualityChecks', () => {
    const currentState = getStateSample();
    const result = getSelectedQualityChecks(currentState);
    const expectedResult =
      currentState.validationOverview.decisionsOverview['23'].qualityChecks;
    expect(result).toEqual(expectedResult);
  });
});
