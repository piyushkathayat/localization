import {
  getParametersUniverse,
  getIsLoading,
  getError,
  getIsUpdating,
  getInstrumentsList,
  getTotalCount,
  getIsin,
  getCurrentPage
} from '../parametersUniverse';

const getStateSample = () => ({
  parametersUniverse: {
    instrumentsList: [
      {
        location: null,
        orgUnit: null,
        isin: 'AN8068571086',
        instrumentName: 'A SCHLUMBERGER LTD.',
        tradingCurrency: 'USD',
        ranking: 3,
        provider: null,
        lastUpdate: null,
        comment: '0558902',
        buy: false
      },
      {
        location: null,
        orgUnit: null,
        isin: 'AT0000383864',
        instrumentName: 'O AUSTRIA REPUBLIC 97-27',
        tradingCurrency: 'EUR',
        ranking: 4,
        provider: null,
        lastUpdate: null,
        comment: '1024790',
        buy: false
      }
    ],
    totalCount: 1778,
    isin: 'AN',
    currentPage: 1,
    isLoading: false,
    isUpdating: false,
    error: null
  }
});

describe('parametersUniverse selector', () => {
  it('Should getParametersUniverse', () => {
    const currentState = getStateSample();
    const result = getParametersUniverse(currentState);
    const expectedResult = currentState.parametersUniverse;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsLoading', () => {
    const currentState = getStateSample();
    const result = getIsLoading(currentState);
    const expectedResult = currentState.parametersUniverse.isLoading;
    expect(result).toEqual(expectedResult);
  });

  it('Should getError', () => {
    const currentState = getStateSample();
    const result = getError(currentState);
    const expectedResult = currentState.parametersUniverse.error;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsUpdating', () => {
    const currentState = getStateSample();
    const result = getIsUpdating(currentState);
    const expectedResult = currentState.parametersUniverse.isUpdating;
    expect(result).toEqual(expectedResult);
  });

  it('Should getInstrumentsList', () => {
    const currentState = getStateSample();
    const result = getInstrumentsList(currentState);
    const expectedResult = currentState.parametersUniverse.instrumentsList;
    expect(result).toEqual(expectedResult);
  });

  it('Should getTotalCount', () => {
    const currentState = getStateSample();
    const result = getTotalCount(currentState);
    const expectedResult = currentState.parametersUniverse.totalCount;
    expect(result).toEqual(expectedResult);
  });

  it('Should getIsin', () => {
    const currentState = getStateSample();
    const result = getIsin(currentState);
    const expectedResult = currentState.parametersUniverse.isin;
    expect(result).toEqual(expectedResult);
  });

  it('Should getCurrentPage', () => {
    const currentState = getStateSample();
    const result = getCurrentPage(currentState);
    const expectedResult = currentState.parametersUniverse.currentPage;
    expect(result).toEqual(expectedResult);
  });
});
