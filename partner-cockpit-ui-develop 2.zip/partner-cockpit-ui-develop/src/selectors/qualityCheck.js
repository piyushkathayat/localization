import * as R from 'ramda';
import { createSelector } from 'reselect';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';

export const getQualityCheck = state => R.prop('qualityCheck', state);

export const getIsLoading = state => R.prop('isLoading', getQualityCheck(state));

export const getError = state => R.prop('error', getQualityCheck(state));

export const getQualityCheckList = state => R.prop('qualityCheckList', getQualityCheck(state));

export const getFilter = state => R.prop('filter', getQualityCheck(state));

export const getFilteredQualityChecks = createSelector(
  [
    getQualityCheckList,
    getFilter
  ],
  (qualityCheckList, filter) => isNonEmptyArray(filter)
    ? qualityCheckList.filter(qc => filter.includes(qc.type))
    : qualityCheckList
);
