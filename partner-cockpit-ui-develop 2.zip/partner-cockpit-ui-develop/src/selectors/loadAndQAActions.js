import * as R from 'ramda';

export const getLoadAndQAActions = state => R.prop('loadAndQAActions', state);

export const getIsLoading = state => R.prop('isLoading', getLoadAndQAActions(state));

export const getActions = state => R.prop('actions', getLoadAndQAActions(state));

export const getError = state => R.prop('error', getLoadAndQAActions(state));
