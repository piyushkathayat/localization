import * as R from 'ramda';
import { DB_TYPES } from 'constants/serverInfo';

export const getServerInfo = state => R.prop('serverInfo', state);

export const getIsLoading = state => R.prop('isLoading', getServerInfo(state));

export const getError = state => R.prop('error', getServerInfo(state));

export const getServerType = state => R.prop('serverType', getServerInfo(state));

export const getEnvironment = state => R.prop('environment', getServerInfo(state));

export const getCurrency = state => R.prop('currency', getServerInfo(state));

export const getLoggedInUser = state => R.prop('loggedInUser', getServerInfo(state));

export const getCentralDBKey = state => R.prop('centralDBKey', getServerInfo(state));

export const getPartnerDBKey = state => R.prop('partnerDBKey', getServerInfo(state));

export const getDBKeyByDBType = (state, dbType) => {
  switch (dbType) {
    case DB_TYPES.CENTRAL:
      return getCentralDBKey(state);
    case DB_TYPES.PARTNER:
      return getPartnerDBKey(state);
    default:
      return null;
  }
};

export const getLayersInfo = state => R.prop('layersInfo', getServerInfo(state));

export const getLayerVersion = (state, layerName) => R.pathOr(
  'UNKNOWN',
  [layerName, 'version'],
  getLayersInfo(state)
);

export const getLayersVersions = state => R.mapObjIndexed(
  (val, layerName) => getLayerVersion(state, layerName),
  {
    database: '',
    cockpitService: '',
    gatewayService: '',
    ui: ''
  }
);

export const getFeatures = state => R.prop('features', getServerInfo(state));

export const getFeatureByName = (state, featureName) => R.prop(featureName, getFeatures(state));

export const getIsFeatureEnabled = (state, featureName) => R.prop(
  'enabled',
  getFeatureByName(state, featureName)
);
