import * as R from 'ramda';
import { createSelector } from 'reselect';
import { SORT_DIRECTIONS } from 'constants/common';
import { SEARCHABLE_FIELDS } from 'constants/validation';
import { getSearch, getSorting } from 'selectors/validation';

const searchDetails = search => detailsList => search.length
  ? R.filter(
    detail => R.any(
      field => detail[field] && detail[field].toLowerCase().includes(search),
      SEARCHABLE_FIELDS
    ),
    detailsList
  )
  : detailsList;

const sortDetails = ({ sortBy, sortDirection }) => detailsList => {
  if (!sortBy.length) {
    return detailsList;
  }
  const sorting = sortDirection === SORT_DIRECTIONS.ASC
    ? R.ascend
    : R.descend;
  return R.sort(
    sorting(R.prop(sortBy)),
    detailsList
  );
};

export const getValidationDetails = state => R.prop('validationDetails', state);

export const getIsLoading = state => R.prop('isLoading', getValidationDetails(state));

export const getIsUpdating = state => R.prop('isUpdating', getValidationDetails(state));

export const getError = state => R.prop('error', getValidationDetails(state));

export const getApprovalStatuses = state => R.prop('approvalStatuses', getValidationDetails(state));

export const getDecisionLevel = state => R.prop('decisionLevel', getValidationDetails(state));

export const getDecisionGroup = state => R.prop('decisionGroup', getValidationDetails(state));

export const getQualityCheckName = state => R.prop('qualityCheckName', getValidationDetails(state));

export const getDecisionItemsIds = state => R.prop('decisionItemsIds', getValidationDetails(state));

export const getDecisionItems = state => R.prop('decisionItems', getValidationDetails(state));

export const getDecisionItemsList = state => R.values(getDecisionItems(state));

export const getSortedAndFilteredDecisionItemsList = createSelector(
  [getDecisionItemsList, getSearch, getSorting],
  (decisionItemsList, search, sorting) => R.compose(
    sortDetails(sorting),
    searchDetails(search.toLowerCase())
  )(decisionItemsList)
);
