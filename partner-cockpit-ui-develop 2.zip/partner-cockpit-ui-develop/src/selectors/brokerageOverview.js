import * as R from 'ramda';

export const getBrokerageOverview = state => R.prop('brokerageOverview', state);

export const getIsLoading = state => R.prop('isLoading', getBrokerageOverview(state));

export const getIsFinalizing = state => R.prop('isFinalizing', getBrokerageOverview(state));

export const getError = state => R.prop('error', getBrokerageOverview(state));

export const getTriggerThemes = state => R.prop('triggerThemes', getBrokerageOverview(state));

export const getTriggerThemesList = state => R.values(getTriggerThemes(state));

export const getTriggerThemeById = (state, triggerThemeId) =>
  R.prop(triggerThemeId, getTriggerThemes(state));
