import * as R from 'ramda';
import { createSelector } from 'reselect';
import { isNonEmptyArray } from '@ubs.partner/shared-ui';

export const getCoreEngine = state => R.prop('coreEngine', state);

export const getTablesList = state => R.prop('tablesList', getCoreEngine(state));

export const getFilter = state => R.prop('filter', getCoreEngine(state));

export const getIsLoading = state => R.prop('isLoading', getCoreEngine(state));

export const getError = state => R.prop('error', getCoreEngine(state));

export const getFilteredTablesList = createSelector(
  [
    getTablesList,
    getFilter
  ],
  (tablesList, filter) => isNonEmptyArray(filter)
    ? tablesList.filter(table => filter.includes(table.tableName))
    : tablesList
);
