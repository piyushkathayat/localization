import * as R from 'ramda';

export const getParametersUniverse = state => R.prop('parametersUniverse', state);

export const getIsLoading = state => R.prop('isLoading', getParametersUniverse(state));

export const getIsUpdating = state => R.prop('isUpdating', getParametersUniverse(state));

export const getError = state => R.prop('error', getParametersUniverse(state));

export const getInstrumentsList = state => R.prop('instrumentsList', getParametersUniverse(state));

export const getTotalCount = state => R.prop('totalCount', getParametersUniverse(state));

export const getIsin = state => R.prop('isin', getParametersUniverse(state));

export const getCurrentPage = state => R.prop('currentPage', getParametersUniverse(state));
