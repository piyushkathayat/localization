import * as R from 'ramda';
import { getDBKeyByDBType } from 'selectors/serverInfo';

export const getLoadAndQA = state => R.prop('loadAndQA', state);

export const getIsLoading = state => R.prop('isLoading', getLoadAndQA(state));

export const getActivities = state => R.prop('activities', getLoadAndQA(state));

export const getActivitiesIds = state => R.prop('activitiesIds', getLoadAndQA(state));

export const getActivitiesList = state => {
  const activities = getActivities(state);
  return R.map(
    id => activities[id],
    getActivitiesIds(state)
  );
};

export const getJobs = state => R.prop('jobs', getLoadAndQA(state));

export const getError = state => R.prop('error', getLoadAndQA(state));

export const getActivitiesByDatabase = (state, dbType) => R.values(
  R.filter(
    activity => R.propEq(
      'activityOwner',
      getDBKeyByDBType(state, dbType),
      activity
    ),
    getActivitiesList(state)
  )
);

export const getJobsByDatabase = (state, database) =>
  R.pathOr([], [database], getJobs(state));

export const getActivityById = (state, id) => R.prop(
  id,
  getActivities(state)
);

export const getIsJobStarting = state => R.prop('isJobStarting', getLoadAndQA(state));
