import React from 'react';
import * as R from 'ramda';
import { Route, Switch, Redirect } from 'react-router-dom';
import { MENU_CONFIGURATION, MENU_ITEMS, VALIDATION_ITEMS } from 'constants/menu';
import { APP_PREFIX } from 'constants/common';
import { VALIDATION_COMPONENTS } from 'constants/validation';
import QualityChecks from 'containers/QualityCheck';
import Validation from 'containers/Validation';
import Promotion from 'containers/Promotion';
import Summary from 'containers/Summary';
import LoadAndQA from 'containers/LoadAndQA';
import Parameters from 'containers/Parameters';
import Logger from 'containers/Logger';

export default function Routes(props) {
  const { serverType } = props;

  const resolveDefaultPath = () => R.propOr(
    MENU_ITEMS.SUMMARY,
    'defaultPath',
    MENU_CONFIGURATION[serverType]
  );

  return (
    <Switch>
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.SUMMARY}`} component={Summary} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.LOAD}`} component={LoadAndQA} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id`} component={LoadAndQA} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.LOAD}/:id/:drilldownType/:drilldownKey`} component={LoadAndQA} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.QUALITY_CHECK}`} component={QualityChecks} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/`} render={() => <Redirect to={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`} />} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}`} render={() => <Validation activeComponent={VALIDATION_COMPONENTS.QUALITY_CHECKS_OVERVIEW} />} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.QUALITY_CHECKS}/:decisionId/:qualityCheckType`} render={() => <Validation activeComponent={VALIDATION_COMPONENTS.QUALITY_CHECKS_DETAILS} />} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}`} render={() => <Validation activeComponent={VALIDATION_COMPONENTS.BROKERAGE_OVERVIEW} />} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.VALIDATION}/${VALIDATION_ITEMS.BROKERAGE}/:triggerThemeId`} render={() => <Validation activeComponent={VALIDATION_COMPONENTS.BROKERAGE_DETAILS} />} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.PROMOTION}`} component={Promotion} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}`} component={Parameters} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.PARAMETERS}/:feedName`} component={Parameters} />
      <Route exact path={`/${APP_PREFIX}/${MENU_ITEMS.LOGGER}`} component={Logger} />
      <Route render={() => <Redirect to={`/${APP_PREFIX}/${resolveDefaultPath()}`} />} />
    </Switch>
  );
}
