const path = require('path');

module.exports = {
  resolve: {
    modules: ['node_modules', path.resolve(__dirname, '../src')],
  },
  module: {
    rules: [{
      test: /\.less$/,
      loaders: ["style-loader", "css-loader", "less-loader"],
      include: path.resolve(__dirname, '../')
    }, {
      test: /\.css$/,
      loaders: ["style-loader", "css-loader"],
      include: path.resolve(__dirname, '../')
    }, {
      test: /\.(png|jpg|gif|eot|otf|svg|ttf|woff|woff2)$/,
      use: [
        {
          loader: 'file-loader',
        }
      ]
    }]
  }
}
