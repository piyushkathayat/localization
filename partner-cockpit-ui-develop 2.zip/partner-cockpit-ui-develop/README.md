# partner-cockpit-ui
Partner Data Management Dashboard

##Supported functions
1. configuration of data sources delivered to Stagging and Central
2. management and monitoring of data loading processes
3. Quality overview of data delivery

