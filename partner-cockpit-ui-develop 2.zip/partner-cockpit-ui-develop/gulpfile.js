const gulp = require('gulp');
const less = require('gulp-less');
const path = require('path');
const runSequence = require('run-sequence');
const injectFont = require('gulp-injectfont');
const rename = require('gulp-rename');
const replace = require('gulp-replace');
const inject = require('gulp-inject');
require('dotenv').config();

/* Get the theme from Env */
const themeName = process.env.THEME_NAME;

gulp.task('build-theme', () => {
  return gulp.src('src/themes/themeIndex.less')
    .pipe(inject(gulp.src(['src/themes/themeIndex.less']), {
      starttag: '/* insertTheme */',
      transform: () => {
        return `@import './workbench_${themeName}/${themeName}.less';`;
      },
      endtag: '/* endInsertTheme */'
    }))
    .pipe(gulp.dest('./src/themes'));
});

gulp.task('build', () => {
  runSequence('build-fonts', 'build-css');
});

gulp.task('watch', () => {
  runSequence('watch-css')
});

gulp.task('build-css', () => {
  return gulp.src(['src/**/*.less', 'src/*.less', '!src/resources/semantic/**'])
    .pipe(less())
    .pipe(gulp.dest('src/'));
});

gulp.task('watch-css', () => {
  gulp.watch('src/**/*.less', ['build-css'])
});

gulp.task('build-fonts', () => {
  return gulp.src(['src/assets/fonts/**/*.{eot,woff}'])
    .pipe(injectFont())
    .pipe(replace(/(font-family:)(.*)(;)/gi, (match) => {
      
      if(/Ergosign/gi.test(match)) return match;

      match = match.replace(/(font-family:)/gi, '');
      match = match.replace(/-/gi, ' ');
      match = match.replace(/(font)(\s)(woff|ttf|svg)/gi, '$1-$3');
      match = ['font-family: ', match, ';'].join('');

      return match;
    }))
    .pipe(rename({
      extname: '.less'
    }))
    .pipe(gulp.dest('src/assets/css/fonts/'))
});
